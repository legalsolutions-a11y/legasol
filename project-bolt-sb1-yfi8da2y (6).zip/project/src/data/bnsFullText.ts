export interface BnsTextEntry {
  section: string;
  actReference: string;
  excerpt: string;
}

export const bnsFullText: BnsTextEntry[] = [
  {
    section: '63',
    actReference: 'BNS 2023, Section 63',
    excerpt:
      'A man is said to commit "rape" if he penetrates his penis, to any extent, into the vagina, mouth, urethra or anus of a woman or makes her do so with him or any other person; or inserts, to any extent, any object or a part of the body, not being the penis, into the vagina, the urethra or anus of a woman or makes her do so with him or any other person; or manipulates any part of the body of a woman so as to cause penetration into the vagina, urethra, anus or any part of body of such woman; or applies his mouth to the vagina, anus, urethra of a woman, under the circumstances falling under any of the following: against her will; without her consent; with her consent when her consent has been obtained by putting her or any person in whom she is interested, in fear of death or of hurt; with or without her consent, when she is under eighteen years of age; when she is unable to communicate consent.',
  },
  {
    section: '103',
    actReference: 'BNS 2023, Section 103',
    excerpt:
      'Whoever commits murder shall be punished with death or imprisonment for life, and shall also be liable to fine. When a group of five or more persons acting in concert commits murder on the ground of race, caste or community, sex, place of birth, language, personal belief or any other similar ground each member of such group shall be punished with death or with imprisonment for life.',
  },
  {
    section: '103(2)',
    actReference: 'BNS 2023, Section 103(2)',
    excerpt:
      'Whoever, being under sentence of imprisonment for life, commits murder, shall be punished with death or with imprisonment for life, which shall mean the remainder of that person\u2019s natural life.',
  },
  {
    section: '111',
    actReference: 'BNS 2023, Section 111',
    excerpt:
      'Any continuing unlawful activity including kidnapping, robbery, vehicle theft, extortion, land grabbing, contract killing, economic offence, cyber-crimes, trafficking of persons, drugs, weapons or illicit goods or services, human trafficking for prostitution or ransom, by any person or a group of persons acting in concert, singly or jointly, either as a member of an organised crime syndicate or on behalf of such syndicate, by use of violence, threat of violence, intimidation, coercion, or by any other unlawful means to obtain direct or indirect material benefit including a financial benefit, shall constitute organised crime.',
  },
  {
    section: '109',
    actReference: 'BNS 2023, Section 109',
    excerpt:
      'Whoever does any act with such intention or knowledge, and under such circumstances that, if he by that act caused death, he would be guilty of murder, shall be punished with imprisonment of either description for a term which may extend to ten years, and shall also be liable to fine; and if hurt is caused to any person by such act, the offender shall be liable either to imprisonment for life, or to such punishment as is hereinbefore mentioned.',
  },
  {
    section: '61',
    actReference: 'BNS 2023, Section 61',
    excerpt:
      'When two or more persons agree with the common object to do, or cause to be done, an illegal act; or an act which is not illegal by illegal means, such an agreement is designated a criminal conspiracy. Whoever is a party to a criminal conspiracy to commit an offence punishable with death, imprisonment for life or rigorous imprisonment for a term of two years or upwards shall, where no express provision is made, be punished in the same manner as if he had abetted such offence.',
  },
  {
    section: '117',
    actReference: 'BNS 2023, Section 117',
    excerpt:
      'Whoever voluntarily causes hurt, if the hurt which he intends to cause or knows himself to be likely to cause is grievous hurt, and if the hurt which he causes is grievous hurt, is said "voluntarily to cause grievous hurt". Whoever voluntarily causes grievous hurt shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.',
  },
  {
    section: '118',
    actReference: 'BNS 2023, Section 118',
    excerpt:
      'Whoever voluntarily causes hurt by means of any instrument for shooting, stabbing or cutting, or any instrument which, used as a weapon of offence, is likely to cause death, or by means of fire or any heated substance, or by means of any poison or any corrosive substance, or by means of any explosive substance, shall be punished with imprisonment of either description for a term which may extend to three years. Whoever voluntarily causes grievous hurt by any such means shall be punished with imprisonment for life, or with imprisonment of either description for a term which shall not be less than one year but which may extend to ten years.',
  },
  {
    section: '115',
    actReference: 'BNS 2023, Section 115',
    excerpt:
      'Whoever does any act with the intention of thereby causing hurt to any person, or with the knowledge that he is likely thereby to cause hurt to any person, and does thereby cause hurt to any person, is said "voluntarily to cause hurt". Whoever voluntarily causes hurt shall be punished with imprisonment of either description for a term which may extend to one year, or with fine which may extend to ten thousand rupees, or with both.',
  },
  {
    section: '126',
    actReference: 'BNS 2023, Section 126',
    excerpt:
      'Whoever wrongfully restrains any person in such a manner as to prevent that person from proceeding beyond certain circumscribing limits, is said "wrongfully to confine" that person. Whoever wrongfully confines any person shall be punished with imprisonment of either description for a term which may extend to one year, or with fine which may extend to five thousand rupees, or with both.',
  },
  {
    section: '74',
    actReference: 'BNS 2023, Section 74',
    excerpt:
      'Whoever assaults or uses criminal force to any woman, intending to outrage or knowing it to be likely that he will thereby outrage her modesty, shall be punished with imprisonment of either description for a term which shall not be less than one year but which may extend to five years, and shall also be liable to fine.',
  },
  {
    section: '75',
    actReference: 'BNS 2023, Section 75',
    excerpt:
      'A man committing any of the following acts: physical contact and advances involving unwelcome and explicit sexual overtures; or a demand or request for sexual favours; or showing pornography against the will of a woman; or making sexually coloured remarks, shall be guilty of the offence of sexual harassment.',
  },
  {
    section: '79',
    actReference: 'BNS 2023, Section 79',
    excerpt:
      'Whoever, intending to insult the modesty of any woman, utters any words, makes any sound or gesture, or exhibits any object in any form, intending that such word or sound shall be heard, or that such gesture or object shall be seen, by such woman, or intrudes upon the privacy of such woman, shall be punished with simple imprisonment for a term which may extend to three years, and also with fine.',
  },
  {
    section: '318',
    actReference: 'BNS 2023, Section 318',
    excerpt:
      'Whoever, intending to take dishonestly any movable property out of the possession of any person without that person\u2019s consent, moves that property in order to such taking, is said to commit theft. Whoever commits theft shall be punished with imprisonment of either description for a term which may extend to three years, or with fine, or with both.',
  },
  {
    section: '319',
    actReference: 'BNS 2023, Section 319',
    excerpt:
      'Theft is snatching if, in order to commit theft, the offender suddenly or quickly or forcibly seizes or secures or grabs or takes away from any person or from his possession any movable property. Whoever commits snatching, shall be punished with imprisonment of either description for a term which may extend to three years, and shall also be liable to fine.',
  },
  {
    section: '330',
    actReference: 'BNS 2023, Section 330',
    excerpt:
      'In all robbery there is either theft or extortion. Theft is robbery if, in order to the committing of the theft, or in committing the theft, or in carrying away or attempting to carry away property obtained by the theft, the offender, for that end voluntarily causes or attempts to cause to any person death or hurt or wrongful restraint, or fear of instant death or of instant hurt, or of instant wrongful restraint. Whoever commits robbery shall be punished with rigorous imprisonment for a term which may extend to ten years, and shall also be liable to fine.',
  },
  {
    section: '333',
    actReference: 'BNS 2023, Section 333',
    excerpt:
      'When five or more persons conjointly commit or attempt to commit a robbery, or where the whole number of persons conjointly committing or attempting to commit a robbery, and persons present and aiding such commission or attempt, amount to five or more, every person so committing, attempting or aiding, is said to commit dacoity. Whoever commits dacoity shall be punished with imprisonment for life, or with rigorous imprisonment for a term which may extend to ten years, and shall also be liable to fine.',
  },
  {
    section: '339',
    actReference: 'BNS 2023, Section 339',
    excerpt:
      'Whoever, being in any manner entrusted with property, or with any dominion over property, dishonestly misappropriates or converts to his own use that property, or dishonestly uses or disposes of that property in violation of any direction of law prescribing the mode in which such trust is to be discharged, or of any legal contract, express or implied, which he has made touching the discharge of such trust, or wilfully suffers any other person so to do, commits criminal breach of trust.',
  },
  {
    section: '346',
    actReference: 'BNS 2023, Section 346',
    excerpt:
      'Whoever, by deceiving any person, fraudulently or dishonestly induces the person so deceived to deliver any property to any person, or to consent that any person shall retain any property, or intentionally induces the person so deceived to do or omit to do anything which he would not do or omit if he were not so deceived, and which act or omission causes or is likely to cause damage or harm to that person in body, mind, reputation or property, is said to cheat.',
  },
  {
    section: '318(4)',
    actReference: 'BNS 2023, Section 318(4)',
    excerpt:
      'Whoever cheats and thereby dishonestly induces the person deceived to deliver any property to any person, or to make, alter or destroy the whole or any part of a valuable security, or anything which is signed or sealed, and which is capable of being converted into a valuable security, shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.',
  },
  {
    section: '111(5)',
    actReference: 'BNS 2023, Section 111(5)',
    excerpt:
      'Whoever uses criminal force to another person intending to commit an offence or knowing it likely to cause injury, fear or annoyance to the person to whom the force is used.',
  },
  {
    section: '351',
    actReference: 'BNS 2023, Section 351',
    excerpt:
      'Whoever threatens another by any means, with any injury to his person, reputation or property, or to the person or reputation of any one in whom that person is interested, with intent to cause alarm to that person, or to cause that person to do any act which he is not legally bound to do, or to omit to do any act which that person is legally entitled to do, as the means of avoiding the execution of such threat, commits criminal intimidation.',
  },
  {
    section: '352',
    actReference: 'BNS 2023, Section 352',
    excerpt:
      'Whoever intentionally insults in any manner, and thereby gives provocation to any person, intending or knowing it to be likely that such provocation will cause him to break the public peace, or to commit any other offence, shall be punished with imprisonment of either description for a term which may extend to two years, or with fine, or with both.',
  },
  {
    section: '324',
    actReference: 'BNS 2023, Section 324',
    excerpt:
      'Whoever with intent to cause, or knowing that he is likely to cause, wrongful loss or damage to the public or to any person, causes the destruction of any property, or any such change in any property or in the situation thereof as destroys or diminishes its value or utility, or affects it injuriously, commits mischief.',
  },
  {
    section: '325',
    actReference: 'BNS 2023, Section 325',
    excerpt:
      'Whoever commits mischief by fire or any explosive substance intending to cause, or knowing it to be likely that he will thereby cause, damage to any property including agricultural produce, shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.',
  },
  {
    section: '308',
    actReference: 'BNS 2023, Section 308',
    excerpt:
      'Whoever intentionally puts any person in fear of any injury to that person, or to any other, and thereby dishonestly induces the person so put in fear to deliver to any person any property, or valuable security or anything signed or sealed which may be converted into a valuable security, commits extortion. Whoever commits extortion shall be punished with imprisonment of either description for a term which may extend to seven years, or with fine, or with both.',
  },
  {
    section: '309',
    actReference: 'BNS 2023, Section 309',
    excerpt:
      'Whoever, in order to the committing of extortion, puts or attempts to put any person in fear of an accusation, against that person or any other, of having committed, or attempted to commit, an offence punishable with death or with imprisonment for life, or with imprisonment for a term which may extend to ten years, shall be punished with imprisonment of either description for a term which may extend to ten years, and shall also be liable to fine.',
  },
  {
    section: '239',
    actReference: 'BNS 2023, Section 239',
    excerpt:
      'Whoever, knowing or having reason to believe that an offence has been committed, intentionally omits to give any information respecting that offence which he is legally bound to give, shall be punished with imprisonment of either description for a term which may extend to six months, or with fine which may extend to five thousand rupees, or with both.',
  },
  {
    section: '223',
    actReference: 'BNS 2023, Section 223',
    excerpt:
      'Whoever, knowing that, by an order promulgated by a public servant lawfully empowered to promulgate such order, he is directed to abstain from a certain act, or to take certain order with certain property in his possession or under his management, disobeys such direction, shall, if such disobedience causes or tends to cause obstruction, annoyance or injury, or risk of obstruction, annoyance or injury, to any person lawfully employed, be punished with simple imprisonment for a term which may extend to six months.',
  },
  {
    section: '356',
    actReference: 'BNS 2023, Section 356',
    excerpt:
      'Whoever, by words either spoken or intended to be read, or by signs or by visible representations, makes or publishes in any manner, any imputation concerning any person intending to harm, or knowing or having reason to believe that such imputation will harm, the reputation of such person, is said to defame that person.',
  },
  {
    section: '329',
    actReference: 'BNS 2023, Section 329',
    excerpt:
      'Whoever enters into or upon property in the possession of another with intent to commit an offence or to intimidate, insult or annoy any person in possession of such property or having lawfully entered into or upon such property, unlawfully remains there with intent thereby to intimidate, insult or annoy any such person or with intent to commit an offence is said to commit criminal trespass.',
  },
  {
    section: '330(4)',
    actReference: 'BNS 2023, Section 330(4)',
    excerpt:
      'Whoever, while committing robbery or dacoity, uses any deadly weapon, or causes grievous hurt to any person, or attempts to cause death or grievous hurt to any person, the imprisonment with which such offender shall be punished shall not be less than seven years.',
  },
  {
    section: '113',
    actReference: 'BNS 2023, Section 113',
    excerpt:
      'Whoever does any act with the intent to threaten or likely to threaten the unity, integrity, sovereignty, security, or economic security of India or with the intent to strike terror or likely to strike terror in the people or any section of the people in India or in any foreign country, by using bombs, dynamite or other explosive substance or inflammable substance or firearms or other lethal weapons or poisonous or noxious gases or other chemicals, commits a terrorist act.',
  },
  {
    section: '69',
    actReference: 'BNS 2023, Section 69',
    excerpt:
      'Whoever, by deceitful means or by making promise to marry to a woman without any intention of fulfilling the same, has sexual intercourse with her, such sexual intercourse not amounting to the offence of rape, shall be punished with imprisonment of either description for a term which may extend to ten years and shall also be liable to fine.',
  },
  {
    section: '318(5)',
    actReference: 'BNS 2023, Section 318(5)',
    excerpt:
      'Whoever dishonestly misappropriates or converts to his own use any movable property, shall be punished with imprisonment of either description for a term which shall not be less than six months but which may extend to two years and with fine.',
  },
  {
    section: '238',
    actReference: 'BNS 2023, Section 238',
    excerpt:
      'Whoever, knowing or having reason to believe that an offence has been committed, causes any evidence of the commission of that offence to disappear, with the intention of screening the offender from legal punishment, or with that intention gives any information respecting the offence which he knows or believes to be false.',
  },
];

export function getBnsTextBySection(section: string): BnsTextEntry | undefined {
  return bnsFullText.find((e) => e.section === section);
}
