export interface BnsSection {
  id: string;
  code: string;
  title: string;
  description: string;
  punishment: string;
  fine: string;
  bail: string;
  cognizable: string;
  court: string;
  intent: string;
}

export interface CrimeCategory {
  id: string;
  label: string;
  description: string;
  icon: string;
  sections: BnsSection[];
}

export const crimeCategories: CrimeCategory[] = [
  {
    id: 'murder',
    label: 'Murder & Culpable Homicide',
    description: 'Unlawful killing of another person, with or without intent.',
    icon: 'Skull',
    sections: [
      {
        id: 'bns-101-1',
        code: 'BNS §101(1)',
        title: 'Murder',
        description: 'Whoever causes death with the intention of causing death, or with the intention of causing bodily injury known to be likely to cause death.',
        punishment: 'Death, or imprisonment for life',
        fine: 'Fine may also be imposed',
        bail: 'Not eligible for bail (non-bailable)',
        cognizable: 'cognizable',
        court: 'Court of Session',
        intent: 'intentional',
      },
      {
        id: 'bns-105',
        code: 'BNS §105',
        title: 'Culpable Homicide by Provocation',
        description: 'Whoever causes death by grave and sudden provocation given by the deceased.',
        punishment: 'Imprisonment up to 10 years',
        fine: 'Fine may also be imposed',
        bail: 'Non-bailable',
        cognizable: 'cognizable',
        court: 'Court of Session',
        intent: 'intentional',
      },
      {
        id: 'bns-106',
        code: 'BNS §106',
        title: 'Causing Death by Negligence',
        description: 'Whoever causes death by doing any rash or negligent act, not amounting to culpable homicide.',
        punishment: 'Imprisonment up to 5 years',
        fine: 'Fine up to ₹5,00,000',
        bail: 'Bailable',
        cognizable: 'cognizable',
        court: 'Magistrate Court',
        intent: 'accidental',
      },
    ],
  },
  {
    id: 'assault',
    label: 'Assault & Grievous Hurt',
    description: 'Intentionally or recklessly causing physical injury to another.',
    icon: 'HeartPulse',
    sections: [
      {
        id: 'bns-117-1',
        code: 'BNS §117(1)',
        title: 'Voluntarily Causing Grievous Hurt',
        description: 'Whoever voluntarily causes grievous hurt by means of any instrument, shooting, stabbing, or poisoning.',
        punishment: 'Imprisonment up to 7 years',
        fine: 'Fine may also be imposed',
        bail: 'Non-bailable',
        cognizable: 'cognizable',
        court: 'Court of Session',
        intent: 'intentional',
      },
      {
        id: 'bns-118',
        code: 'BNS §118',
        title: 'Assault on Grave Provocation',
        description: 'Whoever assaults another on grave and sudden provocation, causing hurt.',
        punishment: 'Imprisonment up to 3 years',
        fine: 'Fine up to ₹10,000',
        bail: 'Bailable',
        cognizable: 'cognizable',
        court: 'Magistrate Court',
        intent: 'intentional',
      },
      {
        id: 'bns-124',
        code: 'BNS §124',
        title: 'Causing Hurt by Rash or Negligent Act',
        description: 'Whoever causes hurt to any person by doing any rash or negligent act.',
        punishment: 'Imprisonment up to 1 year',
        fine: 'Fine up to ₹5,000',
        bail: 'Bailable',
        cognizable: 'non-cognizable',
        court: 'Magistrate Court',
        intent: 'accidental',
      },
    ],
  },
  {
    id: 'theft',
    label: 'Theft & Robbery',
    description: 'Taking property belonging to another, with or without force.',
    icon: 'PackageOpen',
    sections: [
      {
        id: 'bns-303-2',
        code: 'BNS §303(2)',
        title: 'Theft in a Dwelling House',
        description: 'Whoever commits theft in any building, tent, or vessel used as a dwelling, or for the custody of property.',
        punishment: 'Imprisonment up to 7 years',
        fine: 'Fine may also be imposed',
        bail: 'Non-bailable',
        cognizable: 'cognizable',
        court: 'Magistrate Court',
        intent: 'intentional',
      },
      {
        id: 'bns-303-1',
        code: 'BNS §303(1)',
        title: 'Theft',
        description: 'Whoever, intending to take dishonestly any movable property, moves it to take it out of possession of any person without consent.',
        punishment: 'Imprisonment up to 3 years',
        fine: 'Fine may also be imposed',
        bail: 'Bailable',
        cognizable: 'non-cognizable',
        court: 'Magistrate Court',
        intent: 'intentional',
      },
      {
        id: 'bns-310',
        code: 'BNS §310',
        title: 'Robbery',
        description: 'When theft is accompanied by violence, or fear of instant death, hurt, or wrongful restraint.',
        punishment: 'Imprisonment up to 10 years',
        fine: 'Fine may also be imposed',
        bail: 'Non-bailable',
        cognizable: 'cognizable',
        court: 'Court of Session',
        intent: 'intentional',
      },
    ],
  },
  {
    id: 'kidnapping',
    label: 'Kidnapping & Abduction',
    description: "Taking or enticing a person away against their will or guardian's consent.",
    icon: 'UserX',
    sections: [
      {
        id: 'bns-137-1',
        code: 'BNS §137(1)',
        title: 'Kidnapping for Ransom',
        description: 'Whoever kidnaps or abducts any person with the intention of holding for ransom or to compel action by the government.',
        punishment: 'Imprisonment up to 7 years',
        fine: 'Fine may also be imposed',
        bail: 'Non-bailable',
        cognizable: 'cognizable',
        court: 'Court of Session',
        intent: 'intentional',
      },
      {
        id: 'bns-137-2',
        code: 'BNS §137(2)',
        title: 'Kidnapping a Minor',
        description: 'Whoever takes or entices a minor under 16 (male) or 18 (female) from lawful guardianship without consent.',
        punishment: 'Imprisonment up to 7 years',
        fine: 'Fine up to ₹50,000',
        bail: 'Non-bailable',
        cognizable: 'cognizable',
        court: 'Magistrate Court',
        intent: 'intentional',
      },
      {
        id: 'bns-138',
        code: 'BNS §138',
        title: 'Abduction to Compel Marriage',
        description: 'Whoever abducts any person to compel marriage, or to subject them to grievous hurt or slavery.',
        punishment: 'Imprisonment up to 10 years',
        fine: 'Fine may also be imposed',
        bail: 'Non-bailable',
        cognizable: 'cognizable',
        court: 'Court of Session',
        intent: 'intentional',
      },
    ],
  },
  {
    id: 'fraud',
    label: 'Cheating & Fraud',
    description: 'Deceiving another person to dishonestly induce delivery of property.',
    icon: 'FileWarning',
    sections: [
      {
        id: 'bns-318-1',
        code: 'BNS §318(1)',
        title: 'Cheating',
        description: 'Whoever cheats any person and thereby dishonestly induces the person deceived to deliver property or consent to retain it.',
        punishment: 'Imprisonment up to 3 years',
        fine: 'Fine up to ₹25,000',
        bail: 'Bailable',
        cognizable: 'non-cognizable',
        court: 'Magistrate Court',
        intent: 'intentional',
      },
      {
        id: 'bns-318-2',
        code: 'BNS §318(2)',
        title: 'Cheating by Personation',
        description: 'Whoever cheats by personation, pretending to be some other person.',
        punishment: 'Imprisonment up to 3 years',
        fine: 'Fine up to ₹25,000',
        bail: 'Bailable',
        cognizable: 'cognizable',
        court: 'Magistrate Court',
        intent: 'intentional',
      },
      {
        id: 'bns-318-3',
        code: 'BNS §318(3)',
        title: 'Cheating to Deprive of Property',
        description: 'Whoever cheats and thereby dishonestly induces the person deceived to deliver or part with property with intent to cause wrongful loss.',
        punishment: 'Imprisonment up to 7 years',
        fine: 'Fine may also be imposed',
        bail: 'Non-bailable',
        cognizable: 'cognizable',
        court: 'Court of Session',
        intent: 'intentional',
      },
    ],
  },
  {
    id: 'defamation',
    label: 'Defamation',
    description: 'Harming the reputation of another by making false imputations.',
    icon: 'MessageSquareWarning',
    sections: [
      {
        id: 'bns-356-1',
        code: 'BNS §356(1)',
        title: 'Defamation',
        description: 'Whoever by words, signs, or visible imputations harms the reputation of another person.',
        punishment: 'Simple imprisonment up to 6 months',
        fine: 'Fine up to ₹50,000',
        bail: 'Bailable',
        cognizable: 'non-cognizable',
        court: 'Magistrate Court',
        intent: 'intentional',
      },
      {
        id: 'bns-356-2',
        code: 'BNS §356(2)',
        title: 'Defamation by Negligent Publication',
        description: "Whoever negligently publishes content that harms another's reputation without verifying its truth.",
        punishment: 'Imprisonment up to 1 month',
        fine: 'Fine up to ₹5,000',
        bail: 'Bailable',
        cognizable: 'non-cognizable',
        court: 'Magistrate Court',
        intent: 'accidental',
      },
      {
        id: 'bns-356-3',
        code: 'BNS §356(3)',
        title: 'Defamation in Public Interest',
        description: 'Whoever publishes content in good faith for public good, believing the imputation to be true.',
        punishment: 'Simple imprisonment up to 6 months',
        fine: 'Fine up to ₹1,00,000',
        bail: 'Bailable',
        cognizable: 'non-cognizable',
        court: 'Magistrate Court',
        intent: 'intentional',
      },
    ],
  },
];

export interface EvidenceFactor {
  id: string;
  label: string;
  description: string;
  type: 'aggravating' | 'mitigating';
  weight: number;
}

export const evidenceFactors: EvidenceFactor[] = [
  { id: 'weapon', label: 'Weapon Used', description: 'A deadly weapon was involved in the commission of the crime.', type: 'aggravating', weight: 18 },
  { id: 'premeditation', label: 'Premeditation', description: 'There is evidence the act was planned in advance.', type: 'aggravating', weight: 15 },
  { id: 'eyewitness', label: 'Eyewitness Testimony', description: 'Credible witnesses were present at the scene.', type: 'aggravating', weight: 10 },
  { id: 'prior-convictions', label: 'Prior Convictions', description: 'The accused has a history of similar offenses.', type: 'aggravating', weight: 12 },
  { id: 'vulnerable-victim', label: 'Vulnerable Victim', description: 'The victim was a minor, elderly, or otherwise vulnerable.', type: 'aggravating', weight: 14 },
  { id: 'self-defense', label: 'Self-Defense Claim', description: 'The accused acted to protect themselves from imminent harm.', type: 'mitigating', weight: 25 },
  { id: 'grave-provocation', label: 'Grave Provocation', description: 'The accused was provoked by the victim\u2019s conduct.', type: 'mitigating', weight: 18 },
  { id: 'remorse', label: 'Remorse & Cooperation', description: 'The accused showed remorse and cooperated with the investigation.', type: 'mitigating', weight: 12 },
  { id: 'first-offense', label: 'First Offense', description: 'The accused has no prior criminal record.', type: 'mitigating', weight: 10 },
  { id: 'restitution', label: 'Restitution Made', description: 'The accused has compensated the victim for damages.', type: 'mitigating', weight: 8 },
];
