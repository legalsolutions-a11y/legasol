import { useState } from 'react';
import {
  Skull, HeartPulse, PackageOpen, UserX, FileWarning, MessageSquareWarning,
  Gavel, Scale, RotateCcw, ChevronRight, TrendingUp, TrendingDown,
  Shield, AlertTriangle, CheckCircle2, Info,
} from 'lucide-react';
import {
  crimeCategories, evidenceFactors,
  type CrimeCategory, type EvidenceFactor,
} from '@/data/crimeData';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Skull, HeartPulse, PackageOpen, UserX, FileWarning, MessageSquareWarning,
};

type Step = 'crime' | 'section' | 'evidence' | 'verdict';

export default function VerdictWizard() {
  const [step, setStep] = useState<Step>('crime');
  const [selectedCrime, setSelectedCrime] = useState<CrimeCategory | null>(null);
  const [selectedSectionId, setSelectedSectionId] = useState<string>('');
  const [selectedEvidence, setSelectedEvidence] = useState<Set<string>>(new Set());

  const section = selectedCrime?.sections.find((s) => s.id === selectedSectionId) ?? null;

  const selectedEvidenceList = evidenceFactors.filter((e) => selectedEvidence.has(e.id));

  const aggravating = selectedEvidenceList.filter((e) => e.type === 'aggravating');
  const mitigating = selectedEvidenceList.filter((e) => e.type === 'mitigating');

  const baseScore = 50;
  const aggravatingScore = aggravating.reduce((sum, e) => sum + e.weight, 0);
  const mitigatingScore = mitigating.reduce((sum, e) => sum + e.weight, 0);
  const guiltScore = Math.max(0, Math.min(100, baseScore + aggravatingScore - mitigatingScore));

  let verdict = '';
  let verdictColor = '';
  if (guiltScore >= 75) {
    verdict = 'Likely Guilty';
    verdictColor = 'text-red-400';
  } else if (guiltScore >= 55) {
    verdict = 'Probably Guilty';
    verdictColor = 'text-orange-400';
  } else if (guiltScore >= 40) {
    verdict = 'Inconclusive';
    verdictColor = 'text-amber-400';
  } else {
    verdict = 'Likely Not Guilty';
    verdictColor = 'text-emerald-400';
  }

  const reset = () => {
    setStep('crime');
    setSelectedCrime(null);
    setSelectedSectionId('');
    setSelectedEvidence(new Set());
  };

  const toggleEvidence = (id: string) => {
    setSelectedEvidence((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-white to-white text-navy-900">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-navy-800/80 border border-navy-700 mb-4">
            <Scale className="w-4 h-4 text-accent" />
            <span className="text-xs font-medium text-navy-200 tracking-wide uppercase">Interactive Wizard</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-navy-900 mb-3">
            BNS Verdict Wizard
          </h1>
          <p className="text-navy-300 max-w-xl mx-auto">
            Explore the Bharatiya Nyaya Sanhita, 2023. Select a crime category, applicable section,
            and evidence factors to generate a simulated verdict.
          </p>
          <p className="text-xs text-navy-400 mt-3 flex items-center justify-center gap-1.5">
            <Info className="w-3.5 h-3.5" />
            Educational tool — not legal advice
          </p>
        </div>

        <StepIndicator step={step} />

        {step === 'crime' && (
          <div className="grid sm:grid-cols-2 gap-4 animate-slide-up">
            {crimeCategories.map((cat) => {
              const Icon = iconMap[cat.icon] ?? FileWarning;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCrime(cat);
                    setStep('section');
                  }}
                  className="group text-left p-6 rounded-2xl bg-navy-800/60 border border-navy-700 hover:border-accent/60 hover:bg-navy-800 transition-all duration-200"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 rounded-xl bg-navy-700/80 group-hover:bg-accent/20 flex items-center justify-center transition-colors shrink-0">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-display text-lg font-semibold text-navy-900 mb-1">
                        {cat.label}
                      </h3>
                      <p className="text-sm text-navy-300 leading-relaxed">{cat.description}</p>
                      <div className="mt-3 flex items-center gap-1 text-xs text-accent group-hover:gap-2 transition-all">
                        {cat.sections.length} sections
                        <ChevronRight className="w-3 h-3" />
                      </div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}

        {step === 'section' && selectedCrime && (
          <div className="animate-slide-up">
            <div className="flex items-center gap-3 mb-6">
              <button
                onClick={() => setStep('crime')}
                className="text-sm text-navy-300 hover:text-navy-900 transition-colors flex items-center gap-1"
              >
                <RotateCcw className="w-4 h-4" /> Back
              </button>
              <span className="text-navy-600">/</span>
              <span className="text-sm text-accent font-medium">{selectedCrime.label}</span>
            </div>

            <div className="space-y-3">
              {selectedCrime.sections.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setSelectedSectionId(s.id);
                    setStep('evidence');
                  }}
                  className={`w-full text-left p-5 rounded-xl border transition-all duration-200 ${
                    selectedSectionId === s.id
                      ? 'border-accent bg-accent/10'
                      : 'border-navy-700 bg-navy-800/60 hover:border-accent/40'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-mono px-2 py-0.5 rounded bg-navy-700 text-accent">
                          {s.code}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded ${
                          s.intent === 'intentional'
                            ? 'bg-red-500/20 text-red-300'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}>
                          {s.intent}
                        </span>
                      </div>
                      <h4 className="font-semibold text-navy-900 mb-1">{s.title}</h4>
                      <p className="text-sm text-navy-300 leading-relaxed">{s.description}</p>
                      <div className="mt-3 flex flex-wrap gap-2 text-xs">
                        <span className="px-2 py-1 rounded bg-navy-700/60 text-navy-200">
                          {s.punishment}
                        </span>
                        <span className="px-2 py-1 rounded bg-navy-700/60 text-navy-200">
                          {s.bail}
                        </span>
                        <span className="px-2 py-1 rounded bg-navy-700/60 text-navy-200">
                          {s.cognizable}
                        </span>
                        <span className="px-2 py-1 rounded bg-navy-700/60 text-navy-200">
                          {s.court}
                        </span>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-navy-500 shrink-0 mt-1" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 'evidence' && section && (
          <div className="animate-slide-up">
            <div className="flex items-center gap-3 mb-6">
              <button
                onClick={() => setStep('section')}
                className="text-sm text-navy-300 hover:text-navy-900 transition-colors flex items-center gap-1"
              >
                <RotateCcw className="w-4 h-4" /> Back
              </button>
              <span className="text-navy-600">/</span>
              <span className="text-sm text-accent font-medium">{section.code} — {section.title}</span>
            </div>

            <div className="mb-6">
              <h3 className="font-display text-xl font-semibold text-navy-900 mb-1">Select Evidence Factors</h3>
              <p className="text-sm text-navy-300">Toggle all factors that apply to this case</p>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              <div>
                <h4 className="text-sm font-semibold text-red-400 mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" /> Aggravating Factors
                </h4>
                <div className="space-y-2">
                  {evidenceFactors.filter((e) => e.type === 'aggravating').map((e) => (
                    <EvidenceCard
                      key={e.id}
                      factor={e}
                      selected={selectedEvidence.has(e.id)}
                      onToggle={() => toggleEvidence(e.id)}
                    />
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-semibold text-emerald-400 mb-3 flex items-center gap-2">
                  <TrendingDown className="w-4 h-4" /> Mitigating Factors
                </h4>
                <div className="space-y-2">
                  {evidenceFactors.filter((e) => e.type === 'mitigating').map((e) => (
                    <EvidenceCard
                      key={e.id}
                      factor={e}
                      selected={selectedEvidence.has(e.id)}
                      onToggle={() => toggleEvidence(e.id)}
                    />
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={() => setStep('verdict')}
              className="w-full py-3.5 rounded-xl bg-accent hover:bg-accent-dark text-navy-950 font-semibold transition-colors flex items-center justify-center gap-2"
            >
              <Gavel className="w-5 h-5" />
              Generate Verdict
            </button>
          </div>
        )}

        {step === 'verdict' && section && (
          <div className="animate-slide-up space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <button
                onClick={reset}
                className="text-sm text-navy-300 hover:text-navy-900 transition-colors flex items-center gap-1"
              >
                <RotateCcw className="w-4 h-4" /> Start New Case
              </button>
            </div>

            <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-navy-800/80 to-navy-900 border border-navy-700">
              <div className="text-center mb-8">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-navy-700/60 mb-4">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-xs text-navy-200 uppercase tracking-wide">Simulated Verdict</span>
                </div>
                <div className={`font-display text-4xl sm:text-5xl font-bold ${verdictColor} mb-2`}>
                  {verdict}
                </div>
                <div className="text-navy-300 text-sm">Based on the selected offense and evidence factors</div>
              </div>

              <div className="relative h-4 bg-navy-700/60 rounded-full overflow-hidden mb-2">
                <div
                  className="absolute top-0 left-0 h-full rounded-full transition-all duration-700 ease-out"
                  style={{
                    width: `${guiltScore}%`,
                    background:
                      guiltScore >= 75
                        ? 'linear-gradient(to right, #ef4444, #dc2626)'
                        : guiltScore >= 55
                        ? 'linear-gradient(to right, #f97316, #ea580c)'
                        : guiltScore >= 40
                        ? 'linear-gradient(to right, #f59e0b, #d97706)'
                        : 'linear-gradient(to right, #10b981, #059669)',
                  }}
                />
              </div>
              <div className="flex justify-between text-xs text-navy-400">
                <span>Not Guilty</span>
                <span className="font-semibold text-navy-900">{guiltScore}% Guilt Probability</span>
                <span>Guilty</span>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-navy-800/60 border border-navy-700">
              <h4 className="font-display text-lg font-semibold text-navy-900 mb-4 flex items-center gap-2">
                <Scale className="w-5 h-5 text-accent" /> Applicable BNS Section
              </h4>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-navy-700 text-accent">
                    {section.code}
                  </span>
                  <span className="font-medium text-navy-900">{section.title}</span>
                </div>
                <p className="text-sm text-navy-300 leading-relaxed">{section.description}</p>
                <div className="grid sm:grid-cols-2 gap-3 mt-4">
                  <DetailItem label="Punishment" value={section.punishment} />
                  <DetailItem label="Fine" value={section.fine} />
                  <DetailItem label="Bail" value={section.bail} />
                  <DetailItem label="Cognizable" value={section.cognizable} />
                  <DetailItem label="Court" value={section.court} />
                  <DetailItem label="Intent" value={section.intent} />
                </div>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="p-5 rounded-xl bg-navy-800/60 border border-red-500/20">
                <h4 className="text-sm font-semibold text-red-400 mb-3 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" /> Aggravating ({aggravating.length})
                </h4>
                {aggravating.length === 0 ? (
                  <p className="text-xs text-navy-400">No aggravating factors selected</p>
                ) : (
                  <ul className="space-y-2">
                    {aggravating.map((e) => (
                      <li key={e.id} className="flex items-center justify-between text-sm">
                        <span className="text-navy-200">{e.label}</span>
                        <span className="text-red-400 font-mono">+{e.weight}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div className="p-5 rounded-xl bg-navy-800/60 border border-emerald-500/20">
                <h4 className="text-sm font-semibold text-emerald-400 mb-3 flex items-center gap-2">
                  <TrendingDown className="w-4 h-4" /> Mitigating ({mitigating.length})
                </h4>
                {mitigating.length === 0 ? (
                  <p className="text-xs text-navy-400">No mitigating factors selected</p>
                ) : (
                  <ul className="space-y-2">
                    {mitigating.map((e) => (
                      <li key={e.id} className="flex items-center justify-between text-sm">
                        <span className="text-navy-200">{e.label}</span>
                        <span className="text-emerald-400 font-mono">-{e.weight}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            <div className="p-5 rounded-xl bg-navy-800/60 border border-navy-700">
              <h4 className="text-sm font-semibold text-navy-900 mb-3 flex items-center gap-2">
                <Shield className="w-4 h-4 text-accent" /> Score Breakdown
              </h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-navy-300">Base liability</span>
                  <span className="text-navy-900 font-mono">{baseScore}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-navy-300">Aggravating evidence</span>
                  <span className="text-red-400 font-mono">+{aggravatingScore}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-navy-300">Mitigating evidence</span>
                  <span className="text-emerald-400 font-mono">-{mitigatingScore}</span>
                </div>
                <div className="h-px bg-navy-700 my-1" />
                <div className="flex justify-between font-semibold">
                  <span className="text-navy-900">Net guilt score</span>
                  <span className="text-accent font-mono">{guiltScore}</span>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-2 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <p className="text-xs text-amber-200/80 leading-relaxed">
                This is an educational simulation based on simplified scoring. Real legal verdicts
                require thorough judicial examination of all facts, evidence, and legal arguments.
                Do not rely on this tool for actual legal decisions.
              </p>
            </div>

            <button
              onClick={reset}
              className="w-full py-3.5 rounded-xl bg-navy-700 hover:bg-navy-600 text-white font-medium transition-colors flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" /> Start New Case
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function StepIndicator({ step }: { step: Step }) {
  const steps: { key: Step; label: string }[] = [
    { key: 'crime', label: 'Crime Category' },
    { key: 'section', label: 'BNS Section' },
    { key: 'evidence', label: 'Evidence' },
    { key: 'verdict', label: 'Verdict' },
  ];
  const currentIndex = steps.findIndex((s) => s.key === step);

  return (
    <div className="flex items-center justify-center gap-1 sm:gap-2 mb-10">
      {steps.map((s, i) => (
        <div key={s.key} className="flex items-center gap-1 sm:gap-2">
          <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
            i === currentIndex
              ? 'bg-accent text-navy-950'
              : i < currentIndex
              ? 'bg-navy-700 text-navy-200'
              : 'bg-navy-800 text-navy-400'
          }`}>
            <span className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold">
              {i < currentIndex ? <CheckCircle2 className="w-3.5 h-3.5" /> : i + 1}
            </span>
            <span className="hidden sm:inline">{s.label}</span>
          </div>
          {i < steps.length - 1 && (
            <div className={`w-4 sm:w-8 h-px ${i < currentIndex ? 'bg-accent' : 'bg-navy-700'}`} />
          )}
        </div>
      ))}
    </div>
  );
}

function EvidenceCard({
  factor, selected, onToggle,
}: {
  factor: EvidenceFactor;
  selected: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className={`w-full text-left p-3.5 rounded-xl border transition-all duration-200 ${
        selected
          ? factor.type === 'aggravating'
            ? 'border-red-500/50 bg-red-500/10'
            : 'border-emerald-500/50 bg-emerald-500/10'
          : 'border-navy-700 bg-navy-800/40 hover:border-navy-600'
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className={`text-sm font-medium ${selected ? 'text-navy-900' : 'text-navy-200'}`}>
              {factor.label}
            </span>
            <span className={`text-xs font-mono ${factor.type === 'aggravating' ? 'text-red-400' : 'text-emerald-400'}`}>
              {factor.type === 'aggravating' ? '+' : '-'}{factor.weight}
            </span>
          </div>
          <p className="text-xs text-navy-400 mt-1 leading-relaxed">{factor.description}</p>
        </div>
        <div className={`w-5 h-5 rounded-md shrink-0 flex items-center justify-center transition-all ${
          selected
            ? factor.type === 'aggravating' ? 'bg-red-500' : 'bg-emerald-500'
            : 'border border-navy-600'
        }`}>
          {selected && <CheckCircle2 className="w-3.5 h-3.5 text-navy-900" />}
        </div>
      </div>
    </button>
  );
}

function DetailItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-3 rounded-lg bg-white/80">
      <div className="text-xs text-navy-400 uppercase tracking-wide mb-1">{label}</div>
      <div className="text-sm text-navy-900 capitalize">{value}</div>
    </div>
  );
}
