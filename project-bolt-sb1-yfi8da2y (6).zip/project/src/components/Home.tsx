import { Gavel, FileText, Scale, ArrowRight, Shield, BookOpen, AlertTriangle } from 'lucide-react';
import type { View } from './Navbar';

interface HomeProps {
  onNavigate: (view: View) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-white to-white text-navy-900">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-white via-white to-white" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-accent/5 rounded-full blur-3xl" />

        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-16 pb-20 sm:pt-24 sm:pb-28 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-navy-800/80 border border-navy-700 mb-6">
            <Scale className="w-4 h-4 text-accent" />
            <span className="text-xs font-medium text-navy-200 tracking-wide uppercase">Bharatiya Nyaya Sanhita, 2023</span>
          </div>

          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-navy-900 mb-5 leading-tight">
            legalsolutions@legasol.in
          </h1>

          <p className="text-lg sm:text-xl text-navy-300 max-w-2xl mx-auto mb-8 leading-relaxed">
            Your unified toolkit for Indian criminal law. Generate simulated verdicts based on BNS
            sections and evidence factors, create FIR drafts, and compare complaints with
            AI-powered risk analysis.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={() => onNavigate('verdict')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-accent hover:bg-accent-dark text-navy-950 font-semibold transition-all duration-200 flex items-center justify-center gap-2 group"
            >
              <Gavel className="w-5 h-5" />
              Verdict Wizard
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </button>
            <button
              onClick={() => onNavigate('fir-compare')}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-navy-700 hover:bg-navy-600 text-white font-semibold transition-all duration-200 flex items-center justify-center gap-2 group"
            >
              <FileText className="w-5 h-5" />
              FIR & Compare
              <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Tools */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-16">
        <div className="grid md:grid-cols-2 gap-6">
          <ToolCard
            icon={<Gavel className="w-6 h-6" />}
            title="BNS Verdict Wizard"
            description="Select a crime category, choose an applicable BNS section, and toggle evidence factors — aggravating and mitigating — to generate a simulated guilt probability score and verdict."
            features={['6 crime categories with 18 BNS sections', '10 evidence factors with weighted scoring', 'Interactive step-by-step wizard', 'Simulated verdict with score breakdown']}
            onClick={() => onNavigate('verdict')}
          />
          <ToolCard
            icon={<FileText className="w-6 h-6" />}
            title="FIR Recording & Comparison"
            description="Create Indian FIR drafts with structured fields, then compare two complaint texts side-by-side to identify applicable BNS sections, assess risk levels, and generate decision support recommendations."
            features={['Structured FIR draft creation', 'Side-by-side complaint comparison', 'BNS section matching from keywords', 'Risk analysis with evidence indicators']}
            onClick={() => onNavigate('fir-compare')}
          />
        </div>
      </section>

      {/* How It Works */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-16">
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-navy-900 text-center mb-10">How It Works</h2>
        <div className="grid sm:grid-cols-3 gap-6">
          <StepCard
            num="1"
            icon={<BookOpen className="w-5 h-5" />}
            title="Choose Your Tool"
            description="Pick the Verdict Wizard for case simulation or FIR Compare for complaint analysis and drafting."
          />
          <StepCard
            num="2"
            icon={<Scale className="w-5 h-5" />}
            title="Provide Case Details"
            description="Select crime categories, evidence factors, or paste complaint text. The system maps your input to BNS sections automatically."
          />
          <StepCard
            num="3"
            icon={<Shield className="w-5 h-5" />}
            title="Get Analysis & Save"
            description="Receive simulated verdicts, risk assessments, and recommendations. Save records to the database and download reports."
          />
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <StatCard value="18" label="BNS Sections" />
          <StatCard value="6" label="Crime Categories" />
          <StatCard value="37" label="BNS Mapped Offenses" />
          <StatCard value="10" label="Evidence Factors" />
        </div>
      </section>

      {/* Disclaimer */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-16">
        <div className="flex items-start gap-3 p-5 rounded-xl bg-amber-500/10 border border-amber-500/20">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold text-amber-300 mb-1">Educational Tool — Not Legal Advice</h4>
            <p className="text-xs text-amber-200/70 leading-relaxed">
              legalsolutions@legasol.in is designed for educational and research purposes. The verdicts and
              recommendations generated are simulations based on simplified models. Real legal
              decisions require qualified legal professionals. Do not rely on this tool for actual
              legal proceedings.
            </p>
          </div>
        </div>
      </section>

      <footer className="border-t border-navy-800 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Scale className="w-4 h-4 text-accent" />
            <span className="font-display text-sm font-semibold text-navy-900">legalsolutions@legasol.in</span>
          </div>
          <p className="text-xs text-navy-500">
            BNS 2023 Toolkit · Educational use only · Not affiliated with any government body
          </p>
        </div>
      </footer>
    </div>
  );
}

function ToolCard({
  icon, title, description, features, onClick,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  features: string[];
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="group text-left p-6 sm:p-8 rounded-2xl bg-navy-800/60 border border-navy-700 hover:border-accent/50 transition-all duration-300"
    >
      <div className="w-12 h-12 rounded-xl bg-navy-700/80 group-hover:bg-accent/20 flex items-center justify-center mb-4 transition-colors">
        <span className="text-accent">{icon}</span>
      </div>
      <h3 className="font-display text-xl font-semibold text-navy-900 mb-2">{title}</h3>
      <p className="text-sm text-navy-300 leading-relaxed mb-4">{description}</p>
      <ul className="space-y-2 mb-5">
        {features.map((f, i) => (
          <li key={i} className="text-xs text-navy-200 flex items-center gap-2">
            <span className="w-1 h-1 rounded-full bg-accent shrink-0" />
            {f}
          </li>
        ))}
      </ul>
      <div className="flex items-center gap-1 text-sm text-accent group-hover:gap-2 transition-all">
        Open tool <ArrowRight className="w-4 h-4" />
      </div>
    </button>
  );
}

function StepCard({ num, icon, title, description }: { num: string; icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="p-6 rounded-2xl bg-navy-800/40 border border-navy-700/50 text-center">
      <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-accent/20 text-accent mb-4 text-sm font-bold">
        {num}
      </div>
      <div className="flex justify-center mb-3">
        <span className="text-navy-300">{icon}</span>
      </div>
      <h4 className="font-display text-base font-semibold text-navy-900 mb-2">{title}</h4>
      <p className="text-sm text-navy-400 leading-relaxed">{description}</p>
    </div>
  );
}

function StatCard({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center p-4 rounded-xl bg-navy-800/40 border border-navy-700/50">
      <div className="font-display text-2xl sm:text-3xl font-bold text-accent">{value}</div>
      <div className="text-xs text-navy-400 mt-1">{label}</div>
    </div>
  );
}
