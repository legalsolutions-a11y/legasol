import { useState, useRef, useEffect, useCallback } from 'react';
import { Mic, MicOff, Square, Loader2 } from 'lucide-react';

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      length: number;
      isFinal: boolean;
      [index: number]: { transcript: string };
    };
  };
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: ((e: any) => void) | null;
  onend: (() => void) | null;
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionLike;
    webkitSpeechRecognition?: new () => SpeechRecognitionLike;
  }
}

interface VoiceRecorderProps {
  onTranscript: (text: string) => void;
  currentText: string;
}

export default function VoiceRecorder({ onTranscript, currentText }: VoiceRecorderProps) {
  const [recording, setRecording] = useState(false);
  const [supported, setSupported] = useState(true);
  const [interim, setInterim] = useState('');
  const [error, setError] = useState('');
  const [duration, setDuration] = useState(0);

  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const baseTextRef = useRef('');
  const finalAccumulatedRef = useRef('');
  const shouldStopRef = useRef(false);
  const onTranscriptRef = useRef(onTranscript);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    onTranscriptRef.current = onTranscript;
  }, [onTranscript]);

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) setSupported(false);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const updateTranscript = useCallback(() => {
    const parts = [baseTextRef.current, finalAccumulatedRef.current].filter(Boolean);
    onTranscriptRef.current(parts.join(' '));
  }, []);

  const handleResult = useCallback((e: SpeechRecognitionEventLike) => {
    let interimText = '';

    // Only process results from resultIndex onwards — these are NEW since last event
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const transcript = e.results[i][0].transcript;
      if (e.results[i].isFinal) {
        // Append only genuinely new final text, avoid empty/duplicate fragments
        const trimmed = transcript.trim();
        if (trimmed) {
          finalAccumulatedRef.current = finalAccumulatedRef.current
            ? finalAccumulatedRef.current + ' ' + trimmed
            : trimmed;
        }
      } else {
        interimText += transcript;
      }
    }

    // Build full text: base + accumulated finals + current interim
    const parts = [baseTextRef.current, finalAccumulatedRef.current, interimText.trim()].filter(Boolean);
    onTranscriptRef.current(parts.join(' '));
    setInterim(interimText.trim());
  }, []);

  const startRecording = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setError('Voice recognition is not supported in this browser. Try Chrome or Edge.');
      return;
    }

    setError('');
    shouldStopRef.current = false;
    baseTextRef.current = currentText.trim();
    finalAccumulatedRef.current = '';
    setDuration(0);

    const recognition = new SR();
    recognition.lang = 'en-IN';
    recognition.continuous = true;
    recognition.interimResults = true;

    recognition.onresult = handleResult;

    recognition.onerror = (e: any) => {
      if (e?.error === 'no-speech' || e?.error === 'aborted') return;
      setError('Recording error occurred. Please try again.');
    };

    // Auto-restart on unexpected end (Chrome stops after silence), but only if
    // the user hasn't pressed Stop. This keeps recording continuous without
    // re-processing old results because finalAccumulatedRef already holds them.
    recognition.onend = () => {
      if (shouldStopRef.current) {
        updateTranscript();
        setRecording(false);
        setInterim('');
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
        return;
      }
      // Auto-restart for continuous recording
      try {
        recognition.start();
      } catch {
        // If restart fails (e.g. browser throttling), clean up gracefully
        updateTranscript();
        setRecording(false);
        setInterim('');
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }
      }
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
    } catch {
      setError('Could not start recording. Please try again.');
      return;
    }
    setRecording(true);

    // Duration timer
    timerRef.current = setInterval(() => {
      setDuration((d) => d + 1);
    }, 1000);
  };

  const stopRecording = () => {
    shouldStopRef.current = true;
    recognitionRef.current?.stop();
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const formatDuration = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  if (!supported) {
    return (
      <div className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-navy-900/60 border border-navy-700 text-navy-400 text-xs">
        <MicOff className="w-4 h-4" />
        Voice recording requires Chrome or Edge browser
      </div>
    );
  }

  return (
    <div className="flex flex-wrap items-center gap-3">
      {!recording ? (
        <button
          onClick={startRecording}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 text-sm font-medium transition-colors border border-red-500/30"
        >
          <Mic className="w-4 h-4" />
          Start Recording
        </button>
      ) : (
        <button
          onClick={stopRecording}
          className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-red-500 hover:bg-red-600 text-white text-sm font-medium transition-colors animate-pulse"
        >
          <Square className="w-4 h-4" fill="currentColor" />
          Stop Recording
        </button>
      )}

      {recording && (
        <div className="flex items-center gap-3 text-sm text-navy-300">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500" />
            </span>
            <span className="font-mono text-xs">{formatDuration(duration)}</span>
          </div>
          {interim && (
            <span className="text-navy-500 italic truncate max-w-xs">"{interim}"</span>
          )}
        </div>
      )}

      {error && (
        <div className="text-xs text-red-400">{error}</div>
      )}
    </div>
  );
}
