import { useRef, useState } from 'react';
import { Upload, FileText, Loader2, CircleCheck, CircleAlert, X } from 'lucide-react';
import { extractTextFromFile, isAcceptedFile, formatBytes, ACCEPTED_EXTENSIONS, type ExtractedFile } from '@/lib/fileTextExtractor';

interface FileUploadButtonProps {
  onTextExtracted: (text: string, fileName: string) => void;
  className?: string;
}

export default function FileUploadButton({ onTextExtracted, className = '' }: FileUploadButtonProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [lastFile, setLastFile] = useState<ExtractedFile | null>(null);

  const handleFile = async (file: File) => {
    setError('');
    setLastFile(null);

    if (!isAcceptedFile(file.name)) {
      setError(`Unsupported file type. Accepted: ${ACCEPTED_EXTENSIONS.join(', ')}`);
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setError('File too large. Maximum size is 10 MB.');
      return;
    }

    setLoading(true);
    try {
      const result = await extractTextFromFile(file);
      setLastFile(result);
      if (result.text) {
        onTextExtracted(result.text, result.name);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to read file');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  const clearFile = () => {
    setLastFile(null);
    setError('');
  };

  return (
    <div className={className}>
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          disabled={loading}
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-navy-700 hover:bg-navy-600 text-white text-xs font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Reading...</>
          ) : (
            <><Upload className="w-3.5 h-3.5" /> Upload File</>
          )}
        </button>
        <span className="text-[10px] text-navy-500 hidden sm:inline">
          PDF, TXT, JPG, PNG, TIFF · drag & drop supported
        </span>
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED_EXTENSIONS.join(',')}
          onChange={handleInputChange}
          className="hidden"
        />
      </div>

      {lastFile && !loading && (
        <div className="mt-2 flex items-center gap-2 text-xs text-navy-300">
          <CircleCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <FileText className="w-3.5 h-3.5 text-accent shrink-0" />
          <span className="truncate max-w-[200px]">{lastFile.name}</span>
          <span className="text-navy-500">· {formatBytes(lastFile.size)}</span>
          <span className="text-navy-500">· {lastFile.text.length} chars extracted</span>
          <button onClick={clearFile} className="text-navy-500 hover:text-navy-300 transition-colors ml-1">
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {error && (
        <div className="mt-2 flex items-center gap-1.5 text-xs text-red-400">
          <CircleAlert className="w-3.5 h-3.5 shrink-0" />
          {error}
        </div>
      )}
    </div>
  );
}
