import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  FileText, ArrowLeftRight, Save, Download, Trash2, ChevronDown, ChevronRight,
  Shield, AlertTriangle, Scale, Gavel, TrendingUp, TrendingDown,
  CircleCheck, CircleAlert, CircleX, Clock, FileWarning, Database,
  Sparkles, Wand2, Copy, RotateCcw,
} from 'lucide-react';
import { bnsSectionMap, severityColors, severityLabels, type BnsSectionMap } from '@/data/bnsSections';
import { matchBnsSections, analyzeRisk, type MatchedSection, type RiskAnalysis } from '@/lib/analysis';
import { supabase } from '@/lib/supabase';
import VoiceRecorder from '@/components/VoiceRecorder';
import FileUploadButton from '@/components/FileUploadButton';
import { generateFirDocument, type FirDocument } from '@/lib/firFormatter';

interface SavedFIR {
  id: string;
  fir_number: string | null;
  complainant_name: string | null;
  complainant_phone: string | null;
  incident_date: string | null;
  incident_location: string | null;
  bns_section: string | null;
  description: string;
  created_at: string;
}

type Tab = 'fir-record' | 'compare';

export default function FirCompare() {
  const [tab, setTab] = useState<Tab>('fir-record');

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-white to-white text-navy-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-navy-800/80 border border-navy-700 mb-4">
            <FileText className="w-4 h-4 text-accent" />
            <span className="text-xs font-medium text-navy-200 tracking-wide uppercase">FIR & Analysis Module</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-navy-900 mb-3">
            FIR Recording & Complaint Comparison
          </h1>
          <p className="text-navy-300 max-w-2xl mx-auto">
            Create Indian FIR drafts and compare complaint texts to identify applicable BNS sections,
            assess risk, and generate decision support recommendations.
          </p>
        </div>

        <div className="flex items-center gap-2 p-1 rounded-xl bg-navy-800/60 border border-navy-700 mb-8 max-w-md mx-auto">
          <TabButton active={tab === 'fir-record'} onClick={() => setTab('fir-record')} icon={<FileText className="w-4 h-4" />} label="FIR Recording" />
          <TabButton active={tab === 'compare'} onClick={() => setTab('compare')} icon={<ArrowLeftRight className="w-4 h-4" />} label="Compare Complaints" />
        </div>

        {tab === 'fir-record' && <FirRecordTab />}
        {tab === 'compare' && <CompareTab />}
      </div>
    </div>
  );
}

function TabButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
        active ? 'bg-accent text-navy-950' : 'text-navy-300 hover:text-navy-900'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

type RecordMode = 'input' | 'fir-document';

function FirRecordTab() {
  const [description, setDescription] = useState('');
  const [firDoc, setFirDoc] = useState<FirDocument | null>(null);
  const [recordMode, setRecordMode] = useState<RecordMode>('input');
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [records, setRecords] = useState<SavedFIR[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [loadingRecords, setLoadingRecords] = useState(true);

  const loadRecords = useCallback(async () => {
    setLoadingRecords(true);
    const { data, error } = await supabase
      .from('fir_records')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) {
      setRecords(data as SavedFIR[]);
    }
    setLoadingRecords(false);
  }, []);

  useEffect(() => {
    loadRecords();
  }, [loadRecords]);

  const handleGenerateFir = () => {
    if (!description.trim()) return;
    const doc = generateFirDocument(description);
    setFirDoc(doc);
    setRecordMode('fir-document');
  };

  const handleRegenerate = () => {
    if (!description.trim()) return;
    const doc = generateFirDocument(description);
    setFirDoc(doc);
  };

  const handleReset = () => {
    setDescription('');
    setFirDoc(null);
    setRecordMode('input');
    setSavedMsg('');
  };

  const handleCopy = () => {
    if (!firDoc) return;
    navigator.clipboard.writeText(firDoc.firFormattedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = async () => {
    if (!firDoc) return;
    setSaving(true);
    setSavedMsg('');
    const sectionsStr = firDoc.detectedSections.map((s) => `§${s.section}`).join(', ');
    const { error } = await supabase.from('fir_records').insert({
      fir_number: firDoc.firNumber,
      complainant_name: firDoc.complainantName || null,
      complainant_phone: firDoc.complainantPhone || null,
      incident_date: firDoc.occurrenceDate || null,
      incident_location: firDoc.placeOfOccurrence || null,
      bns_section: sectionsStr || null,
      description: firDoc.statementText,
    });
    if (error) {
      setSavedMsg('Failed to save: ' + error.message);
    } else {
      setSavedMsg('Saved to Database');
      loadRecords();
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    await supabase.from('fir_records').delete().eq('id', id);
    loadRecords();
  };

  const downloadRecord = (rec: SavedFIR) => {
    const text = `FIRST INFORMATION REPORT

FIR Number: ${rec.fir_number || 'N/A'}
Complainant Name: ${rec.complainant_name || 'N/A'}
Contact Number: ${rec.complainant_phone || 'N/A'}
Date of Incident: ${rec.incident_date || 'N/A'}
Place of Occurrence: ${rec.incident_location || 'N/A'}
BNS Section: ${rec.bns_section || 'N/A'}

Description:
${rec.description}

Recorded on: ${new Date(rec.created_at).toLocaleString()}`;

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `FIR_${rec.fir_number || rec.id.slice(0, 8)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Step 1: Record / Type complaint */}
      <div className="p-6 rounded-2xl bg-navy-800/60 border border-navy-700">
        <div className="flex items-center gap-2 mb-1">
          <span className="w-6 h-6 rounded-full bg-accent/20 text-accent text-xs font-bold flex items-center justify-center">1</span>
          <h3 className="font-display text-lg font-semibold text-navy-900">Record or Type the Complaint</h3>
        </div>
        <p className="text-sm text-navy-300 mb-5 ml-8">Speak the complaint aloud or type it below — the system will automatically structure it into an Indian FIR format</p>

        {/* Voice recorder */}
        <div className="mb-4 ml-8">
          <VoiceRecorder onTranscript={setDescription} currentText={description} />
        </div>

        {/* Live transcript box */}
        <div className="mb-5">
          <label className="block text-xs font-medium text-navy-300 uppercase tracking-wide mb-1.5">
            Complaint Text
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={7}
            placeholder="Speak or type the complaint here... For example: My name is Ramesh Kumar, on 15th March at around 8 PM near the market road, someone attacked me with a knife and stole my phone and 5000 rupees..."
            className="w-full p-3 rounded-lg bg-white/80 border border-navy-700 text-navy-900 text-sm placeholder:text-navy-500 focus:border-accent focus:outline-none resize-y"
          />
          <div className="text-xs text-navy-500 mt-1">{description.trim().split(/\s+/).filter(Boolean).length} words</div>
        </div>

        {/* File upload */}
        <div className="mb-5">
          <FileUploadButton
            onTextExtracted={(text) => setDescription((prev) => (prev ? prev + '\n\n' + text : text))}
          />
        </div>

        <div className="flex items-center gap-3 ml-8">
          <button
            onClick={handleGenerateFir}
            disabled={!description.trim()}
            className="px-6 py-2.5 rounded-lg bg-accent hover:bg-accent-dark text-navy-950 font-semibold text-sm transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Wand2 className="w-4 h-4" />
            Generate FIR Document
          </button>
          {description.trim() && (
            <button
              onClick={() => { setDescription(''); setFirDoc(null); setRecordMode('input'); }}
              className="px-4 py-2.5 rounded-lg bg-navy-700 hover:bg-navy-600 text-white text-sm transition-colors flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" /> Clear
            </button>
          )}
        </div>
      </div>

      {/* Step 2: Generated FIR Document */}
      {firDoc && recordMode === 'fir-document' && (
        <div className="p-6 rounded-2xl bg-navy-800/60 border border-accent/30 animate-slide-up">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-accent/20 text-accent text-xs font-bold flex items-center justify-center">2</span>
              <h3 className="font-display text-lg font-semibold text-navy-900">Generated FIR Document</h3>
            </div>
            <span className="text-xs px-2 py-1 rounded-full bg-accent/20 text-accent flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Auto-formatted
            </span>
          </div>
          <p className="text-sm text-navy-300 mb-5 ml-8">Review the auto-generated FIR below. Fields are pre-filled from the complaint — edit the complaint and regenerate to update.</p>

          {/* Detected sections */}
          {firDoc.detectedSections.length > 0 && (
            <div className="ml-8 mb-4 p-4 rounded-xl bg-white/80 border border-navy-700">
              <div className="text-xs text-navy-400 uppercase tracking-wide mb-2">Detected BNS Sections</div>
              <div className="flex flex-wrap gap-2">
                {firDoc.detectedSections.map((s) => (
                  <span key={s.section} className={`text-xs font-mono px-2.5 py-1 rounded-lg bg-navy-700 ${severityColors[s.severity]}`}>
                    §{s.section} — {s.title}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* FIR formatted text box */}
          <div className="ml-8 mb-4">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-medium text-navy-300 uppercase tracking-wide">Indian FIR Format</label>
              <button onClick={handleCopy} className="text-xs text-accent hover:text-accent-light flex items-center gap-1 transition-colors">
                {copied ? <><CircleCheck className="w-3.5 h-3.5" /> Copied!</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
              </button>
            </div>
            <pre className="w-full p-4 rounded-lg bg-navy-950 border border-navy-700 text-xs text-navy-200 whitespace-pre-wrap font-mono leading-relaxed max-h-[600px] overflow-y-auto">
{firDoc.firFormattedText}
            </pre>
          </div>

          {/* Extracted fields summary */}
          <div className="ml-8 mb-5">
            <div className="text-xs text-navy-400 uppercase tracking-wide mb-2">Extracted Information</div>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
              <ExtractedField label="Complainant Name" value={firDoc.complainantName} />
              <ExtractedField label="Contact Number" value={firDoc.complainantPhone} />
              <ExtractedField label="Date of Occurrence" value={firDoc.occurrenceDate} />
              <ExtractedField label="Time of Occurrence" value={firDoc.occurrenceTime} />
              <ExtractedField label="Day" value={firDoc.occurrenceDay} />
              <ExtractedField label="Place of Occurrence" value={firDoc.placeOfOccurrence} />
              <ExtractedField label="Accused Details" value={firDoc.accusedDetails} />
              <ExtractedField label="Nature of Offense" value={firDoc.natureOfOffense} />
              <ExtractedField label="Info Type" value={firDoc.typeOfInformation} />
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap items-center gap-3 ml-8">
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-5 py-2.5 rounded-lg bg-accent hover:bg-accent-dark text-navy-950 font-semibold text-sm transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {saving ? 'Saving...' : 'Save FIR Record'}
            </button>
            <button
              onClick={handleRegenerate}
              className="px-5 py-2.5 rounded-lg bg-navy-700 hover:bg-navy-600 text-white text-sm transition-colors flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4" /> Regenerate
            </button>
            <button
              onClick={() => {
                const blob = new Blob([firDoc.firFormattedText], { type: 'text/plain' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `FIR_${firDoc.firNumber}.txt`;
                a.click();
                URL.revokeObjectURL(url);
              }}
              className="px-5 py-2.5 rounded-lg bg-navy-700 hover:bg-navy-600 text-white text-sm transition-colors flex items-center gap-2"
            >
              <Download className="w-4 h-4" /> Download
            </button>
            <button
              onClick={handleReset}
              className="px-5 py-2.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 text-sm transition-colors flex items-center gap-2"
            >
              <Trash2 className="w-4 h-4" /> Discard & Start Over
            </button>
          </div>

          {savedMsg && (
            <div className={`mt-3 ml-8 text-sm flex items-center gap-2 ${savedMsg === 'Saved to Database' ? 'text-emerald-400' : 'text-red-400'}`}>
              {savedMsg === 'Saved to Database' ? <CircleCheck className="w-4 h-4" /> : <CircleAlert className="w-4 h-4" />}
              {savedMsg}
            </div>
          )}
        </div>
      )}

      {/* Saved records */}
      <div>
        <h3 className="font-display text-lg font-semibold text-navy-900 mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-accent" /> Saved FIR Records
        </h3>

        {loadingRecords ? (
          <div className="text-center py-8 text-navy-400 text-sm">Loading records...</div>
        ) : records.length === 0 ? (
          <div className="text-center py-12 rounded-xl bg-navy-800/40 border border-navy-700/50">
            <FileText className="w-8 h-8 text-navy-600 mx-auto mb-2" />
            <p className="text-sm text-navy-400">No FIR records saved yet</p>
          </div>
        ) : (
          <div className="space-y-2">
            {records.map((rec) => (
              <div key={rec.id} className="rounded-xl bg-navy-800/60 border border-navy-700 overflow-hidden">
                <button
                  onClick={() => setExpandedId(expandedId === rec.id ? null : rec.id)}
                  className="w-full flex items-center justify-between p-4 text-left hover:bg-navy-800 transition-colors"
                >
                  <div className="min-w-0 flex items-center gap-3">
                    {expandedId === rec.id ? <ChevronDown className="w-4 h-4 text-navy-400 shrink-0" /> : <ChevronRight className="w-4 h-4 text-navy-400 shrink-0" />}
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-navy-900 truncate">
                        {rec.fir_number || 'Untitled FIR'}
                      </div>
                      <div className="text-xs text-navy-400 truncate">
                        {rec.complainant_name || 'Unknown'} · {new Date(rec.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {rec.bns_section && (
                      <span className="text-xs font-mono px-2 py-0.5 rounded bg-navy-700 text-accent hidden sm:inline">
                        {rec.bns_section}
                      </span>
                    )}
                  </div>
                </button>
                {expandedId === rec.id && (
                  <div className="p-4 pt-0 space-y-3 animate-fade-in">
                    <div className="grid sm:grid-cols-2 gap-2 text-xs">
                      {rec.complainant_phone && <InfoRow label="Phone" value={rec.complainant_phone} />}
                      {rec.incident_date && <InfoRow label="Date" value={rec.incident_date} />}
                      {rec.incident_location && <InfoRow label="Location" value={rec.incident_location} />}
                      {rec.bns_section && <InfoRow label="BNS Section" value={rec.bns_section} />}
                    </div>
                    <div>
                      <div className="text-xs text-navy-400 uppercase tracking-wide mb-1">Description</div>
                      <p className="text-sm text-navy-200 whitespace-pre-wrap leading-relaxed">{rec.description}</p>
                    </div>
                    <div className="flex gap-2 pt-2">
                      <button onClick={() => downloadRecord(rec)} className="text-xs px-3 py-1.5 rounded-lg bg-navy-700 hover:bg-navy-600 text-white flex items-center gap-1.5 transition-colors">
                        <Download className="w-3.5 h-3.5" /> Download
                      </button>
                      <button onClick={() => handleDelete(rec.id)} className="text-xs px-3 py-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-300 flex items-center gap-1.5 transition-colors">
                        <Trash2 className="w-3.5 h-3.5" /> Delete
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ExtractedField({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-2.5 rounded-lg bg-white/80 border border-navy-700/50">
      <div className="text-[10px] text-navy-400 uppercase tracking-wide mb-0.5">{label}</div>
      <div className="text-xs text-navy-900">{value || <span className="text-navy-500 italic">Not detected</span>}</div>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-2">
      <span className="text-navy-400">{label}:</span>
      <span className="text-navy-200">{value}</span>
    </div>
  );
}

function FormField({ label, placeholder, value, onChange, type = 'text' }: { label: string; placeholder: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="block text-xs font-medium text-navy-300 uppercase tracking-wide mb-1.5">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-3 py-2.5 rounded-lg bg-white/80 border border-navy-700 text-navy-900 text-sm placeholder:text-navy-500 focus:border-accent focus:outline-none transition-colors"
      />
    </div>
  );
}

interface ComparisonResult {
  partA: MatchedSection[];
  partB: MatchedSection[];
  common: BnsSectionMap[];
  riskA: RiskAnalysis;
  riskB: RiskAnalysis;
  recommendation: string;
}

function CompareTab() {
  const [partA, setPartA] = useState('');
  const [partB, setPartB] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<ComparisonResult | null>(null);
  const [saveTitle, setSaveTitle] = useState('');
  const [saveMsg, setSaveMsg] = useState('');
  const [savedAnalyses, setSavedAnalyses] = useState<any[]>([]);
  const [loadingSaved, setLoadingSaved] = useState(true);

  const loadSaved = useCallback(async () => {
    setLoadingSaved(true);
    const { data, error } = await supabase
      .from('comparison_analyses')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) setSavedAnalyses(data);
    setLoadingSaved(false);
  }, []);

  useEffect(() => {
    loadSaved();
  }, [loadSaved]);

  const handleAnalyze = async () => {
    if (!partA.trim() || !partB.trim()) return;
    setAnalyzing(true);
    setResult(null);

    await new Promise((r) => setTimeout(r, 1200));

    const matchedA = matchBnsSections(partA, bnsSectionMap);
    const matchedB = matchBnsSections(partB, bnsSectionMap);
    const common = matchedA.filter((a) => matchedB.some((b) => b.section === a.section));
    const riskA = analyzeRisk(partA, matchedA);
    const riskB = analyzeRisk(partB, matchedB);

    let recommendation = '';
    const sevA = riskA.severityLevel;
    const sevB = riskB.severityLevel;
    const ord: Record<string, number> = { Low: 0, Medium: 1, High: 2, 'Very High': 3 };

    if (matchedA.length === 0 && matchedB.length === 0) {
      recommendation = 'No specific BNS sections identified from either complaint. Both complaints require further investigation to determine applicable charges.';
    } else if (matchedA.length === 0) {
      recommendation = 'Part B has stronger documentary foundation. Part A does not clearly identify a recognized offense under BNS.';
    } else if (matchedB.length === 0) {
      recommendation = 'Part A has stronger documentary foundation. Part B does not clearly identify a recognized offense under BNS.';
    } else if (ord[sevA] > ord[sevB]) {
      recommendation = 'Part A is significantly more severe. Priority should be given to investigating Part A.';
    } else if (ord[sevB] > ord[sevA]) {
      recommendation = 'Part B is significantly more severe. Priority should be given to investigating Part B.';
    } else if (matchedA.length > matchedB.length) {
      recommendation = 'Part A provides more factual context with additional identified offenses. Consider consolidating charges from both complaints.';
    } else if (matchedB.length > matchedA.length) {
      recommendation = 'Part B provides more factual context with additional identified offenses. Consider consolidating charges from both complaints.';
    } else {
      recommendation = 'Both complaints are comparable in severity and scope. Consider consolidating into a unified FIR for efficient prosecution.';
    }

    setResult({
      partA: matchedA, partB: matchedB, common, riskA, riskB, recommendation,
    });
    setAnalyzing(false);
  };

  const handleSave = async () => {
    if (!result) return;
    const title = saveTitle.trim() || `Comparison ${new Date().toLocaleDateString()}`;
    const { error } = await supabase.from('comparison_analyses').insert({
      title,
      part_a_text: partA,
      part_b_text: partB,
      part_a_sections: result.partA,
      part_b_sections: result.partB,
      common_sections: result.common,
      risk_a: result.riskA,
      risk_b: result.riskB,
      recommendation: result.recommendation,
    });
    if (error) {
      setSaveMsg('Failed to save: ' + error.message);
    } else {
      setSaveMsg('Saved Successfully');
      setSaveTitle('');
      loadSaved();
    }
    setTimeout(() => setSaveMsg(''), 3000);
  };

  const handleDeleteSaved = async (id: string) => {
    await supabase.from('comparison_analyses').delete().eq('id', id);
    loadSaved();
  };

  const downloadReport = () => {
    if (!result) return;
    const text = `LEGALKANOON — COMPARATIVE ANALYSIS REPORT

Generated: ${new Date().toLocaleString()}

=== PART A INPUT ===
${partA}

=== PART B INPUT ===
${partB}

=== BNS SECTIONS IDENTIFIED ===

Part A:
${result.partA.map((s) => `  §${s.section} — ${s.title} (${severityLabels[s.severity]})`).join('\n') || '  None identified'}

Part B:
${result.partB.map((s) => `  §${s.section} — ${s.title} (${severityLabels[s.severity]})`).join('\n') || '  None identified'}

Common Sections:
${result.common.length > 0 ? result.common.map((s) => `  §${s.section} — ${s.title}`).join('\n') : '  No common sections'}

=== RISK ANALYSIS ===

Part A:
  Overall Risk: ${result.riskA.overallRisk}
  Severity: ${result.riskA.severityLevel}
  Cognizable: ${result.riskA.cognizableOffenses}  Bailable: ${result.riskA.bailableCount}  Non-Bailable: ${result.riskA.nonBailableCount}
  Evidence Strength: ${result.riskA.evidenceStrength}
  Detail Level: ${result.riskA.detailLevel}

Part B:
  Overall Risk: ${result.riskB.overallRisk}
  Severity: ${result.riskB.severityLevel}
  Cognizable: ${result.riskB.cognizableOffenses}  Bailable: ${result.riskB.bailableCount}  Non-Bailable: ${result.riskB.nonBailableCount}
  Evidence Strength: ${result.riskB.evidenceStrength}
  Detail Level: ${result.riskB.detailLevel}

=== DECISION SUPPORT RECOMMENDATION ===
${result.recommendation}

=== POTENTIAL OUTCOMES ===
Part A: ${result.riskA.potentialOutcomes.join('; ') || 'N/A'}
Part B: ${result.riskB.potentialOutcomes.join('; ') || 'N/A'}
`;

    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'LegalKanoon_Comparison_Report.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="grid lg:grid-cols-2 gap-4">
        <ComplaintInput
          label="Part A Input"
          placeholder="Add complaint text or upload document images to begin analysis..."
          value={partA}
          onChange={setPartA}
        />
        <ComplaintInput
          label="Part B Input"
          placeholder="Add complaint text or upload document images to begin analysis..."
          value={partB}
          onChange={setPartB}
        />
      </div>

      <button
        onClick={handleAnalyze}
        disabled={analyzing || !partA.trim() || !partB.trim()}
        className="w-full py-3.5 rounded-xl bg-accent hover:bg-accent-dark text-navy-950 font-semibold transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <Scale className="w-5 h-5" />
        {analyzing ? 'Analyzing complaints...' : 'Compare Complaints'}
      </button>

      {analyzing && (
        <div className="text-center py-8">
          <div className="inline-flex flex-col items-center gap-3">
            <div className="w-10 h-10 border-2 border-navy-700 border-t-accent rounded-full animate-spin" />
            <div className="text-sm text-navy-300">
              <div>Comparative Analysis Pipeline</div>
              <div className="text-xs text-navy-500 mt-1">BNS sections identified and mapped · Both complaints parsed and indexed</div>
            </div>
          </div>
        </div>
      )}

      {result && !analyzing && (
        <div className="space-y-6 animate-slide-up">
          <div className="p-5 rounded-2xl bg-gradient-to-br from-accent/10 to-navy-800 border border-accent/30">
            <h3 className="font-display text-lg font-semibold text-navy-900 mb-2 flex items-center gap-2">
              <Gavel className="w-5 h-5 text-accent" /> Decision Support Recommendation
            </h3>
            <p className="text-sm text-navy-200 leading-relaxed">{result.recommendation}</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-4">
            <RiskPanel title="Part A Risk" risk={result.riskA} sections={result.partA} />
            <RiskPanel title="Part B Risk" risk={result.riskB} sections={result.partB} />
          </div>

          {result.common.length > 0 && (
            <div className="p-5 rounded-xl bg-navy-800/60 border border-navy-700">
              <h4 className="text-sm font-semibold text-navy-900 mb-3 flex items-center gap-2">
                <ArrowLeftRight className="w-4 h-4 text-accent" /> Common BNS Sections ({result.common.length})
              </h4>
              <div className="flex flex-wrap gap-2">
                {result.common.map((s) => (
                  <span key={s.section} className="text-xs font-mono px-2.5 py-1 rounded-lg bg-navy-700 text-accent">
                    §{s.section} — {s.title}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="p-5 rounded-xl bg-navy-800/60 border border-navy-700">
            <h4 className="text-sm font-semibold text-navy-900 mb-3">Similarities Between Complaints</h4>
            <div className="space-y-2 text-xs text-navy-300">
              {result.common.length > 0 ? (
                <p>Both complaints reference common offenses under BNS, suggesting related or connected incidents.</p>
              ) : (
                <p>No common sections — the complaints appear to describe distinct offenses.</p>
              )}
              {result.riskA.weaponInvolvement && result.riskB.weaponInvolvement && (
                <p className="flex items-center gap-1.5"><AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> Weapon Involvement detected in both complaints</p>
              )}
              {result.riskA.financialAspect && result.riskB.financialAspect && (
                <p className="flex items-center gap-1.5"><TrendingUp className="w-3.5 h-3.5 text-amber-400" /> Monetary Dimension present in both complaints</p>
              )}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <input
              value={saveTitle}
              onChange={(e) => setSaveTitle(e.target.value)}
              placeholder="Name this analysis (optional)"
              className="flex-1 px-3 py-2.5 rounded-lg bg-white/80 border border-navy-700 text-navy-900 text-sm placeholder:text-navy-500 focus:border-accent focus:outline-none"
            />
            <button onClick={handleSave} className="px-5 py-2.5 rounded-lg bg-navy-700 hover:bg-navy-600 text-white font-medium text-sm transition-colors flex items-center justify-center gap-2">
              <Save className="w-4 h-4" /> Save Analysis
            </button>
            <button onClick={downloadReport} className="px-5 py-2.5 rounded-lg bg-navy-700 hover:bg-navy-600 text-white font-medium text-sm transition-colors flex items-center justify-center gap-2">
              <Download className="w-4 h-4" /> Download Full Report
            </button>
          </div>

          {saveMsg && (
            <div className={`text-sm flex items-center gap-2 ${saveMsg === 'Saved Successfully' ? 'text-emerald-400' : 'text-red-400'}`}>
              {saveMsg === 'Saved Successfully' ? <CircleCheck className="w-4 h-4" /> : <CircleAlert className="w-4 h-4" />}
              {saveMsg}
            </div>
          )}
        </div>
      )}

      <div>
        <h3 className="font-display text-lg font-semibold text-navy-900 mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-accent" /> Saved Comparison Analyses
        </h3>
        {loadingSaved ? (
          <div className="text-center py-8 text-navy-400 text-sm">Loading...</div>
        ) : savedAnalyses.length === 0 ? (
          <div className="text-center py-10 rounded-xl bg-navy-800/40 border border-navy-700/50">
            <FileWarning className="w-8 h-8 text-navy-600 mx-auto mb-2" />
            <p className="text-sm text-navy-400">No saved analyses yet</p>
          </div>
        ) : (
          <div className="space-y-2">
            {savedAnalyses.map((a) => (
              <div key={a.id} className="flex items-center justify-between p-3 rounded-lg bg-navy-800/60 border border-navy-700">
                <div className="min-w-0">
                  <div className="text-sm font-medium text-navy-900 truncate">{a.title}</div>
                  <div className="text-xs text-navy-400">{new Date(a.created_at).toLocaleDateString()}</div>
                </div>
                <button onClick={() => handleDeleteSaved(a.id)} className="text-red-400 hover:text-red-300 p-1.5 transition-colors shrink-0">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ComplaintInput({ label, placeholder, value, onChange }: { label: string; placeholder: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="block text-xs font-medium text-navy-300 uppercase tracking-wide mb-1.5">{label}</label>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={8}
        placeholder={placeholder}
        className="w-full p-3 rounded-lg bg-white/80 border border-navy-700 text-navy-900 text-sm placeholder:text-navy-500 focus:border-accent focus:outline-none resize-y"
      />
      <div className="flex items-center justify-between mt-1">
        <div className="text-xs text-navy-500">{value.trim().split(/\s+/).filter(Boolean).length} words</div>
      </div>
      <FileUploadButton
        onTextExtracted={(text) => onChange((value ? value + '\n\n' + text : text))}
        className="mt-2"
      />
    </div>
  );
}

function RiskPanel({ title, risk, sections }: { title: string; risk: RiskAnalysis; sections: MatchedSection[] }) {
  const riskColor = risk.overallRisk === 'severe' ? 'text-red-400' : risk.overallRisk === 'moderate' ? 'text-amber-400' : 'text-emerald-400';
  const riskBg = risk.overallRisk === 'severe' ? 'border-red-500/30' : risk.overallRisk === 'moderate' ? 'border-amber-500/30' : 'border-emerald-500/30';

  return (
    <div className={`p-5 rounded-xl bg-navy-800/60 border ${riskBg}`}>
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-semibold text-navy-900">{title}</h4>
        <span className={`text-xs font-bold uppercase tracking-wide ${riskColor}`}>{risk.overallRisk} Risk</span>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <Metric label="Severity" value={risk.severityLevel} valueClass={severityColors[Object.keys(severityColors).find(k => severityLabels[k] === risk.severityLevel) || 'low']} />
        <Metric label="Evidence" value={risk.evidenceStrength} />
        <Metric label="Cognizable" value={String(risk.cognizableOffenses)} />
        <Metric label="Detail" value={risk.detailLevel} />
      </div>

      <div className="space-y-1.5 text-xs mb-4">
        <div className="flex justify-between">
          <span className="text-navy-400">Bailable</span>
          <span className="text-emerald-400">{risk.bailableCount}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-navy-400">Non-Bailable</span>
          <span className="text-red-400">{risk.nonBailableCount}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-navy-400">Weapon Involvement</span>
          <span className={risk.weaponInvolvement ? 'text-red-400' : 'text-navy-500'}>{risk.weaponInvolvement ? 'Yes' : 'No weapons mentioned'}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-navy-400">Financial Aspect</span>
          <span className={risk.financialAspect ? 'text-amber-400' : 'text-navy-500'}>{risk.financialAspect ? 'Yes' : 'No financial aspect'}</span>
        </div>
      </div>

      {risk.evidenceIndicators.length > 0 && (
        <div className="mb-4">
          <div className="text-xs text-navy-400 uppercase tracking-wide mb-1.5">Evidence Indicators</div>
          <div className="space-y-1">
            {risk.evidenceIndicators.map((ind, i) => (
              <div key={i} className="text-xs text-navy-200 flex items-center gap-1.5">
                <CircleCheck className="w-3 h-3 text-emerald-400 shrink-0" /> {ind}
              </div>
            ))}
          </div>
        </div>
      )}

      {sections.length > 0 && (
        <div className="mb-4">
          <div className="text-xs text-navy-400 uppercase tracking-wide mb-1.5">Identified Sections</div>
          <div className="flex flex-wrap gap-1.5">
            {sections.map((s) => (
              <span key={s.section} className={`text-xs font-mono px-2 py-0.5 rounded bg-navy-700 ${severityColors[s.severity]}`}>
                §{s.section}
              </span>
            ))}
          </div>
        </div>
      )}

      {risk.potentialOutcomes.length > 0 && (
        <div>
          <div className="text-xs text-navy-400 uppercase tracking-wide mb-1.5">Potential Outcomes</div>
          <div className="space-y-1">
            {risk.potentialOutcomes.map((o, i) => (
              <div key={i} className="text-xs text-navy-200 flex items-center gap-1.5">
                <Clock className="w-3 h-3 text-navy-400 shrink-0" /> {o}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Metric({ label, value, valueClass = 'text-navy-900' }: { label: string; value: string; valueClass?: string }) {
  return (
    <div className="p-2.5 rounded-lg bg-white/80">
      <div className="text-[10px] text-navy-400 uppercase tracking-wide mb-0.5">{label}</div>
      <div className={`text-sm font-medium capitalize ${valueClass}`}>{value}</div>
    </div>
  );
}
