import { Scale, Gavel, FileText } from 'lucide-react';

export type View = 'home' | 'verdict' | 'fir-compare';

interface NavbarProps {
  view: View;
  onNavigate: (view: View) => void;
}

export default function Navbar({ view, onNavigate }: NavbarProps) {
  return (
    <nav className="sticky top-0 z-50 bg-navy-950/95 backdrop-blur-xl border-b border-navy-700/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 group"
          >
            <img
              src="/legasol.in.png"
              alt="Legasol.in legal solutions logo"
              className="w-11 h-11 rounded-lg object-cover shadow-md"
            />
            <div className="text-left">
              <div className="font-display text-base sm:text-lg font-bold text-navy-900 leading-tight">
                legalsolutions@legasol.in
              </div>
              <div className="text-[10px] text-navy-500 tracking-wider uppercase">
                Legal Solutions & Verdict
              </div>
            </div>
          </button>

          <div className="hidden sm:flex items-center gap-1">
            <NavLink
              active={view === 'home'}
              onClick={() => onNavigate('home')}
              icon={<Scale className="w-4 h-4" />}
              label="Home"
            />
            <NavLink
              active={view === 'verdict'}
              onClick={() => onNavigate('verdict')}
              icon={<Gavel className="w-4 h-4" />}
              label="Verdict Wizard"
            />
            <NavLink
              active={view === 'fir-compare'}
              onClick={() => onNavigate('fir-compare')}
              icon={<FileText className="w-4 h-4" />}
              label="FIR Compare"
            />
          </div>

          <div className="sm:hidden flex items-center gap-1">
            <button
              onClick={() => onNavigate('home')}
              className={`p-2 rounded-lg transition-colors ${view === 'home' ? 'bg-navy-700 text-accent' : 'text-navy-300 hover:text-navy-900'}`}
            >
              <Scale className="w-5 h-5" />
            </button>
            <button
              onClick={() => onNavigate('verdict')}
              className={`p-2 rounded-lg transition-colors ${view === 'verdict' ? 'bg-navy-700 text-accent' : 'text-navy-300 hover:text-navy-900'}`}
            >
              <Gavel className="w-5 h-5" />
            </button>
            <button
              onClick={() => onNavigate('fir-compare')}
              className={`p-2 rounded-lg transition-colors ${view === 'fir-compare' ? 'bg-navy-700 text-accent' : 'text-navy-300 hover:text-navy-900'}`}
            >
              <FileText className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
        active
          ? 'bg-navy-700 text-accent'
          : 'text-navy-200 hover:text-navy-900 hover:bg-navy-800'
      }`}
    >
      {icon}
      {label}
    </button>
  );
}
