import { useState } from 'react';
import Navbar, { type View } from '@/components/Navbar';
import Home from '@/components/Home';
import VerdictWizard from '@/components/VerdictWizard';
import FirCompare from '@/components/FirCompare';

function App() {
  const [view, setView] = useState<View>('home');

  const navigate = (v: View) => {
    setView(v);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar view={view} onNavigate={navigate} />
      {view === 'home' && <Home onNavigate={navigate} />}
      {view === 'verdict' && <VerdictWizard />}
      {view === 'fir-compare' && <FirCompare />}
    </div>
  );
}

export default App;
