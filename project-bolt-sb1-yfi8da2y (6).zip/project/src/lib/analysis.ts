import type { BnsSectionMap } from '@/data/bnsSections';
import { bnsFullText, getBnsTextBySection, type BnsTextEntry } from '@/data/bnsFullText';

export interface MatchedSection extends BnsSectionMap {
  matchedKeywords: string[];
}

export function matchBnsSections(text: string, sections: BnsSectionMap[]): MatchedSection[] {
  const lower = text.toLowerCase();
  const matches: MatchedSection[] = [];

  for (const section of sections) {
    const matched = section.keywords.filter((kw) => lower.includes(kw.toLowerCase()));
    if (matched.length > 0) {
      matches.push({ ...section, matchedKeywords: matched });
    }
  }

  return matches.sort((a, b) => b.matchedKeywords.length - a.matchedKeywords.length);
}

export interface BnsTextSuggestion {
  section: string;
  actReference: string;
  excerpt: string;
  matchedWords: string[];
  matchScore: number;
}

function tokenize(text: string): Set<string> {
  return new Set(
    text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, ' ')
      .split(/\s+/)
      .filter((w) => w.length > 2),
  );
}

const STOP_WORDS = new Set([
  'the', 'and', 'for', 'with', 'that', 'this', 'from', 'shall', 'whoever',
  'which', 'such', 'been', 'have', 'has', 'was', 'were', 'any', 'all',
  'not', 'but', 'are', 'his', 'her', 'him', 'she', 'they', 'their',
  'will', 'may', 'can', 'into', 'upon', 'under', 'order', 'term',
  'year', 'years', 'months', 'month', 'days', 'day', 'fine',
]);

export function matchBnsFullText(text: string): BnsTextSuggestion[] {
  const complaintTokens = tokenize(text);
  if (complaintTokens.size < 3) return [];

  const suggestions: BnsTextSuggestion[] = [];

  for (const entry of bnsFullText) {
    const excerptTokens = tokenize(entry.excerpt);
    const matchedWords: string[] = [];
    let matchCount = 0;

    for (const token of complaintTokens) {
      if (STOP_WORDS.has(token)) continue;
      if (excerptTokens.has(token)) {
        matchCount++;
        if (!matchedWords.includes(token)) {
          matchedWords.push(token);
        }
      }
    }

    const score = matchCount / Math.sqrt(excerptTokens.size);

    if (matchCount >= 3 && score > 0.08) {
      suggestions.push({
        section: entry.section,
        actReference: entry.actReference,
        excerpt: entry.excerpt,
        matchedWords: matchedWords.slice(0, 12),
        matchScore: Math.round(score * 100) / 100,
      });
    }
  }

  return suggestions.sort((a, b) => b.matchScore - a.matchScore);
}

export function getBnsTextSuggestionForSection(section: string): BnsTextEntry | undefined {
  return getBnsTextBySection(section);
}

export interface RiskAnalysis {
  overallRisk: 'low' | 'moderate' | 'severe';
  severityLevel: string;
  cognizableOffenses: number;
  bailableCount: number;
  nonBailableCount: number;
  weaponInvolvement: boolean;
  financialAspect: boolean;
  totalExposure: string;
  evidenceStrength: 'weak' | 'moderate' | 'strong';
  evidenceIndicators: string[];
  detailLevel: 'vague' | 'moderate' | 'detailed';
  potentialOutcomes: string[];
}

export function analyzeRisk(text: string, sections: MatchedSection[]): RiskAnalysis {
  const lower = text.toLowerCase();
  const wordCount = text.trim().split(/\s+/).length;

  const cognizableOffenses = sections.filter((s) => s.cognizable).length;
  const bailableCount = sections.filter((s) => s.bailable).length;
  const nonBailableCount = sections.filter((s) => !s.bailable).length;

  const weaponKeywords = ['weapon', 'knife', 'gun', 'pistol', 'sword', 'acid', 'explosive', 'bomb', 'rod', 'stick', 'blade'];
  const weaponInvolvement = weaponKeywords.some((kw) => lower.includes(kw));

  const financialKeywords = ['money', 'cash', 'property', 'stole', 'amount', 'rupees', 'rs', '₹', 'defrauded', 'extorted', 'bribe'];
  const financialAspect = financialKeywords.some((kw) => lower.includes(kw));

  const evidenceIndicators: string[] = [];
  if (lower.includes('witness') || lower.includes('witnesses') || lower.includes('saw')) {
    evidenceIndicators.push('Eyewitness testimony mentioned');
  }
  if (lower.includes('cctv') || lower.includes('camera') || lower.includes('footage') || lower.includes('video')) {
    evidenceIndicators.push('CCTV/video evidence mentioned');
  }
  if (lower.includes('medical') || lower.includes('hospital') || lower.includes('injury') || lower.includes('wound')) {
    evidenceIndicators.push('Medical documentation referenced');
  }
  if (lower.includes('document') || lower.includes('receipt') || lower.includes('record') || lower.includes('evidence')) {
    evidenceIndicators.push('Documentary evidence referenced');
  }
  if (weaponInvolvement) {
    evidenceIndicators.push('Weapon involvement detected');
  }

  const hasDates = /\b\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b/.test(text) || /\b(january|february|march|april|may|june|july|august|september|october|november|december)\b/i.test(text);
  const hasLocations = /\b(road|street|lane|market|station|area|sector|colony|nagar|pur|vihar|town|city|village)\b/i.test(text);
  const hasNames = /\b(accused|complainant|victim|named|known as)\b/i.test(text);

  const detailScore = (hasDates ? 1 : 0) + (hasLocations ? 1 : 0) + (hasNames ? 1 : 0) + (wordCount > 100 ? 1 : 0) + (wordCount > 200 ? 1 : 0);
  const detailLevel: RiskAnalysis['detailLevel'] = detailScore <= 1 ? 'vague' : detailScore <= 3 ? 'moderate' : 'detailed';

  const evidenceStrength: RiskAnalysis['evidenceStrength'] =
    evidenceIndicators.length >= 3 ? 'strong' : evidenceIndicators.length >= 1 ? 'moderate' : 'weak';

  const maxSeverity = sections.length > 0
    ? sections.reduce((max, s) => {
        const order: Record<string, number> = { low: 0, medium: 1, high: 2, very_high: 3 };
        return order[s.severity] > order[max] ? s.severity : max;
      }, 'low' as string)
    : 'low';

  const overallRisk: RiskAnalysis['overallRisk'] =
    maxSeverity === 'very_high' || (nonBailableCount >= 2 && weaponInvolvement) ? 'severe'
    : maxSeverity === 'high' || nonBailableCount >= 1 ? 'moderate'
    : 'low';

  const severityLabel = maxSeverity === 'very_high' ? 'Very High'
    : maxSeverity === 'high' ? 'High'
    : maxSeverity === 'medium' ? 'Medium'
    : 'Low';

  const potentialOutcomes: string[] = [];
  if (nonBailableCount > 0) {
    potentialOutcomes.push('Prosecution Likely');
  }
  if (sections.length === 0) {
    potentialOutcomes.push('No clear offense identified');
  }
  if (detailLevel === 'vague') {
    potentialOutcomes.push('Vague or incomplete complaint may not sustain prosecution');
  }
  if (evidenceIndicators.length >= 3) {
    potentialOutcomes.push('Strong documentary evidence indicators present');
  }
  if (overallRisk === 'severe') {
    potentialOutcomes.push('Dismissal Likely' as string);
  }
  if (sections.some((s) => s.bailable)) {
    potentialOutcomes.push('Settlement Viable for bailable offenses');
  }

  const maxExposure = sections.length > 0
    ? sections.map((s) => s.punishment).join('; ')
    : 'No specific penalty identified';

  return {
    overallRisk,
    severityLevel: severityLabel,
    cognizableOffenses,
    bailableCount,
    nonBailableCount,
    weaponInvolvement,
    financialAspect,
    totalExposure: maxExposure,
    evidenceStrength,
    evidenceIndicators,
    detailLevel,
    potentialOutcomes,
  };
}
