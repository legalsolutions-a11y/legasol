import type { MatchedSection, BnsTextSuggestion } from './analysis';
import { matchBnsSections, matchBnsFullText } from './analysis';
import { bnsSectionMap } from '@/data/bnsSections';

export interface FirDocument {
  firNumber: string;
  policeStation: string;
  district: string;
  gdReference: string;
  dateOfReport: string;
  timeOfReport: string;
  occurrenceDate: string;
  occurrenceTime: string;
  occurrenceDay: string;
  informationReceivedDate: string;
  informationReceivedTime: string;
  typeOfInformation: string;
  placeOfOccurrence: string;
  complainantName: string;
  complainantAddress: string;
  complainantPhone: string;
  accusedDetails: string;
  actsAndSections: string;
  natureOfOffense: string;
  statementText: string;
  firFormattedText: string;
  detectedSections: MatchedSection[];
  bnsTextSuggestions: BnsTextSuggestion[];
  delayInReporting: string;
}

function extractFromText(text: string, patterns: RegExp[]): string | null {
  for (const p of patterns) {
    const m = text.match(p);
    if (m && m[1]) return m[1].trim();
  }
  return null;
}

function inferName(text: string): string {
  const patterns = [
    /my name is\s+([a-zA-Z\s.]+?)[.,;\n]/i,
    /i am\s+([a-zA-Z\s.]+?)[.,;\n]/i,
    /complainant\s*[:\-]?\s*([a-zA-Z\s.]+?)[.,;\n]/i,
    /name\s*[:\-]?\s*([a-zA-Z\s.]+?)[.,;\n]/i,
  ];
  return extractFromText(text, patterns) ?? '';
}

function inferPhone(text: string): string {
  const m = text.match(/(?:phone|contact|mobile|number)\s*(?:is|:|-)?\s*(\+?\d[\d\s\-]{8,14})/i);
  if (m) return m[1].trim();
  const m2 = text.match(/(\+?91[\-\s]?\d{10})/);
  if (m2) return m2[1].trim();
  const m3 = text.match(/\b(\d{10})\b/);
  if (m3) return m3[1].trim();
  return '';
}

function inferDate(text: string): string {
  const patterns = [
    /(?:on|dated|date)\s+(?:the\s+)?(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
    /(\d{1,2}\s+(?:january|february|march|april|may|june|july|august|september|october|november|december)\s+\d{2,4})/i,
    /(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/,
  ];
  return extractFromText(text, patterns) ?? '';
}

function inferTime(text: string): string {
  const patterns = [
    /(?:at|time|around)\s+(\d{1,2}[:.]\d{2}\s*(?:am|pm)?)/i,
    /(\d{1,2}[:.]\d{2}\s*(?:am|pm))/i,
  ];
  return extractFromText(text, patterns) ?? '';
}

function inferLocation(text: string): string {
  const patterns = [
    /(?:at|near|in|place of|location)\s+(?:the\s+)?([a-zA-Z0-9\s,.-]+?)(?:[.;\n]|$)/i,
    /(?:occurred|happened|took place)\s+(?:at|in|near)\s+([a-zA-Z0-9\s,.-]+?)(?:[.;\n]|$)/i,
  ];
  return extractFromText(text, patterns) ?? '';
}

function inferDay(text: string): string {
  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const lower = text.toLowerCase();
  for (const d of days) {
    if (lower.includes(d)) return d.charAt(0).toUpperCase() + d.slice(1);
  }
  return '';
}

function inferAccused(text: string): string {
  const patterns = [
    /(?:accused|suspect|assailant|perpetrator|attacker)(?:'s)?\s*(?:name(?:d)?(?:is)?\s*[:\-]?)?\s*([a-zA-Z\s.]+?)(?:[.,;\n]|$)/i,
    /(?:by|from)\s+(?:a\s+)?(?:person\s+(?:named|known as)\s+)([a-zA-Z\s.]+?)(?:[.,;\n]|$)/i,
    /(?:named|known as)\s+([a-zA-Z\s.]+?)(?:[.,;\n]|$)/i,
  ];
  const name = extractFromText(text, patterns);
  if (name) return name;
  const knownMatch = text.match(/(?:accused|suspect)\s+is\s+(?:known|unknown)/i);
  if (knownMatch) return 'Unknown';
  const unidentified = text.match(/unidentified|unknown\s+(?:person|man|individual)/i);
  if (unidentified) return 'Unidentified person';
  return '';
}

function inferDelayReason(text: string): string {
  const lower = text.toLowerCase();
  if (lower.includes('delay') || lower.includes('late in reporting') || lower.includes('could not report')) {
    const m = text.match(/(?:delay|late|could not report)(?:ed)?\s*(?:in reporting)?\s*(?:because|due to|as)?\s*[:\-]?\s*([a-zA-Z0-9\s,.-]+?)(?:[.;\n]|$)/i);
    if (m && m[1]) return m[1].trim();
    return 'Delay mentioned in reporting';
  }
  return 'No delay in reporting';
}

function inferInfoType(text: string): string {
  const lower = text.toLowerCase();
  if (lower.includes('oral') || lower.includes('verbal') || lower.includes('in person')) return 'Oral / In person';
  if (lower.includes('phone') || lower.includes('call') || lower.includes('telephonic')) return 'Telephonic';
  if (lower.includes('letter') || lower.includes('written') || lower.includes('email')) return 'Written';
  return 'To be determined by the investigating officer';
}

function cleanStatement(text: string): string {
  let cleaned = text.trim();
  cleaned = cleaned.replace(/\bmy name is\b[^\n]*\n?/gi, '');
  cleaned = cleaned.replace(/\b(?:phone|contact|mobile)\s*(?:is|:|-)?\s*\+?\d[\d\s\-]{8,14}/gi, '');
  cleaned = cleaned.replace(/\s+/g, ' ').trim();
  return cleaned;
}

export function generateFirDocument(
  statement: string,
  overrides: Partial<FirDocument> = {},
): FirDocument {
  const name = overrides.complainantName || inferName(statement);
  const phone = overrides.complainantPhone || inferPhone(statement);
  const date = overrides.occurrenceDate || inferDate(statement);
  const time = overrides.occurrenceTime || inferTime(statement);
  const day = overrides.occurrenceDay || inferDay(statement);
  const location = overrides.placeOfOccurrence || inferLocation(statement);
  const accused = overrides.accusedDetails || inferAccused(statement);
  const delayReason = overrides.delayInReporting || inferDelayReason(statement);
  const infoType = overrides.typeOfInformation || inferInfoType(statement);

  const detectedSections = matchBnsSections(statement, bnsSectionMap);
  const bnsTextSuggestions = matchBnsFullText(statement);
  const actsAndSections = detectedSections.length > 0
    ? detectedSections.map((s) => `BNS §${s.section} (${s.title})`).join(', ')
    : 'To be determined by the investigating officer';
  const natureOfOffense = detectedSections.length > 0
    ? detectedSections.map((s) => s.title).join(', ')
    : 'To be determined after investigation';

  const now = new Date();
  const dateOfReport = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}`;
  const timeOfReport = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  const cleanedStatement = cleanStatement(statement);

  const bnsSuggestionBlock = bnsTextSuggestions.length > 0
    ? bnsTextSuggestions.slice(0, 5).map((s) =>
        `  • ${s.actReference} — Matched: ${s.matchedWords.join(', ')}\n    "${s.excerpt.length > 200 ? s.excerpt.slice(0, 200) + '...' : s.excerpt}"`
      ).join('\n\n')
    : '  No direct BNS statutory text matches found. Refer to detected sections above.';

  const firText = `FIRST INFORMATION REPORT
(First Information Report — Section 173, BNSS 2023)

═══════════════════════════════════════════════════════════════

1.  District:                     ${overrides.district || '_______________'}
2.  Police Station:                ${overrides.policeStation || '_______________'}
3.  FIR Number:                    ${overrides.firNumber || ''}
4.  General Diary Reference:       ${overrides.gdReference || ''}

═══════════════════════════════════════════════════════════════

  OCCURRENCE AND INFORMATION RECEIVED

5.  Date of occurrence:            ${date || '___/___/______'}
6.  Time of occurrence:            ${time || '__:__'}
7.  Day of occurrence:             ${day || '___________'}
8.  Place of occurrence:           ${location || '_______________________________'}

9.  Date information received:     ${dateOfReport}
10. Time information received:     ${timeOfReport}
11. Type of information:           ${infoType}
12. Reasons for delay in reporting: ${delayReason}

═══════════════════════════════════════════════════════════════

  COMPLAINANT DETAILS

13. Name of complainant:           ${name || '_______________________________'}
14. Address:                       ${overrides.complainantAddress || '_______________________________'}
15. Contact number:                ${phone || '_______________'}

═══════════════════════════════════════════════════════════════

  ACCUSED DETAILS

16. Accused details:               ${accused || 'To be identified during investigation'}

═══════════════════════════════════════════════════════════════

  OFFENSE PARTICULARS

17. Acts and Sections:             ${actsAndSections}
18. Nature of offense:             ${natureOfOffense}

═══════════════════════════════════════════════════════════════

  RECORDED STATEMENT

  As stated in recorded information:

  "${cleanedStatement}"

═══════════════════════════════════════════════════════════════

  This is an editable draft based on the recorded statement.
  To be determined by the investigating officer.

  Generated on: ${now.toLocaleString()}

═══════════════════════════════════════════════════════════════

  BNS 2023 STATUTORY TEXT SUGGESTIONS
  (Complaint text matched against The Bharatiya Nyaya Sanhita, 2023)

${bnsSuggestionBlock}

═══════════════════════════════════════════════════════════════`;

  return {
    firNumber: overrides.firNumber || '',
    policeStation: overrides.policeStation || '',
    district: overrides.district || '',
    gdReference: overrides.gdReference || '',
    dateOfReport,
    timeOfReport,
    occurrenceDate: date,
    occurrenceTime: time,
    occurrenceDay: day,
    informationReceivedDate: dateOfReport,
    informationReceivedTime: timeOfReport,
    typeOfInformation: infoType,
    placeOfOccurrence: location,
    complainantName: name,
    complainantAddress: overrides.complainantAddress || '',
    complainantPhone: phone,
    accusedDetails: accused,
    actsAndSections,
    natureOfOffense,
    statementText: cleanedStatement,
    firFormattedText: firText,
    detectedSections,
    bnsTextSuggestions,
    delayInReporting: delayReason,
  };
}
