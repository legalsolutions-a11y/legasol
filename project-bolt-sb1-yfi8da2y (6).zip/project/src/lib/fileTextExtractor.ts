export type ExtractedFile = {
  name: string;
  text: string;
  type: string;
  size: number;
};

const ACCEPTED_TEXT = ['.txt'];
const ACCEPTED_PDF = ['.pdf'];
const ACCEPTED_IMAGE = ['.jpg', '.jpeg', '.png', '.tiff', '.tif'];

export const ACCEPTED_EXTENSIONS = [...ACCEPTED_TEXT, ...ACCEPTED_PDF, ...ACCEPTED_IMAGE];

function getExtension(name: string): string {
  const idx = name.lastIndexOf('.');
  return idx >= 0 ? name.slice(idx).toLowerCase() : '';
}

export function isAcceptedFile(name: string): boolean {
  return ACCEPTED_EXTENSIONS.includes(getExtension(name));
}

async function extractFromTxt(file: File): Promise<string> {
  return await file.text();
}

async function extractFromPdf(file: File): Promise<string> {
  const pdfjs = await import('pdfjs-dist');
  pdfjs.GlobalWorkerOptions.workerSrc = (await import('pdfjs-dist/build/pdf.worker.min.mjs?url')).default;
  const buf = await file.arrayBuffer();
  const pdf = await pdfjs.getDocument({ data: buf }).promise;
  const parts: string[] = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const text = content.items
      .map((item: any) => ('str' in item ? item.str : ''))
      .join(' ');
    parts.push(text);
  }
  return parts.join('\n\n');
}

async function extractFromImage(file: File): Promise<string> {
  return `[Image file: ${file.name} — ${formatBytes(file.size)}]\n` +
    `Image uploaded for reference. Text content cannot be extracted from images directly in this tool.\n` +
    `Please type or paste the relevant text from this image into the text area.`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export async function extractTextFromFile(file: File): Promise<ExtractedFile> {
  const ext = getExtension(file.name);
  let text: string;

  if (ACCEPTED_TEXT.includes(ext)) {
    text = await extractFromTxt(file);
  } else if (ACCEPTED_PDF.includes(ext)) {
    text = await extractFromPdf(file);
  } else if (ACCEPTED_IMAGE.includes(ext)) {
    text = await extractFromImage(file);
  } else {
    throw new Error(`Unsupported file type: ${ext}`);
  }

  return {
    name: file.name,
    text: text.trim(),
    type: ext.replace('.', ''),
    size: file.size,
  };
}
