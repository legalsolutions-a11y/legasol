/*
# Create FIR Records and Comparison Analyses tables (single-tenant, no auth)

1. New Tables
- `fir_records` — stores Indian FIR (First Information Report) drafts created by users
  - `id` (uuid, primary key)
  - `fir_number` (text) — FIR reference number
  - `complainant_name` (text) — name of complainant
  - `complainant_phone` (text) — contact number
  - `incident_date` (text) — date of incident
  - `incident_location` (text) — place of occurrence
  - `bns_section` (text) — applicable BNS section
  - `description` (text, not null) — full complaint/statement text
  - `created_at` (timestamptz)

- `comparison_analyses` — stores side-by-side complaint comparison results
  - `id` (uuid, primary key)
  - `title` (text, not null) — user-given title for the comparison
  - `part_a_text` (text, not null) — first complaint text
  - `part_b_text` (text, not null) — second complaint text
  - `part_a_sections` (jsonb) — detected BNS sections for complaint A
  - `part_b_sections` (jsonb) — detected BNS sections for complaint B
  - `common_sections` (jsonb) — sections common to both
  - `risk_a` (jsonb) — risk analysis for complaint A
  - `risk_b` (jsonb) — risk analysis for complaint B
  - `recommendation` (text) — decision support recommendation
  - `created_at` (timestamptz)

2. Security
- Enable RLS on both tables.
- Allow anon + authenticated CRUD because this is a single-tenant public tool with no sign-in.
*/

CREATE TABLE IF NOT EXISTS fir_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  fir_number text,
  complainant_name text,
  complainant_phone text,
  incident_date text,
  incident_location text,
  bns_section text,
  description text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE fir_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_fir_records" ON fir_records;
CREATE POLICY "anon_select_fir_records" ON fir_records FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_fir_records" ON fir_records;
CREATE POLICY "anon_insert_fir_records" ON fir_records FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_fir_records" ON fir_records;
CREATE POLICY "anon_update_fir_records" ON fir_records FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_fir_records" ON fir_records;
CREATE POLICY "anon_delete_fir_records" ON fir_records FOR DELETE
TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS comparison_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  part_a_text text NOT NULL,
  part_b_text text NOT NULL,
  part_a_sections jsonb DEFAULT '[]'::jsonb,
  part_b_sections jsonb DEFAULT '[]'::jsonb,
  common_sections jsonb DEFAULT '[]'::jsonb,
  risk_a jsonb DEFAULT '{}'::jsonb,
  risk_b jsonb DEFAULT '{}'::jsonb,
  recommendation text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE comparison_analyses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_comparison_analyses" ON comparison_analyses;
CREATE POLICY "anon_select_comparison_analyses" ON comparison_analyses FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_comparison_analyses" ON comparison_analyses;
CREATE POLICY "anon_insert_comparison_analyses" ON comparison_analyses FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_comparison_analyses" ON comparison_analyses;
CREATE POLICY "anon_update_comparison_analyses" ON comparison_analyses FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_comparison_analyses" ON comparison_analyses;
CREATE POLICY "anon_delete_comparison_analyses" ON comparison_analyses FOR DELETE
TO anon, authenticated USING (true);
