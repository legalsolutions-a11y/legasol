/*
# Add statutory reference index for the three new criminal laws

1. New Tables
- `statutory_reference_sections` — a public reference index for sections and section ranges from the supplied practice guide.
- `id` (uuid, primary key)
- `act_code` (text) — BNS, BNSS, or BSA
- `act_name` (text) — full statute name
- `section_range` (text) — section or section range shown in the guide
- `old_reference` (text) — corresponding IPC, CrPC, or Evidence Act reference when supplied
- `subject` (text) — offence or procedural subject
- `practical_purpose` (text) — plain-language application note from the guide
- `status` (text) — guide classification such as Mapped, New Offence, or Updated
- `keywords` (text[]) — terms used for relevant-case lookup
- `created_at` (timestamptz)

2. Seed Data
- Adds the indexed BNS offence/property/state rows, BNSS procedure rows, and BSA evidence rows supplied in the document.
- Existing rows are protected from duplicate inserts by a unique key on act and section range.

3. Security
- Enables row-level security.
- Allows anonymous and authenticated users to read the public legal reference index.
- Explicitly denies browser inserts, updates, and deletes so reference content cannot be altered through the public app.

4. Important Notes
- This is an index and practice-reference layer, not a substitute for the official Gazette text or legal advice.
- The existing local offence matcher remains in place for fast FIR generation; this table provides the durable database reference for future lookups.
*/

CREATE TABLE IF NOT EXISTS statutory_reference_sections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  act_code text NOT NULL CHECK (act_code IN ('BNS', 'BNSS', 'BSA')),
  act_name text NOT NULL,
  section_range text NOT NULL,
  old_reference text,
  subject text NOT NULL,
  practical_purpose text NOT NULL,
  status text NOT NULL,
  keywords text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (act_code, section_range)
);

ALTER TABLE statutory_reference_sections ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_read_statutory_reference_sections" ON statutory_reference_sections;
CREATE POLICY "public_read_statutory_reference_sections"
ON statutory_reference_sections FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "deny_insert_statutory_reference_sections" ON statutory_reference_sections;
CREATE POLICY "deny_insert_statutory_reference_sections"
ON statutory_reference_sections FOR INSERT
TO anon, authenticated
WITH CHECK (false);

DROP POLICY IF EXISTS "deny_update_statutory_reference_sections" ON statutory_reference_sections;
CREATE POLICY "deny_update_statutory_reference_sections"
ON statutory_reference_sections FOR UPDATE
TO anon, authenticated
USING (false)
WITH CHECK (false);

DROP POLICY IF EXISTS "deny_delete_statutory_reference_sections" ON statutory_reference_sections;
CREATE POLICY "deny_delete_statutory_reference_sections"
ON statutory_reference_sections FOR DELETE
TO anon, authenticated
USING (false);

CREATE INDEX IF NOT EXISTS statutory_reference_sections_act_code_idx
ON statutory_reference_sections (act_code);

INSERT INTO statutory_reference_sections (act_code, act_name, section_range, old_reference, subject, practical_purpose, status, keywords) VALUES
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 1–3', 'Sec. 1–5 IPC', 'Title, extent and definitions', 'Establishes territorial jurisdiction, general definitions, and applicability across India.', 'Modified', ARRAY['definitions','jurisdiction','application']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 4', 'Sec. 53 IPC', 'Punishments and community service', 'Introduces community service as a new punishment for minor infractions.', 'New Category', ARRAY['punishment','community service']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 14–44', 'Sec. 76–106 IPC', 'General exceptions and private defence', 'Exempts acts by necessity, accident, insanity, infancy, and self-defence rights.', 'Retained', ARRAY['general exception','necessity','accident','self defence']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 45–62', 'Sec. 107–120B IPC', 'Abetment, conspiracy and attempt', 'Punishes criminal planning, instigation, and conspiracy.', 'Mapped', ARRAY['abetment','conspiracy','attempt','instigation']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 63–73', 'Sec. 375–376 IPC', 'Sexual offences against women', 'Covers rape, marital rape exceptions, and increases penalties including deceitful marriage promises.', 'Enhanced', ARRAY['rape','sexual offence','consent','marriage promise']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 74–79', 'Sec. 354, 509 IPC', 'Modesty and harassment of women', 'Covers assault to outrage modesty, voyeurism, stalking, and word or gesture insult.', 'Mapped', ARRAY['modesty','sexual harassment','voyeurism','stalking','woman']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 80–87', 'Sec. 304B, 498A IPC', 'Dowry death and matrimonial cruelty', 'Covers dowry death and cruelty by husband or relatives.', 'Mapped', ARRAY['dowry death','dowry','cruelty','matrimonial']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 93–99', 'Sec. 312–318 IPC', 'Offences against unborn children', 'Penalizes causing miscarriage, abandonment of infants, and concealment of birth.', 'Retained', ARRAY['miscarriage','abandonment','unborn child','infant']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 100–103', 'Sec. 299–302 IPC', 'Culpable homicide and murder', 'Section 103(1) murder punishment; Section 103(2) penalizes murder by a life convict.', 'New Clause', ARRAY['murder','culpable homicide','death','life imprisonment']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 106', 'Sec. 304A IPC', 'Causing death by negligence', 'Section 106(1) rash or negligent driving; Section 106(2) strict hit-and-run failure to report.', 'Updated', ARRAY['negligence','rash driving','hit and run','death']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 108–109', 'Sec. 306–307 IPC', 'Abetment of suicide and attempt to murder', 'Section 108 handles suicide abetment; Section 109 replaces IPC 307 for murder attempts.', 'Mapped', ARRAY['suicide','abetment','attempt to murder']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 111', 'New Act', 'Organised crime', 'Penalizes criminal syndicates, extortion, contract killing, and cyber-crime networks.', 'New Offence', ARRAY['organised crime','syndicate','extortion','cyber crime','contract killing']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 112', 'New Act', 'Petty organised crime', 'Covers snatching, pocket-picking, cheating, and ticket-scalping by organized groups.', 'New Offence', ARRAY['petty organised crime','snatching','pocket picking','cheating','ticket scalping']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 113', 'Special Acts', 'Terrorist acts', 'Codifies acts threatening unity, integrity, security, or sovereignty of India in BNS.', 'Codified', ARRAY['terrorism','terrorist act','sovereignty','security','bomb']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 115–125', 'Sec. 323–338 IPC', 'Hurt and grievous hurt', 'Section 115 simple hurt; Section 117 grievous hurt; Section 124 acid attack penalties.', 'Mapped', ARRAY['hurt','grievous hurt','acid attack','injury']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 147–158', 'Sec. 121–130 IPC', 'Offences against the State', 'Waging war against India and acts endangering sovereignty.', 'Overhauled', ARRAY['war','state','sovereignty','government']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 152', 'Sec. 124A IPC', 'Acts endangering sovereignty', 'Replaces colonial sedition language with focus on secession, armed rebellion, subversive acts, and sovereignty.', 'Substituted', ARRAY['sovereignty','secession','armed rebellion','unity']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 189–197', 'Sec. 141–160 IPC', 'Public tranquillity and rioting', 'Unlawful assembly, rioting, and promoting enmity between groups.', 'Mapped', ARRAY['unlawful assembly','rioting','public tranquillity','enmity']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 198–205', 'Sec. 161–171 IPC', 'Public servants and impersonation', 'Penalizes public servants unlawfully engaging in trade or illegal acceptance of rewards.', 'Retained', ARRAY['public servant','impersonation','official misconduct']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 206–226', 'Sec. 172–190 IPC', 'Contempt of lawful authority', 'Absconding to avoid service, obstructing public servants, and suicide threat to compel official action.', 'Mapped', ARRAY['summons','public servant','obstruction','authority']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 227–269', 'Sec. 191–229A IPC', 'False evidence and public justice', 'Perjury, giving or fabricating false evidence, and harboring offenders.', 'Mapped', ARRAY['false evidence','perjury','fabrication','harbouring offender']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 270–297', 'Sec. 230–263A IPC', 'Coin, currency and stamps', 'Counterfeiting bank notes, currency notes, government stamps, and possessing machinery.', 'Retained', ARRAY['counterfeit','currency','bank note','stamp']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 298–302', 'Sec. 268–294A IPC', 'Public health, safety and decency', 'Adulteration of food or drugs, public nuisance, rash driving, and obscene acts.', 'Mapped', ARRAY['public nuisance','adulteration','rash driving','obscene']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 303–307', 'Sec. 378–382 IPC', 'Theft and snatching', 'Section 303 theft; Section 304 snatching as forcible and sudden seizure of movable property.', 'New Offence', ARRAY['theft','snatching','stolen property']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 308–315', 'Sec. 383–395 IPC', 'Extortion, robbery and dacoity', 'Sections 308 extortion; 309 robbery; 310 dacoity; 313 gang robbery.', 'Mapped', ARRAY['extortion','robbery','dacoity','ransom']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 316', 'Sec. 405–409 IPC', 'Criminal breach of trust', 'Misappropriation of property by bankers, merchants, agents, or public servants.', 'Mapped', ARRAY['breach of trust','misappropriation','banker','agent']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 317', 'Sec. 410–414 IPC', 'Stolen property', 'Dishonestly receiving or retaining property acquired via theft, robbery, or extortion.', 'Mapped', ARRAY['stolen property','receiving stolen property']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 318–319', 'Sec. 415–420 IPC', 'Cheating and impersonation', 'Section 318 cheating; Section 318(4) replaces IPC 420 for cheating and inducing property delivery.', 'Key Shift', ARRAY['cheating','fraud','impersonation','deception']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 324–328', 'Sec. 425–440 IPC', 'Mischief and property damage', 'Destruction of public or private assets, animal killing, and utility infrastructure damage.', 'Mapped', ARRAY['mischief','property damage','vandalism','fire']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 329–334', 'Sec. 441–462 IPC', 'Criminal trespass and housebreaking', 'Unlawful entry, house-trespass by night, breaking open property receptacles.', 'Mapped', ARRAY['criminal trespass','house trespass','housebreaking','unlawful entry']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 335–344', 'Sec. 463–476A IPC', 'Forgery and document fraud', 'Forging valuable security, wills, court records, and using forged documents.', 'Mapped', ARRAY['forgery','false document','document fraud','electronic record']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 351–356', 'Sec. 499–502 IPC', 'Criminal intimidation and defamation', 'Section 351 criminal intimidation; Section 356 defamation allows community service penalty.', 'Updated', ARRAY['intimidation','threat','defamation','reputation']),
('BNS', 'Bharatiya Nyaya Sanhita, 2023', 'Sec. 357–358', 'Sec. 511 IPC', 'Attempts to commit offences', 'General residual section punishing attempts where no express rule exists.', 'Retained', ARRAY['attempt','preparation','offence']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 1–5', 'Sec. 1–5 CrPC', 'Definitions and constitution', 'Defines electronic communication, bail, complaint, abolishes third-class magistrates.', 'Amended', ARRAY['definitions','bail','complaint','magistrate']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 6–29', 'Sec. 6–25A CrPC', 'Courts and power hierarchy', 'Defines sessions and judicial magistrates and raises fine limits.', 'Updated', ARRAY['courts','magistrate','fine','jurisdiction']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 35', 'Sec. 41 CrPC', 'Arrest without warrant', 'Protects elderly and infirm from arrest without DSP permission for minor crimes.', 'Protection', ARRAY['arrest','warrant','elderly','infirm']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 37', 'Sec. 41B CrPC', 'Arrest procedure and designated officer', 'Requires designated officer in every district to maintain arrest information.', 'Mandatory', ARRAY['arrest','designated officer','district']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 43', 'Sec. 43 CrPC', 'Arrest by private person', 'Must hand over arrested person to police within six hours.', 'Strict Limit', ARRAY['private arrest','six hours','police']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 44', 'Sec. 44 CrPC', 'Handcuffing restrictions', 'Statutorily regulates handcuffing for habitual, terrorist, or terror offenders only.', 'Statutory Rule', ARRAY['handcuff','terrorist','habitual offender']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 51', 'Sec. 50A CrPC', 'Obligation to inform relatives', 'Mandatory immediate notification of arrest details to nominated relative or friend.', 'Enforced', ARRAY['arrest','relative','notification']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 53–54', 'Sec. 53–54 CrPC', 'Medical examination', 'Medical exam of accused and forwarding report directly to investigating officer.', 'Updated', ARRAY['medical examination','accused','investigation']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 105', 'Sec. 100 CrPC', 'Search and seizure videography', 'Mandates audio-video recording of all search and seizure procedures without delay.', 'Digital Mandate', ARRAY['search','seizure','videography','audio video']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 125–144', 'Sec. 106–124 CrPC', 'Security for peace and good behavior', 'Bonds for keeping peace and good behavior from suspected persons or habitual offenders.', 'Mapped', ARRAY['bond','peace','good behaviour','habitual offender']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 144–147', 'Sec. 125–128 CrPC', 'Maintenance of wife, children and parents', 'Summary procedure for maintenance orders and monthly allowances.', 'Mapped', ARRAY['maintenance','wife','children','parents']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 163', 'Sec. 144 CrPC', 'Urgent orders in nuisance or danger', 'Executive Magistrate preventive orders during public emergency.', 'Mapped', ARRAY['magistrate','nuisance','danger','preventive order']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 173', 'Sec. 154 CrPC', 'Information in cognizable cases (FIR)', 'Allows electronic FIR and requires a signed copy within three days.', 'Modernized', ARRAY['FIR','cognizable','electronic','information']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 174', 'New Concept', 'Zero FIR codification', 'Statutory right to lodge FIR at any police station regardless of territorial jurisdiction.', 'New Section', ARRAY['zero FIR','FIR','police station','jurisdiction']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 176', 'Sec. 157 CrPC', 'Forensic investigation', 'Mandatory forensic expert visit to crime scenes for offences punishable above seven years.', 'Mandatory', ARRAY['forensic','crime scene','investigation']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 180', 'Sec. 161 CrPC', 'Police examination of witnesses', 'Statements during investigation and audio-video statement capture.', 'Updated', ARRAY['witness','statement','audio video','investigation']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 183', 'Sec. 164 CrPC', 'Confessions and judicial statements', 'Magistrate recording and mandatory audio-video recording for sexual offences.', 'Tech Enhanced', ARRAY['confession','statement','magistrate','audio video']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 187', 'Sec. 167 CrPC', 'Police and judicial remand', '15-day police custody can be sought in parts across the statutory 40 or 60 day detention period.', 'Crucial Shift', ARRAY['remand','police custody','judicial custody']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 193', 'Sec. 173 CrPC', 'Police final report (challan)', 'Investigation must complete within 90 days and progress update within 90 days.', 'Time Limit', ARRAY['final report','challan','investigation','90 days']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 223–233', 'Sec. 190–203 CrPC', 'Cognizance and issue of process', 'Cognizance by Magistrates; section 223 requires notice to accused before taking cognizance on private complaint.', 'Accused Protection', ARRAY['cognizance','process','private complaint','magistrate']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 248–253', 'Sec. 225–235 CrPC', 'Sessions trial procedure', 'Discharge motion within 60 days; charges framed within 60 days; judgment in 45 days.', 'Strict Deadline', ARRAY['sessions trial','discharge','charge','judgment']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 254–269', 'Sec. 238–250 CrPC', 'Warrant cases by Magistrates', 'Procedure for cases instituted on police report versus private complaint.', 'Mapped', ARRAY['warrant case','magistrate','police report']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 270–278', 'Sec. 251–259 CrPC', 'Summons trial procedure', 'Substantive process for minor offences and rapid disposal timeline.', 'Mapped', ARRAY['summons trial','minor offence','disposal']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 283–293', 'Sec. 260–265 CrPC', 'Summary trials', 'Mandatory summary trial for petty offences with imprisonment up to three years.', 'Expanded', ARRAY['summary trial','petty offence']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 290', 'New Concept', 'Trial in absence of proclaimed offender', 'Enables trial and judgment in absentia for proclaimed offenders absconding justice.', 'In Absentia', ARRAY['proclaimed offender','absentia','absconding','trial']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 297–308', 'Sec. 265A–265L CrPC', 'Plea bargaining', 'Application within 30 days of charge framing for eligible offences.', 'Time-bound', ARRAY['plea bargaining','charge','30 days']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 356', 'Sec. 299 CrPC', 'Evidence in absence of accused', 'Recording of evidence when accused has absconded or cannot be immediately arrested.', 'Mapped', ARRAY['evidence','absconded','accused']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 436–439', 'Sec. 389–394 CrPC', 'Bail in bailable and non-bailable cases', 'Section 436 bailable offences right; Section 437 non-bailable judicial discretion rules.', 'Mapped', ARRAY['bail','bailable','non-bailable','bond']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 479', 'Sec. 436A CrPC', 'Maximum period of detention for undertrial', 'First-time offenders released on bail after completing one-third of maximum prison term.', 'Relief Scale', ARRAY['undertrial','detention','bail','first time offender']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 482', 'Sec. 438 CrPC', 'Anticipatory bail and inherent powers', 'Retains High Court and Sessions Court special bail powers.', 'Mapped', ARRAY['anticipatory bail','inherent powers','sessions court','high court']),
('BNSS', 'Bharatiya Nagarik Suraksha Sanhita, 2023', 'Sec. 530', 'New Concept', 'Electronic and virtual court proceedings', 'Statutory validation of virtual hearings and electronic evidence presentation.', 'Digital Court', ARRAY['virtual hearing','electronic evidence','e summons']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 1–2', 'Sec. 1–3 Evidence Act', 'Definitions and interpretation', 'Broadens document to explicitly include electronic files, emails, chats, and logs.', 'Expanded', ARRAY['document','electronic file','email','chat','log']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 3–15', 'Sec. 5–16 Evidence Act', 'Relevancy of facts and res gestae', 'Section 4 (res gestae) facts forming part of same transaction; motive and preparation.', 'Mapped', ARRAY['relevancy','res gestae','motive','preparation']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 16–21', 'Sec. 17–23 Evidence Act', 'Admissions in civil and criminal cases', 'Defines admissions, statements by agents, and protection of without prejudice offers.', 'Mapped', ARRAY['admission','agent','without prejudice']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 22–24', 'Sec. 24–30 Evidence Act', 'Confession rules', 'Confessions caused by threat, inducement, or irrelevant police confessions inadmissible.', 'Mapped', ARRAY['confession','threat','inducement','police confession']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 26', 'Sec. 32 Evidence Act', 'Dying declarations and statements', 'Statements by persons who cannot be called as witnesses, including dying declarations.', 'Retained', ARRAY['dying declaration','statement','deceased']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 39–45', 'Sec. 45–51 Evidence Act', 'Expert and third-party opinions', 'Expert opinion expressly covers cyber forensics, digital examiners, and medical experts.', 'Modernized', ARRAY['expert','cyber forensics','digital examiner','medical expert']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 56–58', 'Sec. 61–63 Evidence Act', 'Primary and secondary evidence', 'Defines primary document proof; Section 57 includes original electronic records in multiple files.', 'Digital Shift', ARRAY['primary evidence','secondary evidence','electronic record','original']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 61', 'Sec. 65B Evidence Act', 'Electronic record admissibility', 'Establishes mandatory certificate conditions for admitting digital or electronic evidence.', 'Core Provision', ARRAY['electronic evidence','65B','certificate','admissibility']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 74–93', 'Sec. 79–90A Evidence Act', 'Presumptions as to documents', 'Presumptions on electronic gazettes, digital signatures, power of attorney, cyber records.', 'Tech Presumption', ARRAY['presumption','digital signature','electronic gazette','cyber record']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 104–114', 'Sec. 101–111 Evidence Act', 'Burden of proof', 'Section 104 onus of proof; Section 108 burden of proving cases falls under general BNS exceptions.', 'Mapped', ARRAY['burden of proof','onus','general exception']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 117–118', 'Sec. 113A–113B Evidence Act', 'Presumptions in suicide and dowry deaths', 'Mandatory legal presumption against husband or relatives in dowry deaths within seven years.', 'Mapped', ARRAY['dowry death','suicide','presumption','husband']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 121–127', 'Sec. 115–117 Evidence Act', 'Estoppel principles', 'Prevents parties from denying previous declarations, acts, or contractual standings.', 'Retained', ARRAY['estoppel','declaration','contract']),
('BSA', 'Bharatiya Sakshya Adhiniyam, 2023', 'Sec. 128–139', 'Sec. 118–134 Evidence Act', 'Witness competency and privilege', 'Section 132 protects professional privilege; Section 135 accomplice witness testimony rules.', 'Mapped', ARRAY['witness','privilege','professional privilege','accomplice']);

