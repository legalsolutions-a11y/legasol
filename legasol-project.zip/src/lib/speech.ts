/**
 * Advanced Speech Recognition & Text-to-Speech Engine
 * With multi-layer anti-repetition deduplication for Laptops, Tablets, and Smartphones.
 */

export function speakText(text: string, lang: 'en-IN' | 'hi-IN' = 'en-IN'): void {
  if (!('speechSynthesis' in window)) {
    console.warn('Speech synthesis not supported');
    return;
  }

  // Cancel any ongoing speech
  window.speechSynthesis.cancel();

  // Clean text from legal markdown/symbols
  const clean = text
    .replace(/[#*•_\[\]]/g, '')
    .replace(/➔/g, 'to')
    .slice(0, 400);

  const utterance = new SpeechSynthesisUtterance(clean);
  utterance.lang = lang;
  utterance.rate = 0.95; // slightly slower for high clarity
  utterance.pitch = 1.0;

  // Attempt to select an Indian English or Hindi voice if available
  const voices = window.speechSynthesis.getVoices();
  const indianVoice = voices.find(v => v.lang.includes('IN') || v.lang.includes('hi') || v.name.includes('India'));
  if (indianVoice) {
    utterance.voice = indianVoice;
  }

  window.speechSynthesis.speak(utterance);
}

export function stopSpeaking(): void {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

/**
 * Intelligent cross-platform speech deduplicator.
 * Removes repeated sentences, clauses, and phrases caused by Web Speech API
 * restarting or streaming overlapping final/interim tokens on Android/iOS/Chrome.
 */
export function cleanDuplicateSpeech(rawText: string): string {
  if (!rawText || !rawText.trim()) return '';

  let text = rawText.replace(/\s+/g, ' ').trim();

  // 1. Remove immediate duplicate single words: "the the" -> "the"
  text = text.replace(/\b(\w+)\s+\1\b/gi, '$1');

  // 2. Remove immediate duplicate 2-word pairs: "near market near market" -> "near market"
  text = text.replace(/\b(\w+\s+\w+)\s+\1\b/gi, '$1');

  // 3. Remove immediate duplicate 3-word phrases: "on the road on the road" -> "on the road"
  text = text.replace(/\b(\w+\s+\w+\s+\w+)\s+\1\b/gi, '$1');

  // 4. Remove immediate duplicate 4-word phrases: "i was walking home i was walking home"
  text = text.replace(/\b(\w+\s+\w+\s+\w+\s+\w+)\s+\1\b/gi, '$1');

  // 5. Remove immediate duplicate 5-word to 8-word phrases
  text = text.replace(/\b(\w+\s+\w+\s+\w+\s+\w+\s+\w+)\s+\1\b/gi, '$1');

  // 6. Sentence-level deduplication:
  // e.g. "My phone was stolen yesterday. My phone was stolen yesterday." -> "My phone was stolen yesterday."
  const sentenceDelimiters = /([.?!,;\n]+)/;
  const tokens = text.split(sentenceDelimiters);
  const resultTokens: string[] = [];
  
  for (let i = 0; i < tokens.length; i++) {
    const segment = tokens[i].trim();
    if (!segment) {
      if (tokens[i]) resultTokens.push(tokens[i]);
      continue;
    }

    // Check if this segment is identical or 90% overlapping with the previous segment
    const prevSeg = resultTokens.length >= 2 ? resultTokens[resultTokens.length - 2].trim() : '';
    const normCur = segment.toLowerCase().replace(/[^a-z0-9]/g, '');
    const normPrev = prevSeg.toLowerCase().replace(/[^a-z0-9]/g, '');

    if (normCur && normPrev && normCur === normPrev) {
      // Skip the repeated sentence and its punctuation
      if (i + 1 < tokens.length && /^[.?!,;]/.test(tokens[i + 1])) {
        i++; // skip punctuation
      }
      continue;
    }

    resultTokens.push(tokens[i]);
  }

  text = resultTokens.join('').replace(/\s+/g, ' ').trim();

  // 7. Suffix/Prefix overlap removal (e.g. "I went to the police station" + "the police station was closed")
  // Or Android Chrome bug where entire sentence is re-emitted:
  const words = text.split(' ');
  const n = words.length;
  if (n >= 6) {
    // Check if the second half of words repeats the first half
    for (let len = 3; len <= Math.floor(n / 2); len++) {
      const chunkA = words.slice(n - 2 * len, n - len).join(' ').toLowerCase();
      const chunkB = words.slice(n - len).join(' ').toLowerCase();
      if (chunkA === chunkB) {
        words.splice(n - len, len);
        text = words.join(' ');
        break;
      }
    }
  }

  return text;
}

/**
 * Merges existing base text with a newly received chunk without repeating words
 * that overlap across the junction boundary.
 */
export function mergeSpeechChunks(baseText: string, newChunk: string): string {
  const base = (baseText || '').trim();
  const chunk = (newChunk || '').trim();

  if (!base) return cleanDuplicateSpeech(chunk);
  if (!chunk) return cleanDuplicateSpeech(base);

  // If base already contains the chunk at the end, do nothing
  if (base.toLowerCase().endsWith(chunk.toLowerCase())) {
    return base;
  }

  // If chunk begins with the entire base, return chunk
  if (chunk.toLowerCase().startsWith(base.toLowerCase())) {
    return cleanDuplicateSpeech(chunk);
  }

  const baseWords = base.split(/\s+/);
  const chunkWords = chunk.split(/\s+/);

  // Check for word-level suffix-prefix overlap (up to 8 words)
  const maxOverlap = Math.min(baseWords.length, chunkWords.length, 8);
  let bestOverlapCount = 0;

  for (let len = maxOverlap; len >= 1; len--) {
    const baseTail = baseWords.slice(baseWords.length - len).map(w => w.toLowerCase().replace(/[^a-z0-9]/g, '')).join(' ');
    const chunkHead = chunkWords.slice(0, len).map(w => w.toLowerCase().replace(/[^a-z0-9]/g, '')).join(' ');

    if (baseTail === chunkHead && baseTail.length > 0) {
      bestOverlapCount = len;
      break;
    }
  }

  let merged: string;
  if (bestOverlapCount > 0) {
    // Drop the overlapping words from chunk
    const nonOverlappingChunk = chunkWords.slice(bestOverlapCount).join(' ');
    merged = `${base} ${nonOverlappingChunk}`.trim();
  } else {
    merged = `${base} ${chunk}`.trim();
  }

  return cleanDuplicateSpeech(merged);
}

/**
 * Robust Cross-Platform Speech Controller
/**
 * Converts common spoken punctuation commands into punctuation marks.
 */
export function applyVoicePunctuation(rawText: string): string {
  if (!rawText) return '';
  return rawText
    .replace(/\s+(?:full stop|period)\b/gi, '.')
    .replace(/\s+comma\b/gi, ',')
    .replace(/\s+question mark\b/gi, '?')
    .replace(/\s+exclamation mark\b/gi, '!')
    .replace(/\s+(?:new line|next line)\b/gi, '\n')
    .replace(/\s+new paragraph\b/gi, '\n\n')
    .replace(/\s+colon\b/gi, ':')
    .replace(/\s+semicolon\b/gi, ';');
}

/**
 * Robust Cross-Platform Speech Controller
 * Guaranteed to prevent repeated words/sentences on Android, iOS, iPad, Mac & Windows
 */
export class GlitchFreeSpeechRecognizer {
  private recognition: any = null;
  private isListening: boolean = false;
  private baseCommittedText: string = '';
  private currentSessionFinal: string = '';
  private language: string = 'en-IN';
  private onUpdateCallback: (fullText: string, isFinal: boolean) => void;
  private onStatusCallback?: (status: string) => void;
  private onInterimCallback?: (interim: string) => void;
  private onSoundLevelCallback?: (level: number) => void;

  private audioContext: any = null;
  private mediaStream: MediaStream | null = null;
  private animFrameId: number | null = null;

  constructor(
    onUpdate: (fullText: string, isFinal: boolean) => void,
    onStatus?: (status: string) => void,
    initialLanguage: string = 'en-IN',
    onInterim?: (interim: string) => void,
    onSoundLevel?: (level: number) => void
  ) {
    this.onUpdateCallback = onUpdate;
    this.onStatusCallback = onStatus;
    this.language = initialLanguage;
    this.onInterimCallback = onInterim;
    this.onSoundLevelCallback = onSoundLevel;
  }

  public setLanguage(lang: string) {
    this.language = lang;
    if (this.recognition) {
      this.recognition.lang = lang;
    }
  }

  private startAudioMonitoring() {
    if (!this.onSoundLevelCallback || typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) return;
    navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
      if (!this.isListening) {
        stream.getTracks().forEach(t => t.stop());
        return;
      }
      this.mediaStream = stream;
      const AudioCtx = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.audioContext = new AudioCtx();
      const source = this.audioContext.createMediaStreamSource(stream);
      const analyser = this.audioContext.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.4;
      source.connect(analyser);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const checkLevel = () => {
        if (!this.isListening) return;
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        // Normalise to 0 - 100
        const level = Math.min(100, Math.round((avg / 128) * 100));
        if (this.onSoundLevelCallback) {
          this.onSoundLevelCallback(level);
        }
        this.animFrameId = requestAnimationFrame(checkLevel);
      };
      checkLevel();
    }).catch(e => {
      console.warn('Audio level monitoring not available:', e);
    });
  }

  private stopAudioMonitoring() {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
    if (this.audioContext) {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }
    if (this.onSoundLevelCallback) {
      this.onSoundLevelCallback(0);
    }
  }

  public start(existingText: string = ''): boolean {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      if (this.onStatusCallback) {
        this.onStatusCallback('Speech recognition is not supported in this browser. Please use Chrome or Edge.');
      }
      return false;
    }

    this.stop(); // Stop any previous instance

    this.isListening = true;
    this.baseCommittedText = (existingText || '').trim();
    this.currentSessionFinal = '';

    try {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = true;
      this.recognition.interimResults = true;
      this.recognition.lang = this.language;
      this.recognition.maxAlternatives = 1;

      this.recognition.onresult = (event: any) => {
        let sessionFinal = '';
        let sessionInterim = '';

        // Iterate through all results in the current session
        for (let i = 0; i < event.results.length; ++i) {
          const item = event.results[i];
          const part = item[0]?.transcript?.trim() || '';
          if (!part) continue;

          if (item.isFinal) {
            sessionFinal = sessionFinal ? `${sessionFinal} ${part}` : part;
          } else {
            sessionInterim = sessionInterim ? `${sessionInterim} ${part}` : part;
          }
        }

        // Clean internal session final to prevent speech engine self-duplication
        sessionFinal = cleanDuplicateSpeech(sessionFinal);
        sessionFinal = applyVoicePunctuation(sessionFinal);
        this.currentSessionFinal = sessionFinal;

        if (this.onInterimCallback) {
          this.onInterimCallback(sessionInterim);
        }

        // Merge base text with session final
        const committedSoFar = mergeSpeechChunks(this.baseCommittedText, sessionFinal);

        // Attach transient interim without committing
        const displayText = sessionInterim 
          ? mergeSpeechChunks(committedSoFar, sessionInterim)
          : committedSoFar;

        this.onUpdateCallback(displayText, false);
      };

      this.recognition.onerror = (e: any) => {
        console.warn('SpeechRecognition status:', e.error);
        if (e.error === 'not-allowed') {
          this.stopAudioMonitoring();
          if (this.onStatusCallback) {
            this.onStatusCallback('Microphone permission denied. Please allow microphone access in your browser settings.');
          }
        } else if (e.error === 'no-speech') {
          if (this.onStatusCallback) {
            this.onStatusCallback('Listening... (Hands-free voice detection active)');
          }
        }
      };

      this.recognition.onend = () => {
        // If still supposed to be listening (e.g. continuous pause on mobile / tablet)
        if (this.isListening) {
          // Commit current session final to base text before restart
          this.baseCommittedText = mergeSpeechChunks(this.baseCommittedText, this.currentSessionFinal);
          this.currentSessionFinal = '';

          try {
            this.recognition.start();
          } catch (err) {
            // Ignore retry collisions
          }
        }
      };

      this.recognition.start();
      this.startAudioMonitoring();
      if (this.onStatusCallback) {
        this.onStatusCallback('Listening... Speak your complaint clearly (hands-free active).');
      }
      return true;
    } catch (err) {
      console.error('Failed to start SpeechRecognition:', err);
      this.isListening = false;
      this.stopAudioMonitoring();
      return false;
    }
  }

  public stop(): string {
    this.isListening = false;
    this.stopAudioMonitoring();
    if (this.onInterimCallback) {
      this.onInterimCallback('');
    }
    if (this.recognition) {
      try {
        this.recognition.onend = null;
        this.recognition.onerror = null;
        this.recognition.onresult = null;
        this.recognition.stop();
      } catch {}
      this.recognition = null;
    }

    const finalText = mergeSpeechChunks(this.baseCommittedText, this.currentSessionFinal);
    const cleaned = applyVoicePunctuation(cleanDuplicateSpeech(finalText));
    this.onUpdateCallback(cleaned, true);
    if (this.onStatusCallback) {
      this.onStatusCallback('Recording stopped. Text captured.');
    }
    return cleaned;
  }

  public isActive(): boolean {
    return this.isListening;
  }
}
