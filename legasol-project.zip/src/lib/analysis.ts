import { BNS_SECTIONS, IPC_TO_BNS_MAP, BNSSection } from '../data/bnsSections';

export interface ExtractedFIRMetadata {
  firNumber: string;
  policeStation: string;
  district: string;
  dateOccurrence: string;
  complainant: string;
  accused: string;
  detectedIpcSections: string[];
  detectedBnsSections: string[];
  sectionDetails: BNSSection[];
  severityLevel: 'Critical' | 'Major' | 'Moderate' | 'Minor';
  isCognizableOverall: boolean;
  isBailableOverall: boolean;
  bailScore: number;
  bailFactors: { favoring: string[]; opposing: string[] };
  proceduralMandates: string[];
  caseNature: string;
  factualInsights: string[];
}

export interface DiscrepancyResult {
  similarityScore: number;
  timelineMatch: boolean;
  timelineDiff: string;
  accusedDiscrepancies: string[];
  weaponDiscrepancies: string[];
  sectionAdditions: string[];
  sectionOmissions: string[];
  factualContradictions: string[];
  riskAssessment: string;
  recommendation: string;
}

export interface ComplaintPartAnalysis {
  label: string; // 'Part A' or 'Part B'
  riskTitle: string; // 'Part A Risk' or 'Part B Risk'
  riskBadge: 'SEVERE RISK' | 'HIGH RISK' | 'MODERATE RISK' | 'LOW RISK';
  severity: 'Very High' | 'High' | 'Moderate' | 'Low';
  evidence: 'Strong' | 'Moderate' | 'Weak';
  cognizableCount: number;
  detail: 'Detailed' | 'Moderate' | 'Vague';
  bailableCount: number;
  nonBailableCount: number;
  weaponInvolvement: string; // 'No weapons mentioned' or 'Weapon mentioned (gun)'
  financialAspect: string; // 'No financial aspect' or 'Financial fraud detected'
  identifiedSections: {
    code: string; // e.g. "§103"
    bnsSection: string;
    ipcSection: string;
    title: string;
    bnsTitle: string;
    cognizable: boolean;
    bailable: boolean;
    punishment: string;
    court: string;
  }[];
  potentialOutcomes: string[];
  rawText: string;
}

export interface DetailedComparisonResult {
  recommendation: string;
  partA: ComplaintPartAnalysis;
  partB: ComplaintPartAnalysis;
  similarities: string;
  commonSections: string[];
}

export function parseAndAnalyzeFIR(rawText: string): ExtractedFIRMetadata {
  const text = rawText || '';

  // Extract FIR Number
  const firMatch = text.match(/(?:FIR\s*(?:No\.?|Number)?[:\s-]*)([A-Z0-9\/\-_]+)/i);
  const firNumber = firMatch ? firMatch[0].trim() : 'Unnumbered / Draft FIR';

  // Extract Police Station
  const psMatch = text.match(/(?:Police\s*Station|PS|P\.S\.)[:\s-]*([A-Za-z0-9\s,]+?)(?:,|\n|\.|\bDistrict\b)/i);
  const policeStation = psMatch ? psMatch[1].trim() : 'Local Police Station';

  // Extract District
  const distMatch = text.match(/(?:District|Dist\.?)[:\s-]*([A-Za-z\s]+?)(?:,|\n|\.|\bState\b)/i);
  const district = distMatch ? distMatch[1].trim() : 'District Jurisdiction';

  // Extract Date/Time of occurrence
  const dateMatch = text.match(/(?:Date\s*(?:&|and)?\s*Time|Occurrence|Date\s*of\s*Occurrence)[:\s-]*([0-9\/\-:,\sAPMapm]+(?:\bhrs\b|\bhours\b)?)/i);
  const dateOccurrence = dateMatch ? dateMatch[1].trim() : 'Date/Time noted in GD';

  // Extract Complainant
  const compMatch = text.match(/(?:Complainant|Informant|Applicant)[:\s-]*([A-Za-z0-9\s,\.\(\)]+?)(?:,|\n|Age|Address)/i);
  const complainant = compMatch ? compMatch[1].trim() : 'Informant / Victim';

  // Extract Accused
  const accusedMatch = text.match(/(?:Accused|Suspected|Known\/Suspected)[:\s-]*([A-Za-z0-9\s,\.\(\)\-]+?)(?:\n|Place|Brief|3\.)/i);
  const accused = accusedMatch ? accusedMatch[1].trim() : 'Named / Unknown Suspects';

  // Detect IPC sections mentioned in text
  const detectedIpc: string[] = [];
  const ipcRegex = /\b(?:IPC|I\.P\.C\.?|Section|Sec\.?|U\/S|u\/s)?\s*(\d{2,3}[A-Z]?|\d{1,3}\(\d+\))\b/gi;
  let match;
  while ((match = ipcRegex.exec(text)) !== null) {
    const candidate = match[1].toUpperCase();
    if (IPC_TO_BNS_MAP[candidate] && !detectedIpc.includes(candidate)) {
      detectedIpc.push(candidate);
    }
  }

  // Also check common numeric sections directly if IPC or BNS mentioned
  const commonIpcList = ['302', '304', '304A', '307', '323', '324', '325', '326A', '341', '376', '379', '384', '392', '395', '406', '419', '420', '447', '452', '468', '471', '498A', '506', '34', '120B', '147', '148', '149', '279'];
  for (const sec of commonIpcList) {
    const rx = new RegExp(`\\b${sec}\\b`);
    if (rx.test(text) && !detectedIpc.includes(sec)) {
      detectedIpc.push(sec);
    }
  }

  // Map to BNS sections
  const detectedBns: string[] = [];
  const sectionDetails: BNSSection[] = [];

  for (const ipc of detectedIpc) {
    const bnsCode = IPC_TO_BNS_MAP[ipc];
    if (bnsCode && !detectedBns.includes(bnsCode)) {
      detectedBns.push(bnsCode);
      const detail = BNS_SECTIONS.find(s => s.ipcSection === ipc || s.bnsSection === bnsCode);
      if (detail) {
        sectionDetails.push(detail);
      }
    }
  }

  // If no sections detected, provide default general Hurt/Threat fallback or read keywords
  if (sectionDetails.length === 0) {
    if (/death|murder|killed|dead/i.test(text)) {
      const def = BNS_SECTIONS.find(s => s.bnsSection === '103(1)')!;
      detectedBns.push('103(1)');
      detectedIpc.push('302');
      sectionDetails.push(def);
    } else if (/cheat|fraud|money|scam|transfer|lakh/i.test(text)) {
      const def = BNS_SECTIONS.find(s => s.bnsSection === '318(4)')!;
      detectedBns.push('318(4)');
      detectedIpc.push('420');
      sectionDetails.push(def);
    } else if (/accident|hit\s*and\s*run|driving|car|bike/i.test(text)) {
      const def = BNS_SECTIONS.find(s => s.bnsSection === '106(2)')!;
      detectedBns.push('106(2)');
      detectedIpc.push('304A');
      sectionDetails.push(def);
    } else {
      const def = BNS_SECTIONS.find(s => s.bnsSection === '115(2)')!;
      detectedBns.push('115(2)');
      detectedIpc.push('323');
      sectionDetails.push(def);
    }
  }

  // Determine Severity and Bail Score
  const hasCritical = sectionDetails.some(s => s.severity === 'Critical');
  const hasMajor = sectionDetails.some(s => s.severity === 'Major');
  const severityLevel: 'Critical' | 'Major' | 'Moderate' | 'Minor' = 
    hasCritical ? 'Critical' : hasMajor ? 'Major' : sectionDetails.some(s => s.severity === 'Moderate') ? 'Moderate' : 'Minor';

  const isCognizableOverall = sectionDetails.some(s => s.cognizable);
  const isBailableOverall = sectionDetails.every(s => s.bailable);

  // Compute Bail probability score (0 to 100)
  let bailScore = 50;
  const favoring: string[] = [];
  const opposing: string[] = [];

  if (isBailableOverall) {
    bailScore += 35;
    favoring.push("All prima facie alleged sections are bailable as of statutory right (BNSS Section 479).");
  } else {
    bailScore -= 30;
    opposing.push("Involves non-bailable offense under BNS with prescribed sentence exceeding 7 years.");
  }

  if (/weapon|iron rod|knife|gun|firearm|pistol/i.test(text)) {
    bailScore -= 15;
    opposing.push("Allegation of deadly weapon recovery or weapon usage diminishes bail prospects.");
  } else {
    favoring.push("No firearm or lethal weapon recovery reported from immediate crime scene.");
  }

  if (/cctv|video|footage|recording/i.test(text)) {
    bailScore -= 10;
    opposing.push("Direct digital/CCTV ocular evidence cited under Section 61 Bharatiya Sakshya Adhiniyam.");
  }

  if (/surrender|voluntary|cooperated|complied/i.test(text)) {
    bailScore += 15;
    favoring.push("Accused demonstrated voluntary cooperation or lack of immediate flight risk.");
  }

  if (/fled|absconding|ran away|hit and run/i.test(text)) {
    bailScore -= 15;
    opposing.push("Accused fled scene; risk of absconding and non-cooperation highlighted by prosecution.");
  }

  bailScore = Math.max(5, Math.min(95, bailScore));

  // Procedural mandates under BNSS 2023
  const proceduralMandates: string[] = [
    "BNSS Sec 173: Zero FIR provision applies - FIR must be registered irrespective of territorial jurisdiction and transferred within 24 hours.",
    "BNSS Sec 105: All search and seizure proceedings must be recorded using mobile/video recording.",
    "BNSS Sec 36: Arresting officer must immediately inform the designated relative or friend of the accused.",
    "BSA Sec 61: Electronic records and digital communication must be authenticated via digital signature or certificate."
  ];

  if (hasCritical) {
    proceduralMandates.unshift("BNSS Sec 176(3): Offense punishable with 7+ years imprisonment requires mandatory forensic investigation team visit to scene of crime.");
  }

  // Factual insights
  const factualInsights: string[] = [];
  if (/hit\s*and\s*run|fled.*scene|vehicle.*escap/i.test(text)) {
    factualInsights.push("High Hit-and-Run indicator detected: BNS Section 106(2) prescribes enhanced up to 10 years imprisonment.");
  }
  if (/mob|group|5 or more|crowd|caste|religion/i.test(text)) {
    factualInsights.push("Group identity element detected: Evaluated for BNS Section 103(2) (Mob Lynching / Hate Crimes).");
  }
  if (/cheat|otp|bank|transfer|spoof|cbi|arrest/i.test(text)) {
    factualInsights.push("Digital/Cyber fraud modus operandi identified: Asset attachment under BNSS Section 107 recommended.");
  }
  if (/injury|fracture|laceration|hospital|mlc/i.test(text)) {
    factualInsights.push("Physical trauma recorded: Requires verification with Medico-Legal Case (MLC) certificate.");
  }

  let caseNature = "General Offense";
  if (hasCritical) caseNature = "Heinous / Sessions-Triable Offense";
  else if (hasMajor) caseNature = "Serious Cognizable Crime";
  else caseNature = "Compoundable / Magistrate-Triable Dispute";

  return {
    firNumber,
    policeStation,
    district,
    dateOccurrence,
    complainant,
    accused,
    detectedIpcSections: detectedIpc,
    detectedBnsSections: detectedBns,
    sectionDetails,
    severityLevel,
    isCognizableOverall,
    isBailableOverall,
    bailScore,
    bailFactors: { favoring, opposing },
    proceduralMandates,
    caseNature,
    factualInsights
  };
}

export function compareTwoFIRs(fir1Text: string, fir2Text: string): DiscrepancyResult {
  const p1 = parseAndAnalyzeFIR(fir1Text);
  const p2 = parseAndAnalyzeFIR(fir2Text);

  const contradictions: string[] = [];
  const accusedDiff: string[] = [];
  const weaponDiff: string[] = [];

  // Check section additions / omissions
  const sectionAdditions = p2.detectedBnsSections.filter(s => !p1.detectedBnsSections.includes(s));
  const sectionOmissions = p1.detectedBnsSections.filter(s => !p2.detectedBnsSections.includes(s));

  // Check timeline
  const time1 = p1.dateOccurrence.toLowerCase();
  const time2 = p2.dateOccurrence.toLowerCase();
  const timelineMatch = time1.length > 5 && time2.length > 5 && (time1.includes(time2) || time2.includes(time1));
  const timelineDiff = timelineMatch 
    ? "Timelines align consistently between both records."
    : `Discrepancy noted in occurrence timings: Record A states '${p1.dateOccurrence}', while Record B states '${p2.dateOccurrence}'.`;

  // Weapon comparison
  const w1 = /iron rod|knife|blade|gun|lathi|stick|sword|acid/i.test(fir1Text);
  const w2 = /iron rod|knife|blade|gun|lathi|stick|sword|acid/i.test(fir2Text);
  if (w1 !== w2) {
    weaponDiff.push(w1 
      ? "Primary record alleges use of armed lethal weapons, whereas counter record minimizes weapon involvement."
      : "Counter record introduces allegations of weapons absent in primary report."
    );
  }

  // Cross accused check
  if (p1.accused !== p2.accused) {
    accusedDiff.push(`Named entities vary: Version A cites '${p1.accused}' while Version B cites '${p2.accused}'.`);
  }

  // Factual contradictions
  if (/hit and run|escaped/i.test(fir1Text) && /mob|lynch|surrender/i.test(fir2Text)) {
    contradictions.push("Driver flight reason contradiction: Primary alleges wanton hit-and-run evasion; Counter-statement claims fleeing due to imminent threat of unlawful mob violence.");
  }
  if (/unprovoked|trespass/i.test(fir1Text) && /self-defense|provok|peaceful/i.test(fir2Text)) {
    contradictions.push("Aggression origin contradiction: Record A depicts unprovoked armed aggression, while Record B asserts lawful private defense under BNS Sections 34-44.");
  }
  if (sectionAdditions.length > 0) {
    contradictions.push(`Statutory variation: Secondary document introduces additional penal sections: BNS ${sectionAdditions.join(', ')}.`);
  }

  // Calculate similarity score (0 to 100)
  const commonSections = p1.detectedBnsSections.filter(s => p2.detectedBnsSections.includes(s)).length;
  const totalSections = Math.max(1, new Set([...p1.detectedBnsSections, ...p2.detectedBnsSections]).size);
  let sim = Math.round((commonSections / totalSections) * 50);
  if (timelineMatch) sim += 20;
  if (weaponDiff.length === 0) sim += 15;
  if (contradictions.length === 0) sim += 15;
  sim = Math.max(15, Math.min(95, sim));

  let riskAssessment = "Low Risk of Fabrication";
  let recommendation = "Both records exhibit high narrative alignment. Standard prosecution procedure under BNSS Section 193 applies.";

  if (sim < 50) {
    riskAssessment = "High Probability of Embellishment / Cross-Counter Malice";
    recommendation = "Judicial Magistrate inquiry under BNSS Section 223 strongly recommended. Mandatory forensic review of CCTV and phone CDR to eliminate malicious prosecution.";
  } else if (sim < 75) {
    riskAssessment = "Moderate Material Contradictions Detected";
    recommendation = "Cross-examination should focus on the divergent timeline statements and weapon recovery under Section 23 of Bharatiya Sakshya Adhiniyam.";
  }

  return {
    similarityScore: sim,
    timelineMatch,
    timelineDiff,
    accusedDiscrepancies: accusedDiff,
    weaponDiscrepancies: weaponDiff,
    sectionAdditions,
    sectionOmissions,
    factualContradictions: contradictions,
    riskAssessment,
    recommendation
  };
}

export function analyzePartComplaint(text: string, label: 'Part A' | 'Part B'): ComplaintPartAnalysis {
  const trimmed = (text || '').trim();
  const words = trimmed ? trimmed.split(/\s+/).length : 0;
  const lower = trimmed.toLowerCase();

  const identifiedSections: ComplaintPartAnalysis['identifiedSections'] = [];

  // 1. Specific crime recognition
  if (/\b(?:murder|homicide|killed|dead body|killing|assassinated)\b/i.test(trimmed)) {
    const sec = BNS_SECTIONS.find(s => s.bnsSection === '103(1)') || {
      bnsSection: '103(1)',
      ipcSection: '302',
      title: 'Punishment for Murder',
      bnsTitle: 'Murder (General)',
      cognizable: true,
      bailable: false,
      punishment: 'Death or Imprisonment for life, and fine',
      court: 'Court of Session'
    };
    identifiedSections.push({
      code: '§103',
      bnsSection: sec.bnsSection,
      ipcSection: sec.ipcSection,
      title: sec.title,
      bnsTitle: sec.bnsTitle,
      cognizable: sec.cognizable,
      bailable: sec.bailable,
      punishment: sec.punishment,
      court: sec.court
    });
  }

  // Mob lynching (requires multi-word or group context)
  if (/\bmob\s+lynch(?:ing)?\b|\bgroup\s+of\s+(?:people|persons|five)\s+killed\b/i.test(trimmed)) {
    const sec = BNS_SECTIONS.find(s => s.bnsSection === '103(2)');
    if (sec) {
      identifiedSections.push({
        code: '§103(2)',
        bnsSection: sec.bnsSection,
        ipcSection: sec.ipcSection,
        title: sec.title,
        bnsTitle: sec.bnsTitle,
        cognizable: sec.cognizable,
        bailable: sec.bailable,
        punishment: sec.punishment,
        court: sec.court
      });
    }
  }

  // Attempt to murder
  if (/\b(?:attempt\s+to\s+murder|stabbed|shot\s+at|fired\s+at)\b/i.test(trimmed) && !identifiedSections.some(s => s.code.includes('103'))) {
    const sec = BNS_SECTIONS.find(s => s.bnsSection === '109');
    if (sec) {
      identifiedSections.push({
        code: '§109',
        bnsSection: sec.bnsSection,
        ipcSection: sec.ipcSection,
        title: sec.title,
        bnsTitle: sec.bnsTitle,
        cognizable: sec.cognizable,
        bailable: sec.bailable,
        punishment: sec.punishment,
        court: sec.court
      });
    }
  }

  // Theft
  if (/\b(?:theft|stole|stolen|robbed|pickpocket|theft\s+of)\b/i.test(trimmed) && !identifiedSections.some(s => s.code.includes('303'))) {
    const sec = BNS_SECTIONS.find(s => s.bnsSection === '303(2)');
    if (sec) {
      identifiedSections.push({
        code: '§303',
        bnsSection: sec.bnsSection,
        ipcSection: sec.ipcSection,
        title: sec.title,
        bnsTitle: sec.bnsTitle,
        cognizable: sec.cognizable,
        bailable: sec.bailable,
        punishment: sec.punishment,
        court: sec.court
      });
    }
  }

  // Cheating / Fraud
  if (/\b(?:cheat|cheated|cheating|fraud|scam|embezzle|phishing|unauthorized\s+transfer)\b/i.test(trimmed) && !identifiedSections.some(s => s.code.includes('318'))) {
    const sec = BNS_SECTIONS.find(s => s.bnsSection === '318(4)');
    if (sec) {
      identifiedSections.push({
        code: '§318(4)',
        bnsSection: sec.bnsSection,
        ipcSection: sec.ipcSection,
        title: sec.title,
        bnsTitle: sec.bnsTitle,
        cognizable: sec.cognizable,
        bailable: sec.bailable,
        punishment: sec.punishment,
        court: sec.court
      });
    }
  }

  // Accident / Hit and run
  if (/\b(?:accident|hit\s*and\s*run|rash\s+driving|car\s+crash)\b/i.test(trimmed)) {
    const sec = BNS_SECTIONS.find(s => s.bnsSection === '106(2)' || s.bnsSection === '106(1)');
    if (sec) {
      identifiedSections.push({
        code: '§106',
        bnsSection: sec.bnsSection,
        ipcSection: sec.ipcSection,
        title: sec.title,
        bnsTitle: sec.bnsTitle,
        cognizable: sec.cognizable,
        bailable: sec.bailable,
        punishment: sec.punishment,
        court: sec.court
      });
    }
  }

  // Explicit Section mentions like 302, 420, 376, 506
  const explicitSecs = trimmed.match(/\b(?:IPC|BNS|Section|Sec\.?|u\/s)?\s*(302|420|376|307|379|323|506|498A)\b/gi);
  if (explicitSecs) {
    for (const raw of explicitSecs) {
      const numMatch = raw.match(/\d{2,3}[A-Z]?/i);
      if (numMatch) {
        const num = numMatch[0].toUpperCase();
        const bnsEq = IPC_TO_BNS_MAP[num];
        if (bnsEq) {
          const sec = BNS_SECTIONS.find(s => s.bnsSection === bnsEq || s.ipcSection === num);
          if (sec && !identifiedSections.some(s => s.bnsSection === sec.bnsSection)) {
            identifiedSections.push({
              code: `§${sec.bnsSection.split('(')[0]}`,
              bnsSection: sec.bnsSection,
              ipcSection: sec.ipcSection,
              title: sec.title,
              bnsTitle: sec.bnsTitle,
              cognizable: sec.cognizable,
              bailable: sec.bailable,
              punishment: sec.punishment,
              court: sec.court
            });
          }
        }
      }
    }
  }

  // Weapon Involvement
  let weaponInvolvement = 'No weapons mentioned';
  const weaponRegex = /\b(gun|pistol|revolver|rifle|firearm|knife|dagger|blade|sword|iron rod|lathi|stick|baseball bat|acid|axe|machete|weapon)\b/i;
  const weaponMatch = trimmed.match(weaponRegex);
  if (weaponMatch) {
    const w = weaponMatch[1].toLowerCase();
    weaponInvolvement = `Weapon mentioned (${w})`;
  }

  // Financial Aspect
  let financialAspect = 'No financial aspect';
  const financialRegex = /\b(money|cash|bank|account|cheated|cheating|fraud|scam|transfer|transferred|rupees|rs\.?|inr|lakh|crore|extortion|ransom|bribe)\b/i;
  if (financialRegex.test(trimmed)) {
    const amtMatch = trimmed.match(/(?:rs\.?|rupees|₹)\s*([\d,]+(?:\s*(?:lakh|crore|thousand))?)/i);
    if (amtMatch) {
      financialAspect = `Financial fraud / ₹${amtMatch[1]} detected`;
    } else {
      financialAspect = 'Financial fraud detected';
    }
  }

  // Counts
  const cognizableCount = identifiedSections.filter(s => s.cognizable).length;
  const nonBailableCount = identifiedSections.filter(s => !s.bailable).length;
  const bailableCount = identifiedSections.filter(s => s.bailable).length;

  // Severity Level
  let severity: 'Very High' | 'High' | 'Moderate' | 'Low' = 'Low';
  if (identifiedSections.some(s => ['103(1)', '103(2)', '64', '309', '109'].includes(s.bnsSection)) || /\b(?:murder|death|killed|rape)\b/i.test(trimmed)) {
    severity = 'Very High';
  } else if (identifiedSections.some(s => ['308', '137', '318(4)'].includes(s.bnsSection))) {
    severity = 'High';
  } else if (identifiedSections.length > 0) {
    severity = 'Moderate';
  } else {
    severity = 'Low';
  }

  // Risk Badge
  let riskBadge: 'SEVERE RISK' | 'HIGH RISK' | 'MODERATE RISK' | 'LOW RISK' = 'LOW RISK';
  if (severity === 'Very High' || nonBailableCount > 0) {
    riskBadge = 'SEVERE RISK';
  } else if (severity === 'High') {
    riskBadge = 'HIGH RISK';
  } else if (severity === 'Moderate' || cognizableCount > 0) {
    riskBadge = 'MODERATE RISK';
  } else {
    riskBadge = 'LOW RISK';
  }

  // Evidence
  let evidence: 'Strong' | 'Moderate' | 'Weak' = 'Weak';
  const strongEvidence = /\b(cctv|camera|video|recording|footage|medical report|mlc|post mortem|post-mortem|hospital|doctor|forensic|ballistic|bank statement)\b/i;
  const moderateEvidence = /\b(witness|eyewitness|seen by|neighbor|passerby|screenshot|receipt|bill|audio)\b/i;
  if (strongEvidence.test(trimmed)) {
    evidence = 'Strong';
  } else if (moderateEvidence.test(trimmed)) {
    evidence = 'Moderate';
  } else {
    evidence = 'Weak';
  }

  // Detail
  let detail: 'Detailed' | 'Moderate' | 'Vague' = 'Vague';
  if (words > 50) {
    detail = 'Detailed';
  } else if (words >= 15) {
    detail = 'Moderate';
  } else {
    detail = 'Vague';
  }

  // Potential Outcomes
  const potentialOutcomes: string[] = [];
  if (identifiedSections.length === 0) {
    potentialOutcomes.push('No clear offense identified');
    potentialOutcomes.push('Vague or incomplete complaint may not sustain prosecution');
  } else {
    if (nonBailableCount > 0 || severity === 'Very High') {
      potentialOutcomes.push('Prosecution Likely');
    }
    if (detail === 'Vague' || evidence === 'Weak') {
      potentialOutcomes.push('Vague or incomplete complaint may not sustain prosecution');
    }
    if (words < 10 || (identifiedSections.length > 0 && evidence === 'Weak' && detail === 'Vague')) {
      potentialOutcomes.push('Dismissal Likely');
    }
    if (bailableCount > 0 && nonBailableCount === 0) {
      potentialOutcomes.push('Compounding / summary disposal permissible under BNSS');
    }
  }

  return {
    label,
    riskTitle: `${label} Risk`,
    riskBadge,
    severity,
    evidence,
    cognizableCount,
    detail,
    bailableCount,
    nonBailableCount,
    weaponInvolvement,
    financialAspect,
    identifiedSections,
    potentialOutcomes,
    rawText: trimmed
  };
}

export function compareComplaintsDetailed(textA: string, textB: string): DetailedComparisonResult {
  const partA = analyzePartComplaint(textA, 'Part A');
  const partB = analyzePartComplaint(textB, 'Part B');

  const partAHasOffense = partA.identifiedSections.length > 0;
  const partBHasOffense = partB.identifiedSections.length > 0;

  let recommendation = '';
  if (partAHasOffense && !partBHasOffense) {
    recommendation = 'Part A has stronger documentary foundation. Part B does not clearly identify a recognized offense under BNS.';
  } else if (!partAHasOffense && partBHasOffense) {
    recommendation = 'Part B has stronger documentary foundation. Part A does not clearly identify a recognized offense under BNS.';
  } else if (partAHasOffense && partBHasOffense) {
    if (partA.nonBailableCount > partB.nonBailableCount) {
      recommendation = 'Part A alleges higher statutory culpability under BNS. Cross-complaint investigation under BNSS Section 173 required.';
    } else if (partB.nonBailableCount > partA.nonBailableCount) {
      recommendation = 'Part B alleges higher statutory culpability under BNS. Cross-complaint investigation under BNSS Section 173 required.';
    } else {
      recommendation = 'Both complaints establish recognized offenses under BNS. Cross-examination and forensic verification recommended.';
    }
  } else {
    recommendation = 'Neither complaint clearly identifies a recognized offense under BNS. Additional factual particulars required.';
  }

  // Common sections
  const aCodes = partA.identifiedSections.map(s => s.code.replace('§', ''));
  const bCodes = partB.identifiedSections.map(s => s.code.replace('§', ''));
  const commonSections = aCodes.filter(c => bCodes.includes(c));

  let similarities = '';
  if (commonSections.length === 0) {
    similarities = 'No common sections — the complaints appear to describe distinct offenses.';
  } else {
    similarities = `Common sections detected: ${commonSections.map(s => '§' + s).join(', ')}. The complaints describe related statutory offenses arising from the same transaction.`;
  }

  return {
    recommendation,
    partA,
    partB,
    similarities,
    commonSections
  };
}
