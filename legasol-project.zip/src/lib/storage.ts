export interface SavedCase {
  id: string;
  firNumber: string;
  policeStation: string;
  district: string;
  complainant: string;
  accused: string;
  dateOccurrence: string;
  dateCreated: string;
  category: string;
  sections: string[];
  firContent: string;
  bailScore: number;
}

const STORAGE_KEY = 'legasol_saved_cases_v1';

export function getSavedCases(): SavedCase[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) return [];
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export function saveCase(caseData: SavedCase): void {
  try {
    const existing = getSavedCases();
    const filtered = existing.filter(c => c.id !== caseData.id);
    const updated = [caseData, ...filtered];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save case to localStorage:', err);
  }
}

export function deleteSavedCase(id: string): void {
  try {
    const existing = getSavedCases();
    const updated = existing.filter(c => c.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to delete case from localStorage:', err);
  }
}
