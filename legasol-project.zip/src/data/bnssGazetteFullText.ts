/**
 * The Gazette of India Extraordinary (Part II — Section 1, No. 54, New Delhi, Dec 25, 2023)
 * MINISTRY OF LAW AND JUSTICE (Legislative Department)
 * THE BHARATIYA NAGARIK SURAKSHA SANHITA, 2023 (ACT NO. 46 OF 2023)
 * Full Comprehensive Chapters I to XXXIX (39 Chapters, 531 Sections, Schedules & Forms)
 */

export interface BNSSChapter {
  number: string; // e.g. "CHAPTER I"
  title: string; // e.g. "PRELIMINARY"
  sectionRange: string; // e.g. "Sections 1 – 5"
  description: string;
}

export interface BNSSGazetteSection {
  sectionNumber: string; // e.g. "35", "173", "479"
  chapter: string; // e.g. "CHAPTER V: ARREST OF PERSONS"
  chapterNumber: string; // e.g. "CHAPTER V"
  marginalTitle: string; // e.g. "When police may arrest without warrant"
  crpcEquivalent: string; // e.g. "CrPC Section 41"
  statutoryText: string; // Verbatim official Gazette statutory text
  explanationsAndIllustrations?: string;
  category: string;
  keyTimelines?: string; // e.g. "Within 24 hours" or "Within 60/90 days"
  court: string;
  whomToBeTakenTo: string;
  isNewProvision?: boolean;
  keyChangesIn2023?: string;
  keywords: string[];
}

export const BNSS_GAZETTE_CHAPTERS: BNSSChapter[] = [
  {
    number: "CHAPTER I",
    title: "PRELIMINARY",
    sectionRange: "Sections 1 – 5",
    description: "Short title, territorial extent, definitions (bail, bond, cognizable, complaint, electronic communication, victim, audio-video electronic means), and construction of references."
  },
  {
    number: "CHAPTER II",
    title: "CONSTITUTION OF CRIMINAL COURTS AND OFFICES",
    sectionRange: "Sections 6 – 20",
    description: "Classes of criminal courts (Sessions, CJM, JMFC, JM Second Class, Executive Magistrates), territorial divisions, Public Prosecutors, and Directorate of Prosecution."
  },
  {
    number: "CHAPTER III",
    title: "POWER OF COURTS",
    sectionRange: "Sections 21 – 29",
    description: "Offences triable by Courts (rape cases tried as far as practicable by female judge), sentencing powers of High Court, Sessions, CJM (up to 7 yrs), JMFC (up to 3 yrs / Rs 50k fine / community service), and consecutive sentences."
  },
  {
    number: "CHAPTER IV",
    title: "POWERS OF SUPERIOR OFFICERS OF POLICE AND AID TO MAGISTRATES AND POLICE",
    sectionRange: "Sections 30 – 34",
    description: "Powers of superior police officers, public duty to assist police and report serious BNS crimes, and village officers' duties."
  },
  {
    number: "CHAPTER V",
    title: "ARREST OF PERSONS",
    sectionRange: "Sections 35 – 62",
    description: "Arrest without warrant (Sec 35), Notice of appearance under Sec 35(3), Arrest memo & rights (Sec 36-38), Handcuffing parameters (Sec 43(3)), Woman arrest protections after sunset (Sec 43(5)), Medical examination (Sec 51-53), and mandatory 24-hour magistrate production (Sec 58)."
  },
  {
    number: "CHAPTER VI",
    title: "PROCESSES TO COMPEL APPEARANCE",
    sectionRange: "Sections 63 – 93",
    description: "Summons in electronic mode (Sec 63-71), Warrants of arrest (Sec 72-83), Proclamation of absconders (Sec 84), Attachment of proclaimed offender's property (Sec 85-89), and Bond forfeiture."
  },
  {
    number: "CHAPTER VII",
    title: "PROCESSES TO COMPEL THE PRODUCTION OF THINGS",
    sectionRange: "Sections 94 – 110",
    description: "Summons to produce documents and digital communication devices (Sec 94), Search-warrants (Sec 96-104), Mandatory audio-video electronic recording of search & seizure (Sec 105), and Attachment/forfeiture of crime proceeds (Sec 107)."
  },
  {
    number: "CHAPTER VIII",
    title: "RECIPROCAL ARRANGEMENTS AND FORFEITURE OF PROPERTY",
    sectionRange: "Sections 111 – 124",
    description: "International letters of request, cross-border evidence collection, tracing proceeds of crime, and reciprocal seizure treaties."
  },
  {
    number: "CHAPTER IX",
    title: "SECURITY FOR KEEPING THE PEACE AND FOR GOOD BEHAVIOUR",
    sectionRange: "Sections 125 – 143",
    description: "Preventive bonds for keeping peace on conviction (Sec 125) and suspected/habitual offenders (Sec 126-129), with 6-month statutory inquiry limit."
  },
  {
    number: "CHAPTER X",
    title: "ORDER FOR MAINTENANCE OF WIVES, CHILDREN AND PARENTS",
    sectionRange: "Sections 144 – 147",
    description: "Maintenance of wife, minor children, disabled adult children, and elderly parents (replacing Section 125 CrPC); interim maintenance disposed of within 60 days."
  },
  {
    number: "CHAPTER XI",
    title: "MAINTENANCE OF PUBLIC ORDER AND TRANQUILLITY",
    sectionRange: "Sections 148 – 167",
    description: "Dispersal of unlawful assemblies by civil & armed force (Sec 148-151), Public nuisances (Sec 152-162), Urgent orders in nuisance/apprehended danger (Sec 163 replacing Section 144 CrPC), and Immovable property disputes (Sec 164-167)."
  },
  {
    number: "CHAPTER XII",
    title: "PREVENTIVE ACTION OF THE POLICE",
    sectionRange: "Sections 168 – 172",
    description: "Police duty to interpose and prevent cognizable offences, arrest to prevent crime (Sec 170), and public duty to conform to lawful police directions."
  },
  {
    number: "CHAPTER XIII",
    title: "INFORMATION TO THE POLICE AND THEIR POWERS TO INVESTIGATE",
    sectionRange: "Sections 173 – 196",
    description: "FIR registration including Zero FIR and e-FIR (Sec 173), Preliminary inquiry within 14 days for 3-7 yr offences, Mandatory forensic crime scene visit for 7+ yr offences (Sec 176(3)), Statement recording under Sec 180, Confessions under Sec 183, Medical exam of rape victim (Sec 184), Police custody rules (Sec 187), and Chargesheet within 60/90 days (Sec 193)."
  },
  {
    number: "CHAPTER XIV",
    title: "JURISDICTION OF THE CRIMINAL COURTS IN INQUIRIES AND TRIALS",
    sectionRange: "Sections 197 – 209",
    description: "Ordinary place of trial, multi-jurisdiction cyber and phone offences (Sec 202), journey offences, and crimes committed outside India."
  },
  {
    number: "CHAPTER XV",
    title: "CONDITIONS REQUISITE FOR INITIATION OF PROCEEDINGS",
    sectionRange: "Sections 210 – 222",
    description: "Cognizance of offences by Magistrate on complaint, police report or info (Sec 210), and Sanction requirements for public servants with 120-day deemed sanction rule (Sec 218)."
  },
  {
    number: "CHAPTER XVI",
    title: "COMPLAINTS TO MAGISTRATES",
    sectionRange: "Sections 223 – 226",
    description: "Examination of complainant under oath, mandatory prior hearing to accused before taking cognizance (Sec 223 proviso), and dismissal of groundless complaints."
  },
  {
    number: "CHAPTER XVII",
    title: "COMMENCEMENT OF PROCEEDINGS BEFORE MAGISTRATES",
    sectionRange: "Sections 227 – 233",
    description: "Issue of process (Sec 227), Supply of police report, FIR, and electronic records to accused and victim within 14 days free of cost (Sec 230), and Committal to Court of Session within 90 days (Sec 232)."
  },
  {
    number: "CHAPTER XVIII",
    title: "THE CHARGE",
    sectionRange: "Sections 234 – 247",
    description: "Form, contents and language of charges, Joinder of charges, separate trials for distinct offences, and trial of up to 5 offences within 12 months."
  },
  {
    number: "CHAPTER XIX",
    title: "TRIAL BEFORE A COURT OF SESSION",
    sectionRange: "Sections 248 – 260",
    description: "Sessions trial conducted by Public Prosecutor, Discharge application within 60 days (Sec 250), Framing charge within 60 days (Sec 251), Audio-video evidence (Sec 254), and Judgment within 30 to 45 days (Sec 258)."
  },
  {
    number: "CHAPTER XX",
    title: "TRIAL OF WARRANT-CASES BY MAGISTRATES",
    sectionRange: "Sections 261 – 273",
    description: "Cases on police report and otherwise, Discharge within 60 days of documents supply (Sec 262), Framing charges within 60 days (Sec 263), and Compensation for groundless accusations."
  },
  {
    number: "CHAPTER XXI",
    title: "TRIAL OF SUMMONS-CASES BY MAGISTRATES",
    sectionRange: "Sections 274 – 282",
    description: "Substance of accusation, plea of guilty in absence for petty offences, non-appearance of complainant, and withdrawal of complaint."
  },
  {
    number: "CHAPTER XXII",
    title: "SUMMARY TRIALS",
    sectionRange: "Sections 283 – 288",
    description: "Summary trial for theft/stolen property under Rs 20,000, house trespass, criminal intimidation, and maximum 3 months sentence."
  },
  {
    number: "CHAPTER XXIII",
    title: "PLEA BARGAINING",
    sectionRange: "Sections 289 – 300",
    description: "Application for plea bargaining within 30 days of charge (Sec 290), mutually satisfactory disposition, compensation to victim, and reduced sentence."
  },
  {
    number: "CHAPTER XXIV",
    title: "ATTENDANCE OF PERSONS CONFINED IN PRISONS",
    sectionRange: "Sections 301 – 306",
    description: "Power to require attendance of prisoners as accused or witnesses, and video conferencing examination."
  },
  {
    number: "CHAPTER XXV",
    title: "EVIDENCE IN INQUIRIES AND TRIALS",
    sectionRange: "Sections 307 – 336",
    description: "Evidence in presence of accused through audio-video electronic means (Sec 308), In-camera examination of minor rape victims, Examination of accused without oath (Sec 316), and Evidence on affidavit."
  },
  {
    number: "CHAPTER XXVI",
    title: "GENERAL PROVISIONS AS TO INQUIRIES AND TRIALS",
    sectionRange: "Sections 337 – 366",
    description: "Double jeopardy (Sec 337), Right to be defended & Legal Aid at State expense (Sec 340-341), Day-to-day proceedings with maximum two adjournments (Sec 346), Specimen signature/voice sample (Sec 349), Trial in absentia of proclaimed absconders (Sec 356), and Comprehensive Compounding Table (Sec 359)."
  },
  {
    number: "CHAPTER XXVII",
    title: "PROVISIONS AS TO ACCUSED PERSONS OF UNSOUND MIND",
    sectionRange: "Sections 367 – 378",
    description: "Psychiatric examination, medical board appeal, release on bail to psychiatric care, and special custody procedures."
  },
  {
    number: "CHAPTER XXVIII",
    title: "PROVISIONS AS TO OFFENCES AFFECTING THE ADMINISTRATION OF JUSTICE",
    sectionRange: "Sections 379 – 391",
    description: "Procedure in contempt, false evidence in judicial proceedings, and summary trial of perjury (Sec 383)."
  },
  {
    number: "CHAPTER XXIX",
    title: "THE JUDGMENT",
    sectionRange: "Sections 392 – 406",
    description: "Pronouncement within 45 days (Sec 392), Mandatory portal upload within 7 days (Sec 392(4)), Order to pay compensation (Sec 395), Victim Compensation Scheme (Sec 396), Free emergency medical treatment to rape/acid attack victims by all hospitals (Sec 397), Witness Protection Scheme (Sec 398), and Probation (Sec 401)."
  },
  {
    number: "CHAPTER XXX",
    title: "SUBMISSION OF DEATH SENTENCES FOR CONFIRMATION",
    sectionRange: "Sections 407 – 412",
    description: "High Court confirmation by bench of at least two judges before death sentence can be carried into effect."
  },
  {
    number: "CHAPTER XXXI",
    title: "APPEALS",
    sectionRange: "Sections 413 – 435",
    description: "Appeals against conviction and acquittal, statutory victim's right of appeal (Sec 413 proviso), and 6-month disposal rule for rape appeals (Sec 418(4))."
  },
  {
    number: "CHAPTER XXXII",
    title: "REFERENCE AND REVISION",
    sectionRange: "Sections 436 – 445",
    description: "Reference to High Court on validity of laws, and Revisional powers of Sessions Judge and High Court."
  },
  {
    number: "CHAPTER XXXIII",
    title: "TRANSFER OF CRIMINAL CASES",
    sectionRange: "Sections 446 – 452",
    description: "Powers of Supreme Court, High Court, and Sessions Judge to transfer criminal cases and appeals."
  },
  {
    number: "CHAPTER XXXIV",
    title: "EXECUTION, SUSPENSION, REMISSION AND COMMUTATION OF SENTENCES",
    sectionRange: "Sections 453 – 477",
    description: "Execution of death sentence and imprisonment, Set-off of undertrial detention (Sec 468), Mercy petitions to President/Governor within 30 days (Sec 472), and Minimum 14 years actual custody for life convicts (Sec 475)."
  },
  {
    number: "CHAPTER XXXV",
    title: "PROVISIONS AS TO BAIL AND BONDS",
    sectionRange: "Sections 478 – 496",
    description: "Bail in bailable cases (Sec 478), Landmark Undertrial Bail under Section 479 (one-third period for first-time offenders), Non-bailable bail criteria (Sec 480), Anticipatory bail (Sec 482), Special powers of High Court/Sessions (Sec 483), and Bond forfeiture (Sec 491)."
  },
  {
    number: "CHAPTER XXXVI",
    title: "DISPOSAL OF PROPERTY",
    sectionRange: "Sections 497 – 505",
    description: "Custody and disposal of property pending trial, mandatory photography/videography of seized articles within 14 days (Sec 497), and destruction of seized drugs/food."
  },
  {
    number: "CHAPTER XXXVII",
    title: "IRREGULAR PROCEEDINGS",
    sectionRange: "Sections 506 – 512",
    description: "Irregularities which do not vitiate proceedings vs those that render trial void."
  },
  {
    number: "CHAPTER XXXVIII",
    title: "LIMITATION FOR TAKING COGNIZANCE OF CERTAIN OFFENCES",
    sectionRange: "Sections 513 – 519",
    description: "Statutory bar on cognizance after 6 months (fine only), 1 year (up to 1 yr jail), or 3 years (up to 3 yrs jail)."
  },
  {
    number: "CHAPTER XXXIX",
    title: "MISCELLANEOUS",
    sectionRange: "Sections 520 – 531",
    description: "Inherent powers of High Court (Sec 528), Electronic mode for all trials, inquiries, summons and evidence (Sec 530), Repeal of Code of Criminal Procedure, 1973 (Act 2 of 1974) with savings (Sec 531), and 58 Statutory Forms."
  }
];

export const BNSS_GAZETTE_SECTIONS: BNSSGazetteSection[] = [
  // SECTION 2: DEFINITIONS
  {
    sectionNumber: "2",
    chapter: "CHAPTER I: PRELIMINARY",
    chapterNumber: "CHAPTER I",
    marginalTitle: "Definitions",
    crpcEquivalent: "CrPC Section 2",
    statutoryText: `2. (1) In this Sanhita, unless the context otherwise requires,—
(a) "audio-video electronic means" shall include use of any communication device for the purposes of video conferencing, recording of processes of identification, search and seizure or evidence, transmission of electronic communication...
(b) "bail" means release of a person accused of or suspected of commission of an offence from the custody of law upon certain conditions imposed by an officer or Court on execution by such person of a bond or a bail bond;
(c) "bailable offence" means an offence which is shown as bailable in the First Schedule, or which is made bailable by any other law for the time being in force; and "non-bailable offence" means any other offence;
(d) "bail bond" means an undertaking for release with surety;
(e) "bond" means a personal bond or an undertaking for release without surety;
(g) "cognizable offence" means an offence for which, and "cognizable case" means a case in which, a police officer may, in accordance with the First Schedule or under any other law, arrest without warrant;
(h) "complaint" means any allegation made orally or in writing to a Magistrate...
(i) "electronic communication" means the communication of any written, verbal, pictorial information or video content transmitted by mobile phone, computer or audio-video device;
(y) "victim" means a person who has suffered any loss or injury caused by reason of the act or omission of the accused person and includes the guardian or legal heir of such victim.`,
    category: "Preliminary & Core Legal Definitions",
    court: "All Criminal Courts",
    whomToBeTakenTo: "Defines foundational terms applicable across all 531 sections of the Code.",
    keyChangesIn2023: "Explicitly introduces definitions for 'audio-video electronic means', 'bail', 'bail bond', and 'electronic communication'.",
    keywords: ["bnss section 2", "definitions", "bail definition", "bond", "bail bond", "cognizable offence", "audio-video electronic means", "victim", "electronic communication"]
  },

  // SECTION 35: ARREST WITHOUT WARRANT & NOTICE
  {
    sectionNumber: "35",
    chapter: "CHAPTER V: ARREST OF PERSONS",
    chapterNumber: "CHAPTER V",
    marginalTitle: "When police may arrest without warrant & Notice of Appearance",
    crpcEquivalent: "CrPC Section 41 & 41A",
    statutoryText: `35. (1) Any police officer may without an order from a Magistrate and without a warrant, arrest any person—
(a) who commits, in the presence of a police officer, a cognizable offence; or
(b) against whom a reasonable complaint has been made, or credible information has been received... punishable with imprisonment for a term which may be less than seven years or which may extend to seven years... if satisfied that such arrest is necessary to prevent further offence, for proper investigation, or to prevent evidence tampering; and the police officer shall record while making such arrest, his reasons in writing:
Provided that a police officer shall, in all cases where the arrest of a person is not required, record the reasons in writing for not making the arrest;
(3) The police officer shall, in all cases where the arrest of a person is not required under sub-section (1) issue a notice directing the person... to appear before him or at such other place as may be specified in the notice [Form No. 1, Second Schedule].
(7) No arrest shall be made without prior permission of an officer not below the rank of Deputy Superintendent of Police in case of an offence which is punishable for imprisonment of less than three years and such person is infirm or is above sixty years of age.`,
    category: "Police Powers & Arrest Safegaurds",
    keyTimelines: "Notice of appearance issued; DSP permission mandatory for senior citizens above 60 years or infirm for <3 yr offences",
    court: "Jurisdictional Magistrate",
    whomToBeTakenTo: "Produced before nearest Judicial Magistrate within 24 hours under Section 58.",
    isNewProvision: true,
    keyChangesIn2023: "Sub-section (7) protects senior citizens (above 60) and infirm persons from arrest for minor crimes (<3 yrs) without DSP prior approval.",
    keywords: ["bnss section 35", "arrest without warrant", "notice of appearance", "section 35(3)", "41a crpc equivalent", "senior citizen arrest protection", "dsp permission"]
  },

  // SECTION 43: ARREST HOW MADE, HANDCUFFS & WOMEN ARREST
  {
    sectionNumber: "43",
    chapter: "CHAPTER V: ARREST OF PERSONS",
    chapterNumber: "CHAPTER V",
    marginalTitle: "Arrest how made, use of handcuffs, and arrest of women",
    crpcEquivalent: "CrPC Section 46",
    statutoryText: `43. (1) In making an arrest the police officer or other person making the same shall actually touch or confine the body of the person to be arrested, unless there be a submission to the custody by word or action:
Provided that where a woman is to be arrested, unless the circumstances indicate to the contrary, her submission to custody on an oral intimation of arrest shall be presumed and, unless the circumstances otherwise require or unless the police officer is a female, the police officer shall not touch the person of the woman for making her arrest.
(3) The police officer may, keeping in view the nature and gravity of the offence, use handcuff while making the arrest of a person or while producing such person before the court who is a habitual or repeat offender, or who escaped from custody, or who has committed offence of organised crime, terrorist act, drug related crime, or illegal possession of arms and ammunition, murder, rape, acid attack, counterfeiting of coins and currency-notes, human trafficking, sexual offence against children, or offence against the State.
(5) Save in exceptional circumstances, no woman shall be arrested after sunset and before sunrise, and where such exceptional circumstances exist, the woman police officer shall, by making a written report, obtain the prior permission of the Magistrate of the first class within whose local jurisdiction the offence is committed or the arrest is to be made.`,
    category: "Arrest Protocols & Human Dignity",
    keyTimelines: "No arrest of women between sunset and sunrise without prior Judicial Magistrate First Class written sanction",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Woman police officer mandatory for arresting women; produced before JMFC.",
    isNewProvision: true,
    keyChangesIn2023: "Sub-section (3) codifies specific statutory parameters for using handcuffs for heinous offenders (terrorists, rapists, organized syndicates, murderers).",
    keywords: ["bnss section 43", "handcuff rules", "handcuffing", "arrest of women", "sunset sunrise woman arrest", "female police officer", "touching woman body prohibited"]
  },

  // SECTION 58: 24-HOUR DETENTION LIMIT
  {
    sectionNumber: "58",
    chapter: "CHAPTER V: ARREST OF PERSONS",
    chapterNumber: "CHAPTER V",
    marginalTitle: "Person arrested not to be detained more than twenty-four hours",
    crpcEquivalent: "CrPC Section 57",
    statutoryText: `58. No police officer shall detain in custody a person arrested without warrant for a longer period than under all the circumstances of the case is reasonable, and such period shall not, in the absence of a special order of a Magistrate under section 187, exceed twenty-four hours exclusive of the time necessary for the journey from the place of arrest to the Magistrate's Court, whether having jurisdiction or not.`,
    category: "Fundamental Arrest Safeguards",
    keyTimelines: "Maximum 24 hours strict statutory detention limit",
    court: "Nearest Magistrate (Judicial or Executive)",
    whomToBeTakenTo: "Must be produced before nearest Magistrate within 24 hours (Constitutional mandate Article 22(2)).",
    keywords: ["bnss section 58", "24 hours limit", "magistrate production within 24 hours", "57 crpc", "unlawful custody", "journey time excluded"]
  },

  // SECTION 63: ELECTRONIC SUMMONS
  {
    sectionNumber: "63",
    chapter: "CHAPTER VI: PROCESSES TO COMPEL APPEARANCE",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Form of summons and Electronic Service",
    crpcEquivalent: "CrPC Section 61 & 62",
    statutoryText: `63. Every summons issued by a Court under this Sanhita shall be,—
(i) in writing, in duplicate, signed by the presiding officer of such Court... and shall bear the seal of the Court; or
(ii) in an encrypted or any other form of electronic communication and shall bear the image of the seal of the Court or digital signature.
64. (2) Provided that summons bearing the image of Court's seal may also be served by electronic communication in such form and in such manner, as the State Government may, by rules, provide.
70. (3) All summons served through electronic communication under sections 64 to 71 shall be considered as duly served.`,
    category: "Court Processes & Digital Transformation",
    court: "All Criminal Courts",
    whomToBeTakenTo: "Served directly via email, encrypted mobile messaging, or physical delivery.",
    isNewProvision: true,
    keyChangesIn2023: "Recognizes electronic summons with digital signature / encrypted seal as legally valid summons service.",
    keywords: ["bnss section 63", "electronic summons", "digital signature summons", "whatsapp summons", "email summons", "service of summons"]
  },

  // SECTION 84: PROCLAMATION FOR ABSCONDERS
  {
    sectionNumber: "84",
    chapter: "CHAPTER VI: PROCESSES TO COMPEL APPEARANCE",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Proclamation for person absconding",
    crpcEquivalent: "CrPC Section 82",
    statutoryText: `84. (1) If any Court has reason to believe... that any person against whom a warrant has been issued by it has absconded or is concealing himself... such Court may publish a written proclamation requiring him to appear at a specified place and at a specified time not less than thirty days from the date of publishing such proclamation.
(4) Where a proclamation published under sub-section (1) is in respect of a person accused of an offence which is made punishable with imprisonment of ten years or more, or imprisonment for life or with death under the Bharatiya Nyaya Sanhita, 2023... and such person fails to appear... the Court may, after making such inquiry as it thinks fit, pronounce him a proclaimed offender and make a declaration to that effect.`,
    category: "Proclamation & Attachment",
    keyTimelines: "Notice period not less than 30 days",
    court: "Court of Magistrate / Court of Session",
    whomToBeTakenTo: "Sets foundation for property attachment under Section 85 and trial in absentia under Section 356.",
    keywords: ["bnss section 84", "proclaimed offender", "absconder", "82 crpc", "attachment of property 85", "30 days proclamation notice"]
  },

  // SECTION 94: SUMMONS TO PRODUCE DIGITAL EVIDENCE
  {
    sectionNumber: "94",
    chapter: "CHAPTER VII: PROCESSES TO COMPEL THE PRODUCTION OF THINGS",
    chapterNumber: "CHAPTER VII",
    marginalTitle: "Summons to produce document, electronic communication or digital devices",
    crpcEquivalent: "CrPC Section 91",
    statutoryText: `94. (1) Whenever any Court or any officer in charge of a police station considers that the production of any document, electronic communication, including communication devices, which is likely to contain digital evidence or other thing is necessary or desirable for the purposes of any investigation, inquiry, trial or other proceeding under this Sanhita by or before such Court or officer, such Court may issue a summons or such officer may, by a written order, either in physical form or in electronic form, require the person in whose possession or power such document or thing is believed to be, to attend and produce it...`,
    category: "Evidence Collection & Cyber Forensics",
    court: "Criminal Courts & Police Station In-Charge",
    whomToBeTakenTo: "Directs production of digital devices, mobile phones, and servers to Court or Police.",
    isNewProvision: true,
    keyChangesIn2023: "Explicitly expands Section 91 CrPC to encompass communication devices, electronic records, and digital evidence.",
    keywords: ["bnss section 94", "summons to produce", "digital evidence", "91 crpc", "mobile phone seizure", "electronic communication devices"]
  },

  // SECTION 105: MANDATORY VIDEOGRAPHY OF SEARCH AND SEIZURE
  {
    sectionNumber: "105",
    chapter: "CHAPTER VII: PROCESSES TO COMPEL THE PRODUCTION OF THINGS",
    chapterNumber: "CHAPTER VII",
    marginalTitle: "Recording of search and seizure through audio-video electronic means",
    crpcEquivalent: "Brand new landmark procedural safeguard",
    statutoryText: `105. The process of conducting search of a place or taking possession of any property, article or thing under this Chapter or under section 185, including preparation of the list of all things seized in the course of such search and seizure and signing of such list by witnesses, shall be recorded through any audio-video electronic means preferably mobile phone and the police officer shall without delay forward such recording to the District Magistrate, Sub-divisional Magistrate or Judicial Magistrate of the first class.`,
    category: "Police Search & Evidence Integrity",
    keyTimelines: "Recording forwarded without delay to Magistrate",
    court: "Judicial Magistrate of the First Class / DM / SDM",
    whomToBeTakenTo: "Police must record on mobile phone/camera and submit recording with panchnama.",
    isNewProvision: true,
    keyChangesIn2023: "Mandatory requirement to videograph every search and seizure on mobile phone to eliminate planting of false evidence.",
    keywords: ["bnss section 105", "videography of search", "audio-video seizure", "panchnama videography", "mobile phone recording police search", "search safeguards"]
  },

  // SECTION 107: ATTACHMENT OF PROCEEDS OF CRIME
  {
    sectionNumber: "107",
    chapter: "CHAPTER VII: PROCESSES TO COMPEL THE PRODUCTION OF THINGS",
    chapterNumber: "CHAPTER VII",
    marginalTitle: "Attachment, forfeiture or restoration of property derived from criminal activity",
    crpcEquivalent: "Brand new provision in general criminal procedure",
    statutoryText: `107. (1) Where a police officer making an investigation has reason to believe that any property is derived or obtained, directly or indirectly, as a result of a criminal activity or from the commission of any offence, he may, with the approval of the Superintendent of Police or Commissioner of Police, make an application to the Court or the Magistrate... for the attachment of such property.
(6) If the Court or the Magistrate finds the attached or seized properties to be the proceeds of crime, the Court or the Magistrate shall by order direct the District Magistrate to rateably distribute such proceeds of crime to the persons who are affected by such crime.
(7) On receipt of an order... the District Magistrate shall, within a period of sixty days distribute the proceeds of crime... to the victims.`,
    category: "Proceeds of Crime & Victim Restitution",
    keyTimelines: "Show-cause within 14 days; DM distributes proceeds to victims within 60 days",
    court: "Court of Session / Magistrate",
    whomToBeTakenTo: "District Magistrate manages and rateably distributes recovered crime proceeds to victims.",
    isNewProvision: true,
    keyChangesIn2023: "Allows attachment of proceeds of crime in ordinary police cases and direct distribution of recovered funds to affected victims.",
    keywords: ["bnss section 107", "proceeds of crime", "attachment of property", "forfeiture", "victim restitution", "rateable distribution of crime money"]
  },

  // SECTION 144: MAINTENANCE OF WIVES, CHILDREN AND PARENTS
  {
    sectionNumber: "144",
    chapter: "CHAPTER X: ORDER FOR MAINTENANCE OF WIVES, CHILDREN AND PARENTS",
    chapterNumber: "CHAPTER X",
    marginalTitle: "Order for maintenance of wives, children and parents",
    crpcEquivalent: "CrPC Section 125",
    statutoryText: `144. (1) If any person having sufficient means neglects or refuses to maintain—
(a) his wife, unable to maintain herself; or
(b) his legitimate or illegitimate child, whether married or not, unable to maintain itself; or
(c) his legitimate or illegitimate child (not being a married daughter) who has attained majority, where such child is, by reason of any physical or mental abnormality or injury unable to maintain itself; or
(d) his father or mother, unable to maintain himself or herself,
a Magistrate of the first class may, upon proof of such neglect or refusal, order such person to make a monthly allowance for the maintenance...
Provided that an application for the monthly allowance for the interim maintenance and expenses of proceeding shall, as far as possible, be disposed of within sixty days from the date of the service of notice of the application to such person.`,
    category: "Family Law & Social Security",
    keyTimelines: "Interim maintenance application must be decided within 60 days of notice service",
    court: "Magistrate of the First Class / Family Court",
    whomToBeTakenTo: "Jurisdictional Magistrate of the First Class; enforceable across India under Section 147.",
    keyChangesIn2023: "Statutory mandate to dispose of interim maintenance petitions within sixty (60) days.",
    keywords: ["bnss section 144", "maintenance", "125 crpc", "wife maintenance", "parents maintenance", "interim maintenance 60 days", "child maintenance"]
  },

  // SECTION 163: URGENT ORDERS IN NUISANCE (FORMER SECTION 144 CrPC)
  {
    sectionNumber: "163",
    chapter: "CHAPTER XI: MAINTENANCE OF PUBLIC ORDER AND TRANQUILLITY",
    chapterNumber: "CHAPTER XI",
    marginalTitle: "Power to issue order in urgent cases of nuisance or apprehended danger",
    crpcEquivalent: "CrPC Section 144",
    statutoryText: `163. (1) In cases where, in the opinion of a District Magistrate, a Sub-divisional Magistrate or any other Executive Magistrate specially empowered... immediate prevention or speedy remedy is desirable, such Magistrate may, by a written order... direct any person to abstain from a certain act or to take certain order with respect to certain property in his possession or under his management, if such direction is likely to prevent obstruction, annoyance, injury, danger to human life, health, safety, riot or affray.
(4) No order under this section shall remain in force for more than two months: Provided that the State Government may extend it up to six months.`,
    category: "Public Order & Emergency Powers",
    keyTimelines: "Initial order valid up to 2 months; state extension up to 6 months",
    court: "Executive Magistrate / District Magistrate",
    whomToBeTakenTo: "Promulgated by DM / SDM; disobedience punishable under BNS Section 223.",
    keyChangesIn2023: "Replaces colonial Section 144 CrPC; appearance/hearing permitted through audio-video conferencing.",
    keywords: ["bnss section 163", "section 144 crpc replacement", "curfew", "prohibitory orders", "public nuisance order", "unlawful assembly prevention"]
  },

  // SECTION 173: FIR, ZERO FIR & ELECTRONIC FIR
  {
    sectionNumber: "173",
    chapter: "CHAPTER XIII: INFORMATION TO THE POLICE AND THEIR POWERS TO INVESTIGATE",
    chapterNumber: "CHAPTER XIII",
    marginalTitle: "Information in cognizable cases (First Information Report)",
    crpcEquivalent: "CrPC Section 154",
    statutoryText: `173. (1) Every information relating to the commission of a cognizable offence, irrespective of the area where the offence is committed, may be given orally or by electronic communication to an officer in charge of a police station, and if given—
(i) orally, it shall be reduced to writing by him or under his direction, and be read over to the informant; and every such information... shall be signed by the person giving it;
(ii) by electronic communication, it shall be taken on record by him on being signed within three days by the person giving it.
Provided that information given by woman regarding sexual offenses shall be recorded by a woman police officer.
(2) A copy of the information as recorded under sub-section (1) shall be given forthwith, free of cost, to the informant or the victim.
(3) On receipt of information relating to the commission of any cognizable offence punishable for three years or more but less than seven years, the officer in charge may with prior permission of DSP:
(i) conduct preliminary enquiry within fourteen days to ascertain whether prima facie case exists; or
(ii) proceed with investigation when prima facie case exists.
(4) Aggrieved person on refusal of SHO may send substance in writing to Superintendent of Police (SP).`,
    category: "Crime Reporting & Registration",
    keyTimelines: "e-FIR signed within 3 days; preliminary enquiry for 3-7 yr offenses within 14 days",
    court: "Jurisdictional Magistrate",
    whomToBeTakenTo: "Registered at any police station (Zero FIR) and forwarded to jurisdictional police station.",
    isNewProvision: true,
    keyChangesIn2023: "Codifies Zero FIR (irrespective of area); introduces e-FIR (electronic FIR signed within 3 days); mandates 14-day preliminary enquiry for 3-7 yr offenses to prevent frivolous arrests.",
    keywords: ["bnss section 173", "fir", "first information report", "154 crpc", "zero fir", "electronic fir", "e-fir", "14 days preliminary enquiry", "free copy of fir"]
  },

  // SECTION 176(3): MANDATORY FORENSIC INVESTIGATION
  {
    sectionNumber: "176",
    chapter: "CHAPTER XIII: INFORMATION TO THE POLICE AND THEIR POWERS TO INVESTIGATE",
    chapterNumber: "CHAPTER XIII",
    marginalTitle: "Procedure for investigation & Mandatory forensic examination",
    crpcEquivalent: "CrPC Section 157",
    statutoryText: `176. (3) On receipt of every information relating to the commission of an offence which is made punishable for seven years or more, the officer in charge of a police station shall... cause the forensic expert to visit the crime scene to collect forensic evidence in the offence and also cause videography of the process on mobile phone or any other electronic device:
Provided that where forensic facility is not available in respect of any such offence, the State Government shall, until the facility is developed, notify the utilisation of such facility of any other State.`,
    category: "Forensic Evidence & Crime Scene",
    keyTimelines: "Immediate visit and collection upon reporting of 7+ year offenses",
    court: "Court of Session / Trial Magistrate",
    whomToBeTakenTo: "Forensic evidence must be submitted as part of police report under Section 193.",
    isNewProvision: true,
    keyChangesIn2023: "Mandatory requirement that forensic teams visit the scene and videograph collection on mobile phone for all offenses carrying 7+ years imprisonment.",
    keywords: ["bnss section 176(3)", "forensic investigation", "forensic expert visit", "7 years offence forensics", "crime scene videography", "scientific investigation"]
  },

  // SECTION 187: POLICE CUSTODY REMAND (15 DAYS IN 40/60 DAYS)
  {
    sectionNumber: "187",
    chapter: "CHAPTER XIII: INFORMATION TO THE POLICE AND THEIR POWERS TO INVESTIGATE",
    chapterNumber: "CHAPTER XIII",
    marginalTitle: "Procedure when investigation cannot be completed in twenty-four hours (Remand)",
    crpcEquivalent: "CrPC Section 167",
    statutoryText: `187. (2) The Magistrate to whom an accused person is forwarded under this section may... authorise, from time to time, the detention of the accused in such custody as such Magistrate thinks fit, for a term not exceeding fifteen days in the whole, or in parts, at any time during the initial forty days or sixty days out of detention period of sixty days or ninety days, as the case may be...
(3) The Magistrate may authorise detention beyond fifteen days up to:
(i) ninety days, where investigation relates to an offence punishable with death, life imprisonment or imprisonment for 10 years or more;
(ii) sixty days, where investigation relates to any other offence,
and on expiry of 90 or 60 days, the accused person shall be released on default bail if prepared to furnish bail.`,
    category: "Remand & Default Bail",
    keyTimelines: "15 days police remand permitted in parts across first 40 or 60 days; default bail on 60/90 days",
    court: "Judicial Magistrate / Executive Magistrate (up to 7 days)",
    whomToBeTakenTo: "Accused must be produced in person for first remand; subsequent remands allowed via video conference.",
    isNewProvision: true,
    keyChangesIn2023: "Police custody of 15 days is no longer restricted to the first 15 days only; it can now be availed in parts across the first 40 or 60 days.",
    keywords: ["bnss section 187", "remand", "police custody", "167 crpc", "default bail", "60 days", "90 days", "intermittent custody", "15 days police remand"]
  },

  // SECTION 193: POLICE REPORT / CHARGESHEET TIMELINES
  {
    sectionNumber: "193",
    chapter: "CHAPTER XIII: INFORMATION TO THE POLICE AND THEIR POWERS TO INVESTIGATE",
    chapterNumber: "CHAPTER XIII",
    marginalTitle: "Report of police officer on completion of investigation (Chargesheet)",
    crpcEquivalent: "CrPC Section 173",
    statutoryText: `193. (1) Every investigation under this Chapter shall be completed without unnecessary delay.
(2) Investigation in relation to rape offences (under BNS sections 64 to 71) or POCSO Act shall be completed within two months from the date of recording information.
(3) (ii) The police officer shall, within a period of ninety days, inform the progress of the investigation by any means including through electronic communication to the informant or the victim.
(9) Further investigation during trial may be conducted with the permission of the Court and shall be completed within a period of ninety days.`,
    category: "Chargesheet & Investigation Timelines",
    keyTimelines: "Rape investigation completed within 2 months; progress update to victim within 90 days; supplementary probe within 90 days",
    court: "Cognizance Magistrate",
    whomToBeTakenTo: "Forwarded electronically or physically to Magistrate empowered to take cognizance.",
    keyChangesIn2023: "Mandatory 90-day progress report to victim/informant; 90-day time cap on supplementary investigation during trial.",
    keywords: ["bnss section 193", "chargesheet", "police report", "173 crpc", "two months rape investigation", "90 days victim update", "further investigation 90 days"]
  },

  // SECTION 223: PRIOR HEARING TO ACCUSED BEFORE COGNIZANCE
  {
    sectionNumber: "223",
    chapter: "CHAPTER XVI: COMPLAINTS TO MAGISTRATES",
    chapterNumber: "CHAPTER XVI",
    marginalTitle: "Examination of complainant & Prior hearing to accused",
    crpcEquivalent: "CrPC Section 200",
    statutoryText: `223. (1) A Magistrate having jurisdiction while taking cognizance of an offence on complaint shall examine upon oath the complainant and the witnesses present...
Provided that no cognizance of an offence shall be taken by the Magistrate without giving the accused an opportunity of being heard:
Provided further that when the complaint is made in writing, the Magistrate need not examine complainant if public servant has made complaint.
(2) A Magistrate shall not take cognizance on a complaint against a public servant unless the public servant is given an opportunity to make assertions and report from superior officer is received.`,
    category: "Private Complaints & Accused Protection",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Accused receives notice and opportunity of being heard before Magistrate issues process or takes cognizance.",
    isNewProvision: true,
    keyChangesIn2023: "First-ever statutory right of prior hearing to the accused before cognizance is taken on private complaints, preventing false harassment cases.",
    keywords: ["bnss section 223", "complaint to magistrate", "200 crpc", "prior hearing to accused", "opportunity of being heard before cognizance", "private complaint safeguard"]
  },

  // SECTION 230: SUPPLY OF COPIES WITHIN 14 DAYS
  {
    sectionNumber: "230",
    chapter: "CHAPTER XVII: COMMENCEMENT OF PROCEEDINGS BEFORE MAGISTRATES",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Supply to accused of copy of police report and other documents",
    crpcEquivalent: "CrPC Section 207",
    statutoryText: `230. In any case where the proceeding has been instituted on a police report, the Magistrate shall without delay, and in no case beyond fourteen days from the date of production or appearance of the accused, furnish to the accused and the victim (if represented by an advocate) free of cost, a copy of: (i) police report; (ii) FIR; (iii) witness statements under Sec 180(3); (iv) confessions under Sec 183; (v) any other document forwarded with police report:
Provided that supply of documents in electronic form shall be considered as duly furnished.`,
    category: "Trial Fair Play & Accused Rights",
    keyTimelines: "Mandatory within 14 days of appearance",
    court: "Magistrate Court",
    whomToBeTakenTo: "Furnished free of cost to accused and victim's advocate (electronic supply valid).",
    keyChangesIn2023: "Strict 14-day statutory deadline imposed on Magistrate to supply documents; victim's advocate officially entitled to copies.",
    keywords: ["bnss section 230", "supply of chargesheet copies", "207 crpc", "14 days document supply", "electronic copy chargesheet", "victim advocate copy"]
  },

  // SECTION 250 & 251: SESSIONS TRIAL TIMELINES
  {
    sectionNumber: "250",
    chapter: "CHAPTER XIX: TRIAL BEFORE A COURT OF SESSION",
    chapterNumber: "CHAPTER XIX",
    marginalTitle: "Discharge and Framing of charge in Sessions Trial",
    crpcEquivalent: "CrPC Section 227 & 228",
    statutoryText: `250. (1) The accused may prefer an application for discharge within a period of sixty days from the date of commitment of the case under section 232.
251. (1) (b) If exclusively triable by the Court of Session, he shall frame in writing a charge against the accused within a period of sixty days from the date of first hearing on charge.
254. (1) Evidence of witness under this sub-section may be recorded by audio-video electronic means.
258. (1) After hearing arguments, the Judge shall give a judgment in the case, as soon as possible, within a period of thirty days from the date of completion of arguments, which may be extended to forty-five days for reasons recorded in writing.`,
    category: "Sessions Court Timelines",
    keyTimelines: "Discharge within 60 days; charge framing within 60 days; judgment within 30-45 days",
    court: "Court of Session",
    whomToBeTakenTo: "Sessions Judge hears discharge and pronounces judgment.",
    isNewProvision: true,
    keyChangesIn2023: "Rigid statutory deadlines: 60 days for discharge, 60 days for framing charges, and 30-45 days for delivery of judgment.",
    keywords: ["bnss section 250", "bnss section 251", "bnss section 258", "sessions trial timelines", "discharge 60 days", "framing charge 60 days", "judgment 30 days"]
  },

  // SECTION 356: TRIAL IN ABSENTIA OF PROCLAIMED OFFENDERS
  {
    sectionNumber: "356",
    chapter: "CHAPTER XXVI: GENERAL PROVISIONS AS TO INQUIRIES AND TRIALS",
    chapterNumber: "CHAPTER XXVI",
    marginalTitle: "Inquiry, trial or judgment in absentia of proclaimed offender",
    crpcEquivalent: "Brand new historic legal reform",
    statutoryText: `356. (1) Notwithstanding anything contained in this Sanhita or in any other law for the time being in force, when a person declared as a proclaimed offender, whether or not charged jointly, has absconded to evade trial and there is no immediate prospect of arresting him, it shall be deemed to operate as a waiver of the right of such person to be present and tried in person, and the Court shall, after recording reasons in writing, in the interest of justice, proceed with the trial in the like manner and with like effect as if he was present, under this Sanhita and pronounce the judgment:
Provided that the Court shall not commence the trial unless a period of ninety days has lapsed from the date of framing of the charge.
(2) Requires 2 consecutive warrants, publication in national newspaper with 30 days notice, informing relatives, and pasting notice on residence.
(3) Proclaimed offender provided with advocate at State expense.
(6) Voluntary absence after trial commenced shall not prevent continuing trial including pronouncement of judgment.`,
    category: "Anti-Fugitive & Absconder Trial",
    keyTimelines: "Trial starts after 90 days from charge framing; 30 days newspaper notice",
    court: "Court of Session / Magistrate",
    whomToBeTakenTo: "Allows full conviction, sentencing, and property confiscation of absconding terrorists, mobsters, and fugitives living abroad.",
    isNewProvision: true,
    keyChangesIn2023: "Historic reform permitting criminal trials and judgments to proceed to conviction in absentia against absconding proclaimed offenders.",
    keywords: ["bnss section 356", "trial in absentia", "proclaimed offender trial", "absconder conviction", "fugitive trial", "judgment in absence of accused"]
  },

  // SECTION 359: COMPOUNDING OF OFFENCES TABLE
  {
    sectionNumber: "359",
    chapter: "CHAPTER XXVI: GENERAL PROVISIONS AS TO INQUIRIES AND TRIALS",
    chapterNumber: "CHAPTER XXVI",
    marginalTitle: "Compounding of offences",
    crpcEquivalent: "CrPC Section 320",
    statutoryText: `359. (1) The offences punishable under the sections of the Bharatiya Nyaya Sanhita, 2023 specified in the Table may be compounded by the persons mentioned in the third column:
Includes: Enticing married woman (Sec 84), Voluntarily causing hurt (Sec 115(2)), Hurt on provocation (Sec 122), Wrongful confinement (Sec 126/127), Theft (Sec 303(2) by property owner), Dishonest misappropriation (Sec 314), Criminal breach of trust (Sec 316), Cheating (Sec 318), Defamation (Sec 356(2)).
(2) Offences compoundable with permission of Court: Word/gesture insulting modesty (Sec 79), Bigamy (Sec 82), Grievous hurt (Sec 117(2)), Negligent hurt (Sec 125), Servant theft (Sec 306), Cheating by valuable security (Sec 318(4)).
(8) The composition of an offence under this section shall have the effect of an acquittal of the accused.`,
    category: "Alternative Dispute Resolution & Settlements",
    court: "Trial Magistrate / Court of Session",
    whomToBeTakenTo: "Parties submit compromise petition before trial Magistrate; operates as complete acquittal.",
    keyChangesIn2023: "Updated cross-references to all corresponding BNS sections with expanded compounding scope.",
    keywords: ["bnss section 359", "compounding of offences", "320 crpc", "compromise in criminal case", "compoundable sections table", "acquittal on compromise"]
  },

  // SECTION 396: VICTIM COMPENSATION SCHEME
  {
    sectionNumber: "396",
    chapter: "CHAPTER XXIX: THE JUDGMENT",
    chapterNumber: "CHAPTER XXIX",
    marginalTitle: "Victim compensation scheme and immediate relief",
    crpcEquivalent: "CrPC Section 357A",
    statutoryText: `396. (1) Every State Government in co-ordination with the Central Government shall prepare a scheme for providing funds for the purpose of compensation to the victim or his dependents who have suffered loss or injury as a result of the crime and who require rehabilitation.
(2) Decided by District Legal Services Authority (DLSA) or State Legal Services Authority (SLSA).
(5) DLSA/SLSA shall complete enquiry and award compensation within two months.
(6) DLSA/SLSA may order immediate first-aid facility or medical benefits free of cost on certificate of police officer or Magistrate.
397. All hospitals, public or private... shall immediately, provide first-aid or medical treatment, free of cost, to victims of rape, sexual assault or acid attack.
398. Every State Government shall prepare and notify a Witness Protection Scheme.`,
    category: "Victim Rights & Rehabilitation",
    keyTimelines: "Compensation inquiry completed within 2 months; immediate free medical aid",
    court: "Court of Session / DLSA / SLSA",
    whomToBeTakenTo: "Victims apply to District Legal Services Authority (DLSA) for interim/final compensation.",
    isNewProvision: true,
    keyChangesIn2023: "Mandates 2-month deadline for DLSA to award compensation; Section 398 introduces mandatory Witness Protection Scheme.",
    keywords: ["bnss section 396", "victim compensation scheme", "dlsa", "357a crpc", "free hospital treatment rape acid attack", "witness protection scheme 398"]
  },

  // SECTION 472: MERCY PETITION PROCEDURE
  {
    sectionNumber: "472",
    chapter: "CHAPTER XXXIV: EXECUTION, SUSPENSION, REMISSION AND COMMUTATION OF SENTENCES",
    chapterNumber: "CHAPTER XXXIV",
    marginalTitle: "Mercy petition in death sentence cases",
    crpcEquivalent: "Brand new statutory codification",
    statutoryText: `472. (1) A convict under sentence of death or his legal heir or relative may file a mercy petition before the President of India under article 72 or the Governor under article 161 of the Constitution within a period of thirty days from date jail superintendent informs of dismissal of appeal/review by Supreme Court.
(2) Petition initially made to Governor; on rejection, petition to President within sixty days.
(4) Central Government shall make recommendations to President within sixty days from receipt of State comments.
(7) No appeal shall lie in any Court against the order of President or Governor made under article 72 or 161, and it shall be final.`,
    category: "Death Sentence & Executive Clemency",
    keyTimelines: "Mercy petition within 30 days; second petition within 60 days; recommendations within 60 days",
    court: "President of India / Governor of State",
    whomToBeTakenTo: "Jail Superintendent forwards mercy petition to Home Ministry / Governor / President.",
    isNewProvision: true,
    keyChangesIn2023: "First-time statutory codification of strict time limits for mercy petitions to eliminate indefinite execution delays.",
    keywords: ["bnss section 472", "mercy petition", "death sentence clemency", "article 72", "article 161", "30 days mercy petition", "finality of mercy order"]
  },

  // SECTION 479: MAXIMUM PERIOD FOR UNDERTRIAL DETENTION (ONE-THIRD FOR FIRST TIMERS)
  {
    sectionNumber: "479",
    chapter: "CHAPTER XXXV: PROVISIONS AS TO BAIL AND BONDS",
    chapterNumber: "CHAPTER XXXV",
    marginalTitle: "Maximum period for which undertrial prisoner can be detained (Undertrial Bail)",
    crpcEquivalent: "CrPC Section 436A (Substantially Liberalized)",
    statutoryText: `479. (1) Where a person has, during the period of investigation, inquiry or trial under this Sanhita... undergone detention for a period extending up to one-half of the maximum period of imprisonment... he shall be released by the Court on bail:
Provided that where such person is a first-time offender (who has never been convicted of any offence in the past) he shall be released on bond by the Court, if he has undergone detention for the period extending up to one-third of the maximum period of imprisonment specified for such offence under that law.
(3) The Superintendent of jail, where the accused person is detained, on completion of one-half or one-third of the period... shall forthwith make an application in writing to the Court to proceed under sub-section (1) for the release of such person on bail.`,
    category: "Undertrial Bail & Prison De-congestion",
    keyTimelines: "Release on bond at 1/3rd sentence for first-time offenders; 1/2 sentence for repeat undertrials",
    court: "Trial Magistrate / Court of Session",
    whomToBeTakenTo: "Jail Superintendent must automatically apply to Court on behalf of eligible undertrial.",
    isNewProvision: true,
    keyChangesIn2023: "Major human rights reform: first-time offenders must be released on personal bond upon completing 1/3rd of the maximum sentence; jail superintendents mandated to file bail applications.",
    keywords: ["bnss section 479", "undertrial bail", "436a crpc", "first time offender bail one third", "one half detention bail", "jail superintendent duty", "prison decongestion"]
  },

  // SECTION 482: ANTICIPATORY BAIL
  {
    sectionNumber: "482",
    chapter: "CHAPTER XXXV: PROVISIONS AS TO BAIL AND BONDS",
    chapterNumber: "CHAPTER XXXV",
    marginalTitle: "Direction for grant of bail to person apprehending arrest (Anticipatory Bail)",
    crpcEquivalent: "CrPC Section 438",
    statutoryText: `482. (1) When any person has reason to believe that he may be arrested on an accusation of having committed a non-bailable offence, he may apply to the High Court or the Court of Session for a direction under this section; and that Court may, if it thinks fit, direct that in the event of such arrest, he shall be released on bail.
(2) Court may include conditions: (i) person shall make himself available for interrogation by police; (ii) no inducement, threat or promise to witnesses; (iii) shall not leave India without permission.
(4) Nothing in this section shall apply to any case involving the arrest of any person on accusation of having committed an offence under section 65 (rape on girl under 16/12) and sub-section (2) of section 70 (gang rape on girl under 18) of the Bharatiya Nyaya Sanhita, 2023.`,
    category: "Pre-Arrest Bail & Protection",
    court: "Court of Session & High Court",
    whomToBeTakenTo: "Application filed before Sessions Court or High Court; police must issue bailable warrant if granted.",
    keyChangesIn2023: "Explicit statutory exclusion of anticipatory bail for heinous child rape under Section 65 and minor gang rape under Section 70(2) BNS.",
    keywords: ["bnss section 482", "anticipatory bail", "438 crpc", "pre arrest bail", "high court bail", "sessions court anticipatory bail", "arrest protection"]
  },

  // SECTION 530: TRIALS AND PROCEEDINGS IN ELECTRONIC MODE
  {
    sectionNumber: "530",
    chapter: "CHAPTER XXXIX: MISCELLANEOUS",
    chapterNumber: "CHAPTER XXXIX",
    marginalTitle: "Trial and proceedings to be held in electronic mode",
    crpcEquivalent: "Brand new technological mandate",
    statutoryText: `530. All trials, inquires and proceedings under this Sanhita, including—
(i) issuance, service and execution of summons and warrant;
(ii) examination of complainant and witnesses;
(iii) recording of evidence in inquiries and trials; and
(iv) all appellate proceedings or any other proceeding,
may be held in electronic mode, by use of electronic communication or use of audio-video electronic means.`,
    category: "Digital Courts & E-Justice",
    court: "All Criminal Courts, High Courts & Supreme Court",
    whomToBeTakenTo: "Empowers paperless e-courts, virtual hearings, digital warrants, and remote witness examinations.",
    isNewProvision: true,
    keyChangesIn2023: "Revolutionary statutory authorization making electronic mode, digital trials, and video hearings standard across Indian criminal justice.",
    keywords: ["bnss section 530", "electronic mode trial", "virtual court", "video conferencing trial", "digital warrants", "electronic evidence recording"]
  },

  // SECTION 531: REPEAL OF CR.P.C. 1973
  {
    sectionNumber: "531",
    chapter: "CHAPTER XXXIX: MISCELLANEOUS",
    chapterNumber: "CHAPTER XXXIX",
    marginalTitle: "Repeal and savings",
    crpcEquivalent: "Repeal of Code of Criminal Procedure, 1973 (Act 2 of 1974)",
    statutoryText: `531. (1) The Code of Criminal Procedure, 1973 is hereby repealed.
(2) Notwithstanding such repeal—
(a) if, immediately before the date on which this Sanhita comes into force, there is any appeal, application, trial, inquiry or investigation pending, then, such appeal, application, trial, inquiry or investigation shall be disposed of, continued, held or made, as the case may be, in accordance with the provisions of the Code of Criminal Procedure, 1973, as if this Sanhita had not come into force;
(b) all notifications, proclamations, powers, forms, jurisdictions, sentences and orders in force shall be deemed passed under the corresponding provisions of this Sanhita;
(c) any sanction or consent under the said Code shall be deemed given under this Sanhita.`,
    category: "Transition & Repeal",
    court: "All Criminal Courts",
    whomToBeTakenTo: "Applies to all criminal cases across India; pending matters continue under 1973 Code.",
    keyChangesIn2023: "Formal sunset of 50-year-old CrPC 1973, establishing seamless transition to BNSS 2023.",
    keywords: ["bnss section 531", "repeal of crpc", "repeal and savings", "code of criminal procedure repealed", "transitional cases", "crpc 1973"]
  }
];
