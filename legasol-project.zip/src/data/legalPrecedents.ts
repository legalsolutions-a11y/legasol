export interface LegalPrecedent {
  id: string;
  caseTitle: string;
  citation: string;
  court: string;
  year: number;
  bench: string;
  sections: string[];
  ipcCounterpart: string;
  outcomeSupport: 'conviction' | 'acquittal' | 'dilution' | 'all';
  category: 'body' | 'property' | 'women' | 'economic' | 'public' | 'minor';
  ratioDecidendi: string;
  keyQuotation: string;
  evidentiaryApplication: string;
  landmarkSignificance: string;
  tags: string[];
}

export const LEGAL_PRECEDENTS: LegalPrecedent[] = [
  // 1. Human Body & Injury (BNS 103, 105, 106, 109, 115, 117)
  {
    id: 'prec-sharad-birdhichand',
    caseTitle: 'Sharad Birdhichand Sarda v. State of Maharashtra',
    citation: '(1984) 4 SCC 116 : AIR 1984 SC 1622',
    court: 'Supreme Court of India',
    year: 1984,
    bench: 'Y.V. Chandrachud C.J., S. Murtaza Fazal Ali & A. Varadarajan JJ.',
    sections: ['103(1)', '105'],
    ipcCounterpart: 'IPC Section 302, 304',
    outcomeSupport: 'acquittal',
    category: 'body',
    ratioDecidendi: 'Laid down the foundational "Panchsheel" (five golden principles) for convicting an accused on circumstantial evidence. The chain of evidence must be so complete as to leave no reasonable ground for a conclusion consistent with the innocence of the accused.',
    keyQuotation: 'The circumstances from which the conclusion of guilt is to be drawn should be in the first instance fully established... they should be conclusive in nature and exclude every possible hypothesis except the one to be proved.',
    evidentiaryApplication: 'Directly supports Acquittal when forensic chain of custody is broken, weapon recovery under Section 23 BSA (Sec 27 IEA) is doubtful, or independent witnesses are absent.',
    landmarkSignificance: 'The golden charter for evaluating circumstantial criminal charges in all Indian trial courts.',
    tags: ['Circumstantial Evidence', 'Benefit of Doubt', 'Panchsheel', 'Burden of Proof']
  },
  {
    id: 'prec-rayavarapu-punnayya',
    caseTitle: 'State of Andhra Pradesh v. Rayavarapu Punnayya',
    citation: '(1976) 4 SCC 382 : AIR 1977 SC 45',
    court: 'Supreme Court of India',
    year: 1976,
    bench: 'R.S. Sarkaria & P.N. Shinghal JJ.',
    sections: ['103(1)', '105'],
    ipcCounterpart: 'IPC Section 299, 300, 302, 304',
    outcomeSupport: 'dilution',
    category: 'body',
    ratioDecidendi: 'Established the definitive 3-stage judicial test to demarcate Murder (now BNS 101/103) from Culpable Homicide not amounting to Murder (BNS 100/105). Absence of premeditated intention or single blow in sudden quarrel dilutes charge to BNS 105 Part II.',
    keyQuotation: 'Culpable homicide is the genus and murder is its specie. All murder is culpable homicide but all culpable homicide is not murder.',
    evidentiaryApplication: 'Crucial for Section Dilution when weapon is not lethal, injuries were sustained during a mutual scuffle, or medical testimony shows death was not the immediate inevitable result.',
    landmarkSignificance: 'The benchmark precedent cited in every homicide trial arguing for charge dilution from death/life sentence to term imprisonment.',
    tags: ['Murder vs Culpable Homicide', 'Intention vs Knowledge', 'Sudden Fight', 'Section Dilution']
  },
  {
    id: 'prec-bachan-singh',
    caseTitle: 'Bachan Singh v. State of Punjab',
    citation: '(1980) 2 SCC 684 : AIR 1980 SC 898',
    court: 'Supreme Court of India (Constitution Bench)',
    year: 1980,
    bench: 'Y.V. Chandrachud C.J., A.C. Gupta, N.L. Untwalia, P.N. Kailasam & P.N. Bhagwati JJ.',
    sections: ['103(1)', '103(2)'],
    ipcCounterpart: 'IPC Section 302',
    outcomeSupport: 'all',
    category: 'body',
    ratioDecidendi: 'Formulated the "Rarest of Rare" doctrine for capital punishment. Life imprisonment is the rule and capital sentence is an exception. Aggravating and mitigating circumstances must be balanced.',
    keyQuotation: 'A real and abiding concern for the dignity of human life postulates resistance to taking a life through law\'s instrumentality. That ought not to be done save in the rarest of rare cases when the alternative option is unquestionably foreclosed.',
    evidentiaryApplication: 'Governs sentencing in murder charges. Lack of past criminal record, young age, or probability of reformation firmly rules out capital sentence even on conviction.',
    landmarkSignificance: 'Constitutional bedrock restricting death penalty under Indian penal statutes.',
    tags: ['Rarest of Rare', 'Death Penalty', 'Sentencing Mitigations', 'Aggravating Factors']
  },
  {
    id: 'prec-balram-bama-patil',
    caseTitle: 'State of Maharashtra v. Balram Bama Patil',
    citation: '(1983) 2 SCC 28 : AIR 1983 SC 305',
    court: 'Supreme Court of India',
    year: 1983,
    bench: 'O. Chinnappa Reddy & E.S. Venkataramiah JJ.',
    sections: ['109', '115(2)', '117(2)'],
    ipcCounterpart: 'IPC Section 307, 324, 326',
    outcomeSupport: 'conviction',
    category: 'body',
    ratioDecidendi: 'To establish Attempt to Murder (now BNS 109), it is not essential that bodily injury capable of causing death should actually have been inflicted. The intention to cause death, coupled with an overt act towards its execution, completes the offence.',
    keyQuotation: 'It is not necessary under Section 307 that the injury actually caused should be capable of causing death in the ordinary course of nature... What the Court has to see is whether the act was done with the intention or knowledge and under circumstances mentioned in that section.',
    evidentiaryApplication: 'Supports Conviction under BNS Section 109 when accused aimed at vital parts with lethal weapons, even if prompt medical aid prevented fatal consequences.',
    landmarkSignificance: 'Prevents accused from evading Section 109 liability merely because the victim survived by chance or medical intervention.',
    tags: ['Attempt to Murder', 'Overt Act', 'Vital Organ Injury', 'Intention']
  },
  {
    id: 'prec-jacob-mathew',
    caseTitle: 'Jacob Mathew v. State of Punjab',
    citation: '(2005) 6 SCC 1 : AIR 2005 SC 3180',
    court: 'Supreme Court of India (3-Judge Bench)',
    year: 2005,
    bench: 'R.C. Lahoti C.J., G.P. Mathur & P.K. Balasubramanyan JJ.',
    sections: ['106(1)', '106(2)'],
    ipcCounterpart: 'IPC Section 304A',
    outcomeSupport: 'acquittal',
    category: 'body',
    ratioDecidendi: 'To fasten criminal liability for rash or negligent acts under Section 304A (now BNS 106), the negligence must be gross and of a very high degree ("mens rea of reckless disregard"), far surpassing mere civil tort negligence.',
    keyQuotation: 'A simple lack of care, an error of judgment or an accident, is not proof of negligence on the part of a medical professional or driver so as to attract criminal penal liability.',
    evidentiaryApplication: 'Protects accused from rash driving or professional negligence convictions when unexpected mechanical failure, road hazard, or complainant\'s own contributory sudden crossing caused the mishap.',
    landmarkSignificance: 'Mandated preliminary medical board opinion prior to arresting professionals or booking under criminal rashness.',
    tags: ['Gross Negligence', 'Hit and Run', 'Mens Rea', 'Error of Judgment']
  },

  // 2. Property, Robbery & Theft (BNS 303, 304, 308, 309, 310, 316)
  {
    id: 'prec-pyare-lal',
    caseTitle: 'Pyare Lal Bhargava v. State of Rajasthan',
    citation: 'AIR 1963 SC 1094 : 1963 Supp (1) SCR 689',
    court: 'Supreme Court of India',
    year: 1963,
    bench: 'K. Subba Rao, Raghubar Dayal & J.R. Mudholkar JJ.',
    sections: ['303(2)', '304'],
    ipcCounterpart: 'IPC Section 378, 379',
    outcomeSupport: 'conviction',
    category: 'property',
    ratioDecidendi: 'To constitute theft under BNS 303 (IPC 378), permanent deprivation of property is not necessary. Temporary removal of movable property from the lawful possession of a person with dishonest intention satisfies all legal ingredients.',
    keyQuotation: 'Taking dishonestly does not mean that the taking must be with the intention of causing permanent wrongful gain or loss. A temporary deprivation is sufficient to complete the offence.',
    evidentiaryApplication: 'Supports conviction even if the accused claims they returned the snatched bag or borrowed the vehicle without permission.',
    landmarkSignificance: 'Clarified that temporary unauthorized possession with mens rea fulfills theft requirements.',
    tags: ['Theft', 'Dishonest Intention', 'Temporary Deprivation', 'Moving of Property']
  },
  {
    id: 'prec-raj-kumar-dacoity',
    caseTitle: 'Raj Kumar @ Suman v. State (NCT of Delhi)',
    citation: '(2017) 11 SCC 145 : AIR 2017 SC 1145',
    court: 'Supreme Court of India',
    year: 2017,
    bench: 'Pinaki Chandra Ghose & Amitava Roy JJ.',
    sections: ['308(2)', '309(4)', '310(2)'],
    ipcCounterpart: 'IPC Section 392, 395, 397',
    outcomeSupport: 'acquittal',
    category: 'property',
    ratioDecidendi: 'In cases of armed robbery and dacoity committed by strangers in the dark, failure of the investigating agency to hold a prompt Test Identification Parade (TIP) creates a fatal lacuna in prosecution testimony.',
    keyQuotation: 'Dock identification in court for the very first time without prior TIP loses its corroborative value where the accused was unfamiliar to the victim.',
    evidentiaryApplication: 'Provides strong foundation for Acquittal when no TIP was conducted, or recovered stolen items lacked distinctive identification marks proved by purchase invoices.',
    landmarkSignificance: 'Mandated strict compliance with TIP procedures under Indian criminal evidentiary standards.',
    tags: ['Robbery', 'Dacoity', 'Test Identification Parade', 'Identification in Court']
  },

  // 3. Women & Child Protection (BNS 64, 69, 70, 85)
  {
    id: 'prec-gurmit-singh',
    caseTitle: 'State of Punjab v. Gurmit Singh',
    citation: '(1996) 2 SCC 384 : AIR 1996 SC 1393',
    court: 'Supreme Court of India',
    year: 1996,
    bench: 'A.S. Anand & Faizan Uddin JJ.',
    sections: ['64(1)', '70(1)'],
    ipcCounterpart: 'IPC Section 376',
    outcomeSupport: 'conviction',
    category: 'women',
    ratioDecidendi: 'The testimony of a victim of sexual violence is entitled to great weight and does not require corroboration like an accomplice. Unless there are compelling reasons to doubt, conviction can be based solely on the truthful deposition of the prosecutrix.',
    keyQuotation: 'The courts must deal with cases of sexual assault with utmost sensitivity. Seeking corroboration of her statement before relying upon the same is adding insult to injury.',
    evidentiaryApplication: 'Prosecution holds high probability of conviction even if independent public witnesses are absent, provided the victim\'s statement under Section 183 BNSS (Sec 164 CrPC) remains consistent.',
    landmarkSignificance: 'The landmark ruling establishing judicial empathy and evidentiary weight for victims of sexual crimes.',
    tags: ['Sole Testimony', 'Corroboration Not Mandatory', 'Sexual Assault', 'Victim Credibility']
  },
  {
    id: 'prec-pramod-pawar',
    caseTitle: 'Pramod Suryabhan Pawar v. State of Maharashtra',
    citation: '(2019) 9 SCC 608 : AIR 2019 SC 4010',
    court: 'Supreme Court of India',
    year: 2019,
    bench: 'D.Y. Chandrachud & Indira Banerjee JJ.',
    sections: ['69', '64(1)'],
    ipcCounterpart: 'BNS Section 69 (IPC 375/376/417)',
    outcomeSupport: 'acquittal',
    category: 'women',
    ratioDecidendi: 'Drew a sharp distinction between a false promise to marry made deceitfully from inception, versus a subsequent breach of promise arising from parental disapproval or unforeseen circumstances. Only intentional deceit from inception attracts criminal sanction under Section 69.',
    keyQuotation: 'There is a clear distinction between rape and consensual sex. Where the relationship was long-standing and mutual affection existed, subsequent breakdown of marriage talks does not constitute rape under misconception of fact.',
    evidentiaryApplication: 'Directly supports Acquittal under BNS Section 69 when digital chats show voluntary consensual intimacy and genuine efforts were made to solemnize marriage.',
    landmarkSignificance: 'The cornerstone precedent guiding the application of the newly enacted BNS Section 69.',
    tags: ['Promise of Marriage', 'Deceitful Assurances', 'Consensual Relationship', 'BNS Section 69']
  },
  {
    id: 'prec-arnesh-kumar',
    caseTitle: 'Arnesh Kumar v. State of Bihar',
    citation: '(2014) 8 SCC 273 : AIR 2014 SC 2756',
    court: 'Supreme Court of India',
    year: 2014,
    bench: 'Chandramauli Kumar Prasad & Pinaki Chandra Ghose JJ.',
    sections: ['85', '351(2)'],
    ipcCounterpart: 'IPC Section 498A, 506 / CrPC 41',
    outcomeSupport: 'dilution',
    category: 'women',
    ratioDecidendi: 'Issued strict arrest guidelines for offenses punishable with up to 7 years imprisonment (specifically domestic cruelty BNS 85 / IPC 498A). Police officers cannot mechanically arrest; Section 35(3) BNSS notice must be issued first.',
    keyQuotation: 'Arrest brings humiliation, curtails freedom and casts scars forever. Law makers know it and we must prevent police harassment by enforcing Section 41 notice rigorously.',
    evidentiaryApplication: 'Mandatory shield against arbitrary arrest in marital disputes. Supports Section Dilution and judicial mediation prior to framing charges.',
    landmarkSignificance: 'Transformed arrest procedure across India for offenses carrying under 7 years penalty.',
    tags: ['BNS 85', 'Domestic Cruelty', 'Arrest Safeguards', 'BNSS Section 35 Notice']
  },
  {
    id: 'prec-kahkashan-kausar',
    caseTitle: 'Kahkashan Kausar @ Sonam v. State of Bihar',
    citation: '(2022) 6 SCC 599 : AIR 2022 SC 920',
    court: 'Supreme Court of India (3-Judge Bench)',
    year: 2022,
    bench: 'S. Abdul Nazeer, A.S. Bopanna & V. Ramasubramanian JJ.',
    sections: ['85'],
    ipcCounterpart: 'IPC Section 498A',
    outcomeSupport: 'acquittal',
    category: 'women',
    ratioDecidendi: 'General and omnibus allegations against relatives of the husband without specific roles or physical incidents cannot sustain criminal trial under Section 498A (BNS 85). Trial against distant in-laws is liable to be quashed.',
    keyQuotation: 'This court has repeatedly cautioned against implicating the entire family of the husband on general vague assertions devoid of specific dates or overt acts.',
    evidentiaryApplication: 'Directly supports discharge or acquittal for co-accused in-laws when FIR text lacks specific dates, times, and overt acts of dowry demand.',
    landmarkSignificance: 'Primary defense shield against omnibus implication of extended family members in matrimonial disputes.',
    tags: ['Omnibus Allegations', 'In-laws Protection', 'Discharge', 'Quashing']
  },

  // 4. Economic, Cyber & Cheating (BNS 318(4), 319, 336(3), 338, 111)
  {
    id: 'prec-hridaya-ranjan',
    caseTitle: 'Hridaya Ranjan Prasad Verma v. State of Bihar',
    citation: '(2000) 4 SCC 168 : AIR 2000 SC 2341',
    court: 'Supreme Court of India',
    year: 2000,
    bench: 'K.T. Thomas & D.P. Mohapatra JJ.',
    sections: ['318(4)', '319'],
    ipcCounterpart: 'IPC Section 415, 420',
    outcomeSupport: 'acquittal',
    category: 'economic',
    ratioDecidendi: 'To constitute Cheating under BNS Section 318(4) (IPC 420), dishonest intention must exist at the very inception of the transaction. Mere inability to fulfill commercial promise subsequently is only breach of contract, not criminal cheating.',
    keyQuotation: 'The distinction between mere breach of contract and cheating depends upon the intention of the accused at the time of inducement. Subsequent non-fulfillment does not give rise to criminal prosecution.',
    evidentiaryApplication: 'Decisive for Acquittal in financial disputes, business failures, or unpaid loans where complainant fails to prove deceptive fraudulent mind from Day 1.',
    landmarkSignificance: 'The quintessential authority quashing criminal complaints filed to recover commercial debts.',
    tags: ['Cheating', 'Civil Dispute vs Criminal Offence', 'Fraudulent Inception', 'Mens Rea']
  },
  {
    id: 'prec-arjun-panditrao',
    caseTitle: 'Arjun Panditrao Khotkar v. Kailash Kushanrao Gorantyal',
    citation: '(2020) 7 SCC 1 : AIR 2020 SC 4917',
    court: 'Supreme Court of India (3-Judge Bench)',
    year: 2020,
    bench: 'R.F. Nariman, S. Ravindra Bhat & V. Ramasubramanian JJ.',
    sections: ['318(4)', '336(3)', '338'],
    ipcCounterpart: 'Section 65B Indian Evidence Act / Section 61 BSA 2023',
    outcomeSupport: 'all',
    category: 'economic',
    ratioDecidendi: 'Compliance with electronic certificate requirements (now Section 61 of BSA 2023 / former Sec 65B) is mandatory condition precedent for admissibility of electronic records like WhatsApp chats, server logs, CDRs, and CCTV footage.',
    keyQuotation: 'Production of Section 65B certificate is mandatory where electronic evidence is relied upon. Oral testimony cannot substitute the statutory electronic certificate.',
    evidentiaryApplication: 'If police/prosecution fails to secure a valid Section 61 BSA electronic certificate for CDRs, bank cyber traces, or WhatsApp logs, all digital evidence becomes legally inadmissible, collapsing the prosecution case.',
    landmarkSignificance: 'Governs all cybercrime, bank fraud, and digital forensic trials under BNS and BSA 2023.',
    tags: ['Electronic Evidence', 'BSA Section 61', 'Admissibility', 'Cyber Forensics']
  },

  // 5. State & Public Order (BNS 152, 191(2), 190, 196, 223)
  {
    id: 'prec-baladin-assembly',
    caseTitle: 'Baladin v. State of Uttar Pradesh',
    citation: 'AIR 1956 SC 181 : 1956 Cri LJ 345',
    court: 'Supreme Court of India',
    year: 1956,
    bench: 'B. Jagannadhadas, B.P. Sinha & Syed Jafer Imam JJ.',
    sections: ['191(2)', '190', '196'],
    ipcCounterpart: 'IPC Section 141, 147, 149',
    outcomeSupport: 'acquittal',
    category: 'public',
    ratioDecidendi: 'Mere presence in an unruly crowd or assembly does not make an innocent bystander a member of an unlawful assembly under Section 190 (IPC 149). Prosecution must prove active participation or sharing of the common criminal object.',
    keyQuotation: 'In an assembly of persons, it is necessary to show that a person was actuated by the common unlawful object before he can be condemned as a member thereof.',
    evidentiaryApplication: 'Vital for defending bystanders caught in mob clashes or street protests who were arrested without proof of weapons or overt acts.',
    landmarkSignificance: 'Protects citizens against collective guilt and indiscriminate group booking in public disorder cases.',
    tags: ['Unlawful Assembly', 'Rioting', 'Common Object', 'Innocent Bystander']
  },
  {
    id: 'prec-kedar-nath',
    caseTitle: 'Kedar Nath Singh v. State of Bihar',
    citation: 'AIR 1962 SC 955 : 1962 Supp (2) SCR 769',
    court: 'Supreme Court of India (Constitution Bench)',
    year: 1962,
    bench: 'B.P. Sinha C.J., A.K. Sarkar, J.R. Mudholkar, N. Rajagopala Ayyangar & J.R. Subba Rao JJ.',
    sections: ['152', '196', '223'],
    ipcCounterpart: 'IPC Section 124A, 153A',
    outcomeSupport: 'acquittal',
    category: 'public',
    ratioDecidendi: 'Strong criticism of government policies or administration, unaccompanied by incitement to public disorder or violent acts, is constitutionally protected under Article 19(1)(a) and does not constitute treason or subversion.',
    keyQuotation: 'Criticism of public measures or comment on government action, however strongly worded, is within reasonable limits and does not endanger sovereignty unless there is incitement to violence.',
    evidentiaryApplication: 'Guards against overzealous state prosecution under BNS Section 152 (acts endangering sovereignty) for political discourse or social media critiques.',
    landmarkSignificance: 'The constitutional benchmark preserving free speech from penal overreach.',
    tags: ['Freedom of Speech', 'Article 19', 'Incitement Standard', 'BNS Section 152']
  },

  // 6. Minor Offences & General Criminal Law (BNS 351(2), 352, 296, 355)
  {
    id: 'prec-vikram-johar',
    caseTitle: 'Vikram Johar v. State of Uttar Pradesh',
    citation: '(2019) 14 SCC 207 : AIR 2019 SC 2109',
    court: 'Supreme Court of India',
    year: 2019,
    bench: 'Ashok Bhushan & K.M. Joseph JJ.',
    sections: ['351(2)', '352', '296'],
    ipcCounterpart: 'IPC Section 504, 506',
    outcomeSupport: 'acquittal',
    category: 'minor',
    ratioDecidendi: 'Mere abusive words or foul verbal exchange without intent to provoke the victim to break the public peace, or without causing an alarming threat to life/property, does not attract criminal prosecution under Section 504/506 (BNS 351/352).',
    keyQuotation: 'Mere abuse, discourtesy or rude language does not attract Section 504. The intentional insult must be of such nature that it gives provocation to cause breach of public peace.',
    evidentiaryApplication: 'Directly supports dismissal or acquittal in neighborhood brawls and verbal disputes where no physical threat or weapons were displayed.',
    landmarkSignificance: 'Prevents minor verbal disputes and insults from burdening criminal courts as cognizable threats.',
    tags: ['Criminal Intimidation', 'Intentional Insult', 'Verbal Dispute', 'Lack of Mens Rea']
  },
  {
    id: 'prec-manik-taneja',
    caseTitle: 'Manik Taneja v. State of Karnataka',
    citation: '(2015) 7 SCC 423 : 2015 Cri LJ 1754',
    court: 'Supreme Court of India',
    year: 2015,
    bench: 'Ranjan Gogoi & N.V. Ramana JJ.',
    sections: ['351(2)', '352'],
    ipcCounterpart: 'IPC Section 503, 506',
    outcomeSupport: 'acquittal',
    category: 'minor',
    ratioDecidendi: 'Posting genuine grievances or emotional complaints on social media criticizing traffic police or municipal officers does not constitute Criminal Intimidation unless there is an overt threat to cause bodily harm, reputation loss, or property destruction.',
    keyQuotation: 'The intention of the accused must be to cause an alarm to the person threatened. A mere expression of anguish or protest cannot be termed criminal intimidation.',
    evidentiaryApplication: 'Guarantees acquittal in online complaints and public reviews misconstrued as intimidation.',
    landmarkSignificance: 'Defends digital citizens from abuse of criminal intimidation provisions.',
    tags: ['Online Free Speech', 'Criminal Intimidation', 'Social Media Posts', 'Public Grievance']
  }
];

export function getPrecedentsForAnalysis(
  activeSections: string[],
  predictedOutcome: 'conviction' | 'acquittal' | 'dilution',
  category?: string
): LegalPrecedent[] {
  let matched = LEGAL_PRECEDENTS.filter(prec => {
    // Check if section matches
    const hasSectionMatch = prec.sections.some(s => activeSections.includes(s));
    // Or if category matches
    const hasCategoryMatch = category ? prec.category === category : false;
    return hasSectionMatch || hasCategoryMatch;
  });

  // If no direct matches, return general landmark authorities
  if (matched.length === 0) {
    matched = LEGAL_PRECEDENTS.filter(p => p.outcomeSupport === predictedOutcome || p.outcomeSupport === 'all');
  }

  // Sort: matching section first, then matching predicted outcome
  return matched.sort((a, b) => {
    const aSectionMatch = a.sections.some(s => activeSections.includes(s)) ? 1 : 0;
    const bSectionMatch = b.sections.some(s => activeSections.includes(s)) ? 1 : 0;
    if (bSectionMatch !== aSectionMatch) return bSectionMatch - aSectionMatch;

    const aOutcomeMatch = (a.outcomeSupport === predictedOutcome || a.outcomeSupport === 'all') ? 1 : 0;
    const bOutcomeMatch = (b.outcomeSupport === predictedOutcome || b.outcomeSupport === 'all') ? 1 : 0;
    return bOutcomeMatch - aOutcomeMatch;
  });
}
