/**
 * The Gazette of India Extraordinary (Part II — Section 1, No. 53, New Delhi, Dec 25, 2023)
 * MINISTRY OF LAW AND JUSTICE (Legislative Department)
 * THE BHARATIYA NYAYA SANHITA, 2023 (ACT NO. 45 OF 2023)
 * Full Comprehensive Chapters I to XX and Key Sections with Official Gazette Verbatim Text
 */

export interface BNSChapter {
  number: string; // e.g. "CHAPTER I"
  title: string; // e.g. "PRELIMINARY"
  sectionRange: string; // e.g. "Sections 1 – 3"
  description: string;
}

export interface BNSGazetteSection {
  sectionNumber: string; // e.g. "1", "103", "318"
  chapter: string; // e.g. "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY"
  chapterNumber: string; // e.g. "CHAPTER VI"
  marginalTitle: string; // Official title from Gazette e.g. "Punishment for murder"
  ipcEquivalent: string; // e.g. "IPC Section 302"
  statutoryText: string; // Verbatim official Gazette statutory text
  explanationsAndIllustrations?: string;
  cognizable: boolean;
  bailable: boolean;
  compoundable: boolean;
  punishment: string;
  prisonYears: string;
  court: string;
  whomToBeTakenTo: string;
  isNewProvision?: boolean;
  keyChangesIn2023?: string;
  keywords: string[];
}

export const BNS_GAZETTE_CHAPTERS: BNSChapter[] = [
  {
    number: "CHAPTER I",
    title: "PRELIMINARY",
    sectionRange: "Sections 1 – 3",
    description: "Short title, commencement, territorial and extra-territorial application, 39 statutory definitions, and general explanations including common intention."
  },
  {
    number: "CHAPTER II",
    title: "OF PUNISHMENTS",
    sectionRange: "Sections 4 – 13",
    description: "Categories of punishments (Death, Life imprisonment, Rigorous/Simple imprisonment, Forfeiture, Fine, Community Service), commutation, fractions, and solitary confinement."
  },
  {
    number: "CHAPTER III",
    title: "GENERAL EXCEPTIONS",
    sectionRange: "Sections 14 – 44",
    description: "Acts bound by law, mistake of fact, judicial acts, accidents, necessity, infancy (under 7, 7-12), unsoundness of mind, intoxication, consent, and comprehensive Right of Private Defence (Sec 34-44)."
  },
  {
    number: "CHAPTER IV",
    title: "OF ABETMENT, CRIMINAL CONSPIRACY AND ATTEMPT",
    sectionRange: "Sections 45 – 62",
    description: "Abetment of offences (Sec 45-60), Criminal conspiracy (Sec 61), and general provisions for Attempt to commit offences (Sec 62)."
  },
  {
    number: "CHAPTER V",
    title: "OF OFFENCES AGAINST WOMAN AND CHILD",
    sectionRange: "Sections 63 – 99",
    description: "Sexual offences (Rape Sec 63-66, Gang rape Sec 70, False promise to marry Sec 69), Outraging modesty (Sec 74), Sexual harassment (Sec 75), Voyeurism (Sec 77), Stalking (Sec 78), Dowry death (Sec 80), Cruelty by husband/relatives (Sec 85-86), Miscarriage (Sec 88-92), and Offences against children (Sec 93-99)."
  },
  {
    number: "CHAPTER VI",
    title: "OF OFFENCES AFFECTING THE HUMAN BODY",
    sectionRange: "Sections 100 – 146",
    description: "Offences affecting life (Culpable homicide Sec 100, Murder Sec 101-104, Negligent death/hit-and-run Sec 106, Attempt to murder Sec 109-110), Organised crime (Sec 111), Petty organised crime (Sec 112), Terrorist act (Sec 113), Hurt & Grievous hurt (Sec 114-124), Acid attacks (Sec 124), Wrongful restraint/confinement (Sec 126-127), Criminal force & assault (Sec 128-136), Kidnapping, abduction, trafficking & slavery (Sec 137-146)."
  },
  {
    number: "CHAPTER VII",
    title: "OF OFFENCES AGAINST THE STATE",
    sectionRange: "Sections 147 – 158",
    description: "Waging war against Government of India (Sec 147-150), Assaulting President or Governor (Sec 151), Endangering sovereignty, unity and integrity of India (Sec 152 replacing sedition), and State prisoner escapes."
  },
  {
    number: "CHAPTER VIII",
    title: "OF OFFENCES RELATING TO THE ARMY, NAVY AND AIR FORCE",
    sectionRange: "Sections 159 – 168",
    description: "Abetting mutiny, desertion, insubordination, and wearing unauthorized military garb or tokens."
  },
  {
    number: "CHAPTER IX",
    title: "OF OFFENCES RELATING TO ELECTIONS",
    sectionRange: "Sections 169 – 177",
    description: "Bribery (Sec 170/173), Undue influence (Sec 171/174), Personation at elections (Sec 172), False election statements (Sec 175), and Illegal election payments (Sec 176)."
  },
  {
    number: "CHAPTER X",
    title: "OF OFFENCES RELATING TO COIN, CURRENCY-NOTES, BANK-NOTES, AND GOVERNMENT STAMPS",
    sectionRange: "Sections 178 – 188",
    description: "Counterfeiting currency-notes, coins, and stamps, trafficking counterfeit notes, making dies/machinery, and mint offences."
  },
  {
    number: "CHAPTER XI",
    title: "OF OFFENCES AGAINST THE PUBLIC TRANQUILLITY",
    sectionRange: "Sections 189 – 197",
    description: "Unlawful assembly (Sec 189-190), Rioting (Sec 191-193), Affray (Sec 194), Promoting enmity between groups (Sec 196), and Imputations prejudicial to national integration (Sec 197)."
  },
  {
    number: "CHAPTER XII",
    title: "OF OFFENCES BY OR RELATING TO PUBLIC SERVANTS",
    sectionRange: "Sections 198 – 205",
    description: "Public servant disobeying law (Sec 198-199), Non-treatment of victims by hospitals (Sec 200), Framing incorrect documents (Sec 201), Unlawful trading/bidding (Sec 202-203), and False personation of public servants (Sec 204-205)."
  },
  {
    number: "CHAPTER XIII",
    title: "OF CONTEMPTS OF THE LAWFUL AUTHORITY OF PUBLIC SERVANTS",
    sectionRange: "Sections 206 – 226",
    description: "Absconding to avoid summons (Sec 206-208), Proclaimed offender non-appearance (Sec 209), Omission to produce documents or info (Sec 210-212), False info (Sec 217), Obstructing public servants (Sec 221-222), Disobeying promulgated orders (Sec 223), and Suicide threat to coerce public servant (Sec 226)."
  },
  {
    number: "CHAPTER XIV",
    title: "OF FALSE EVIDENCE AND OFFENCES AGAINST PUBLIC JUSTICE",
    sectionRange: "Sections 227 – 269",
    description: "Giving and fabricating false evidence (Sec 227-231), Threatening witnesses (Sec 232), Disappearance of evidence (Sec 238), False charges with intent to injure (Sec 248), Harbouring offenders (Sec 249-254), Resisting arrest/escaping custody (Sec 262-265), and Bail bond jump (Sec 269)."
  },
  {
    number: "CHAPTER XV",
    title: "OF OFFENCES AFFECTING THE PUBLIC HEALTH, SAFETY, CONVENIENCE, DECENCY AND MORALS",
    sectionRange: "Sections 270 – 297",
    description: "Public nuisance (Sec 270), Spreading infectious disease (Sec 271-272), Adulteration of food and drugs (Sec 274-278), Fouling public water/air (Sec 279-280), Rash driving/riding (Sec 281), Negligence with machinery/fire/poisons (Sec 286-291), Obscene literature and acts (Sec 294-296), and Keeping lottery offices (Sec 297)."
  },
  {
    number: "CHAPTER XVI",
    title: "OF OFFENCES RELATING TO RELIGION",
    sectionRange: "Sections 298 – 302",
    description: "Defiling places of worship (Sec 298), Outraging religious feelings (Sec 299), Disturbing religious assemblies (Sec 300), Burial trespass (Sec 301), and Words wounding religious feelings (Sec 302)."
  },
  {
    number: "CHAPTER XVII",
    title: "OF OFFENCES AGAINST PROPERTY",
    sectionRange: "Sections 303 – 334",
    description: "Theft (Sec 303), Snatching (Sec 304 brand new offense), Dwelling theft (Sec 305), Extortion (Sec 308), Robbery & Dacoity (Sec 309-313), Criminal misappropriation (Sec 314-315), Criminal breach of trust (Sec 316), Stolen property (Sec 317), Cheating & Personation (Sec 318-319), Mischief (Sec 324-328), Criminal trespass and House-breaking (Sec 329-334)."
  },
  {
    number: "CHAPTER XVIII",
    title: "OF OFFENCES RELATING TO DOCUMENTS AND TO PROPERTY MARKS",
    sectionRange: "Sections 335 – 350",
    description: "Making false documents/electronic records (Sec 335), Forgery (Sec 336-340), Counterfeit seals/plates (Sec 341-342), Falsification of accounts (Sec 344), and Property marks tampering (Sec 345-350)."
  },
  {
    number: "CHAPTER XIX",
    title: "OF CRIMINAL INTIMIDATION, INSULT, ANNOYANCE, DEFAMATION, ETC.",
    sectionRange: "Sections 351 – 356",
    description: "Criminal intimidation (Sec 351), Intentional insult causing breach of peace (Sec 352), Statements conducing to public mischief/fake news (Sec 353), Inducing divine displeasure (Sec 354), Drunken annoyance (Sec 355), and Defamation with Community Service provision (Sec 356)."
  },
  {
    number: "CHAPTER XX",
    title: "REPEAL AND SAVINGS",
    sectionRange: "Sections 357 – 358",
    description: "Breach of contract to attend helpless person (Sec 357), and Repeal of the Indian Penal Code, 1860 (Act 45 of 1860) with statutory savings and continuous transition (Sec 358)."
  }
];

export const BNS_GAZETTE_SECTIONS: BNSGazetteSection[] = [
  // SECTION 1
  {
    sectionNumber: "1",
    chapter: "CHAPTER I: PRELIMINARY",
    chapterNumber: "CHAPTER I",
    marginalTitle: "Short title, commencement and application",
    ipcEquivalent: "IPC Sections 1, 2, 3, 4",
    statutoryText: `1. (1) This Act may be called the Bharatiya Nyaya Sanhita, 2023.
(2) It shall come into force on such date as the Central Government may, by notification in the Official Gazette, appoint, and different dates may be appointed for different provisions of this Sanhita.
(3) Every person shall be liable to punishment under this Sanhita and not otherwise for every act or omission contrary to the provisions thereof, of which he shall be guilty within India.
(4) Any person liable, by any law for the time being in force in India, to be tried for an offence committed beyond India shall be dealt with according to the provisions of this Sanhita for any act committed beyond India in the same manner as if such act had been committed within India.
(5) The provisions of this Sanhita shall also apply to any offence committed by—
(a) any citizen of India in any place without and beyond India;
(b) any person on any ship or aircraft registered in India wherever it may be;
(c) any person in any place without and beyond India committing offence targeting a computer resource located in India.`,
    explanationsAndIllustrations: `Explanation.—In this section, the word “offence” includes every act committed outside India which, if committed in India, would be punishable under this Sanhita.
Illustration: A, who is a citizen of India, commits a murder in any place without and beyond India. He can be tried and convicted of murder in any place in India in which he may be found.`,
    cognizable: false,
    bailable: true,
    compoundable: false,
    punishment: "Jurisdictional application of the Sanhita",
    prisonYears: "N/A (Defines application scope)",
    court: "All Criminal Courts in India",
    whomToBeTakenTo: "Trial court having local territorial jurisdiction over the offender when found in India.",
    keyChangesIn2023: "Explicitly incorporates offences committed anywhere targeting Indian computer resources under sub-clause (5)(c).",
    keywords: ["section 1", "short title", "commencement", "application", "jurisdiction", "computer resource", "extra territorial", "citizen outside india"]
  },

  // SECTION 2
  {
    sectionNumber: "2",
    chapter: "CHAPTER I: PRELIMINARY",
    chapterNumber: "CHAPTER I",
    marginalTitle: "Definitions",
    ipcEquivalent: "IPC Sections 6 to 52A (consolidated)",
    statutoryText: `2. In this Sanhita, unless the context otherwise requires,—
(1) “act” denotes as well a series of acts as a single act;
(2) “animal” means any living creature, other than a human being;
(3) “child” means any person below the age of eighteen years;
(4) “counterfeit”.—A person is said to “counterfeit” who causes one thing to resemble another thing, intending by means of that resemblance to practise deception, or knowing it to be likely that deception will thereby be practised;
(5) “Court” means a Judge who is empowered by law to act judicially alone, or a body of Judges which is empowered by law to act judicially as a body, when such Judge or body of Judges is acting judicially;
(6) “death” means the death of a human being unless the contrary appears from the context;
(7) “dishonestly” means doing anything with the intention of causing wrongful gain to one person or wrongful loss to another person;
(8) “document” means any matter expressed or described upon any substance by means of letters, figures or marks, or by more than one of those means, and includes electronic and digital record, intended to be used, or which may be used, as evidence of that matter;
(10) “gender”.—The pronoun “he” and its derivatives are used of any person, whether male, female or transgender;
(14) “injury” means any harm whatever illegally caused to any person, in body, mind, reputation or property;
(16) “Judge” means a person officially designated as a Judge;
(24) “offence” means a thing made punishable by this Sanhita or under any special or local law;
(28) “public servant” means a person falling under statutory descriptions including judges, armed forces officers, and government servants.`,
    explanationsAndIllustrations: `Clause (10) explicitly defines gender to include 'transgender' pursuant to the Transgender Persons (Protection of Rights) Act, 2019. Clause (8) explicitly defines document to include 'electronic and digital record'.`,
    cognizable: false,
    bailable: true,
    compoundable: false,
    punishment: "Statutory Definitions Clause",
    prisonYears: "N/A",
    court: "All Courts",
    whomToBeTakenTo: "Applies to interpretation across all 358 sections.",
    keyChangesIn2023: "Consolidates dozens of separate IPC sections (6 to 52A) into a single master definition section; adds digital records and transgender recognition.",
    keywords: ["section 2", "definitions", "child", "counterfeit", "document", "dishonestly", "gender", "transgender", "injury", "public servant", "electronic record"]
  },

  // SECTION 4
  {
    sectionNumber: "4",
    chapter: "CHAPTER II: OF PUNISHMENTS",
    chapterNumber: "CHAPTER II",
    marginalTitle: "The punishments to which offenders are liable",
    ipcEquivalent: "IPC Section 53",
    statutoryText: `4. The punishments to which offenders are liable under the provisions of this Sanhita are—
(a) Death;
(b) Imprisonment for life;
(c) Imprisonment, which is of two descriptions, namely:—
    (1) Rigorous, that is, with hard labour;
    (2) Simple;
(d) Forfeiture of property;
(e) Fine;
(f) Community Service.`,
    explanationsAndIllustrations: `Clause (f) introduces Community Service as a formal punishment for the first time in Indian penal jurisprudence for petty and non-violent offences (such as petty theft under Rs 5,000, defamation, public intoxication, and non-appearance of public servants).`,
    cognizable: false,
    bailable: true,
    compoundable: false,
    punishment: "Death, Life imprisonment, Rigorous/Simple imprisonment, Forfeiture, Fine, Community Service",
    prisonYears: "Prescribed according to respective offenses",
    court: "Sentencing Courts",
    whomToBeTakenTo: "Sentencing court determines sentence and community service terms.",
    isNewProvision: true,
    keyChangesIn2023: "Community service officially added as clause (f) punishment.",
    keywords: ["section 4", "punishments", "death", "life imprisonment", "rigorous", "simple", "community service", "fine", "forfeiture"]
  },

  // SECTION 14
  {
    sectionNumber: "14",
    chapter: "CHAPTER III: GENERAL EXCEPTIONS",
    chapterNumber: "CHAPTER III",
    marginalTitle: "Act done by a person bound, or by mistake of fact believing himself bound, by law",
    ipcEquivalent: "IPC Section 76",
    statutoryText: `14. Nothing is an offence which is done by a person who is, or who by reason of a mistake of fact and not by reason of a mistake of law in good faith believes himself to be, bound by law to do it.`,
    explanationsAndIllustrations: `Illustration: (a) A, a soldier, fires on a mob by the order of his superior officer, in conformity with the commands of the law. A has committed no offence.
(b) A, an officer of a Court, being ordered by that Court to arrest Y, and, after due enquiry, believing Z to be Y, arrests Z. A has committed no offence.`,
    cognizable: false,
    bailable: true,
    compoundable: false,
    punishment: "Complete General Defense (No Offence)",
    prisonYears: "Exemption from criminal liability",
    court: "Trial Courts",
    whomToBeTakenTo: "Plea of general exception raised before Judicial Magistrate or Sessions Judge.",
    keywords: ["section 14", "mistake of fact", "bound by law", "superior orders", "general exception", "good faith", "76"]
  },

  // SECTION 20
  {
    sectionNumber: "20",
    chapter: "CHAPTER III: GENERAL EXCEPTIONS",
    chapterNumber: "CHAPTER III",
    marginalTitle: "Act of a child under seven years of age",
    ipcEquivalent: "IPC Section 82 (Doli incapax)",
    statutoryText: `20. Nothing is an offence which is done by a child under seven years of age.`,
    explanationsAndIllustrations: `Absolute statutory immunity (doli incapax) for children below seven years of age. Section 21 covers children between 7 and 12 years of immature understanding.`,
    cognizable: false,
    bailable: true,
    compoundable: false,
    punishment: "Complete Statutory Exemption",
    prisonYears: "Immunity",
    court: "Juvenile Justice Board (JJB)",
    whomToBeTakenTo: "Child produced before Juvenile Justice Board; no criminal prosecution permissible.",
    keywords: ["section 20", "child under seven", "doli incapax", "juvenile immunity", "age defense", "82"]
  },

  // SECTION 34
  {
    sectionNumber: "34",
    chapter: "CHAPTER III: GENERAL EXCEPTIONS",
    chapterNumber: "CHAPTER III",
    marginalTitle: "Things done in private defence",
    ipcEquivalent: "IPC Section 96",
    statutoryText: `34. Nothing is an offence which is done in the exercise of the right of private defence.
35. Every person has a right, subject to the restrictions contained in section 37, to defend—
(a) his own body, and the body of any other person, against any offence affecting the human body;
(b) the property, whether movable or immovable, of himself or of any other person, against any act which is an offence falling under theft, robbery, mischief or criminal trespass.`,
    explanationsAndIllustrations: `Section 38: Right of private defence of body extends to voluntarily causing death in cases of reasonable apprehension of death, grievous hurt, rape, unnatural lust, kidnapping, wrongful confinement, or acid throwing. Section 44 covers defense against deadly assaults even where harm to innocent persons is risked.`,
    cognizable: false,
    bailable: true,
    compoundable: false,
    punishment: "Complete Statutory Defense (No Offence)",
    prisonYears: "Self-defence justification",
    court: "Trial Courts / Sessions Court",
    whomToBeTakenTo: "Asserted before Judicial Magistrate or Sessions Court under Section 105 BSA 2023.",
    keywords: ["section 34", "section 35", "section 38", "private defence", "self defence", "right of private defence", "causing death in self defence", "protect property", "96", "100"]
  },

  // SECTION 61
  {
    sectionNumber: "61",
    chapter: "CHAPTER IV: OF ABETMENT, CRIMINAL CONSPIRACY AND ATTEMPT",
    chapterNumber: "CHAPTER IV",
    marginalTitle: "Criminal conspiracy",
    ipcEquivalent: "IPC Section 120A & 120B",
    statutoryText: `61. (1) When two or more persons agree with the common object to do, or cause to be done—
(a) an illegal act; or
(b) an act which is not illegal by illegal means, such an agreement is designated a criminal conspiracy:
Provided that no agreement except an agreement to commit an offence shall amount to a criminal conspiracy unless some act besides the agreement is done by one or more parties to such agreement in pursuance thereof.
(2) Whoever is a party to a criminal conspiracy,—
(a) to commit an offence punishable with death, imprisonment for life or rigorous imprisonment for a term of two years or upwards, shall be punished in the same manner as if he had abetted such offence;
(b) other than a criminal conspiracy to commit an offence punishable as aforesaid shall be punished with imprisonment of either description for a term not exceeding six months, or with fine or with both.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Punished in same manner as abettor of the substantive offense",
    prisonYears: "Tied to substantive offense, or up to 6 months for petty conspiracies",
    court: "Court trying the substantive offence",
    whomToBeTakenTo: "Produced before Judicial Magistrate having jurisdiction over the conspired acts.",
    keywords: ["section 61", "criminal conspiracy", "120b", "120a", "agreement to commit offence", "joint conspiracy", "sazish"]
  },

  // SECTION 63 & 64
  {
    sectionNumber: "63",
    chapter: "CHAPTER V: OF OFFENCES AGAINST WOMAN AND CHILD",
    chapterNumber: "CHAPTER V",
    marginalTitle: "Rape and Punishment for rape",
    ipcEquivalent: "IPC Section 375 & 376",
    statutoryText: `63. A man is said to commit “rape” if he penetrates his penis, to any extent, into the vagina, mouth, urethra or anus of a woman or makes her to do so with him or any other person... under circumstances falling under any of the seven statutory descriptions: (i) against her will; (ii) without her consent; (iii) with consent obtained under fear of death or hurt; (iv) under misconception of marriage; (v) under intoxication/unsoundness; (vi) when woman is under eighteen years of age; (vii) when unable to communicate consent.
64. (1) Whoever commits rape shall be punished with rigorous imprisonment of either description for a term which shall not be less than ten years, but which may extend to imprisonment for life, and shall also be liable to fine.
(2) Aggravated rape committed by police officer, public servant, member of armed forces, staff of jail/hospital/shelter, relative, guardian, during communal violence, on pregnant woman, or causing grievous harm/disfigurement shall be punished with rigorous imprisonment for not less than ten years, extending to imprisonment for the remainder of natural life, and fine.`,
    explanationsAndIllustrations: `Minimum punishment for rape enhanced from 7 years under IPC 376 to 10 years under BNS Section 64(1). Section 65 prescribes minimum 20 years for rape on girl under 16, and death penalty/natural life for rape on girl under 12. Section 70 prescribes minimum 20 years to natural life for gang rape.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Rigorous Imprisonment for not less than 10 years, up to Life Imprisonment (Natural Life), and fine",
    prisonYears: "Minimum 10 years to remainder of natural life",
    court: "Court of Session",
    whomToBeTakenTo: "Arrested without warrant; mandatory medical examination of accused within 24 hours under Section 53 BNSS; produced before Judicial Magistrate.",
    keyChangesIn2023: "Enhanced baseline punishment from 7 years to 10 years; mandatory fine to be paid as compensation to the victim.",
    keywords: ["section 63", "section 64", "rape", "punishment for rape", "375", "376", "sexual assault", "aggravated rape", "life imprisonment"]
  },

  // SECTION 69
  {
    sectionNumber: "69",
    chapter: "CHAPTER V: OF OFFENCES AGAINST WOMAN AND CHILD",
    chapterNumber: "CHAPTER V",
    marginalTitle: "Sexual intercourse by employing deceitful means, etc.",
    ipcEquivalent: "New statutory provision (Previously covered under IPC 375/417/493)",
    statutoryText: `69. Whoever, by deceitful means or by making promise to marry to a woman without any intention of fulfilling the same, has sexual intercourse with her, such sexual intercourse not amounting to the offence of rape, shall be punished with imprisonment of either description for a term which may extend to ten years and shall also be liable to fine.
Explanation.—“deceitful means” shall include inducement for, or false promise of employment or promotion, or marrying by suppressing identity.`,
    explanationsAndIllustrations: `Brand new landmark section enacted in BNS 2023 to resolve longstanding Supreme Court litigation regarding consensual relationships based on marriage promises vs genuine breach of promise. Criminalizes intercourse via false marriage promises, suppressed identity, or employment inducement.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment of either description up to 10 years, and fine",
    prisonYears: "Up to 10 years imprisonment",
    court: "Court of Session",
    whomToBeTakenTo: "Produced before Judicial Magistrate First Class; non-bailable offense.",
    isNewProvision: true,
    keyChangesIn2023: "New provision explicitly distinguishing false promise to marry from rape, punishable up to 10 years.",
    keywords: ["section 69", "false promise to marry", "deceitful means", "promise of marriage", "suppressing identity", "shaadi ka jhootha vaada", "intercourse by deceit"]
  },

  // SECTION 70
  {
    sectionNumber: "70",
    chapter: "CHAPTER V: OF OFFENCES AGAINST WOMAN AND CHILD",
    chapterNumber: "CHAPTER V",
    marginalTitle: "Gang rape",
    ipcEquivalent: "IPC Section 376D & 376DA/DB",
    statutoryText: `70. (1) Where a woman is raped by one or more persons constituting a group or acting in furtherance of a common intention, each of those persons shall be deemed to have committed the offence of rape and shall be punished with rigorous imprisonment for a term which shall not be less than twenty years, but which may extend to imprisonment for life which shall mean imprisonment for the remainder of that person’s natural life, and with fine.
(2) Where a woman under eighteen years of age is raped by one or more persons constituting a group or acting in furtherance of a common intention, each of those persons shall be deemed to have committed the offence of rape and shall be punished with imprisonment for life, which shall mean imprisonment for the remainder of that person’s natural life, and with fine, or with death.`,
    explanationsAndIllustrations: `Any fine imposed shall be just and reasonable to meet the medical expenses and rehabilitation of the victim and shall be paid directly to the victim.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Rigorous Imprisonment for not less than 20 years to natural life; or Death (if victim under 18), and fine",
    prisonYears: "20 years minimum to remainder of natural life or Capital Punishment",
    court: "Court of Session",
    whomToBeTakenTo: "Arrested without warrant; produced before Magistrate; non-bailable.",
    keyChangesIn2023: "Death penalty explicitly provided for gang rape of minor girls under 18 years.",
    keywords: ["section 70", "gang rape", "376d", "376da", "gangrape minor", "death penalty gang rape", "remainder of natural life"]
  },

  // SECTION 80
  {
    sectionNumber: "80",
    chapter: "CHAPTER V: OF OFFENCES AGAINST WOMAN AND CHILD",
    chapterNumber: "CHAPTER V",
    marginalTitle: "Dowry death",
    ipcEquivalent: "IPC Section 304B",
    statutoryText: `80. (1) Where the death of a woman is caused by any burns or bodily injury or occurs otherwise than under normal circumstances within seven years of her marriage and it is shown that soon before her death she was subjected to cruelty or harassment by her husband or any relative of her husband for, or in connection with, any demand for dowry, such death shall be called “dowry death”, and such husband or relative shall be deemed to have caused her death.
(2) Whoever commits dowry death shall be punished with imprisonment for a term which shall not be less than seven years but which may extend to imprisonment for life.`,
    explanationsAndIllustrations: `Explanation.—“dowry” shall have the same meaning as in section 2 of the Dowry Prohibition Act, 1961. Statutory presumption under Section 118 of Bharatiya Sakshya Adhiniyam, 2023 applies.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment for not less than 7 years, extending to Imprisonment for Life",
    prisonYears: "7 years to Life Imprisonment",
    court: "Court of Session",
    whomToBeTakenTo: "Produced before Judicial Magistrate; mandatory investigation by DSP rank officer under BNSS.",
    keywords: ["section 80", "dowry death", "304b", "dahej hatya", "7 years marriage", "dowry harassment death", "burns"]
  },

  // SECTION 85 & 86
  {
    sectionNumber: "85",
    chapter: "CHAPTER V: OF OFFENCES AGAINST WOMAN AND CHILD",
    chapterNumber: "CHAPTER V",
    marginalTitle: "Husband or relative of husband of a woman subjecting her to cruelty",
    ipcEquivalent: "IPC Section 498A",
    statutoryText: `85. Whoever, being the husband or the relative of the husband of a woman, subjects such woman to cruelty shall be punished with imprisonment for a term which may extend to three years and shall also be liable to fine.
86. For the purposes of section 85, “cruelty” means—
(a) any wilful conduct which is of such a nature as is likely to drive the woman to commit suicide or to cause grave injury or danger to life, limb or health (whether mental or physical) of the woman; or
(b) harassment of the woman where such harassment is with a view to coercing her or any person related to her to meet any unlawful demand for any property or valuable security or is on account of failure by her or any person related to her to meet such demand.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment up to 3 years, and fine",
    prisonYears: "Up to 3 years imprisonment",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Produced before Judicial Magistrate First Class; Section 35(3) BNSS notice provisions apply prior to arrest.",
    keyChangesIn2023: "Split into substantive offence (Section 85) and formal definition of cruelty (Section 86) for statutory clarity.",
    keywords: ["section 85", "section 86", "cruelty", "498a", "dowry harassment", "mental cruelty", "husband cruelty", "domestic violence criminal"]
  },

  // SECTION 100 & 101 & 103
  {
    sectionNumber: "103",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Punishment for murder",
    ipcEquivalent: "IPC Section 302",
    statutoryText: `103. (1) Whoever commits murder shall be punished with death or imprisonment for life, and shall also be liable to fine.
(2) When a group of five or more persons acting in concert commits murder on the ground of race, caste or community, sex, place of birth, language, personal belief or any other similar ground each member of such group shall be punished with death or with imprisonment for life, and shall also be liable to fine.`,
    explanationsAndIllustrations: `Section 100 defines culpable homicide. Section 101 specifies when culpable homicide is murder (with 5 exceptions including grave & sudden provocation, private defence, lawful public duty, sudden fight, and consent of adult victim). Section 103 prescribes punishment. Section 104 covers murder by life-convict.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Death or Imprisonment for life, and fine",
    prisonYears: "Life Imprisonment (Min 14 years before remission) or Capital Punishment (Death)",
    court: "Court of Session",
    whomToBeTakenTo: "Arrested without warrant; produced before Judicial Magistrate within 24 hours; committed to Sessions Court for trial under Section 232 BNSS.",
    keyChangesIn2023: "Replaces IPC 302. Distinguishes general murder (103(1)) from Mob Lynching / Hate Group Murder (103(2)). Mandatory crime scene forensic videography under Section 176(3) BNSS.",
    keywords: ["section 103", "murder", "punishment for murder", "302", "101", "100", "hatya", "death sentence", "life imprisonment", "mob lynching 103(2)"]
  },

  // SECTION 106
  {
    sectionNumber: "106",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Causing death by negligence",
    ipcEquivalent: "IPC Section 304A",
    statutoryText: `106. (1) Whoever causes death of any person by doing any rash or negligent act not amounting to culpable homicide, shall be punished with imprisonment of either description for a term which may extend to five years, and shall also be liable to fine; and if such act is done by a registered medical practitioner while performing medical procedure, he shall be punished with imprisonment of either description for a term which may extend to two years, and shall also be liable to fine.
(2) Whoever causes death of any person by rash and negligent driving of vehicle not amounting to culpable homicide, and escapes without reporting it to a police officer or a Magistrate soon after the incident, shall be punished with imprisonment of either description of a term which may extend to ten years, and shall also be liable to fine.`,
    explanationsAndIllustrations: `Sub-section (2) constitutes the landmark 'Hit-and-Run' provision: if a driver causes death by rash driving and flees without reporting to police/magistrate, the punishment jumps to 10 years and fine.`,
    cognizable: true,
    bailable: false, // sub-section (2) hit and run is non-bailable; sub-section (1) is bailable
    compoundable: false,
    punishment: "Sub-sec (1): Up to 5 years (medical: up to 2 years) and fine; Sub-sec (2) Hit-and-run: Up to 10 years and fine",
    prisonYears: "Up to 5 years (General) or up to 10 years (Hit-and-Run fleeing)",
    court: "Court of Session (for Hit-and-Run) / Magistrate First Class (General)",
    whomToBeTakenTo: "Sub-section (1) bailable at police station/court; Sub-section (2) non-bailable, produced before Magistrate.",
    isNewProvision: true,
    keyChangesIn2023: "Created two-tier framework: baseline increased from 2 to 5 years; fleeing drivers face up to 10 years imprisonment.",
    keywords: ["section 106", "hit and run", "causing death by negligence", "304a", "road accident death", "rash driving death", "fleeing scene", "doctor negligence"]
  },

  // SECTION 109
  {
    sectionNumber: "109",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Attempt to murder",
    ipcEquivalent: "IPC Section 307",
    statutoryText: `109. (1) Whoever does any act with such intention or knowledge, and under such circumstances that, if he by that act caused death, he would be guilty of murder, shall be punished with imprisonment of either description for a term which may extend to ten years, and shall also be liable to fine; and if hurt is caused to any person by such act, the offender shall be liable either to imprisonment for life, or to such punishment as is hereinbefore mentioned.
(2) When any person offending under sub-section (1) is under sentence of imprisonment for life, he may, if hurt is caused, be punished with death or with imprisonment for life, which shall mean the remainder of that person’s natural life.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment up to 10 years and fine; if hurt caused, Imprisonment for Life or 10 years; if committed by life-convict, Death or Natural Life",
    prisonYears: "10 years to Life Imprisonment",
    court: "Court of Session",
    whomToBeTakenTo: "Arrested without warrant; produced before Judicial Magistrate within 24 hours.",
    keywords: ["section 109", "attempt to murder", "307", "stabbing", "gunfire attempt", "jaanleva hamla", "life convict murder attempt"]
  },

  // SECTION 111
  {
    sectionNumber: "111",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Organised crime",
    ipcEquivalent: "Brand new central statute provision (previously state laws like MCOCA)",
    statutoryText: `111. (1) Any continuing unlawful activity including kidnapping, robbery, vehicle theft, extortion, land grabbing, contract killing, economic offence, cyber-crimes, trafficking of persons, drugs, weapons or illicit goods or services, human trafficking for prostitution or ransom, by any person or a group of persons acting in concert, singly or jointly, either as a member of an organised crime syndicate or on behalf of such syndicate, by use of violence, threat of violence, intimidation, coercion, or by any other unlawful means to obtain direct or indirect material benefit including a financial benefit, shall constitute organised crime.
(2) Whoever commits organised crime shall,—
(a) if such offence has resulted in the death of any person, be punished with death or imprisonment for life, and shall also be liable to fine which shall not be less than ten lakh rupees;
(b) in any other case, be punished with imprisonment for a term which shall not be less than five years but which may extend to imprisonment for life, and shall also be liable to fine which shall not be less than five lakh rupees.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Death or Imprisonment for Life, and minimum fine of Rs 10 Lakh (if death caused); or 5 years to Life, and minimum fine of Rs 5 Lakh",
    prisonYears: "5 years to Life Imprisonment or Death",
    court: "Special Court or Court of Session",
    whomToBeTakenTo: "Produced before Special Judge / Sessions Court; strict bail restrictions apply.",
    isNewProvision: true,
    keyChangesIn2023: "First ever national central penal law defining organized crime syndicates, contract killings, cyber mafias, and land grabbing.",
    keywords: ["section 111", "organised crime", "syndicate", "gang", "land grabbing", "contract killing", "cyber crime syndicate", "mcoca", "extortion gang"]
  },

  // SECTION 112
  {
    sectionNumber: "112",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Petty organised crime",
    ipcEquivalent: "Brand new statutory offense",
    statutoryText: `112. (1) Whoever, being a member of a group or gang, either singly or jointly, commits any act of theft, snatching, cheating, unauthorised selling of tickets, unauthorised betting or gambling, selling of public examination question papers or any other similar criminal act, is said to commit petty organised crime.
Explanation.—For the purposes of this sub-section "theft" includes trick theft, theft from vehicle, dwelling house or business premises, cargo theft, pick pocketing, theft through card skimming, shoplifting and theft of Automated Teller Machine.
(2) Whoever commits any petty organised crime shall be punished with imprisonment for a term which shall not be less than one year but which may extend to seven years, and shall also be liable to fine.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment for not less than 1 year but which may extend to 7 years, and fine",
    prisonYears: "1 to 7 years imprisonment",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Produced before Judicial Magistrate; covers paper leak mafias and card skimming gangs.",
    isNewProvision: true,
    keyChangesIn2023: "Criminalizes paper leaks, pick-pocket gangs, ATM card skimming, and betting syndicates as organized crime.",
    keywords: ["section 112", "petty organised crime", "paper leak", "atm skimming", "ticket scalping", "pick pocket gang", "exam cheating mafia"]
  },

  // SECTION 113
  {
    sectionNumber: "113",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Terrorist act",
    ipcEquivalent: "Brand new provision in general penal code (previously exclusively under UAPA 1967)",
    statutoryText: `113. (1) Whoever does any act with the intent to threaten or likely to threaten the unity, integrity, sovereignty, security, or economic security of India or with the intent to strike terror or likely to strike terror in the people or any section of the people in India or in any foreign country,—
(a) by using bombs, dynamite, explosives, firearms, lethal weapons, poisonous gases, radioactive or nuclear substances to cause death, injury, property destruction, or disruption of essential services;
(b) overawes by criminal force or causes death of any public functionary;
(c) detains, kidnaps or abducts any person to compel the Government of India or a foreign State to do or abstain from doing any act, commits a terrorist act.
(2) Whoever commits a terrorist act shall,—
(a) if resulting in death, be punished with death or imprisonment for life, and fine;
(b) in any other case, be punished with imprisonment for not less than five years up to life, and fine.`,
    explanationsAndIllustrations: `Explanation: Officer not below the rank of Superintendent of Police (SP) shall decide whether to register the case under Section 113 BNS or under the Unlawful Activities (Prevention) Act, 1967.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Death or Imprisonment for Life, and fine (if death caused); or 5 years to Life, and fine",
    prisonYears: "5 years to Life or Death Penalty",
    court: "Special Court or Court of Session",
    whomToBeTakenTo: "Special NIA/Terrorism Court or Court of Session; investigation overseen by Superintendent of Police.",
    isNewProvision: true,
    keyChangesIn2023: "Terrorism explicitly incorporated into the primary substantive penal code of India.",
    keywords: ["section 113", "terrorist act", "terrorism", "uapa", "bomb blast", "economic security", "counterfeit currency terror", "sovereignty threat"]
  },

  // SECTION 115
  {
    sectionNumber: "115",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Voluntarily causing hurt",
    ipcEquivalent: "IPC Section 323",
    statutoryText: `115. (1) Whoever does any act with the intention of thereby causing hurt to any person, or with the knowledge that he is likely thereby to cause hurt to any person, and does thereby cause hurt to any person, is said “voluntarily to cause hurt”.
(2) Whoever voluntarily causes hurt, shall be punished with imprisonment of either description for a term which may extend to one year, or with fine which may extend to ten thousand rupees, or with both.`,
    cognizable: false,
    bailable: true,
    compoundable: true,
    punishment: "Imprisonment up to 1 year, or fine up to Rs 10,000, or both",
    prisonYears: "Up to 1 year",
    court: "Any Magistrate",
    whomToBeTakenTo: "Bailable; compoundable with permission of court or by parties.",
    keywords: ["section 115", "causing hurt", "323", "marpeet", "simple assault", "fine up to 10000"]
  },

  // SECTION 116 & 117
  {
    sectionNumber: "117",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Voluntarily causing grievous hurt",
    ipcEquivalent: "IPC Section 325",
    statutoryText: `117. (1) Whoever voluntarily causes hurt, if the hurt which he intends to cause or knows himself to be likely to cause is grievous hurt, is said “voluntarily to cause grievous hurt”.
(2) Whoever voluntarily causes grievous hurt, shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.
(3) Whoever causes hurt resulting in permanent disability or persistent vegetative state shall be punished with rigorous imprisonment for not less than 10 years up to imprisonment for life (natural life).
(4) When a group of five or more persons acting in concert causes grievous hurt on grounds of race, caste, community, sex, place of birth, or personal belief, each member faces up to 7 years imprisonment and fine.`,
    explanationsAndIllustrations: `Section 116 designates 8 kinds of hurt as grievous: emasculation, privation of eye/ear, privation of joint, fracture of bone/tooth, or severe bodily pain for 15 days (reduced from 20 days in IPC 320).`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment up to 7 years, and fine; or 10 years to Life (if persistent vegetative state)",
    prisonYears: "Up to 7 years or remainder of natural life",
    court: "Magistrate of the First Class / Court of Session",
    whomToBeTakenTo: "Produced before Judicial Magistrate; non-bailable.",
    keyChangesIn2023: "Added sub-sections (3) and (4) for permanent disability / coma and group mob-assaults; reduced grievous hurt recovery timeline from 20 days to 15 days.",
    keywords: ["section 116", "section 117", "grievous hurt", "325", "320", "bone fracture", "severe bodily pain", "persistent vegetative state", "15 days pain"]
  },

  // SECTION 124
  {
    sectionNumber: "124",
    chapter: "CHAPTER VI: OF OFFENCES AFFECTING THE HUMAN BODY",
    chapterNumber: "CHAPTER VI",
    marginalTitle: "Voluntarily causing grievous hurt by use of acid, etc.",
    ipcEquivalent: "IPC Section 326A & 326B",
    statutoryText: `124. (1) Whoever causes permanent or partial damage or deformity to, or burns or maims or disfigures or disables, any part or parts of the body of a person or causes grievous hurt by throwing acid on or by administering acid to that person... or causes a person to be in a permanent vegetative state shall be punished with imprisonment of either description for a term which shall not be less than ten years but which may extend to imprisonment for life, and with fine:
Provided that such fine shall be just and reasonable to meet the medical expenses of the treatment of the victim: Provided further that any fine imposed under this sub-section shall be paid to the victim.
(2) Whoever throws or attempts to throw acid shall be punished with imprisonment for not less than five years but which may extend to seven years, and fine.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Rigorous Imprisonment for not less than 10 years up to Life Imprisonment, and mandatory medical fine",
    prisonYears: "10 years to Life Imprisonment",
    court: "Court of Session",
    whomToBeTakenTo: "Produced before Judicial Magistrate; non-bailable; non-compoundable.",
    keywords: ["section 124", "acid attack", "326a", "326b", "acid throwing", "disfigurement", "chemical burns", "victim compensation fine"]
  },

  // SECTION 152
  {
    sectionNumber: "152",
    chapter: "CHAPTER VII: OF OFFENCES AGAINST THE STATE",
    chapterNumber: "CHAPTER VII",
    marginalTitle: "Act endangering sovereignty, unity and integrity of India",
    ipcEquivalent: "Replaces colonial Sedition (IPC Section 124A)",
    statutoryText: `152. Whoever, purposely or knowingly, by words, either spoken or written, or by signs, or by visible representation, or by electronic communication or by use of financial mean, or otherwise, excites or attempts to excite, secession or armed rebellion or subversive activities, or encourages feelings of separatist activities or endangers sovereignty or unity and integrity of India; or indulges in or commits any such act shall be punished with imprisonment for life or with imprisonment which may extend to seven years, and shall also be liable to fine.
Explanation.––Comments expressing disapprobation of the measures, or administrative or other action of the Government with a view to obtain their alteration by lawful means without exciting or attempting to excite the activities referred to in this section do not constitute an offence under this section.`,
    explanationsAndIllustrations: `Repeals the British colonial sedition law (rajdroh). Targets specific acts of armed rebellion, secession, and subversion of sovereignty (deshdroh) while explicitly safeguarding democratic criticism of government policies.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment for Life or up to 7 years, and fine",
    prisonYears: "Up to 7 years or Life Imprisonment",
    court: "Court of Session",
    whomToBeTakenTo: "Court of Session; requires sanction under Section 218 BNSS.",
    isNewProvision: true,
    keyChangesIn2023: "Replaces IPC 124A sedition; removes 'disaffection towards government' and replaces with acts endangering sovereignty and armed rebellion.",
    keywords: ["section 152", "sovereignty", "sedition replacement", "124a", "secession", "armed rebellion", "separatist activities", "deshdroh", "integrity of india"]
  },

  // SECTION 189 & 191
  {
    sectionNumber: "189",
    chapter: "CHAPTER XI: OF OFFENCES AGAINST THE PUBLIC TRANQUILLITY",
    chapterNumber: "CHAPTER XI",
    marginalTitle: "Unlawful assembly and Rioting",
    ipcEquivalent: "IPC Section 141, 143, 146, 147",
    statutoryText: `189. (1) An assembly of five or more persons is designated an “unlawful assembly”, if the common object of the persons composing that assembly is— (a) to overawe by criminal force Government or public servant; (b) to resist execution of law; (c) to commit mischief/criminal trespass; (d) to enforce any right by criminal force; (e) to compel any person to do what he is not legally bound to do.
191. (1) Whenever force or violence is used by an unlawful assembly, or by any member thereof, in prosecution of the common object of such assembly, every member of such assembly is guilty of the offence of rioting.
(2) Punishment for rioting: Imprisonment up to 2 years, or fine, or both.
(3) Armed with deadly weapon: Imprisonment up to 5 years, or fine, or both.`,
    cognizable: true,
    bailable: true,
    compoundable: false,
    punishment: "Rioting: Up to 2 years, or fine; Armed with deadly weapon: Up to 5 years, or fine",
    prisonYears: "2 to 5 years",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Produced before Judicial Magistrate; station or court bail applicable for simple rioting.",
    keywords: ["section 189", "section 191", "unlawful assembly", "rioting", "danga", "141", "147", "148", "deadly weapon rioting"]
  },

  // SECTION 303 & 304
  {
    sectionNumber: "303",
    chapter: "CHAPTER XVII: OF OFFENCES AGAINST PROPERTY",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Theft",
    ipcEquivalent: "IPC Section 378 & 379",
    statutoryText: `303. (1) Whoever, intending to take dishonestly any movable property out of the possession of any person without that person’s consent, moves that property in order to such taking, is said to commit theft.
(2) Whoever commits theft shall be punished with imprisonment of either description for a term which may extend to three years, or with fine, or with both and in case of second or subsequent conviction... with rigorous imprisonment not less than one year up to five years and with fine:
Provided that in cases of theft where the value of the stolen property is less than five thousand rupees, and a person is convicted for the first time, shall upon return of the value of property or restoration of the stolen property, shall be punished with community service.`,
    explanationsAndIllustrations: `First-time petty theft under Rs 5,000 where property is restored is statutorily punished with Community Service rather than incarceration.`,
    cognizable: true,
    bailable: false,
    compoundable: true,
    punishment: "Imprisonment up to 3 years, or fine, or both; First petty offender under Rs 5,000: Community Service",
    prisonYears: "Up to 3 years (or Community Service)",
    court: "Any Magistrate",
    whomToBeTakenTo: "Produced before Judicial Magistrate; compoundable with owner's consent under BNSS Section 359.",
    keyChangesIn2023: "Added community service proviso for first-time petty theft under Rs 5,000.",
    keywords: ["section 303", "theft", "chori", "378", "379", "stolen property", "dishonest taking", "community service theft under 5000"]
  },

  // SECTION 304 (SNATCHING)
  {
    sectionNumber: "304",
    chapter: "CHAPTER XVII: OF OFFENCES AGAINST PROPERTY",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Snatching",
    ipcEquivalent: "Brand new statutory offense in central penal law (previously uncodified in IPC)",
    statutoryText: `304. (1) Theft is snatching if, in order to commit theft, the offender suddenly or quickly or forcibly seizes or secures or grabs or takes away from any person or from his possession any movable property.
(2) Whoever commits snatching, shall be punished with imprisonment of either description for a term which may extend to three years, and shall also be liable to fine.`,
    explanationsAndIllustrations: `Specifically addresses street chain snatching, purse snatching, and mobile snatching by bike-borne gangs. Section 305 covers theft in dwelling house/transport/places of worship with up to 7 years.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment of either description up to 3 years, and fine",
    prisonYears: "Up to 3 years imprisonment",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Arrested without warrant; produced before Judicial Magistrate; non-bailable.",
    isNewProvision: true,
    keyChangesIn2023: "Recognizes Snatching as a distinct standalone criminal offense for the first time in Indian central law.",
    keywords: ["section 304", "snatching", "chain snatching", "mobile snatching", "purse snatching", "grab property", "street crime"]
  },

  // SECTION 308 (EXTORTION)
  {
    sectionNumber: "308",
    chapter: "CHAPTER XVII: OF OFFENCES AGAINST PROPERTY",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Extortion",
    ipcEquivalent: "IPC Section 383 & 384",
    statutoryText: `308. (1) Whoever intentionally puts any person in fear of any injury to that person, or to any other, and thereby dishonestly induces the person so put in fear to deliver to any person any property, or valuable security or anything signed or sealed which may be converted into a valuable security, commits extortion.
(2) Whoever commits extortion shall be punished with imprisonment of either description for a term which may extend to seven years, or with fine, or with both.
(5) Whoever commits extortion by putting any person in fear of death or of grievous hurt... shall be punished with imprisonment up to ten years, and fine.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Imprisonment up to 7 years (up to 10 years if fear of death/grievous hurt), and fine",
    prisonYears: "Up to 7 years (General) or up to 10 years (Aggravated)",
    court: "Magistrate of the First Class / Court of Session",
    whomToBeTakenTo: "Produced before Judicial Magistrate; non-bailable.",
    keywords: ["section 308", "extortion", "383", "384", "blackmail", "ransom demand", "vasooli", "threat of injury for money"]
  },

  // SECTION 309 & 310 (ROBBERY & DACOITY)
  {
    sectionNumber: "309",
    chapter: "CHAPTER XVII: OF OFFENCES AGAINST PROPERTY",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Robbery and Dacoity",
    ipcEquivalent: "IPC Section 390, 392, 391, 395",
    statutoryText: `309. (1) In all robbery there is either theft or extortion.
(4) Whoever commits robbery shall be punished with rigorous imprisonment for a term which may extend to ten years, and shall also be liable to fine; and, if the robbery be committed on the highway between sunset and sunrise, the imprisonment may be extended to fourteen years.
310. (1) When five or more persons conjointly commit or attempt to commit a robbery, every person so committing, attempting or aiding, is said to commit dacoity.
(2) Whoever commits dacoity shall be punished with imprisonment for life, or with rigorous imprisonment for a term which may extend to ten years, and fine.
(3) If any one of five or more persons committing dacoity commits murder, every one of those persons shall be punished with death, or imprisonment for life, or rigorous imprisonment not less than ten years, and fine.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Robbery: Up to 10 years (highway night: 14 years); Dacoity: 10 years to Life; Dacoity with murder: Death or Life Imprisonment",
    prisonYears: "10 years to Life or Death Penalty",
    court: "Court of Session",
    whomToBeTakenTo: "Court of Session; strictly non-bailable.",
    keywords: ["section 309", "section 310", "robbery", "dacoity", "390", "392", "395", "loot", "armed robbery", "highway robbery", "dacoity with murder"]
  },

  // SECTION 316 (CRIMINAL BREACH OF TRUST)
  {
    sectionNumber: "316",
    chapter: "CHAPTER XVII: OF OFFENCES AGAINST PROPERTY",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Criminal breach of trust",
    ipcEquivalent: "IPC Section 405 & 406",
    statutoryText: `316. (1) Whoever, being in any manner entrusted with property, or with any dominion over property, dishonestly misappropriates or converts to his own use that property, or dishonestly uses or disposes of that property in violation of any direction of law... commits criminal breach of trust.
(2) Whoever commits criminal breach of trust shall be punished with imprisonment of either description for a term which may extend to five years, or with fine, or with both.
(5) By public servant, banker, merchant, or agent: Imprisonment for life, or up to ten years, and fine.`,
    cognizable: true,
    bailable: false,
    compoundable: true,
    punishment: "Imprisonment up to 5 years (enhanced from 3 years in IPC 406); Public servant/banker: Life or up to 10 years",
    prisonYears: "Up to 5 years (General) or up to Life (Banker/Public Servant)",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Produced before Judicial Magistrate; compoundable with owner's consent.",
    keyChangesIn2023: "General punishment for criminal breach of trust enhanced from 3 years to 5 years.",
    keywords: ["section 316", "criminal breach of trust", "405", "406", "amanat me khayanat", "misappropriation of funds", "pf deduction default"]
  },

  // SECTION 318 (CHEATING)
  {
    sectionNumber: "318",
    chapter: "CHAPTER XVII: OF OFFENCES AGAINST PROPERTY",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Cheating",
    ipcEquivalent: "IPC Section 415 & 420",
    statutoryText: `318. (1) Whoever, by deceiving any person, fraudulently or dishonestly induces the person so deceived to deliver any property to any person, or to consent that any person shall retain any property... is said to cheat.
(2) Whoever cheats shall be punished with imprisonment of either description for a term which may extend to three years, or with fine, or with both.
(4) Whoever cheats and thereby dishonestly induces the person deceived to deliver any property to any person, or to make, alter or destroy the whole or any part of a valuable security... shall be punished with imprisonment of either description for a term which may extend to seven years, and shall also be liable to fine.`,
    explanationsAndIllustrations: `Section 319 covers Cheating by Personation punishable up to 5 years. Section 318(4) corresponds to famous IPC Section 420.`,
    cognizable: true,
    bailable: false,
    compoundable: true,
    punishment: "Sub-section (4): Imprisonment up to 7 years, and fine (formerly IPC 420); Simple cheating: up to 3 years",
    prisonYears: "Up to 7 years imprisonment",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Produced before Judicial Magistrate First Class; compoundable with victim's permission.",
    keyChangesIn2023: "Replaces IPC 420. Incorporates modern electronic inducement, cyber phishing, and corporate cheating.",
    keywords: ["section 318", "cheating", "420", "415", "dhokhadhadi", "fraud", "420 bns equivalent", "financial scam", "cheating by personation 319"]
  },

  // SECTION 324 (MISCHIEF)
  {
    sectionNumber: "324",
    chapter: "CHAPTER XVII: OF OFFENCES AGAINST PROPERTY",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Mischief",
    ipcEquivalent: "IPC Section 425 & 426",
    statutoryText: `324. (1) Whoever with intent to cause, or knowing that he is likely to cause, wrongful loss or damage to the public or to any person, causes the destruction of any property, or any such change in any property or in the situation thereof as destroys or diminishes its value or utility... commits mischief.
(2) Punishment: Imprisonment up to 6 months, or fine, or both.
(3) If causing damage to property of Government or Local Authority: Imprisonment up to 1 year, or fine, or both.
(4) If damage is Rs 20,000 to Rs 1 Lakh: Imprisonment up to 2 years, or fine, or both.
(5) If damage is Rs 1 Lakh or upwards: Imprisonment up to 5 years, or fine, or both.`,
    cognizable: true,
    bailable: true,
    compoundable: true,
    punishment: "Scaled by value: 6 months (petty); 1 year (Govt property); 2 years (Rs 20k-1L); 5 years (Rs 1 Lakh+)",
    prisonYears: "6 months to 5 years",
    court: "Any Magistrate",
    whomToBeTakenTo: "Judicial Magistrate; compoundable with victim.",
    keyChangesIn2023: "Created progressive slab-based penalty based on monetary loss (Rs 20k and Rs 1 Lakh thresholds).",
    keywords: ["section 324", "mischief", "property destruction", "425", "426", "vandalism", "public property damage", "fire mischief 326"]
  },

  // SECTION 329 & 330 (CRIMINAL TRESPASS & HOUSE-BREAKING)
  {
    sectionNumber: "329",
    chapter: "CHAPTER XVII: OF OFFENCES AGAINST PROPERTY",
    chapterNumber: "CHAPTER XVII",
    marginalTitle: "Criminal trespass and house-trespass",
    ipcEquivalent: "IPC Section 441, 442, 445, 448",
    statutoryText: `329. (1) Whoever enters into or upon property in the possession of another with intent to commit an offence or to intimidate, insult or annoy any person in possession... commits criminal trespass.
(2) Into human dwelling/place of worship: house-trespass.
(3) Criminal trespass punishment: Imprisonment up to 3 months, or fine up to Rs 5,000, or both.
(4) House-trespass: Imprisonment up to 1 year, or fine up to Rs 5,000, or both.
330. (2) House-breaking defined through 6 designated entries (aperture, scaling wall, unfastening lock, threat of assault, etc.).
331. Lurking house-trespass or house-breaking: Up to 2 years; by night: Up to 3 years; to commit theft: Up to 10 years (night: 14 years).`,
    cognizable: true,
    bailable: true,
    compoundable: true,
    punishment: "Criminal trespass: 3 months; House-trespass: 1 year; House-breaking by night: 3 to 14 years",
    prisonYears: "3 months to 14 years",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Produced before Magistrate.",
    keywords: ["section 329", "section 330", "section 331", "criminal trespass", "house breaking", "441", "448", "452", "457", "trespass by night", "illegal entry"]
  },

  // SECTION 336 (FORGERY)
  {
    sectionNumber: "336",
    chapter: "CHAPTER XVIII: OF OFFENCES RELATING TO DOCUMENTS AND TO PROPERTY MARKS",
    chapterNumber: "CHAPTER XVIII",
    marginalTitle: "Forgery",
    ipcEquivalent: "IPC Section 463 & 465",
    statutoryText: `336. (1) Whoever makes any false document or false electronic record or part of a document or electronic record, with intent to cause damage or injury, to the public or to any person, or to support any claim or title, or to cause any person to part with property... commits forgery.
(2) Whoever commits forgery shall be punished with imprisonment of either description for a term which may extend to two years, or with fine, or with both.
(3) Forgery for purpose of cheating: Imprisonment up to 7 years, and fine.
(4) Forgery to harm reputation: Imprisonment up to 3 years, and fine.
337. Forgery of Court record, Aadhaar card, or public register: Up to 7 years and fine.
338. Forgery of valuable security, will, or adoption authority: Imprisonment for life, or up to 10 years, and fine.`,
    cognizable: true,
    bailable: false,
    compoundable: false,
    punishment: "Simple forgery: 2 years; Forgery for cheating: 7 years; Forgery of Aadhaar/Court record: 7 years; Valuable security/Will: Life or 10 years",
    prisonYears: "2 to 10 years or Life Imprisonment",
    court: "Magistrate of the First Class / Court of Session",
    whomToBeTakenTo: "Produced before Judicial Magistrate; non-bailable for Section 338 and 336(3).",
    keyChangesIn2023: "Explicitly criminalizes forging electronic records, digital signatures, and Aadhaar cards.",
    keywords: ["section 336", "section 337", "section 338", "forgery", "463", "465", "468", "471", "fake document", "aadhaar forgery", "will forgery", "forged electronic record"]
  },

  // SECTION 351 (CRIMINAL INTIMIDATION)
  {
    sectionNumber: "351",
    chapter: "CHAPTER XIX: OF CRIMINAL INTIMIDATION, INSULT, ANNOYANCE, DEFAMATION, ETC.",
    chapterNumber: "CHAPTER XIX",
    marginalTitle: "Criminal intimidation",
    ipcEquivalent: "IPC Section 503 & 506",
    statutoryText: `351. (1) Whoever threatens another by any means, with any injury to his person, reputation or property, or to the person or reputation of any one in whom that person is interested, with intent to cause alarm to that person... commits criminal intimidation.
(2) Whoever commits criminal intimidation shall be punished with imprisonment of either description for a term which may extend to two years, or with fine, or with both.
(3) If threat be to cause death or grievous hurt, or destruction of property by fire, or an offence punishable with death or life imprisonment, or to impute unchastity to a woman: Imprisonment up to 7 years, or with fine, or with both.
(4) By anonymous communication: Additional 2 years imprisonment.`,
    cognizable: false, // sub-section (2) is non-cognizable; sub-section (3) can be cognizable by state amendment
    bailable: true,
    compoundable: true,
    punishment: "Simple threat: up to 2 years, or fine; Threat to kill / burn / unchastity: up to 7 years, or fine",
    prisonYears: "2 to 7 years imprisonment",
    court: "Magistrate of the First Class",
    whomToBeTakenTo: "Produced before Judicial Magistrate; compoundable with victim.",
    keywords: ["section 351", "criminal intimidation", "503", "506", "threat to kill", "dhamki", "anonymous threat", "threat of fire"]
  },

  // SECTION 356 (DEFAMATION)
  {
    sectionNumber: "356",
    chapter: "CHAPTER XIX: OF CRIMINAL INTIMIDATION, INSULT, ANNOYANCE, DEFAMATION, ETC.",
    chapterNumber: "CHAPTER XIX",
    marginalTitle: "Defamation",
    ipcEquivalent: "IPC Section 499 & 500",
    statutoryText: `356. (1) Whoever, by words either spoken or intended to be read, or by signs or by visible representations, makes or publishes in any manner, any imputation concerning any person intending to harm, or knowing or having reason to believe that such imputation will harm, the reputation of such person, is said, except in the cases hereinafter excepted, to defame that person.
(Contains 10 Statutory Exceptions including Imputation of truth for public good, Public conduct of public servants, Court reports, Censure passed in good faith, and Accusation to authorized person).
(2) Whoever defames another shall be punished with simple imprisonment for a term which may extend to two years, or with fine, or with both, or with community service.`,
    explanationsAndIllustrations: `Crucial 2023 reform: Sub-section (2) empowers the trial court to award 'Community Service' as an alternative punishment for defamation instead of mandatory jail or fine.`,
    cognizable: false,
    bailable: true,
    compoundable: true,
    punishment: "Simple Imprisonment up to 2 years, or fine, or both, or with Community Service",
    prisonYears: "Up to 2 years or Community Service",
    court: "Court of Session (for public officials) or Magistrate of the First Class",
    whomToBeTakenTo: "Initiated only via private complaint under Section 222 BNSS; bailable as of right.",
    isNewProvision: true,
    keyChangesIn2023: "Introduced Community Service as an alternative sentence for defamation.",
    keywords: ["section 356", "defamation", "499", "500", "maan-haani", "community service defamation", "reputation harm", "10 exceptions"]
  },

  // SECTION 358 (REPEAL AND SAVINGS)
  {
    sectionNumber: "358",
    chapter: "CHAPTER XX: REPEAL AND SAVINGS",
    chapterNumber: "CHAPTER XX",
    marginalTitle: "Repeal and savings",
    ipcEquivalent: "Repeal of Act No. 45 of 1860 (Indian Penal Code)",
    statutoryText: `358. (1) The Indian Penal Code is hereby repealed.
(2) Notwithstanding the repeal of the Code referred to in sub-section (1), it shall not affect—
(a) the previous operation of the Code so repealed or anything duly done or suffered thereunder; or
(b) any right, privilege, obligation or liability acquired, accrued or incurred under the Code so repealed; or
(c) any penalty, or punishment incurred in respect of any offences committed against the Code so repealed; or
(d) any investigation or remedy in respect of any such penalty, or punishment; or
(e) any proceeding, investigation or remedy in respect of any such penalty or punishment as aforesaid, and any such proceeding or remedy may be instituted, continued or enforced, and any such penalty may be imposed as if that Code had not been repealed.
(3) Notwithstanding such repeal, anything done or any action taken under the said Code shall be deemed to have been done or taken under the corresponding provisions of this Sanhita.`,
    cognizable: false,
    bailable: true,
    compoundable: false,
    punishment: "Statutory Repeal & Legal Continuity",
    prisonYears: "N/A",
    court: "All Courts across India",
    whomToBeTakenTo: "Applies to all transitional criminal cases pending or instituted for pre-July 1, 2024 acts.",
    keyChangesIn2023: "Formal statutory sunset of 163-year-old IPC 1860, with complete savings clause for pending trials and FIRs.",
    keywords: ["section 358", "repeal and savings", "repeal of indian penal code", "ipc repeal", "transitional provision", "act 45 of 1860"]
  }
];
