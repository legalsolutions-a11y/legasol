import { BNS_GAZETTE_SECTIONS } from './bnsGazetteFullText';
import { BNSS_GAZETTE_SECTIONS } from './bnssGazetteFullText';

/**
 * Comprehensive Indian Statutory & Constitutional Compendium (2026 Edition)
 * Covers:
 * 1. Bharatiya Nyaya Sanhita, 2023 (BNS) - Official Gazette Text (Act 45 of 2023)
 * 2. Bharatiya Nagarik Suraksha Sanhita, 2023 (BNSS) - 531 Total Sections
 * 3. Bharatiya Sakshya Adhiniyam, 2023 (BSA) - 170 Total Sections
 * 4. The Constitution of India - 448 Articles, 12 Schedules
 */

export interface StatutoryItem {
  id: string;
  act: 'BNS 2023' | 'BNSS 2023' | 'BSA 2023' | 'Constitution of India';
  number: string; // e.g. "Section 103(1)" or "Article 21" or "Seventh Schedule"
  legacyReference?: string; // e.g. "IPC Section 302" or "CrPC Section 154" or "Indian Evidence Act Section 65B"
  title: string;
  hindiTitle?: string;
  category: string;
  description: string;
  cognizable?: boolean;
  bailable?: boolean;
  court?: string;
  whomToBeTakenTo?: string; // e.g. "Jurisdictional Judicial Magistrate within 24 hours under Section 57 BNSS"
  punishment?: string; // e.g. "Death or Imprisonment for Life, and fine"
  prisonYears?: string; // e.g. "Life Imprisonment (Min 14 years) or Capital Punishment"
  keyProvisions: string;
  keywords: string[];
  gazetteVerbatimText?: string;
}

const BASE_STATUTORY_ITEMS: StatutoryItem[] = [
  // --- BNS (Bharatiya Nyaya Sanhita) ---
  {
    id: 'bns-103-1',
    act: 'BNS 2023',
    number: 'Section 103(1)',
    legacyReference: 'IPC Section 302',
    title: 'Murder (General)',
    hindiTitle: 'हत्या की सजा (Murder)',
    category: 'Offenses Affecting Human Body',
    description: 'Whoever commits murder shall be punished with death or imprisonment for life, and shall also be liable to fine.',
    cognizable: true,
    bailable: false,
    court: 'Court of Session',
    whomToBeTakenTo: 'Must be produced before Judicial Magistrate First Class (JMFC) within 24 hours; committed to Court of Session for trial.',
    punishment: 'Death or Imprisonment for life, and fine',
    prisonYears: 'Life Imprisonment or Capital Punishment (Death Sentence)',
    keyProvisions: 'Requires proof of intention or knowledge of causing bodily injury sufficient in ordinary course of nature to cause death. Forensic evidence mandatory at crime scene under BNSS 176(3).',
    keywords: ['murder', 'kill', 'homicide', 'death', '302', '103', 'hatya', 'jaan se maarna', 'fatal assault']
  },
  {
    id: 'bns-103-2',
    act: 'BNS 2023',
    number: 'Section 103(2)',
    legacyReference: 'New statutory offense (Previously IPC 302/34/149)',
    title: 'Mob Lynching & Hate Murder by Group',
    hindiTitle: 'भीड़ द्वारा पीट-पीटकर हत्या (Mob Lynching)',
    category: 'Offenses Affecting Human Body',
    description: 'When a group of five or more persons acting in concert commits murder on grounds of race, caste, sex, place of birth, language, religion or personal belief, each member faces capital punishment or life imprisonment.',
    cognizable: true,
    bailable: false,
    court: 'Court of Session',
    whomToBeTakenTo: 'Produced before Judicial Magistrate; investigation monitored by Senior Superintendent of Police (SSP).',
    punishment: 'Death or Imprisonment for life, or not less than 7 years, and fine',
    prisonYears: '7 years to Life Imprisonment or Death',
    keyProvisions: 'Brand new section in BNS 2023 explicitly addressing mob violence, communal lynching, and collective hate crimes.',
    keywords: ['mob lynching', 'lynching', 'group murder', 'caste murder', 'hate crime', 'communal violence']
  },
  {
    id: 'bns-105',
    act: 'BNS 2023',
    number: 'Section 105',
    legacyReference: 'IPC Section 304',
    title: 'Culpable Homicide Not Amounting to Murder',
    hindiTitle: 'गैर-इरादतन हत्या (Culpable Homicide)',
    category: 'Offenses Affecting Human Body',
    description: 'Punishment for culpable homicide not amounting to murder, committed without premeditated intention or under sudden and grave provocation.',
    cognizable: true,
    bailable: false,
    court: 'Court of Session',
    whomToBeTakenTo: 'Produced before Judicial Magistrate within 24 hours; tried by Court of Session.',
    punishment: 'Imprisonment for life, or up to 10 years, and fine',
    prisonYears: 'Up to 10 years or Life Imprisonment',
    keyProvisions: 'Distinguishes between knowledge and intention; applies to sudden fights, excessive private defense, and sudden provocation.',
    keywords: ['culpable homicide', 'accidental murder', 'manslaughter', 'fight death', 'provocation', '304', '105']
  },
  {
    id: 'bns-106-1',
    act: 'BNS 2023',
    number: 'Section 106(1)',
    legacyReference: 'IPC Section 304A',
    title: 'Causing Death by Negligence (General)',
    hindiTitle: 'लापरवाही से मौत (Negligent Death)',
    category: 'Offenses Affecting Human Body',
    description: 'Whoever causes the death of any person by doing any rash or negligent act not amounting to culpable homicide shall be punished with imprisonment up to 5 years, and fine.',
    cognizable: true,
    bailable: true,
    court: 'Magistrate of the First Class',
    whomToBeTakenTo: 'Produced before Judicial Magistrate; eligible for regular or station bail subject to surety bonds.',
    punishment: 'Imprisonment up to 5 years, and fine',
    prisonYears: 'Up to 5 years imprisonment',
    keyProvisions: 'Punishment enhanced from 2 years in IPC 304A to 5 years in BNS 106(1) for medical and workplace negligence.',
    keywords: ['negligence', 'accident', 'medical negligence', 'rash driving', '304a', '106']
  },
  {
    id: 'bns-106-2',
    act: 'BNS 2023',
    number: 'Section 106(2)',
    legacyReference: 'New strict provision (Replacing IPC 304A)',
    title: 'Hit-and-Run Vehicle Crash (Fleeing without Reporting)',
    hindiTitle: 'हिट एंड रन - टक्कर मारकर भाग जाना',
    category: 'Offenses Affecting Human Body & Traffic',
    description: 'Whoever causes death of any person by rash or negligent driving and escapes without reporting to a police officer or magistrate soon after the incident.',
    cognizable: true,
    bailable: false,
    court: 'Court of Session',
    whomToBeTakenTo: 'Immediate arrest by police; produced before Judicial Magistrate. Bail heard exclusively before Sessions Court.',
    punishment: 'Imprisonment up to 10 years, and fine',
    prisonYears: 'Up to 10 years rigorous imprisonment',
    keyProvisions: 'Created to stop drivers from abandoning injured victims on highways; mandates prompt reporting to police or hospital.',
    keywords: ['hit and run', 'fleeing', 'car crash', 'highway accident', 'road death', 'speeding truck', 'negligent driving']
  },
  {
    id: 'bns-109',
    act: 'BNS 2023',
    number: 'Section 109',
    legacyReference: 'IPC Section 307',
    title: 'Attempt to Murder',
    hindiTitle: 'हत्या का प्रयास (Attempt to Murder)',
    category: 'Offenses Affecting Human Body',
    description: 'Whoever does any act with such intention or knowledge, and under such circumstances, that if he by that act caused death, he would be guilty of murder.',
    cognizable: true,
    bailable: false,
    court: 'Court of Session',
    whomToBeTakenTo: 'Produced before Judicial Magistrate; non-bailable, sent to Judicial Custody.',
    punishment: 'Imprisonment up to 10 years, and fine; if hurt is caused, life imprisonment',
    prisonYears: 'Up to 10 years or Imprisonment for Life',
    keyProvisions: 'Replaces IPC 307. Firearm discharges, stabbing in vital areas, or fatal poisoning with survival trigger life sentence.',
    keywords: ['attempt to murder', '307', 'stabbing', 'gunshot', 'poison', 'murder attempt', 'jaan leva hamla']
  },
  {
    id: 'bns-303-2',
    act: 'BNS 2023',
    number: 'Section 303(2)',
    legacyReference: 'IPC Section 379',
    title: 'Theft (General)',
    hindiTitle: 'चोरी की सजा (Theft)',
    category: 'Offenses Against Property',
    description: 'Whoever commits theft shall be punished with imprisonment up to 3 years, or with fine, or with both; for first-time offenders of petty theft, community service may be ordered.',
    cognizable: true,
    bailable: false,
    court: 'Any Magistrate',
    whomToBeTakenTo: 'Produced before Jurisdictional Judicial Magistrate; community service option available for first petty offenses.',
    punishment: 'Imprisonment up to 3 years, or with fine, or both, or community service',
    prisonYears: 'Up to 3 years imprisonment',
    keyProvisions: 'First offense of petty theft below Rs 5,000 allows the court to award Community Service instead of prison under BNSS.',
    keywords: ['theft', 'steal', 'chori', 'stolen', '379', '303', 'pickpocketing', 'valuables']
  },
  {
    id: 'bns-304',
    act: 'BNS 2023',
    number: 'Section 304',
    legacyReference: 'New statutory crime (Previously IPC 379/356/392)',
    title: 'Snatching (Chain / Mobile / Purse Snatching)',
    hindiTitle: 'झपटमारी (Mobile & Chain Snatching)',
    category: 'Offenses Against Property',
    description: 'Whoever, in order to commit theft, suddenly or quickly or forcibly seizes, secures, grabs or takes away any movable property from any person.',
    cognizable: true,
    bailable: false,
    court: 'Magistrate of the First Class',
    whomToBeTakenTo: 'Produced before Judicial Magistrate; rigorous non-bailable offense.',
    punishment: 'Imprisonment up to 3 years, and fine',
    prisonYears: 'Up to 3 years rigorous imprisonment',
    keyProvisions: 'Explicitly recognized as an independent statutory crime in Indian law for the first time to curb street crime.',
    keywords: ['snatching', 'chain snatching', 'mobile snatching', 'purse snatching', 'bike gang', '304']
  },
  {
    id: 'bns-318-4',
    act: 'BNS 2023',
    number: 'Section 318(4)',
    legacyReference: 'IPC Section 420',
    title: 'Cheating & Dishonestly Inducing Delivery of Property (Fraud)',
    hindiTitle: 'धोखाधड़ी और जालसाजी (Cheating / Fraud)',
    category: 'Offenses Against Property & Economic',
    description: 'Whoever cheats and thereby dishonestly induces the person deceived to deliver any property, or to make, alter or destroy the whole or any part of a valuable security.',
    cognizable: true,
    bailable: false,
    court: 'Magistrate of the First Class',
    whomToBeTakenTo: 'Produced before Judicial Magistrate; bail discretionary based on restitution of defrauded sums.',
    punishment: 'Imprisonment up to 7 years, and fine',
    prisonYears: 'Up to 7 years imprisonment',
    keyProvisions: 'Replaces IPC 420. Covers bank scams, crypto frauds, counterfeit documentation, and online deception.',
    keywords: ['420', 'cheating', 'fraud', 'scam', 'dhokhadhadi', 'online cheating', 'fake kyc', 'financial fraud', '318']
  },
  {
    id: 'bns-64-1',
    act: 'BNS 2023',
    number: 'Section 64(1)',
    legacyReference: 'IPC Section 376(1)',
    title: 'Rape & Sexual Assault',
    hindiTitle: 'बलात्कार का अपराध (Sexual Assault)',
    category: 'Offenses Against Women & Children',
    description: 'Whoever commits rape shall be punished with rigorous imprisonment for a term which shall not be less than 10 years, extending to imprisonment for life, and fine.',
    cognizable: true,
    bailable: false,
    court: 'Court of Session',
    whomToBeTakenTo: 'Immediate arrest; statement of victim recorded before female Judicial Magistrate under Section 183 BNSS.',
    punishment: 'Rigorous imprisonment not less than 10 years, up to life imprisonment, and fine',
    prisonYears: '10 years to Life Imprisonment',
    keyProvisions: 'Medical examination within 24 hours under Section 53 BNSS; time-bound trial mandated.',
    keywords: ['rape', 'sexual assault', '376', '64', 'women protection', 'pocso', 'balatkar']
  },
  {
    id: 'bns-69',
    act: 'BNS 2023',
    number: 'Section 69',
    legacyReference: 'New statutory crime (Previously disputed under IPC 375/417)',
    title: 'Sexual Intercourse by Deceitful Means or False Promise to Marry',
    hindiTitle: 'शादी का झूठा झांसा देकर शारीरिक संबंध',
    category: 'Offenses Against Women & Children',
    description: 'Whoever, by deceitful means including false promises of employment, promotion, or marriage without intention of fulfilling it, has sexual intercourse with a woman.',
    cognizable: true,
    bailable: false,
    court: 'Court of Session',
    whomToBeTakenTo: 'Produced before Judicial Magistrate; Sessions trial.',
    punishment: 'Imprisonment up to 10 years, and fine',
    prisonYears: 'Up to 10 years imprisonment',
    keyProvisions: 'Resolves decades of Supreme Court debate by codifying deceitful promises as a discrete offense separate from standard rape.',
    keywords: ['false promise to marry', 'deceit', 'shaadi ka jhootha vada', 'marriage promise', 'section 69']
  },
  {
    id: 'bns-111',
    act: 'BNS 2023',
    number: 'Section 111',
    legacyReference: 'New statutory crime (Replacing MCOCA/State laws at national level)',
    title: 'Organized Crime & Syndicate Operations',
    hindiTitle: 'संगठित अपराध (Organized Crime Gang)',
    category: 'Cyber & Organized Crime',
    description: 'Any continuing unlawful activity including kidnapping, robbery, cyber-crimes, trafficking, economic offenses committed by a syndicate.',
    cognizable: true,
    bailable: false,
    court: 'Special Court / Court of Session',
    whomToBeTakenTo: 'Produced before Special Designated Court; stringent bail limitations under Section 111(5).',
    punishment: 'Death or Imprisonment for life (if death caused), or not less than 5 years to life',
    prisonYears: '5 years to Life Imprisonment or Capital Punishment',
    keyProvisions: 'Nationalized framework for organized underworld cartels, contract killers, and interstate cyber syndicates.',
    keywords: ['organized crime', 'gang', 'syndicate', 'mafia', 'extortion ring', 'kidnapping racket', '111']
  },

  // --- BNSS (Bharatiya Nagarik Suraksha Sanhita) ---
  {
    id: 'bnss-35',
    act: 'BNSS 2023',
    number: 'Section 35',
    legacyReference: 'CrPC Section 41 & 41A',
    title: 'Arrest of Persons Without Warrant & Notice of Appearance',
    hindiTitle: 'बिना वारंट गिरफ्तारी व हाजिरी की नोटिस',
    category: 'Criminal Procedure & Police Powers',
    description: 'Police may arrest without warrant in cognizable offenses punishable with more than 7 years. For offenses up to 7 years, notice of appearance is mandatory unless reasons in writing are recorded with prior DSP permission.',
    cognizable: true,
    court: 'Jurisdictional Magistrate',
    whomToBeTakenTo: 'Accused must be given Notice of Appearance (Section 35(3)) before arrest for offenses punishable under 7 years.',
    keyProvisions: 'Incorporate Arnesh Kumar guidelines. Senior citizen and infirm arrest protections added; prior sanction of DSP required for arrests in petty crimes.',
    keywords: ['arrest', 'police powers', 'without warrant', 'notice', '41a', '35 bnss', 'giraftari', 'police custody']
  },
  {
    id: 'bnss-57',
    act: 'BNSS 2023',
    number: 'Section 57',
    legacyReference: 'CrPC Section 57 / Article 22(2)',
    title: 'Person Arrested Not to be Detained Beyond 24 Hours',
    hindiTitle: '24 घंटे से अधिक पुलिस हिरासत नहीं',
    category: 'Fundamental Rights & Police Custody',
    description: 'No police officer shall detain in custody a person arrested without warrant for a longer period than under all circumstances of the case is reasonable, and such period shall not exceed 24 hours excluding journey time.',
    court: 'Nearest Judicial Magistrate',
    whomToBeTakenTo: 'Must be produced before the nearest Judicial Magistrate within 24 hours of apprehension.',
    keyProvisions: 'Strict constitutional compliance under Article 22(2); failure constitutes illegal detention and habeas corpus relief.',
    keywords: ['24 hours', 'detention', 'magistrate production', 'police custody', 'illegal detention', 'remand']
  },
  {
    id: 'bnss-173',
    act: 'BNSS 2023',
    number: 'Section 173',
    legacyReference: 'CrPC Section 154',
    title: 'Information in Cognizable Cases (FIR Registration & e-FIR)',
    hindiTitle: 'प्रथम सूचना रिपोर्ट (FIR) और ई-एफआईआर',
    category: 'FIR & Investigation Procedure',
    description: 'Every information relating to commission of a cognizable offense must be reduced to writing. Introduces Zero-FIR and electronic FIR (e-FIR) across all jurisdictions in India.',
    court: 'Jurisdictional Magistrate',
    whomToBeTakenTo: 'Informant given free copy of FIR immediately; signed within 3 days for e-FIR.',
    keyProvisions: 'Mandates Zero-FIR registration regardless of territorial jurisdiction. Preliminary inquiry within 14 days for offenses between 3 to 7 years.',
    keywords: ['fir', 'zero fir', 'efir', 'first information report', '154', '173 bnss', 'complaint registration']
  },
  {
    id: 'bnss-176-3',
    act: 'BNSS 2023',
    number: 'Section 176(3)',
    legacyReference: 'Brand new mandatory provision',
    title: 'Mandatory Forensic Evidence Collection for Serious Crimes',
    hindiTitle: '7 साल से अधिक अपराध में फोरेंसिक जांच अनिवार्य',
    category: 'Forensic Investigation & Evidence',
    description: 'For all crimes punishable with 7 years or more imprisonment, visit by a forensic expert to the crime scene and mobile video recording of scene collection is statutory and mandatory.',
    court: 'Trial Court',
    whomToBeTakenTo: 'Forensic team dispatched to crime scene; video recording submitted with chargesheet.',
    keyProvisions: 'Guarantees scientific investigation; video recording of search and seizure mandated under Section 105 BNSS.',
    keywords: ['forensic', 'crime scene', 'videography', 'dna', 'fingerprints', 'scientific proof']
  },
  {
    id: 'bnss-479',
    act: 'BNSS 2023',
    number: 'Section 479',
    legacyReference: 'CrPC Section 436A',
    title: 'Maximum Period for Which an Undertrial Prisoner Can Be Detained (Bail for Undertrials)',
    hindiTitle: 'विचाराधीन कैदियों की जमानत (Undertrial Bail)',
    category: 'Bail & Personal Liberty',
    description: 'First-time offenders (never convicted before) who have served one-third of maximum sentence must be released on bail. Other undertrials released after half maximum period.',
    court: 'Court of Session / High Court',
    whomToBeTakenTo: 'Jail Superintendent must submit application to trial court for automatic release on bond.',
    keyProvisions: 'Historic reform easing jail overcrowding; fast-tracks bail for first-time undertrial prisoners.',
    keywords: ['bail', 'undertrial', 'jail release', 'bond', '436a', '479 bnss', 'anticipatory bail', 'zamanat']
  },

  // --- BSA (Bharatiya Sakshya Adhiniyam) ---
  {
    id: 'bsa-61',
    act: 'BSA 2023',
    number: 'Section 61',
    legacyReference: 'Evidence Act Section 65B',
    title: 'Admissibility of Electronic Records (Digital Evidence)',
    hindiTitle: 'इलेक्ट्रॉनिक व डिजिटल सबूतों की स्वीकार्यता',
    category: 'Law of Evidence & Digital Forensics',
    description: 'Electronic records including emails, server logs, mobile WhatsApp chats, CCTV footage, and digital audio recordings have equal legal standing as paper documents when backed by standard certificate.',
    court: 'All Judicial Courts',
    whomToBeTakenTo: 'Admitted before trial court with certificate from person in charge of computer device or certified laboratory.',
    keyProvisions: 'Simplifies electronic certification; broadens definition of digital records to include cloud servers and semiconductor memory.',
    keywords: ['cctv', 'whatsapp', 'digital evidence', 'electronic record', '65b', '61 bsa', 'phone recording', 'cyber proof']
  },
  {
    id: 'bsa-23',
    act: 'BSA 2023',
    number: 'Section 23',
    legacyReference: 'Evidence Act Section 27',
    title: 'Discovery of Facts Disclosed in Police Custody (Recovery)',
    hindiTitle: 'हिरासत में बरामदगी का सबूत (Recovery Memo)',
    category: 'Law of Evidence & Confessions',
    description: 'When any fact is deposed to as discovered in consequence of information received from a person accused of an offense in police custody, only that part relating to the discovery is admissible.',
    court: 'Trial Court',
    whomToBeTakenTo: 'Material weapon, stolen cash, or vehicle recovered in presence of independent punch witnesses with video record.',
    keyProvisions: 'Protects against forced confessions while allowing physical corroboration like recovered knives, guns, or hidden loot.',
    keywords: ['recovery', 'weapon recovered', 'confession', 'custody disclosure', 'section 27', 'baramadgi']
  },

  // --- CONSTITUTION OF INDIA ---
  {
    id: 'const-art-14',
    act: 'Constitution of India',
    number: 'Article 14',
    title: 'Equality Before Law & Equal Protection of the Laws',
    hindiTitle: 'विधि के समक्ष समता (समानता का अधिकार)',
    category: 'Fundamental Rights (Part III)',
    description: 'The State shall not deny to any person equality before the law or the equal protection of the laws within the territory of India.',
    court: 'Supreme Court (Art 32) & High Courts (Art 226)',
    keyProvisions: 'Prohibits arbitrariness in police action, bail grants, and governmental prosecution.',
    keywords: ['article 14', 'equality', 'discrimination', 'arbitrary', 'fundamental rights', 'samanta']
  },
  {
    id: 'const-art-19',
    act: 'Constitution of India',
    number: 'Article 19',
    title: 'Protection of Six Fundamental Freedoms (Speech, Assembly, Movement)',
    hindiTitle: 'वाक् एवं अभिव्यक्ति की स्वतंत्रता',
    category: 'Fundamental Rights (Part III)',
    description: 'Guarantees freedom of speech and expression, peaceful assembly, association, free movement across India, residence, and trade or profession.',
    court: 'Supreme Court & High Courts',
    keyProvisions: 'Subject to reasonable restrictions under Art 19(2) including sovereignty, public order, and morality.',
    keywords: ['article 19', 'freedom of speech', 'free speech', 'assembly', 'protest', 'fundamental rights']
  },
  {
    id: 'const-art-20',
    act: 'Constitution of India',
    number: 'Article 20',
    title: 'Protection in Respect of Conviction for Offenses',
    hindiTitle: 'अपराधों के दोषसिद्धि के संबंध में संरक्षण',
    category: 'Fundamental Rights (Part III)',
    description: 'Prohibits retrospective criminal laws (Ex-post facto law), double jeopardy (tried twice for same offense), and self-incrimination (compelled to be witness against oneself).',
    court: 'All Criminal Courts & Constitutional Benches',
    keyProvisions: 'Absolute protection: No person accused of any offense shall be compelled to be a witness against himself (Right to Silence).',
    keywords: ['article 20', 'double jeopardy', 'self incrimination', 'narco test', 'right to silence', 'retroactive law']
  },
  {
    id: 'const-art-21',
    act: 'Constitution of India',
    number: 'Article 21',
    title: 'Protection of Life and Personal Liberty (Due Process)',
    hindiTitle: 'प्राण और दैहिक स्वतंत्रता का संरक्षण (जीवन का अधिकार)',
    category: 'Fundamental Rights (Part III)',
    description: 'No person shall be deprived of his life or personal liberty except according to procedure established by law.',
    court: 'Supreme Court (Art 32) & High Courts (Art 226)',
    keyProvisions: 'Expansive heart of the Indian Constitution: covers speedy trial, free legal aid, right against custodial torture, right to privacy, and humane prison conditions.',
    keywords: ['article 21', 'life and liberty', 'privacy', 'custodial violence', 'speedy trial', 'bail is rule', 'personal freedom']
  },
  {
    id: 'const-art-22',
    act: 'Constitution of India',
    number: 'Article 22',
    title: 'Protection Against Arrest and Detention in Certain Cases',
    hindiTitle: 'गिरफ्तारी और निरोध से संरक्षण',
    category: 'Fundamental Rights (Part III)',
    description: 'Right to be informed of grounds of arrest, right to consult and be defended by a legal practitioner of choice, and mandatory production before nearest Magistrate within 24 hours.',
    court: 'Magistrate Court, High Court & Supreme Court',
    whomToBeTakenTo: 'Production before nearest Magistrate within 24 hours is a non-negotiable Constitutional command.',
    keyProvisions: 'Groundwork for Section 57 BNSS; non-compliance invalidates detention and empowers release on writ of Habeas Corpus.',
    keywords: ['article 22', 'arrest rights', 'lawyer rights', '24 hours production', 'grounds of arrest', 'preventive detention']
  },
  {
    id: 'const-art-32',
    act: 'Constitution of India',
    number: 'Article 32',
    title: 'Remedies for Enforcement of Fundamental Rights (Writs)',
    hindiTitle: 'संवैधानिक उपचारों का अधिकार (रिट याचिकाएं)',
    category: 'Constitutional Remedies',
    description: 'Guarantees the right to move the Supreme Court directly by appropriate proceedings for enforcement of Fundamental Rights. Dr. B.R. Ambedkar termed it the "Heart and Soul of the Constitution".',
    court: 'Supreme Court of India',
    keyProvisions: 'Empowers Supreme Court to issue 5 Writs: Habeas Corpus, Mandamus, Prohibition, Quo Warranto, and Certiorari.',
    keywords: ['article 32', 'writs', 'habeas corpus', 'supreme court petition', 'illegal custody', 'mandamus']
  },
  {
    id: 'const-art-226',
    act: 'Constitution of India',
    number: 'Article 226',
    title: 'Power of High Courts to Issue Certain Writs',
    hindiTitle: 'उच्च न्यायालयों की रिट जारी करने की शक्ति',
    category: 'High Court Constitutional Powers',
    description: 'Empowers High Courts throughout their territorial jurisdictions to issue writs for the enforcement of Fundamental Rights and for any other legal right (quashing false FIRs, anticipatory protection).',
    court: 'High Courts of States',
    keyProvisions: 'Wider jurisdiction than Article 32 as it covers both Fundamental Rights and statutory civil rights. Major forum for quashing vexatious FIRs.',
    keywords: ['article 226', 'high court writ', 'quash fir', 'habeas corpus high court', 'police harassment protection']
  },
  {
    id: 'const-sched-7',
    act: 'Constitution of India',
    number: 'Seventh Schedule',
    title: 'Division of Legislative Powers (Union, State, and Concurrent Lists)',
    hindiTitle: 'सातवीं अनुसूची (संघ, राज्य और समवर्ती सूची)',
    category: 'Constitutional Schedules',
    description: 'Delineates legislative competence: List I (Union), List II (State - Police & Public Order), List III (Concurrent - Criminal Law & Criminal Procedure).',
    court: 'Constitutional Benches',
    keyProvisions: 'Criminal Law and Procedure (IPC/BNS and CrPC/BNSS) fall under Concurrent List (Entries 1 & 2), enabling Central and State enactments.',
    keywords: ['seventh schedule', 'lists', 'police powers', 'concurrent list', 'state list', 'legislative competence']
  }
];

// Map Gazette Sections to StatutoryItem and merge
const GAZETTE_MAPPED_ITEMS: StatutoryItem[] = [
  ...BNS_GAZETTE_SECTIONS.map((gSec) => ({
    id: `gazette-bns-${gSec.sectionNumber}`,
    act: 'BNS 2023' as const,
    number: `Section ${gSec.sectionNumber}`,
    legacyReference: gSec.ipcEquivalent,
    title: gSec.marginalTitle,
    hindiTitle: `बीएनएस धारा ${gSec.sectionNumber} (BNS Sec ${gSec.sectionNumber})`,
    category: gSec.chapter,
    description: gSec.statutoryText.slice(0, 320) + (gSec.statutoryText.length > 320 ? '...' : ''),
    cognizable: gSec.cognizable,
    bailable: gSec.bailable,
    court: gSec.court,
    whomToBeTakenTo: gSec.whomToBeTakenTo,
    punishment: gSec.punishment,
    prisonYears: gSec.prisonYears,
    keyProvisions: gSec.keyChangesIn2023 || gSec.statutoryText.slice(0, 200),
    keywords: gSec.keywords,
    gazetteVerbatimText: gSec.statutoryText
  })),
  ...BNSS_GAZETTE_SECTIONS.map((bnssSec) => ({
    id: `gazette-bnss-${bnssSec.sectionNumber}`,
    act: 'BNSS 2023' as const,
    number: `Section ${bnssSec.sectionNumber}`,
    legacyReference: bnssSec.crpcEquivalent,
    title: bnssSec.marginalTitle,
    hindiTitle: `बीएनएसएस धारा ${bnssSec.sectionNumber} (BNSS Sec ${bnssSec.sectionNumber})`,
    category: bnssSec.chapter,
    description: bnssSec.statutoryText.slice(0, 320) + (bnssSec.statutoryText.length > 320 ? '...' : ''),
    court: bnssSec.court,
    whomToBeTakenTo: bnssSec.whomToBeTakenTo,
    keyProvisions: bnssSec.keyChangesIn2023 || bnssSec.keyTimelines || bnssSec.statutoryText.slice(0, 200),
    keywords: bnssSec.keywords,
    gazetteVerbatimText: bnssSec.statutoryText
  }))
];

// Combined compendium: Base items + Gazette items (deduplicated by number + act)
export const STATUTORY_COMPENDIUM: StatutoryItem[] = [
  ...BASE_STATUTORY_ITEMS,
  ...GAZETTE_MAPPED_ITEMS.filter(
    (gItem) => !BASE_STATUTORY_ITEMS.some((bItem) => bItem.act === gItem.act && bItem.number.toLowerCase() === gItem.number.toLowerCase())
  )
];

export interface SearchResult {
  matchedItem: StatutoryItem;
  aiExplanation: string;
  recommendedVerdict: string;
  relevanceScore: number;
}

/**
 * Intelligent 2026 AI Legal Query Processor
 * Responds to natural human questions like "what sections are used for a murder", "snatching", "forgery", etc.
 * Uses official Gazette of India Extraordinary provisions
 */
export function processLegalQuery(query: string): SearchResult[] {
  const clean = query.toLowerCase().trim();
  if (!clean) return [];

  const results: SearchResult[] = [];

  for (const item of STATUTORY_COMPENDIUM) {
    let score = 0;

    // Check exact section/article matches
    if (clean.includes(item.number.toLowerCase())) score += 100;
    if (item.legacyReference && clean.includes(item.legacyReference.toLowerCase())) score += 90;
    if (clean.includes(item.title.toLowerCase())) score += 70;

    // Check keywords
    for (const kw of item.keywords) {
      if (clean.includes(kw.toLowerCase())) {
        score += 40;
      }
    }

    // Concept specific checks
    if ((clean.includes('murder') || clean.includes('kill') || clean.includes('hatya')) && item.number.includes('103')) {
      score += 85;
    }
    if ((clean.includes('accident') || clean.includes('hit and run') || clean.includes('takkar')) && item.number.includes('106')) {
      score += 85;
    }
    if ((clean.includes('theft') || clean.includes('chori') || clean.includes('stolen')) && item.number.includes('303')) {
      score += 80;
    }
    if ((clean.includes('snatch') || clean.includes('chain snatching') || clean.includes('mobile snatch')) && item.number.includes('304')) {
      score += 85;
    }
    if ((clean.includes('fraud') || clean.includes('cheating') || clean.includes('scam') || clean.includes('420')) && item.number.includes('318')) {
      score += 80;
    }
    if ((clean.includes('rape') || clean.includes('sexual assault') || clean.includes('balatkar')) && (item.number.includes('63') || item.number.includes('64') || item.number.includes('70'))) {
      score += 90;
    }
    if ((clean.includes('defamation') || clean.includes('maan-haani') || clean.includes('insult reputation')) && item.number.includes('356')) {
      score += 85;
    }
    if ((clean.includes('forgery') || clean.includes('fake document') || clean.includes('aadhaar')) && (item.number.includes('336') || item.number.includes('337'))) {
      score += 85;
    }
    if ((clean.includes('extortion') || clean.includes('blackmail') || clean.includes('vasooli')) && item.number.includes('308')) {
      score += 85;
    }
    if ((clean.includes('terrorist') || clean.includes('terrorism') || clean.includes('bomb')) && item.number.includes('113')) {
      score += 85;
    }
    if ((clean.includes('organised crime') || clean.includes('syndicate') || clean.includes('gang')) && item.number.includes('111')) {
      score += 85;
    }
    if ((clean.includes('paper leak') || clean.includes('exam cheat') || clean.includes('atm skimming')) && item.number.includes('112')) {
      score += 85;
    }
    if ((clean.includes('arrest') || clean.includes('police') || clean.includes('giraftari')) && (item.number.includes('35') || item.number.includes('57') || item.number.includes('22'))) {
      score += 75;
    }
    if ((clean.includes('life') || clean.includes('liberty') || clean.includes('fundamental') || clean.includes('torture')) && item.number.includes('21')) {
      score += 80;
    }
    // BNSS Concept Checks
    if ((clean.includes('undertrial') || clean.includes('first time offender') || clean.includes('one-third') || clean.includes('jail bail') || clean.includes('479')) && item.act === 'BNSS 2023' && item.number.includes('479')) {
      score += 95;
    }
    if ((clean.includes('anticipatory') || clean.includes('pre-arrest') || clean.includes('agrim zamanat') || clean.includes('482')) && item.act === 'BNSS 2023' && item.number.includes('482')) {
      score += 95;
    }
    if ((clean.includes('fir') || clean.includes('zero fir') || clean.includes('e-fir') || clean.includes('electronic fir') || clean.includes('173')) && item.act === 'BNSS 2023' && item.number.includes('173')) {
      score += 95;
    }
    if ((clean.includes('chargesheet') || clean.includes('police report') || clean.includes('90 days') || clean.includes('193')) && item.act === 'BNSS 2023' && item.number.includes('193')) {
      score += 90;
    }
    if ((clean.includes('handcuff') || clean.includes('hathkadi') || clean.includes('sunset') || clean.includes('woman arrest') || clean.includes('43')) && item.act === 'BNSS 2023' && item.number.includes('43')) {
      score += 95;
    }
    if ((clean.includes('trial in absentia') || clean.includes('absconder') || clean.includes('fugitive') || clean.includes('356')) && item.act === 'BNSS 2023' && item.number.includes('356')) {
      score += 95;
    }
    if ((clean.includes('remand') || clean.includes('police custody') || clean.includes('default bail') || clean.includes('187')) && item.act === 'BNSS 2023' && item.number.includes('187')) {
      score += 95;
    }
    if ((clean.includes('maintenance') || clean.includes('wife maintenance') || clean.includes('parents maintenance') || clean.includes('144') || clean.includes('125 crpc')) && item.act === 'BNSS 2023' && item.number.includes('144')) {
      score += 95;
    }
    if ((clean.includes('forensic') || clean.includes('crime scene visit') || clean.includes('176')) && item.act === 'BNSS 2023' && item.number.includes('176')) {
      score += 90;
    }
    if ((clean.includes('videography') || clean.includes('search and seizure') || clean.includes('105')) && item.act === 'BNSS 2023' && item.number.includes('105')) {
      score += 90;
    }
    if ((clean.includes('victim compensation') || clean.includes('free medical treatment') || clean.includes('396') || clean.includes('397')) && item.act === 'BNSS 2023' && (item.number.includes('396') || item.number.includes('397'))) {
      score += 90;
    }
    if ((clean.includes('electronic trial') || clean.includes('virtual court') || clean.includes('video conferencing') || clean.includes('530')) && item.act === 'BNSS 2023' && item.number.includes('530')) {
      score += 90;
    }

    if (score > 30) {
      // Craft 2026 AI Legal Verdict and Explanation
      let explanation = '';
      let verdict = '';

      if (item.act === 'BNS 2023') {
        explanation = `Under Bharatiya Nyaya Sanhita (Official Gazette Act 45 of 2023) ${item.number} (formerly ${item.legacyReference || 'IPC'}), this offense is classified as ${item.cognizable ? 'COGNIZABLE (police can arrest without a warrant)' : 'NON-COGNIZABLE'}. It is ${item.bailable ? 'BAILABLE as a matter of right upon furnishing sureties' : 'NON-BAILABLE where bail is at judicial discretion'}.`;
        verdict = `Statutory Verdict: ${item.punishment || 'Varies by judicial assessment'}. ${item.whomToBeTakenTo || 'Produced before Magistrate.'}`;
      } else if (item.act === 'BNSS 2023') {
        explanation = `Procedural Mandate under BNSS 2023 ${item.number} (replacing ${item.legacyReference || 'CrPC'}): Governs custody, investigation timeline, and arrest rights.`;
        verdict = `Procedural Requirement: ${item.whomToBeTakenTo || 'To be followed strictly by the Investigating Officer.'}`;
      } else if (item.act === 'Constitution of India') {
        explanation = `Constitutional Shield under ${item.number}: Fundamental Right enforceable via Writ Petition under Article 32 or Article 226. Prevents unlawful state or police excess.`;
        verdict = `Constitutional Remedy: Relief granted by High Court or Supreme Court (Habeas Corpus / Bail / Quashing of Proceedings).`;
      } else {
        explanation = `Statutory Rule under ${item.act} ${item.number}: Governs evidentiary admissibility and judicial scrutiny.`;
        verdict = `Evidentiary Burden: ${item.keyProvisions}`;
      }

      results.push({
        matchedItem: item,
        aiExplanation: explanation,
        recommendedVerdict: verdict,
        relevanceScore: score
      });
    }
  }

  // Sort by highest relevance score
  return results.sort((a, b) => b.relevanceScore - a.relevanceScore);
}
