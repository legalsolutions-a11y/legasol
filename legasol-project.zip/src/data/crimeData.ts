export interface SampleFIR {
  id: string;
  firNumber: string;
  policeStation: string;
  district: string;
  state: string;
  dateOfOccurrence: string;
  dateReported: string;
  complainant: string;
  accused: string;
  applicableIpcSections: string[];
  applicableBnsSections: string[];
  firContent: string;
  counterFirContent?: string;
  summary: string;
  category: string;
  bailLikelihood: number;
}

export const SAMPLE_FIRS: SampleFIR[] = [
  {
    id: "fir-001",
    firNumber: "FIR No. 248/2024",
    policeStation: "Khar Police Station",
    district: "Mumbai Suburban",
    state: "Maharashtra",
    dateOfOccurrence: "12-08-2024 at 23:45 hrs",
    dateReported: "13-08-2024 at 02:15 hrs",
    complainant: "Rajesh S. Verma (Father of deceased)",
    accused: "Sameer Deshmukh & unknown driver of White SUV MH-02-CB-9912",
    applicableIpcSections: ["279", "304A", "34"],
    applicableBnsSections: ["281", "106(1)", "106(2)", "3(5)"],
    firContent: `FIRST INFORMATION REPORT (Under Section 154 Cr.P.C. / Section 173 BNSS)
Police Station: Khar, Mumbai Suburban District
FIR Number: 248/2024 | Date & Time of FIR: 13-08-2024 at 02:15 Hours

1. Complainant Details:
   Name: Rajesh Shanker Verma, Age: 52 Years, Occupation: Civil Engineer
   Address: Flat 402, Sea Green Apartments, 14th Road, Khar West, Mumbai

2. Details of Known/Suspected Accused:
   Sameer Deshmukh (driver of White Toyota Fortuner MH-02-CB-9912) and two unknown co-passengers.

3. Place of Occurrence:
   Western Express Highway near Khar Subway Junction, approximately 1.5 km East of Police Station.

4. Brief Facts of the Incident:
   The complainant states that on 12-08-2024 at approximately 23:45 hours, his son Rohan Verma (Age 22) was returning home on his motorcycle (Yamaha FZ, MH-02-ER-3341) after his university study session.
   While taking a permissible right turn at the Khar Subway junction signal, a White Toyota Fortuner registration no. MH-02-CB-9912 traveling at reckless speed (estimated >100 km/h) from Bandra towards Santacruz jumped the red traffic signal and violently rammed into the motorcycle.
   The impact propelled the victim Rohan Verma onto the road median, causing severe traumatic head injuries and multiple fractures.
   Instead of stopping to render immediate medical assistance or informing the nearest emergency response vehicle, the driver of the SUV accelerated and fled the scene at high speed (Hit and Run).
   Bystanders and an auto-rickshaw driver rushed Rohan to Bhabha Hospital where he was declared dead on arrival at 00:30 hours. Eyewitness dashcam footage and CCTV cameras at junction 14 captured the vehicle and license plate clearly.

5. Sections Alleged:
   Previously IPC 279, 304A, 34.
   Under Bharatiya Nyaya Sanhita (BNS 2023): Section 281 (Rash driving), Section 106(1) (Causing death by rash/negligent act), Section 106(2) (Hit-and-Run failing to report), and Section 3(5) (Common intention).`,
    counterFirContent: `CROSS FIR / DEFENSE STATEMENT
Accused Sameer Deshmukh claims that the deceased motorcyclist was riding without a helmet on the wrong side of the carriageway without functioning headlamps during heavy rainfall. Accused states he did not flee out of malice but fled to save himself from an aggressive local mob gathering to lynch him, and surrendered before the Santacruz Traffic Division within 4 hours.`,
    summary: "Fatal high-speed vehicular collision on highway resulting in instant death. Triggers new stringent BNS 106(2) hit-and-run provisions with up to 10 years imprisonment.",
    category: "Vehicular Homicide & Hit-and-Run",
    bailLikelihood: 35
  },
  {
    id: "fir-002",
    firNumber: "FIR No. 412/2024",
    policeStation: "Cyber Crime Police Station",
    district: "South West Delhi",
    state: "Delhi NCT",
    dateOfOccurrence: "04-09-2024 to 06-09-2024",
    dateReported: "07-09-2024 at 11:30 hrs",
    complainant: "Dr. Ananya Sen (Senior Consultant Cardiologist)",
    accused: "Kunal Mehra (alias 'DSP Vikramaditya CBI Mumbai') and gang operating Mule Bank Accounts",
    applicableIpcSections: ["419", "420", "468", "471", "120B"],
    applicableBnsSections: ["319(2)", "318(4)", "336(3)", "338", "61(2)", "111"],
    firContent: `FIRST INFORMATION REPORT (Digital Cyber Crime Unit)
Police Station: Special Cyber Cell, Dwarka, New Delhi
FIR No: 412/2024 | Dated: 07-09-2024 at 11:30 Hours

1. Complainant:
   Dr. Ananya Sen, D/o Late Prof. Debabrata Sen, R/o Sector 11, Dwarka, New Delhi.

2. Accused:
   Unknown syndicate members identifying as CBI Investigation Officers and Department of Telecommunications Enforcement Cell using VoIP virtual numbers +91-88902-XXXXX and spoofed Supreme Court digital arrest notices.

3. Nature of Offense:
   Digital Arrest Scam, Impersonation of Public Servant, Fraudulent Extortion & Cheating via Online Banking.

4. Brief Facts:
   Between 04-09-2024 and 06-09-2024, the complainant received an interactive voice call stating that her Aadhaar card was linked to 24 illegal parcel shipments containing forged passports and contraband sent to Cambodia.
   She was coerced into a Skype video session where accused persons wearing realistic Police uniforms and displaying a counterfeit CBI logo and fake Supreme Court interim freezing order instructed her that she was under 'Digital Arrest'.
   Threatened with immediate non-bailable arrest warrant, complainant was pressured into liquidating her fixed deposits amounting to Rs. 48,50,000/- and transferring the funds to designated 'Supreme Court Escrow Verification Accounts' across three private banks.
   Once transfers were credited, the calls were abruptly terminated and communication channels blocked.

5. Penal Provisions Invoked:
   IPC: 419 (Cheating by impersonation), 420 (Cheating), 468 (Forgery for cheating), 471 (Using forged record), 120B (Conspiracy) & Sec 66D IT Act.
   BNS 2023: Section 319(2) (Cheating by personation), Section 318(4) (Cheating and dishonestly inducing delivery), Section 336(3) (Forgery of electronic record), Section 338 (Using forged record), Section 61(2) (Criminal conspiracy), and Section 111 (Organized Crime).`,
    counterFirContent: `SUPPLEMENTARY POLICE INVESTIGATION REPORT
Three mule account holders arrested in Jamtara and Alwar. Accused claim their accounts were rented for Rs. 5,000 monthly commission and they had no direct awareness of the digital arrest extortion calls. Investigating Officer seeks asset attachment under BNSS Section 107.`,
    summary: "Organized interstate digital arrest scam defrauding Rs. 48.5 Lakhs by fabricating state emblems and court seals. Qualifies as Organized Cyber Syndicate under BNS Section 111.",
    category: "Cyber Crime & Syndicate Fraud",
    bailLikelihood: 15
  },
  {
    id: "fir-003",
    firNumber: "FIR No. 189/2024",
    policeStation: "Indiranagar Police Station",
    district: "Bengaluru City",
    state: "Karnataka",
    dateOfOccurrence: "21-07-2024 at 16:30 hrs",
    dateReported: "21-07-2024 at 20:00 hrs",
    complainant: "Manjunath Gowda (Commercial Property Owner)",
    accused: "Pawan Shetty, Karthik Reddy and 6 others armed with iron rods",
    applicableIpcSections: ["147", "148", "323", "324", "452", "506", "149"],
    applicableBnsSections: ["191(2)", "191(3)", "115(2)", "118(1)", "331(4)", "351(2)", "190"],
    firContent: `FIRST INFORMATION REPORT (Cognizable Offense)
Police Station: Indiranagar, Bengaluru
FIR No: 189/2024 | Dated: 21-07-2024

1. Complainant:
   Manjunath Gowda, Age 44, R/o 100 Feet Road, Indiranagar, Bengaluru.

2. Accused:
   Pawan Shetty (builder/contractor), Karthik Reddy (associate), and 6 unnamed henchmen.

3. Place of Occurrence:
   Site No. 44/2, 12th Main, HAL 2nd Stage, Indiranagar, Bengaluru.

4. Incident Facts:
   Complainant is the lawful registered title holder in physical possession of commercial plot 44/2. There is a pending civil injunction suit in Bengaluru City Civil Court (OS No. 1204/2023).
   On 21-07-2024 at 16:30 hours, while complainant and his security supervisor Basavaraj were overseeing boundary fencing, the accused Pawan Shetty and Karthik Reddy arrived with 6 associates in two Scorpio vehicles carrying iron rods and wooden clubs.
   The accused unlawfully broke open the entrance gate, trespassed onto the premises, hurled verbal abuses in foul Kannada, and assaulted Basavaraj with an iron rod causing deep laceration on forearm.
   When complainant intervened, accused threatened him at knifepoint stating 'Withdraw the civil suit within 48 hours or your family will be eliminated.'
   Security supervisor was treated at Bowring Hospital (MLC # 8892/24). CCTV footage from adjacent commercial showroom captured the entire armed entry.

5. Legal Sections:
   IPC: 147, 148, 323, 324, 452, 506, 149.
   BNS 2023: 191(2) (Rioting), 191(3) (Rioting with deadly weapon), 115(2) (Causing hurt), 118(1) (Hurt by dangerous weapon), 331(4) (House trespass after preparation for hurt), 351(2) (Criminal intimidation), 190 (Unlawful assembly liability).`,
    counterFirContent: `CROSS FIR No. 191/2024 filed by Pawan Shetty:
Alleges that he went for peaceful joint survey as per agreed memorandum of understanding, but complainant's private security guards assaulted them with bamboo sticks and provoked mutual fistfight over possession dispute. Both parties booked under reciprocal hurt offenses.`,
    summary: "Armed real-estate trespass and grievous assault with deadly weapons during pending civil title dispute. High risk of witness intimidation.",
    category: "Property & Violent Trespass",
    bailLikelihood: 60
  }
];
