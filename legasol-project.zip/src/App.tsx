import React, { useState } from 'react';
import { Navbar, ActiveTab } from './components/Navbar';
import { Home } from './components/Home';
import { FirCompare } from './components/FirCompare';
import { VerdictWizard } from './components/VerdictWizard';
import { StatutoryConstitutionExplorer } from './components/StatutoryConstitutionExplorer';
import { SAMPLE_FIRS, SampleFIR } from './data/crimeData';
import { Scale, X, MessageSquareHeart, Download, FolderOpen } from 'lucide-react';
import { LegasolCrest } from './components/LegasolCrest';
import { FeedbackModal } from './components/FeedbackModal';
import { ProjectFolderModal } from './components/ProjectFolderModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [showSampleModal, setShowSampleModal] = useState(false);
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  const [showFolderModal, setShowFolderModal] = useState(false);

  const handleSelectSample = (sample: SampleFIR) => {
    setShowSampleModal(false);
    setActiveTab('home');
  };

  return (
    <div className="min-h-screen bg-white text-slate-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white relative">
      {/* Background Subtle Watermark of Legasol Crest */}
      <div className="fixed inset-0 pointer-events-none z-0 flex items-center justify-center opacity-[0.035]">
        <LegasolCrest size={750} watermark={true} />
      </div>

      {/* Floating Water Bubble Orbs */}
      <div className="fixed top-20 right-10 w-72 h-72 rounded-full bg-gradient-to-br from-blue-100/50 to-indigo-100/30 blur-3xl pointer-events-none animate-bubble-slow"></div>
      <div className="fixed bottom-20 left-10 w-96 h-96 rounded-full bg-gradient-to-br from-sky-100/40 to-blue-50/50 blur-3xl pointer-events-none animate-bubble-float"></div>

      {/* Top Navigation Bar: Order: Home -> FIR Compare -> Verdict Wizard -> BNS & Constitution */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenSample={() => setShowSampleModal(true)}
        onOpenProjectFolder={() => setShowFolderModal(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        {activeTab === 'home' && (
          <Home
            onNavigateToCompare={() => setActiveTab('compare')}
            onNavigateToVerdict={() => setActiveTab('verdict')}
          />
        )}

        {activeTab === 'compare' && (
          <FirCompare
            onNavigateToRecording={() => setActiveTab('home')}
          />
        )}

        {activeTab === 'verdict' && <VerdictWizard />}

        {activeTab === 'bns-index' && <StatutoryConstitutionExplorer />}
      </main>

      {/* Preset Sample Case Modal */}
      {showSampleModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white border border-blue-200 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-blue-700" />
                <h3 className="text-base font-bold text-blue-950 font-crest">Select a Case Scenario to Test</h3>
              </div>
              <button
                onClick={() => setShowSampleModal(false)}
                className="text-slate-400 hover:text-slate-800 p-1.5 rounded-xl hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
              {SAMPLE_FIRS.map((sample) => (
                <div
                  key={sample.id}
                  onClick={() => handleSelectSample(sample)}
                  className="bg-blue-50/40 hover:bg-blue-50 border border-blue-100 hover:border-blue-400 p-4 rounded-2xl cursor-pointer transition-all group shadow-sm"
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="font-bold text-sm text-blue-950 group-hover:text-blue-700 transition-colors">
                      {sample.firNumber} - {sample.category}
                    </div>
                    <span className="text-xs text-blue-900 font-bold bg-white px-2.5 py-0.5 rounded-full border border-blue-200">
                      {sample.policeStation}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-2 mt-1">
                    {sample.summary}
                  </p>
                  <div className="flex items-center gap-2 mt-2 text-xs font-mono text-slate-500">
                    <span>IPC: {sample.applicableIpcSections.join(', ')}</span>
                    <span>➔</span>
                    <span className="text-blue-700 font-bold">BNS: {sample.applicableBnsSections.join(', ')}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2 text-right">
              <button
                onClick={() => setShowSampleModal(false)}
                className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold px-5 py-2.5 rounded-xl cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer with Legasol Crest */}
      <footer className="bg-white border-t border-blue-100 py-8 mt-16 text-xs text-slate-600 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <LegasolCrest size={36} />
            <div>
              <a 
                href="https://legasol.in" 
                target="_blank" 
                rel="noopener noreferrer"
                className="font-crest font-bold text-sm tracking-wide hover:underline cursor-pointer group"
                title="Visit Legasol.in"
              >
                <span className="text-red-600 font-extrabold">LEGA</span><span className="text-red-600 font-extrabold">SOL</span><span className="text-blue-950">.IN</span>
              </a>
              <span className="mx-2 text-slate-300">•</span>
              <span className="text-slate-600 font-medium">
                <span className="text-red-600 font-bold">Lega</span>l <span className="text-red-600 font-bold">Sol</span>utions & Verdict • BNS, BNSS, BSA 2023 & Constitution of India
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 text-center sm:text-right">
            <div className="text-[11px] text-slate-500 max-w-md font-medium">
              Educational & legal research platform. Does not constitute formal attorney-client counsel. For court proceedings, consult an advocate registered with the Bar Council.
            </div>

            {/* Feedback Button Exactly Beside the Educational Platform Text */}
            <button
              onClick={() => setShowFeedbackModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 text-xs font-semibold shadow-2xs hover:shadow-sm transition-all cursor-pointer whitespace-nowrap active:scale-95"
              title="Share feedback to improve the app"
            >
              <MessageSquareHeart className="w-3.5 h-3.5 text-blue-600" />
              <span>Feedback</span>
            </button>

            {/* View Project in Folder Format */}
            <button
              onClick={() => setShowFolderModal(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 text-xs font-semibold shadow-2xs hover:shadow-sm transition-all cursor-pointer whitespace-nowrap active:scale-95"
              title="View full project source code and directory hierarchy in folder format"
            >
              <FolderOpen className="w-3.5 h-3.5 text-blue-600" />
              <span>Project Folders</span>
            </button>

            {/* Download Project ZIP Archive */}
            <a
              href="/legasol-project.zip"
              download="legasol-project.zip"
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-2xs hover:shadow-sm transition-all cursor-pointer whitespace-nowrap active:scale-95 group"
              title="Download full project source code as a ZIP archive"
            >
              <Download className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
              <span>Project ZIP</span>
            </a>
          </div>
        </div>
      </footer>

      {/* User Feedback & Suggestions Modal */}
      <FeedbackModal 
        isOpen={showFeedbackModal} 
        onClose={() => setShowFeedbackModal(false)} 
      />

      {/* Project Folder & Directory Structure Explorer Modal */}
      <ProjectFolderModal 
        isOpen={showFolderModal} 
        onClose={() => setShowFolderModal(false)} 
      />
    </div>
  );
}
