import React, { useState } from 'react';
import { 
  X, MessageSquareHeart, Mail, User, Phone, Send, CheckCircle2, 
  Copy, Check, Star, Sparkles, AlertCircle, ExternalLink 
} from 'lucide-react';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [category, setCategory] = useState('App Improvement & Feature Suggestions');
  const [rating, setRating] = useState(5);
  const [feedback, setFeedback] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const targetEmail = 'legalsolutions@legasol.in';

  const generateFeedbackSummary = () => {
    const timestamp = new Date().toLocaleString('en-IN');
    return `FEEDBACK & APP IMPROVEMENT SUBMISSION
=====================================================
Target Recipient: ${targetEmail}
Submitted On:     ${timestamp}
Platform:         LegaSol Indian Legal Platform (2026 Edition)

USER CONTACT DETAILS:
• Full Name:      ${name.trim()}
• Email ID:       ${email.trim()}
• Phone Number:   ${phone.trim()}
• Feedback Type:  ${category}
• Overall Rating: ${'★'.repeat(rating)}${'☆'.repeat(5 - rating)} (${rating}/5)

FEEDBACK & SUGGESTIONS TO IMPROVE THE APP:
-----------------------------------------------------
${feedback.trim()}
=====================================================`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMessage('Please enter your full name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('Please enter a valid email address.');
      return;
    }
    if (!phone.trim()) {
      setErrorMessage('Please enter your contact phone number.');
      return;
    }
    if (!feedback.trim()) {
      setErrorMessage('Please provide your feedback or suggestions to improve the app.');
      return;
    }

    setErrorMessage(null);

    // Save feedback to local storage
    try {
      const stored = localStorage.getItem('legasol_user_feedbacks');
      const existing = stored ? JSON.parse(stored) : [];
      const newEntry = {
        id: `fb-${Date.now()}`,
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        category,
        rating,
        feedback: feedback.trim(),
        date: new Date().toISOString()
      };
      localStorage.setItem('legasol_user_feedbacks', JSON.stringify([newEntry, ...existing]));
    } catch (err) {
      console.error('Failed to save feedback to localStorage', err);
    }

    // Compose mailto URI
    const subject = encodeURIComponent(`LegaSol App Feedback & Suggestions from ${name.trim()} (${phone.trim()})`);
    const body = encodeURIComponent(generateFeedbackSummary());
    const mailtoUrl = `mailto:${targetEmail}?subject=${subject}&body=${body}`;

    // Open mail client
    try {
      window.location.href = mailtoUrl;
    } catch {
      // Fallback handled in UI
    }

    setIsSubmitted(true);
  };

  const handleCopySummary = () => {
    navigator.clipboard.writeText(generateFeedbackSummary());
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setPhone('');
    setFeedback('');
    setRating(5);
    setIsSubmitted(false);
    setErrorMessage(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-xl w-full p-6 sm:p-7 shadow-2xl relative my-8 animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 p-2 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
          title="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Header */}
            <div className="space-y-1 pr-8">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-900 text-xs font-semibold mb-1">
                <MessageSquareHeart className="w-3.5 h-3.5 text-blue-600" />
                <span>USER FEEDBACK & SUGGESTIONS</span>
              </div>
              <h2 className="font-headline font-bold text-xl sm:text-2xl text-slate-900">
                Help Us Improve <span className="text-red-600 font-extrabold">Lega</span><span className="text-red-600 font-extrabold">Sol</span>
              </h2>
              <p className="text-xs text-slate-600 leading-relaxed">
                Your feedback will be delivered directly to our product team at{' '}
                <a 
                  href={`mailto:${targetEmail}`}
                  className="font-semibold text-blue-700 hover:underline"
                >
                  legalsolutions@<span className="text-red-600 font-bold">lega</span><span className="text-red-600 font-bold">sol</span>.in
                </a>.
              </p>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2 font-medium">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Form Fields */}
            <div className="space-y-4 text-xs">
              {/* Full Name */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-slate-500" />
                  <span>Full Name *</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Adv. Rajesh Sharma / Complainant Name"
                  className="w-full bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3.5 py-2.5 text-slate-800 placeholder:text-slate-400 focus:outline-none transition-all shadow-2xs font-medium"
                />
              </div>

              {/* Email & Phone side by side */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-slate-500" />
                    <span>Email Address *</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. name@example.com"
                    className="w-full bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3.5 py-2.5 text-slate-800 placeholder:text-slate-400 focus:outline-none transition-all shadow-2xs font-medium"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-500" />
                    <span>Phone Number *</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. +91 98765 43210"
                    className="w-full bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3.5 py-2.5 text-slate-800 placeholder:text-slate-400 focus:outline-none transition-all shadow-2xs font-medium"
                  />
                </div>
              </div>

              {/* Feedback Category & Rating */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px] block">
                    Feedback Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 focus:border-blue-600 rounded-xl px-3.5 py-2.5 text-slate-800 focus:outline-none transition-all shadow-2xs font-medium"
                  >
                    <option value="App Improvement & Feature Suggestions">App Improvement & Feature Suggestions</option>
                    <option value="FIR Draft & Speech Recognition Accuracy">FIR Draft & Speech Recognition Accuracy</option>
                    <option value="BNS & BNSS 2023 Statutory Sections">BNS & BNSS 2023 Statutory Sections</option>
                    <option value="FIR Compare & Decision Support Panel">FIR Compare & Decision Support Panel</option>
                    <option value="UI, Font & Visual Experience">UI, Font & Visual Experience</option>
                    <option value="Bug / Glitch Report">Bug / Glitch Report</option>
                    <option value="General Legal Inquiry">General Legal Inquiry</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px] block">
                    Overall Experience Rating
                  </label>
                  <div className="flex items-center gap-1.5 pt-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        className="p-1 text-slate-300 hover:text-amber-400 transition-colors cursor-pointer"
                        title={`${star} Star${star > 1 ? 's' : ''}`}
                      >
                        <Star
                          className={`w-5 h-5 ${
                            star <= rating
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-slate-300'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="text-xs text-slate-500 font-bold ml-2">
                      {rating} / 5
                    </span>
                  </div>
                </div>
              </div>

              {/* Feedback Text Area */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 uppercase tracking-wider text-[11px] flex items-center justify-between">
                  <span>What feedback or suggestions would you like to give to improve the app? *</span>
                  <span className="text-slate-400 font-mono text-[10px]">
                    {feedback.trim().length} chars
                  </span>
                </label>
                <textarea
                  required
                  rows={4}
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Please describe how we can improve the app, features you'd like to see, legal sections you need added, or any glitch/experience feedback..."
                  className="w-full bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 focus:border-blue-600 rounded-xl p-3.5 text-slate-800 placeholder:text-slate-400 focus:outline-none transition-all resize-none shadow-2xs font-normal leading-relaxed"
                />
              </div>

              {/* Direct Mail Recipient Banner */}
              <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200/80 flex items-center justify-between text-xs text-blue-950">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-blue-700 shrink-0" />
                  <span>
                    Sending directly to: <strong className="font-mono text-blue-850">legalsolutions@<span className="text-red-600 font-bold">lega</span><span className="text-red-600 font-bold">sol</span>.in</strong>
                  </span>
                </div>
                <span className="text-[10px] font-bold text-blue-700 uppercase bg-blue-100/80 px-2 py-0.5 rounded-full">
                  Verified Mail
                </span>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-[#c49a6c] hover:bg-[#b3895b] text-white text-xs font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit Feedback</span>
              </button>
            </div>
          </form>
        ) : (
          /* Submission Success State */
          <div className="text-center py-6 space-y-5">
            <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="font-headline font-bold text-xl sm:text-2xl text-slate-900">
                Thank You for Your Feedback!
              </h3>
              <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
                Your feedback has been prepared and addressed to{' '}
                <strong className="text-blue-700 font-mono">legalsolutions@<span className="text-red-600 font-bold">lega</span><span className="text-red-600 font-bold">sol</span>.in</strong>.
              </p>
            </div>

            {/* Feedback Review Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left font-mono text-xs text-slate-800 max-h-48 overflow-y-auto whitespace-pre-wrap leading-relaxed shadow-inner">
              {generateFeedbackSummary()}
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                onClick={handleCopySummary}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-300 transition-all cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Summary Copied!' : 'Copy Feedback Summary'}</span>
              </button>

              <a
                href={`mailto:${targetEmail}?subject=${encodeURIComponent(`LegaSol App Feedback from ${name}`)}&body=${encodeURIComponent(generateFeedbackSummary())}`}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold shadow-md transition-all cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5" />
                <span>Open in Email App</span>
              </a>

              <button
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-sm transition-all cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
