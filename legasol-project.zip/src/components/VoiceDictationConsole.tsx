import React from 'react';
import { 
  Mic, Square, Volume2, Sparkles, AlertCircle, CheckCircle2, 
  RotateCcw, Globe, Zap, Radio, Info
} from 'lucide-react';

interface VoiceDictationConsoleProps {
  isRecording: boolean;
  recordingSeconds: number;
  soundLevel: number;
  speechStatus: string;
  interimTranscript: string;
  language: 'en-IN' | 'hi-IN';
  onLanguageChange: (lang: 'en-IN' | 'hi-IN') => void;
  onToggleRecording: () => void;
  onClearTranscript: () => void;
  isBrowserSupported: boolean;
}

export const VoiceDictationConsole: React.FC<VoiceDictationConsoleProps> = ({
  isRecording,
  recordingSeconds,
  soundLevel,
  speechStatus,
  interimTranscript,
  language,
  onLanguageChange,
  onToggleRecording,
  onClearTranscript,
  isBrowserSupported
}) => {
  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Generate 14 equalizer bars with dynamic heights responding to live microphone level
  const numBars = 14;
  const bars = Array.from({ length: numBars }, (_, i) => {
    // Symmetrical wave weighting: center bars taller
    const distFromCenter = Math.abs(i - (numBars - 1) / 2);
    const weight = 1 - (distFromCenter / (numBars / 2)) * 0.45;
    
    // Dynamic height calculation
    if (!isRecording) return 15;
    const randomizedFlutter = ((i * 17 + recordingSeconds * 7) % 25) * 0.6;
    const barHeight = Math.min(100, Math.max(16, (soundLevel * 0.85 * weight) + randomizedFlutter));
    return Math.round(barHeight);
  });

  return (
    <div className={`rounded-2xl border transition-all duration-300 p-4 sm:p-5 shadow-sm space-y-4 ${
      isRecording 
        ? 'bg-gradient-to-br from-red-50/90 via-white to-amber-50/70 border-red-300 ring-2 ring-red-400/20 shadow-md' 
        : 'bg-gradient-to-br from-slate-50 via-white to-blue-50/40 border-slate-200'
    }`}>
      {/* Top Controls Row */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {/* Main Voice Button with Ripple Ring */}
          <div className="relative">
            {isRecording && (
              <>
                <span className="absolute -inset-1 rounded-2xl bg-red-500/30 animate-ping pointer-events-none"></span>
                <span className="absolute -inset-2 rounded-2xl bg-red-400/15 animate-pulse pointer-events-none"></span>
              </>
            )}
            <button
              onClick={onToggleRecording}
              disabled={!isBrowserSupported}
              className={`relative z-10 flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer ${
                !isBrowserSupported
                  ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                  : isRecording
                  ? 'bg-red-600 hover:bg-red-700 text-white ring-2 ring-red-400 ring-offset-2'
                  : 'bg-red-500 hover:bg-red-600 text-white hover:shadow-md'
              }`}
            >
              {isRecording ? (
                <>
                  <Square className="w-4 h-4 fill-white" />
                  <span>Stop Dictation</span>
                </>
              ) : (
                <>
                  <Mic className="w-4 h-4" />
                  <span>Start Voice Dictation</span>
                </>
              )}
            </button>
          </div>

          {/* Hands-Free Live Status Pill */}
          {isRecording ? (
            <div className="flex items-center gap-2 bg-white/95 px-3 py-1.5 rounded-xl border border-red-200 shadow-2xs">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping"></span>
              <span className="text-xs font-mono font-bold text-red-600">
                {formatTimer(recordingSeconds)}
              </span>
              <span className="text-slate-300">|</span>
              <span className="text-[11px] font-semibold text-slate-700 flex items-center gap-1">
                <Radio className="w-3.5 h-3.5 text-red-500 animate-pulse" />
                <span>Hands-Free Listening</span>
              </span>
            </div>
          ) : (
            <div className="text-xs font-medium text-slate-500 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>Web Speech API Ready</span>
            </div>
          )}
        </div>

        {/* Right Tools: Language Selector & Clear */}
        <div className="flex items-center gap-2">
          {/* Language Toggle */}
          <div className="inline-flex items-center p-0.5 rounded-xl bg-white border border-slate-200 shadow-2xs text-xs font-semibold">
            <button
              onClick={() => onLanguageChange('en-IN')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                language === 'en-IN'
                  ? 'bg-blue-900 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Dictate in Indian English"
            >
              English (India)
            </button>
            <button
              onClick={() => onLanguageChange('hi-IN')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                language === 'hi-IN'
                  ? 'bg-blue-900 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="हिन्दी में बोलें"
            >
              हिन्दी (Hindi)
            </button>
          </div>

          {isRecording && (
            <button
              onClick={onClearTranscript}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-white rounded-lg transition-colors cursor-pointer border border-transparent hover:border-slate-200"
              title="Reset speech buffer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Real-time Visual Audio Waveform Equalizer */}
      {isRecording && (
        <div className="space-y-3 pt-1 border-t border-red-100">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              <span>Real-Time Voice Volume & Frequency:</span>
            </span>

            <span className="font-mono text-[11px] font-bold text-slate-600">
              {soundLevel > 40 ? 'High Voice Level' : soundLevel > 15 ? 'Optimal Speech Volume' : 'Listening for Voice...'} ({soundLevel}%)
            </span>
          </div>

          {/* Equalizer Frequency Bars */}
          <div className="h-12 bg-white/90 border border-slate-200/90 rounded-xl p-2 flex items-end justify-center gap-1.5 sm:gap-2 shadow-inner">
            {bars.map((barH, idx) => (
              <div
                key={idx}
                className="w-2.5 sm:w-3.5 rounded-t-md transition-all duration-75 ease-out"
                style={{
                  height: `${barH}%`,
                  background: barH > 65
                    ? 'linear-gradient(to top, #f59e0b, #ef4444)'
                    : barH > 35
                    ? 'linear-gradient(to top, #3b82f6, #06b6d4)'
                    : 'linear-gradient(to top, #94a3b8, #cbd5e1)'
                }}
              />
            ))}
          </div>

          {/* Live Interim Transcript Bubble */}
          <div className="bg-white border border-amber-200/90 rounded-xl p-3 shadow-2xs space-y-1">
            <div className="flex items-center justify-between text-[11px]">
              <span className="font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                <span>Live Speech Stream</span>
              </span>
              <span className="text-slate-400 font-mono text-[10px]">
                Web Speech API Real-Time Interim
              </span>
            </div>

            <p className="text-xs text-slate-800 font-medium min-h-[1.5rem] leading-relaxed">
              {interimTranscript ? (
                <span className="italic text-amber-900 font-semibold bg-amber-50 px-1 py-0.5 rounded">
                  "{interimTranscript}"
                  <span className="inline-block w-1.5 h-3.5 ml-1 bg-amber-500 animate-pulse align-middle"></span>
                </span>
              ) : (
                <span className="text-slate-400 italic">
                  Speak into your microphone — your words will appear here instantly...
                </span>
              )}
            </p>
          </div>

          {/* Hands-Free Voice Commands Helper Chips */}
          <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500 pt-0.5">
            <span className="font-bold text-slate-600">Voice Shortcuts:</span>
            <span className="bg-white border border-slate-200 px-2 py-0.5 rounded-md font-mono text-slate-700">
              Say "Full stop" ➔ .
            </span>
            <span className="bg-white border border-slate-200 px-2 py-0.5 rounded-md font-mono text-slate-700">
              Say "Comma" ➔ ,
            </span>
            <span className="bg-white border border-slate-200 px-2 py-0.5 rounded-md font-mono text-slate-700">
              Say "New line" ➔ ↵
            </span>
            <span className="bg-white border border-slate-200 px-2 py-0.5 rounded-md font-mono text-slate-700">
              Say "New paragraph" ➔ ¶
            </span>
          </div>
        </div>
      )}

      {/* Browser Not Supported Warning */}
      {!isBrowserSupported && (
        <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
          <span>
            Web Speech API is not supported in this browser. Please use Google Chrome or Microsoft Edge for hands-free speech dictation.
          </span>
        </div>
      )}
    </div>
  );
};
