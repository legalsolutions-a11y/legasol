import React, { useState } from 'react';
import { Sparkles, Scale, BookOpen, ShieldCheck, AlertCircle, CheckCircle2, ChevronRight, RefreshCw, FileText, Volume2, Landmark } from 'lucide-react';
import { BNS_SECTIONS, BNSSection } from '../data/bnsSections';
import { speakText } from '../lib/speech';
import { TrialProgressTimeline } from './TrialProgressTimeline';
import { LegalPrecedentSection } from './LegalPrecedentSection';

interface CrimeCategory {
  id: string;
  name: string;
  hindiName: string;
  description: string;
  sectionKeys: string[];
}

const CRIME_CATEGORIES: CrimeCategory[] = [
  {
    id: 'body',
    name: 'Human Body & Injury',
    hindiName: 'मारपीट, चोट या हत्या',
    description: 'Murder, Culpable Homicide, Grievous Hurt, Assault and Fatal Acts',
    sectionKeys: ['103(1)', '105', '106(1)', '106(2)', '109', '115(2)', '117(2)']
  },
  {
    id: 'property',
    name: 'Property, Robbery & Theft',
    hindiName: 'चोरी, डकैती और जबरन वसूली',
    description: 'Theft, Snatching, Extortion, Robbery, Dacoity, Criminal Breach of Trust',
    sectionKeys: ['303(2)', '304', '308(2)', '309(4)', '310(2)', '316(2)', '318(4)']
  },
  {
    id: 'women',
    name: 'Women & Child Protection',
    hindiName: 'महिला व बाल अपराध',
    description: 'Sexual assault, Gang rape, Deceitful marriage promise, Domestic Cruelty',
    sectionKeys: ['64(1)', '69', '70(1)', '85']
  },
  {
    id: 'economic',
    name: 'Economic, Cyber & Cheating',
    hindiName: 'ऑनलाइन ठगी और जालसाजी',
    description: 'Cheating, Impersonation, Digital Forgery, Organized Syndicate Crimes',
    sectionKeys: ['318(4)', '319', '336(3)', '338', '111', '112']
  },
  {
    id: 'public',
    name: 'Public Order & Riot',
    hindiName: 'दंगा और शांति भंग',
    description: 'Acts endangering sovereignty, Rioting, Terrorist acts',
    sectionKeys: ['152', '189', '191(2)', '113']
  },
  {
    id: 'traffic',
    name: 'Traffic Accident & Hit-Run',
    hindiName: 'गाड़ी दुर्घटना और भाग जाना',
    description: 'Rash driving, death by negligence, fleeing without reporting',
    sectionKeys: ['281', '106(1)', '106(2)']
  }
];

interface EvidenceFactor {
  id: string;
  name: string;
  hindiName: string;
  type: 'aggravating' | 'mitigating';
  description: string;
  impactWeight: number;
}

const TEN_EVIDENCE_FACTORS: EvidenceFactor[] = [
  {
    id: 'f1',
    name: 'Independent Eyewitnesses',
    hindiName: 'चश्मदीद गवाह मौजूद हैं',
    type: 'aggravating',
    description: 'Independent neutral bystander statements corroborating the incident.',
    impactWeight: 15
  },
  {
    id: 'f2',
    name: 'Doctor Medical Report (MLC)',
    hindiName: 'डॉक्टर का एमएलसी मेडिकल रिपोर्ट',
    type: 'aggravating',
    description: 'Injury or cause of death verified by certified hospital medical officer.',
    impactWeight: 14
  },
  {
    id: 'f3',
    name: 'Weapon / Stolen Goods Found',
    hindiName: 'हथियार या चोरी का सामान बरामद',
    type: 'aggravating',
    description: 'Physical discovery of weapon or stolen cash under BSA Section 23.',
    impactWeight: 12
  },
  {
    id: 'f4',
    name: 'Clear CCTV / Video Proof',
    hindiName: 'साफ सीसीटीवी या वीडियो रिकॉर्डिंग',
    type: 'aggravating',
    description: 'CCTV video or phone recording authenticated with digital certificate.',
    impactWeight: 18
  },
  {
    id: 'f5',
    name: 'Previous Criminal Record',
    hindiName: 'आरोपी का पिछला आपराधिक रिकॉर्ड',
    type: 'aggravating',
    description: 'History of previous criminal convictions or habitual offender status.',
    impactWeight: 10
  },
  {
    id: 'f6',
    name: 'Right of Self-Defense',
    hindiName: 'आत्मरक्षा (प्राइवेट डिफेंस)',
    type: 'mitigating',
    description: 'Defensive force used to protect life or bodily harm under BNS Sec 34–44.',
    impactWeight: -18
  },
  {
    id: 'f7',
    name: 'Sudden Fight / No Premeditation',
    hindiName: 'अचानक हुआ झगड़ा (पूर्व योजना नहीं)',
    type: 'mitigating',
    description: 'Act occurred in sudden mutual fight without prior criminal plan.',
    impactWeight: -14
  },
  {
    id: 'f8',
    name: 'Long Unexplained Delay in FIR',
    hindiName: 'एफआईआर में बहुत देरी (संदिग्ध)',
    type: 'mitigating',
    description: 'Complaint lodged days or weeks later without valid reason.',
    impactWeight: -12
  },
  {
    id: 'f9',
    name: 'Doctor Report Contradicts Story',
    hindiName: 'मेडिकल रिपोर्ट शिकायत से अलग है',
    type: 'mitigating',
    description: 'Physical injuries do not match the aggressive weapons claimed.',
    impactWeight: -15
  },
  {
    id: 'f10',
    name: 'Civil Dispute / Money Returned',
    hindiName: 'पैसे लौटा दिए / व्यापारिक विवाद',
    type: 'mitigating',
    description: 'Commercial disagreement or loan dispute given criminal color.',
    impactWeight: -16
  }
];

export const VerdictWizard: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('body');
  const [selectedSections, setSelectedSections] = useState<string[]>(['103(1)']);
  const [activeFactors, setActiveFactors] = useState<Record<string, boolean>>({
    f1: true,
    f2: true,
    f4: true,
    f6: false,
    f7: false,
    f8: false,
    f9: false,
    f10: false
  });

  const toggleSection = (sec: string) => {
    if (selectedSections.includes(sec)) {
      if (selectedSections.length > 1) {
        setSelectedSections(selectedSections.filter(s => s !== sec));
      }
    } else {
      setSelectedSections([...selectedSections, sec]);
    }
  };

  const toggleFactor = (id: string) => {
    setActiveFactors(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const activeCategory = CRIME_CATEGORIES.find(c => c.id === selectedCategory)!;
  const currentCategorySections = BNS_SECTIONS.filter(s => 
    activeCategory.sectionKeys.some(k => s.bnsSection.startsWith(k) || k.startsWith(s.bnsSection))
  );

  let netWeight = 0;
  TEN_EVIDENCE_FACTORS.forEach(f => {
    if (activeFactors[f.id]) {
      netWeight += f.impactWeight;
    }
  });

  const baseConviction = 50 + netWeight;
  const convictionProb = Math.max(8, Math.min(92, baseConviction));
  const acquittalProb = Math.max(5, Math.min(90, 100 - convictionProb - (activeFactors.f7 || activeFactors.f10 ? 20 : 10)));
  const dilutionProb = Math.max(3, 100 - convictionProb - acquittalProb);

  let simulatedVerdict = "Likely Conviction on Charged Sections (दोषी सिद्ध होने की संभावना)";
  let verdictColor = "text-rose-700";
  let verdictSummary = "Direct eyewitnesses and authenticated digital/medical records create a strong case under Bharatiya Sakshya Adhiniyam 2023.";

  if (acquittalProb > 55) {
    simulatedVerdict = "Probable Full Acquittal (संदेह का लाभ / बरी होना)";
    verdictColor = "text-emerald-700";
    verdictSummary = "Key mitigating factors, delay in FIR, or lack of independent corroboration establish strong reasonable doubt favoring acquittal.";
  } else if (dilutionProb > 30 || activeFactors.f7 || activeFactors.f10) {
    simulatedVerdict = "Section Dilution / Compounded Settlement (धारा कम होना / समझौता)";
    verdictColor = "text-amber-700";
    verdictSummary = "Evidence indicates absence of premeditation or civil coloration. High probability of alteration of charges to lesser compoundable sections under BNSS.";
  }

  const predictedOutcomeType: 'conviction' | 'acquittal' | 'dilution' = 
    acquittalProb > 55 ? 'acquittal' :
    (dilutionProb > 30 || activeFactors.f7 || activeFactors.f10) ? 'dilution' : 'conviction';

  const handleSpeakVerdict = () => {
    speakText(`Verdict prediction: ${simulatedVerdict}. Conviction probability is ${convictionProb} percent. Acquittal on benefit of doubt is ${acquittalProb} percent. ${verdictSummary}`);
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-16">
      {/* Header */}
      <div className="bubble-glass rounded-3xl p-6 sm:p-8 shadow-md border border-blue-100">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2.5 rounded-2xl bg-blue-100 text-blue-900 border border-blue-200">
                <Scale className="w-6 h-6 text-blue-700" />
              </span>
              <div>
                <h2 className="text-2xl font-black font-crest text-blue-950">
                  <span className="text-red-600 font-extrabold">Lega</span><span className="text-red-600 font-extrabold">Sol</span> Verdict Wizard Simulator
                </h2>
                <span className="text-xs font-bold text-blue-700">6 Crime Categories • 18 BNS Sections • 10 Evidence Factors</span>
              </div>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 mt-2 max-w-2xl font-medium">
              Simulate what will happen in court! Toggle evidence, witnesses, and self-defense to see the simulated verdict probability in simple visual terms.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSpeakVerdict}
              className="flex items-center gap-1.5 text-xs text-blue-900 font-bold bg-blue-100 hover:bg-blue-200 px-4 py-2.5 rounded-xl transition-all cursor-pointer shadow-sm"
            >
              <Volume2 className="w-4 h-4 text-blue-700" />
              <span>Listen / बोलकर सुनें</span>
            </button>
            <button
              onClick={() => {
                setActiveFactors({ f1: false, f2: false, f3: false, f4: false, f5: false, f6: true, f7: true, f8: true, f9: true, f10: true });
              }}
              className="flex items-center gap-1.5 text-xs text-white font-bold bg-blue-700 hover:bg-blue-800 px-4 py-2.5 rounded-xl transition-all shadow cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Simulate Defense Case</span>
            </button>
          </div>
        </div>
      </div>

      {/* Visual Courtroom Trial Progress & Timeline Tracker */}
      <TrialProgressTimeline
        convictionProb={convictionProb}
        acquittalProb={acquittalProb}
        dilutionProb={dilutionProb}
        activeFactorsCount={Object.values(activeFactors).filter(Boolean).length}
        totalFactorsCount={TEN_EVIDENCE_FACTORS.length}
        selectedCategoryName={activeCategory.name}
      />

      {/* Main Grid: Left Controls (Categories, Sections, Factors) & Right Simulated Verdict */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column (7 cols): Configuration Panel */}
        <div className="lg:col-span-7 space-y-6">
          {/* 1. Category Selector */}
          <div className="bubble-card rounded-3xl p-6 shadow-sm border border-blue-100 bg-white">
            <label className="text-xs font-bold text-blue-950 uppercase tracking-wider block mb-3 font-crest">
              Step 1: Choose Crime Type / अपराध की श्रेणी (6 Categories)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {CRIME_CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategory(cat.id);
                    const firstSec = BNS_SECTIONS.find(s => cat.sectionKeys.some(k => s.bnsSection.startsWith(k)));
                    if (firstSec) setSelectedSections([firstSec.bnsSection]);
                  }}
                  className={`p-3.5 rounded-2xl text-left border transition-all cursor-pointer ${
                    selectedCategory === cat.id
                      ? 'border-blue-600 bg-blue-50/80 text-blue-950 ring-2 ring-blue-500/20 shadow-sm'
                      : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="font-bold text-xs text-blue-950">{cat.name}</div>
                  <div className="text-[11px] font-semibold text-blue-700 mt-0.5">{cat.hindiName}</div>
                </button>
              ))}
            </div>
          </div>

          {/* 2. BNS Sections Selection */}
          <div className="bubble-card rounded-3xl p-6 shadow-sm border border-blue-100 bg-white">
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-bold text-blue-950 uppercase tracking-wider font-crest">
                Step 2: Charged Sections (बीएनएस धाराएं)
              </label>
              <span className="text-xs font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
                {selectedSections.length} Section(s) Selected
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {currentCategorySections.map((sec) => {
                const isSelected = selectedSections.includes(sec.bnsSection);
                return (
                  <div
                    key={sec.bnsSection}
                    onClick={() => toggleSection(sec.bnsSection)}
                    className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-start gap-2.5 ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50 text-blue-950 shadow-sm ring-1 ring-blue-500/20'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className={`w-4 h-4 rounded-full mt-0.5 flex items-center justify-center shrink-0 text-[10px] font-bold ${
                      isSelected ? 'bg-blue-700 text-white' : 'border border-slate-300 bg-slate-50'
                    }`}>
                      {isSelected ? '✓' : ''}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-xs text-blue-900 font-mono">BNS {sec.bnsSection}</span>
                        <span className="text-[10px] text-slate-500">(IPC {sec.ipcSection})</span>
                      </div>
                      <div className="text-xs font-bold text-slate-900 mt-0.5 line-clamp-1">{sec.bnsTitle}</div>
                      <div className="text-[11px] text-slate-600 mt-1 line-clamp-1">{sec.punishment}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 3. 10 Evidence Factors */}
          <div className="bubble-card rounded-3xl p-6 shadow-sm border border-blue-100 bg-white">
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-bold text-blue-950 uppercase tracking-wider font-crest">
                Step 3: 10 Case & Evidence Factors (सबूत और गवाह)
              </label>
              <span className="text-xs text-slate-500">Tap to turn ON or OFF</span>
            </div>

            <div className="space-y-2">
              {TEN_EVIDENCE_FACTORS.map((factor) => {
                const isActive = !!activeFactors[factor.id];
                const isAgg = factor.type === 'aggravating';

                return (
                  <label
                    key={factor.id}
                    onClick={() => toggleFactor(factor.id)}
                    className={`flex items-start justify-between p-3.5 rounded-2xl border cursor-pointer transition-all ${
                      isActive
                        ? isAgg
                          ? 'border-rose-300 bg-rose-50/70 text-rose-950 shadow-sm'
                          : 'border-emerald-300 bg-emerald-50/70 text-emerald-950 shadow-sm'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <input
                        type="checkbox"
                        checked={isActive}
                        onChange={() => {}}
                        className={`mt-1 w-4 h-4 rounded cursor-pointer ${isAgg ? 'accent-rose-600' : 'accent-emerald-600'}`}
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold">{factor.name}</span>
                          <span className="text-xs font-semibold text-slate-500">({factor.hindiName})</span>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            isAgg ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {isAgg ? 'Against Accused' : 'Favors Accused'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-1">{factor.description}</p>
                      </div>
                    </div>

                    <div className="text-xs font-mono font-bold shrink-0 ml-3">
                      {isAgg ? `+${factor.impactWeight}%` : `${factor.impactWeight}%`}
                    </div>
                  </label>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Real-Time Simulated Verdict Output */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bubble-glass rounded-3xl p-6 shadow-xl sticky top-24 border border-blue-100 bg-white/95">
            <div className="flex items-center justify-between pb-3 border-b border-blue-100">
              <div className="flex items-center gap-2">
                <Scale className="w-5 h-5 text-blue-700" />
                <h3 className="font-bold text-sm text-blue-950 font-crest">Simulated Judicial Verdict</h3>
              </div>
              <button
                onClick={handleSpeakVerdict}
                className="p-1.5 rounded-full bg-blue-100 text-blue-800 hover:bg-blue-200 cursor-pointer"
                title="Speak verdict out loud"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>

            {/* Main Verdict Card */}
            <div className="mt-4 p-5 rounded-2xl bg-blue-50/80 border border-blue-200 text-center">
              <div className="text-[11px] font-bold text-blue-900 uppercase tracking-wider mb-1 font-crest">
                Probable Court Result
              </div>
              <div className={`text-lg font-black ${verdictColor} leading-tight`}>
                {simulatedVerdict}
              </div>
              <p className="text-xs text-slate-700 mt-2 leading-relaxed font-medium">
                {verdictSummary}
              </p>
            </div>

            {/* Probability Breakdown Bar */}
            <div className="mt-5 space-y-3">
              <div className="text-xs font-bold text-blue-950 uppercase tracking-wider font-crest">
                Verdict Odds Breakdown
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-rose-700">Guilty as Charged (सजा होना):</span>
                  <span className="font-mono text-slate-900">{convictionProb}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden border border-slate-200">
                  <div className="bg-rose-500 h-3 rounded-full transition-all duration-300" style={{ width: `${convictionProb}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-emerald-700">Full Acquittal (बरी होना):</span>
                  <span className="font-mono text-slate-900">{acquittalProb}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden border border-slate-200">
                  <div className="bg-emerald-500 h-3 rounded-full transition-all duration-300" style={{ width: `${acquittalProb}%` }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-amber-700">Dilution / Settlement (धाराएं कम होना):</span>
                  <span className="font-mono text-slate-900">{dilutionProb}%</span>
                </div>
                <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden border border-slate-200">
                  <div className="bg-amber-500 h-3 rounded-full transition-all duration-300" style={{ width: `${dilutionProb}%` }} />
                </div>
              </div>
            </div>

            {/* Relevant Statutory Sentences */}
            <div className="mt-5 pt-4 border-t border-blue-100">
              <div className="text-xs font-bold text-blue-950 uppercase tracking-wider mb-2 font-crest">
                Prescribed Statutory Tariffs
              </div>
              <div className="space-y-2 text-xs">
                {selectedSections.map(secKey => {
                  const s = BNS_SECTIONS.find(item => item.bnsSection === secKey);
                  if (!s) return null;
                  return (
                    <div key={secKey} className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <div className="font-bold text-blue-950">BNS Section {s.bnsSection} - {s.bnsTitle}</div>
                      <div className="text-[11px] text-slate-600 mt-0.5">{s.punishment}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Relevant Legal Precedents & Landmark Case Law Section */}
      <LegalPrecedentSection
        activeSections={selectedSections}
        predictedOutcome={predictedOutcomeType}
        convictionProb={convictionProb}
        acquittalProb={acquittalProb}
        dilutionProb={dilutionProb}
        selectedCategoryName={activeCategory.name}
      />
    </div>
  );
};
