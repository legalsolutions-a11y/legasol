import React, { useState, useRef, useEffect } from 'react';
import { 
  FileText, Upload, RefreshCw, Copy, Check, Download, Trash2, 
  Sparkles, Volume2, Mic, Square, Save, RotateCcw, 
  ArrowLeftRight, VolumeX, ShieldAlert
} from 'lucide-react';
import { parseAndAnalyzeFIR, ExtractedFIRMetadata } from '../lib/analysis';
import { getSavedCases, saveCase, deleteSavedCase, SavedCase } from '../lib/storage';
import { extractTextFromFile } from '../lib/fileTextExtractor';
import { speakText, stopSpeaking, GlitchFreeSpeechRecognizer } from '../lib/speech';
import { VoiceDictationConsole } from './VoiceDictationConsole';
import { ProceduralStrategyBox } from './ProceduralStrategyBox';
import { LegalFeasibilityBox } from './LegalFeasibilityBox';

import assaultImg from '../assets/images/crime_physical_assault_1792160670610.jpg';
import theftImg from '../assets/images/crime_theft_snatching_1792160671264.jpg';
import accidentImg from '../assets/images/crime_accident_hitrun_1792160670261.jpg';
import cyberImg from '../assets/images/crime_cyber_phone_fraud_1792160670102.jpg';

interface HomeProps {
  onNavigateToCompare: () => void;
  onNavigateToVerdict: () => void;
}

interface VisualIncidentTemplate {
  id: string;
  title: string;
  hindiTitle: string;
  image: string;
  description: string;
  sampleComplaint: string;
}

const VISUAL_TEMPLATES: VisualIncidentTemplate[] = [
  {
    id: 'theft',
    title: 'Theft / Snatching',
    hindiTitle: 'चोरी या फोन छीनना',
    image: theftImg,
    description: 'Mobile phone or purse snatched on the road by unknown persons on motorbike',
    sampleComplaint: 'My mobile phone and wallet were snatched by two unknown men on a black motorbike near MG Road market around 8:30 PM yesterday while I was returning home. The rider was wearing a black helmet and the vehicle had no number plate.'
  },
  {
    id: 'assault',
    title: 'Physical Assault / Attack',
    hindiTitle: 'मारपीट या चोट लगना',
    image: assaultImg,
    description: 'Beaten or attacked by identified neighbors or strangers with sticks or fists',
    sampleComplaint: 'I was wrongfully restrained and assaulted with wooden sticks and iron rods by Ramesh and his two associates near Sector 4 community hall on 14th October at 6:00 PM. I sustained serious bleeding injuries on my head and right arm and was treated at the District Civil Hospital.'
  },
  {
    id: 'accident',
    title: 'Road Accident / Hit & Run',
    hindiTitle: 'गाड़ी से टक्कर और भागना',
    image: accidentImg,
    description: 'Vehicle collided with pedestrian or bike and driver fled without helping',
    sampleComplaint: 'A speeding white SUV rammed into my motorcycle at the NH-48 bypass signal on Monday at 9:15 PM and fled the spot without providing medical help or reporting to police. The vehicle registration number was partially noted as DL 3C XX 4521.'
  },
  {
    id: 'cyber',
    title: 'Cyber Fraud / Bank Scam',
    hindiTitle: 'ऑनलाइन धोखाधड़ी व ठगी',
    image: cyberImg,
    description: 'Money deducted via fake call, lottery link, or bank APK impersonation',
    sampleComplaint: 'I was cheated of Rs 85,000 through an unauthorized bank transfer after receiving a fraudulent phone call from a person claiming to be a bank manager. They sent a malicious payment link claiming to update my KYC documents.'
  }
];

export const Home: React.FC<HomeProps> = ({ onNavigateToCompare }) => {
  // Box starts completely empty as requested by user
  const [complaintText, setComplaintText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [copied, setCopied] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [savedCases, setSavedCases] = useState<SavedCase[]>([]);

  // Hands-free Web Speech API real-time states
  const [speechStatus, setSpeechStatus] = useState<string>('Ready');
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [soundLevel, setSoundLevel] = useState<number>(0);
  const [speechLanguage, setSpeechLanguage] = useState<'en-IN' | 'hi-IN'>('en-IN');
  const [isBrowserSupported, setIsBrowserSupported] = useState<boolean>(true);

  // Extracted Information fields (empty until generated)
  const [extractedInfo, setExtractedInfo] = useState({
    complainantName: '_______________',
    contactNumber: '_______________',
    dateOccurrence: '___/___/______',
    timeOccurrence: '__:__',
    day: '___________',
    placeOccurrence: '_______________________________',
    accusedDetails: 'To be identified during investigation',
    natureOfOffense: 'To be determined after investigation',
    infoType: 'Telephonic'
  });

  // Generated FIR box starts strictly empty
  const [generatedFirDoc, setGeneratedFirDoc] = useState<string>('');
  const [analysisResult, setAnalysisResult] = useState<ExtractedFIRMetadata | null>(null);

  // Audio / Speech refs
  const recognizerRef = useRef<GlitchFreeSpeechRecognizer | null>(null);
  const timerRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setSavedCases(getSavedCases());

    const isSupported = typeof window !== 'undefined' && 
      Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);
    setIsBrowserSupported(isSupported);

    // Initialize cross-platform speech recognizer with real-time interim and audio monitoring
    recognizerRef.current = new GlitchFreeSpeechRecognizer(
      (newText) => {
        setComplaintText(newText);
        setGeneratedFirDoc('');
      },
      (status) => {
        setSpeechStatus(status);
      },
      speechLanguage,
      (interim) => {
        setInterimTranscript(interim);
      },
      (level) => {
        setSoundLevel(level);
      }
    );

    return () => {
      cleanupSpeech();
      stopSpeaking();
    };
  }, []);

  const cleanupSpeech = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    if (recognizerRef.current) {
      recognizerRef.current.stop();
    }
    setIsRecording(false);
    setInterimTranscript('');
    setSoundLevel(0);
  };

  const handleLanguageChange = (newLang: 'en-IN' | 'hi-IN') => {
    setSpeechLanguage(newLang);
    if (recognizerRef.current) {
      recognizerRef.current.setLanguage(newLang);
    }
  };

  const handleClearTranscript = () => {
    setComplaintText('');
    setInterimTranscript('');
    setGeneratedFirDoc('');
  };

  // Build the generated FIR document matching the user's exact specification and template
  const generateDocument = (text: string) => {
    const trimmed = text.trim();
    if (!trimmed) {
      setGeneratedFirDoc('');
      return;
    }

    const analysis = parseAndAnalyzeFIR(trimmed);
    setAnalysisResult(analysis);

    const today = new Date();
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const pad = (n: number) => n.toString().padStart(2, '0');

    // Date & Time information received
    const dateInfoReceived = `${pad(today.getDate())}/${pad(today.getMonth() + 1)}/${today.getFullYear()}`;
    const timeInfoReceived = `${pad(today.getHours())}:${pad(today.getMinutes())}`;
    const nowStr = `${today.toLocaleDateString('en-US')}, ${today.toLocaleTimeString('en-US')}`;

    // Occurrence fields extraction
    let occDate = '___/___/______';
    let occTime = '__:__';
    let occDay = '___________';

    if (analysis.dateOccurrence && analysis.dateOccurrence !== 'Date/Time noted in GD') {
      occDate = analysis.dateOccurrence;
    }

    for (const d of dayNames) {
      if (new RegExp(`\\b${d}\\b`, 'i').test(trimmed)) {
        occDay = d;
        break;
      }
    }

    if (trimmed.toLowerCase().includes('yesterday')) {
      const yDate = new Date(today);
      yDate.setDate(today.getDate() - 1);
      occDay = dayNames[yDate.getDay()];
      occDate = `${pad(yDate.getDate())}/${pad(yDate.getMonth() + 1)}/${yDate.getFullYear()}`;
    }

    const timeMatch = trimmed.match(/\b(\d{1,2}(?::\d{2})?\s*(?:AM|PM|hrs|hours)?)\b/i);
    if (timeMatch && !timeMatch[1].includes('/') && !timeMatch[1].includes('-')) {
      occTime = timeMatch[1];
    }

    // Extract Complainant Name if stated
    let complainantName = '_______________________________';
    const nameMatch = trimmed.match(/(?:my name is|i am|informant is|complainant is)\s+([A-Za-z\s.]{2,30})/i);
    if (nameMatch && nameMatch[1]) {
      complainantName = nameMatch[1].trim();
    } else if (analysis.complainant && analysis.complainant !== 'Informant / Victim') {
      complainantName = analysis.complainant;
    }

    // Extract Contact Number if stated
    const phoneMatch = trimmed.match(/\b(?:[6-9]\d{9})\b/);
    const contactNumber = phoneMatch ? phoneMatch[0] : '_______________';

    // Place of Occurrence
    const placeOfOccurrence = analysis.policeStation !== 'Local Police Station' ? analysis.policeStation : '_______________________________';
    
    // Accused details
    const accusedDetails = analysis.accused !== 'Named / Unknown Suspects' ? analysis.accused : 'To be identified during investigation';
    
    // Acts and Sections
    const actsAndSections = analysis.sectionDetails.length > 0
      ? analysis.sectionDetails.map(s => `BNS Section ${s.bnsSection} (IPC ${s.ipcSection}): ${s.bnsTitle}`).join(', ')
      : 'To be determined by the investigating officer';
      
    // Nature of offense
    const natureOfOffense = analysis.caseNature || 'To be determined after investigation';

    setExtractedInfo({
      complainantName: complainantName !== '_______________________________' ? complainantName : 'Not detected',
      contactNumber: contactNumber !== '_______________' ? contactNumber : 'Not detected',
      dateOccurrence: occDate !== '___/___/______' ? occDate : 'Not detected',
      timeOccurrence: occTime !== '__:__' ? occTime : 'Not detected',
      day: occDay !== '___________' ? occDay : 'Not detected',
      placeOccurrence: placeOfOccurrence !== '_______________________________' ? placeOfOccurrence : 'Not detected',
      accusedDetails: accusedDetails !== 'To be identified during investigation' ? accusedDetails : 'Not detected',
      natureOfOffense: natureOfOffense,
      infoType: 'Telephonic'
    });

    const bnsSuggestions = analysis.sectionDetails.length > 0
      ? analysis.sectionDetails.map(s => `• BNS Section ${s.bnsSection} (IPC ${s.ipcSection}): ${s.bnsTitle}\n  Classification: ${s.cognizable ? 'Cognizable' : 'Non-Cognizable'} | ${s.bailable ? 'Bailable' : 'Non-Bailable'}\n  Punishment: ${s.punishment}\n  Court: ${s.court}`).join('\n\n')
      : 'No direct BNS statutory text matches found. Refer to detected sections above.';

    const separator = '═══════════════════════════════════════════════════════════════';

    const doc = `FIRST INFORMATION REPORT
(First Information Report — Section 173, BNSS 2023)

${separator}

1.  District:                     _______________
2.  Police Station:                ${analysis.policeStation !== 'Local Police Station' ? analysis.policeStation : '_______________'}
3.  FIR Number:                    
4.  General Diary Reference:       

${separator}

  OCCURRENCE AND INFORMATION RECEIVED

5.  Date of occurrence:            ${occDate}
6.  Time of occurrence:            ${occTime}
7.  Day of occurrence:             ${occDay}
8.  Place of occurrence:           ${placeOfOccurrence}

9.  Date information received:     ${dateInfoReceived}
10. Time information received:     ${timeInfoReceived}
11. Type of information:           Telephonic
12. Reasons for delay in reporting: No delay in reporting

${separator}

  COMPLAINANT DETAILS

13. Name of complainant:           ${complainantName}
14. Address:                       _______________________________
15. Contact number:                ${contactNumber}

${separator}

  ACCUSED DETAILS

16. Accused details:               ${accusedDetails}

${separator}

  OFFENSE PARTICULARS

17. Acts and Sections:             ${actsAndSections}
18. Nature of offense:             ${natureOfOffense}

${separator}

  RECORDED STATEMENT

  As stated in recorded information:

  "${trimmed}"

${separator}

  This is an editable draft based on the recorded statement.
  To be determined by the investigating officer.

  Generated on: ${nowStr}

${separator}

  BNS 2023 STATUTORY TEXT SUGGESTIONS
  (Complaint text matched against The Bharatiya Nyaya Sanhita, 2023)

  ${bnsSuggestions}

${separator}`;

    setGeneratedFirDoc(doc);
  };

  // Start / Stop Voice Recording
  const toggleRecording = () => {
    if (isRecording) {
      cleanupSpeech();
      setIsRecording(false);
    } else {
      setIsRecording(true);
      setRecordingSeconds(0);
      setGeneratedFirDoc('');
      setInterimTranscript('');

      timerRef.current = window.setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);

      if (recognizerRef.current) {
        recognizerRef.current.setLanguage(speechLanguage);
        recognizerRef.current.start(complaintText);
      }
    }
  };

  const handleApplyTemplate = (tmpl: VisualIncidentTemplate) => {
    setComplaintText(tmpl.sampleComplaint);
    setGeneratedFirDoc(''); // Keep box empty until user clicks Generate FIR
    speakText(`Selected ${tmpl.title}. You can now review or add more details with your voice, then click Generate FIR Document.`);
  };

  const handleSpeakText = (textToRead: string) => {
    if (!textToRead) return;
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
    } else {
      setIsSpeaking(true);
      speakText(textToRead);
      setTimeout(() => setIsSpeaking(false), 9000);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const res = await extractTextFromFile(e.target.files[0]);
      setComplaintText(res.text);
      setGeneratedFirDoc(''); // Keep box empty until user clicks generate
    }
  };

  const handleCopy = () => {
    if (!generatedFirDoc) return;
    navigator.clipboard.writeText(generatedFirDoc);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    if (!generatedFirDoc) return;
    const blob = new Blob([generatedFirDoc], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LegaSol_FIR_Document_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSaveRecord = () => {
    if (!generatedFirDoc) return;
    const today = new Date();
    const newCase: SavedCase = {
      id: `fir-${Date.now()}`,
      firNumber: `FIR No. ${Math.floor(100 + Math.random() * 899)}/2026`,
      policeStation: extractedInfo.placeOccurrence !== '_______________________________' && extractedInfo.placeOccurrence !== 'Not detected' ? extractedInfo.placeOccurrence : 'Jurisdictional Police Station',
      district: 'State Jurisdiction',
      complainant: extractedInfo.complainantName !== '_______________________________' && extractedInfo.complainantName !== 'Not detected' ? extractedInfo.complainantName : 'Informant / Victim',
      accused: extractedInfo.accusedDetails !== 'To be identified during investigation' && extractedInfo.accusedDetails !== 'Not detected' ? extractedInfo.accusedDetails : 'To be investigated',
      dateOccurrence: extractedInfo.dateOccurrence !== '___/___/______' && extractedInfo.dateOccurrence !== 'Not detected' ? extractedInfo.dateOccurrence : today.toLocaleDateString(),
      dateCreated: today.toLocaleDateString(),
      category: extractedInfo.natureOfOffense,
      sections: analysisResult?.sectionDetails.map(s => `BNS ${s.bnsSection}`) || ['BNS 318(4)'],
      firContent: generatedFirDoc,
      bailScore: analysisResult?.bailScore || 50
    };

    saveCase(newCase);
    setSavedCases(getSavedCases());
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const handleDiscard = () => {
    setComplaintText('');
    setGeneratedFirDoc('');
    setExtractedInfo({
      complainantName: '_______________',
      contactNumber: '_______________',
      dateOccurrence: '___/___/______',
      timeOccurrence: '__:__',
      day: '___________',
      placeOccurrence: '_______________________________',
      accusedDetails: 'To be identified during investigation',
      natureOfOffense: 'To be determined after investigation',
      infoType: 'Telephonic'
    });
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const wordCount = complaintText.trim() ? complaintText.trim().split(/\s+/).length : 0;

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-20">
      {/* 1. Header Pill & Titles */}
      <div className="text-center pt-2">
        <a 
          href="https://legasol.in" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-4 py-1 rounded-full border border-slate-300 bg-white text-xs text-slate-700 font-medium tracking-wide shadow-sm hover:border-slate-400 transition-colors"
        >
          <FileText className="w-3.5 h-3.5 text-[#b08958]" />
          <span><strong className="text-red-600 font-extrabold">LEGA</strong><strong className="text-red-600 font-extrabold">SOL</strong>.IN • FIR & ANALYSIS MODULE</span>
        </a>

        <h1 className="font-headline font-bold text-3xl sm:text-4xl text-[#1e293b] mt-4 tracking-tight">
          <span className="text-red-600 font-extrabold">Lega</span><span className="text-red-600 font-extrabold">Sol</span> FIR Recording & Complaint Comparison
        </h1>

        <p className="text-sm text-slate-600 max-w-2xl mx-auto mt-2 leading-relaxed">
          Create Indian FIR drafts and compare complaint texts to identify applicable BNS sections, assess risk, and generate decision support recommendations.
        </p>

        {/* Segmented Mode Buttons */}
        <div className="inline-flex items-center p-1 rounded-xl bg-white border border-slate-200 shadow-sm mt-6">
          <button
            className="flex items-center gap-2 px-6 py-2 rounded-lg text-xs font-semibold bg-[#c49a6c] text-white shadow-sm cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>FIR Recording</span>
          </button>

          <button
            onClick={onNavigateToCompare}
            className="flex items-center gap-2 px-6 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span>Compare Complaints</span>
          </button>
        </div>
      </div>

      {/* Visual Quick Select Bar for Easy Access */}
      <div className="bg-gradient-to-r from-blue-50/80 via-white to-sky-50/80 border border-blue-200/80 rounded-2xl p-5 shadow-sm space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-blue-600 text-white shadow-xs">
              <ShieldAlert className="w-4 h-4" />
            </span>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                Easy Tap-to-Report / तस्वीर छूकर शिकायत दर्ज करें
              </h3>
              <p className="text-[11px] text-slate-500">
                Click any picture matching what happened, or speak into the microphone below
              </p>
            </div>
          </div>

          <button
            onClick={() => handleSpeakText("Choose an incident picture below or click the red microphone to speak your problem aloud in simple words.")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white border border-blue-200 text-blue-700 hover:bg-blue-50 text-xs font-semibold shadow-2xs transition-all cursor-pointer"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>Listen (सुनें)</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {VISUAL_TEMPLATES.map((tmpl) => (
            <div
              key={tmpl.id}
              onClick={() => handleApplyTemplate(tmpl)}
              className="group cursor-pointer rounded-xl overflow-hidden border border-slate-200 bg-white hover:border-blue-500 hover:shadow-md transition-all flex flex-col"
            >
              <div className="h-28 w-full overflow-hidden relative bg-slate-100">
                <img
                  src={tmpl.image}
                  alt={tmpl.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
                <span className="absolute bottom-1.5 left-2 right-2 text-white font-bold text-xs leading-tight drop-shadow-sm">
                  {tmpl.title}
                </span>
              </div>
              <div className="p-2.5 flex-1 flex flex-col justify-between bg-white">
                <div className="text-[11px] font-medium text-blue-800 line-clamp-1">
                  {tmpl.hindiTitle}
                </div>
                <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                  Tap to load template
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Step 1: Record or Type the Complaint */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-7 shadow-sm space-y-4">
        {/* Step Header */}
        <div className="flex items-start gap-3">
          <span className="w-6 h-6 rounded-full bg-[#fef3c7] text-[#92400e] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
            1
          </span>
          <div>
            <h2 className="font-headline text-lg font-bold text-[#1e293b]">
              Record or Type the Complaint
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Speak the complaint aloud or type it below — the system will automatically structure it into an Indian FIR format
            </p>
          </div>
        </div>

        {/* Hands-Free Web Speech API Voice Dictation Console */}
        <VoiceDictationConsole
          isRecording={isRecording}
          recordingSeconds={recordingSeconds}
          soundLevel={soundLevel}
          speechStatus={speechStatus}
          interimTranscript={interimTranscript}
          language={speechLanguage}
          onLanguageChange={handleLanguageChange}
          onToggleRecording={toggleRecording}
          onClearTranscript={handleClearTranscript}
          isBrowserSupported={isBrowserSupported}
        />

        {/* Complaint Textarea */}
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <label className="text-xs font-bold text-slate-500 uppercase tracking-wider block">
                COMPLAINT TEXT
              </label>
              {isRecording && (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-red-600 bg-red-50 border border-red-200 px-2 py-0.5 rounded-full">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping"></span>
                  <span>Voice Stream Active</span>
                </span>
              )}
            </div>

            <div className="flex items-center gap-3">
              {complaintText && (
                <button
                  type="button"
                  onClick={() => handleSpeakText(complaintText)}
                  className="flex items-center gap-1 text-[11px] text-blue-700 hover:text-blue-900 font-semibold cursor-pointer"
                >
                  {isSpeaking ? <VolumeX className="w-3.5 h-3.5 text-red-500" /> : <Volume2 className="w-3.5 h-3.5 text-blue-600" />}
                  <span>{isSpeaking ? "Stop" : "Listen (बोलकर सुनें)"}</span>
                </button>
              )}
              <span className="text-[11px] text-slate-400 font-mono">
                {wordCount} words
              </span>
            </div>
          </div>

          <div className="relative">
            <textarea
              value={complaintText}
              onChange={(e) => {
                setComplaintText(e.target.value);
                setGeneratedFirDoc(''); // Clear generated doc if complaint is edited
              }}
              rows={6}
              placeholder="Speak hands-free with the voice dictation console above, or type the complaint here..."
              className={`w-full bg-white border rounded-xl p-3.5 text-xs text-slate-800 focus:outline-none leading-relaxed resize-y font-normal transition-all ${
                isRecording 
                  ? 'border-red-400 ring-2 ring-red-400/20 bg-red-50/10' 
                  : 'border-slate-300 focus:border-slate-500'
              }`}
            />
          </div>
        </div>

        {/* Upload File Row */}
        <div className="flex flex-wrap items-center gap-3 pt-1">
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.pdf,.png,.jpg,.jpeg,.doc,.docx"
            className="hidden"
            onChange={handleFileUpload}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 bg-[#1e293b] hover:bg-slate-800 text-white text-xs font-medium px-3.5 py-2 rounded-lg shadow-sm transition-all cursor-pointer"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload File</span>
          </button>
          <span className="text-xs text-slate-500">
            PDF, TXT, JPG, PNG, TIFF · drag & drop supported
          </span>
        </div>

        {/* Action Buttons Row */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={() => generateDocument(complaintText)}
            className="flex items-center gap-2 bg-[#c49a6c] hover:bg-[#b3895b] text-white text-xs font-bold px-4 py-2.5 rounded-lg shadow-sm transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate FIR Document</span>
          </button>

          <button
            onClick={() => {
              setComplaintText('');
              setGeneratedFirDoc('');
              cleanupSpeech();
            }}
            className="flex items-center gap-1.5 bg-[#1e293b] hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm transition-all cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>
        </div>
      </div>

      {/* 3. Step 2: Generated FIR Document */}
      <div className="bg-[#fffdfa] border border-slate-200 rounded-2xl p-6 sm:p-7 shadow-sm space-y-4">
        {/* Step Header */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full bg-[#fef3c7] text-[#92400e] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              2
            </span>
            <div>
              <h2 className="font-headline text-lg font-bold text-[#1e293b]">
                Generated FIR Document
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Review the auto-generated FIR below. Fields are pre-filled from the complaint — edit the complaint and regenerate to update.
              </p>
            </div>
          </div>

          <span className="bg-[#fef9f2] text-[#b08958] border border-[#f5e6d3] text-xs px-2.5 py-1 rounded-md font-semibold flex items-center gap-1 shrink-0">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Auto-formatted</span>
          </span>
        </div>

        {/* Indian FIR Format Header line */}
        <div className="flex items-center justify-between text-xs pt-1">
          <span className="font-bold text-slate-600 uppercase tracking-wider">INDIAN FIR FORMAT</span>
          
          <div className="flex items-center gap-3">
            {generatedFirDoc && (
              <button
                onClick={() => handleSpeakText(generatedFirDoc)}
                className="flex items-center gap-1 text-blue-700 hover:text-blue-900 font-medium cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Listen to FIR</span>
              </button>
            )}

            <button
              onClick={handleCopy}
              disabled={!generatedFirDoc}
              className={`flex items-center gap-1 font-medium transition-colors cursor-pointer ${
                generatedFirDoc ? 'text-slate-600 hover:text-slate-900' : 'text-slate-300 cursor-not-allowed'
              }`}
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied" : "Copy"}</span>
            </button>
          </div>
        </div>

        {/* Document Box strictly empty until user speaks, stops, and clicks Generate FIR */}
        <textarea
          value={generatedFirDoc}
          onChange={(e) => setGeneratedFirDoc(e.target.value)}
          placeholder=""
          rows={18}
          className="w-full bg-white border border-slate-300 rounded-xl p-5 font-mono text-xs text-slate-800 leading-relaxed shadow-inner resize-y focus:outline-none focus:border-slate-400 select-all min-h-[300px]"
        />

        {/* 4. EXTRACTED INFORMATION (9-Box Grid) */}
        <div className="pt-2">
          <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-3">
            EXTRACTED INFORMATION
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {/* Box 1: Complainant Name */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">COMPLAINANT NAME</span>
              <span className={`text-xs mt-1 block ${extractedInfo.complainantName === '_______________' || extractedInfo.complainantName === 'Not detected' ? 'italic text-slate-400' : 'font-semibold text-slate-900'}`}>
                {extractedInfo.complainantName}
              </span>
            </div>

            {/* Box 2: Contact Number */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">CONTACT NUMBER</span>
              <span className={`text-xs mt-1 block ${extractedInfo.contactNumber === '_______________' || extractedInfo.contactNumber === 'Not detected' ? 'italic text-slate-400' : 'font-semibold text-slate-900'}`}>
                {extractedInfo.contactNumber}
              </span>
            </div>

            {/* Box 3: Date of Occurrence */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">DATE OF OCCURRENCE</span>
              <span className={`text-xs mt-1 block ${extractedInfo.dateOccurrence === '___/___/______' || extractedInfo.dateOccurrence === 'Not detected' ? 'italic text-slate-400' : 'font-semibold text-slate-900'}`}>
                {extractedInfo.dateOccurrence}
              </span>
            </div>

            {/* Box 4: Time of Occurrence */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">TIME OF OCCURRENCE</span>
              <span className={`text-xs mt-1 block ${extractedInfo.timeOccurrence === '__:__' || extractedInfo.timeOccurrence === 'Not detected' ? 'italic text-slate-400' : 'font-semibold text-slate-900'}`}>
                {extractedInfo.timeOccurrence}
              </span>
            </div>

            {/* Box 5: Day */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">DAY</span>
              <span className={`text-xs mt-1 block ${extractedInfo.day === '___________' || extractedInfo.day === 'Not detected' ? 'italic text-slate-400' : 'font-semibold text-slate-900'}`}>
                {extractedInfo.day}
              </span>
            </div>

            {/* Box 6: Place of Occurrence */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">PLACE OF OCCURRENCE</span>
              <span className={`text-xs mt-1 block ${extractedInfo.placeOccurrence === '_______________________________' || extractedInfo.placeOccurrence === 'Not detected' ? 'italic text-slate-400' : 'font-semibold text-slate-900'}`}>
                {extractedInfo.placeOccurrence}
              </span>
            </div>

            {/* Box 7: Accused Details */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">ACCUSED DETAILS</span>
              <span className={`text-xs mt-1 block ${extractedInfo.accusedDetails === 'To be identified during investigation' || extractedInfo.accusedDetails === 'Not detected' ? 'italic text-slate-400' : 'font-semibold text-slate-900'}`}>
                {extractedInfo.accusedDetails}
              </span>
            </div>

            {/* Box 8: Nature of Offense */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">NATURE OF OFFENSE</span>
              <span className="text-xs mt-1 block font-semibold text-slate-900">
                {extractedInfo.natureOfOffense}
              </span>
            </div>

            {/* Box 9: Info Type */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-2xs">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">INFO TYPE</span>
              <span className="text-xs mt-1 block font-semibold text-slate-900">
                {extractedInfo.infoType}
              </span>
            </div>
          </div>
        </div>

        {/* 5. Four Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 pt-3">
          <button
            onClick={handleSaveRecord}
            disabled={!generatedFirDoc}
            className={`flex items-center gap-1.5 text-white text-xs font-bold px-4 py-2.5 rounded-lg shadow-sm transition-all ${
              generatedFirDoc ? 'bg-[#c49a6c] hover:bg-[#b3895b] cursor-pointer' : 'bg-slate-300 cursor-not-allowed opacity-60'
            }`}
          >
            {savedSuccess ? <Check className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
            <span>{savedSuccess ? "Saved to Records!" : "Save FIR Record"}</span>
          </button>

          <button
            onClick={() => generateDocument(complaintText)}
            disabled={!complaintText.trim()}
            className={`flex items-center gap-1.5 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm transition-all ${
              complaintText.trim() ? 'bg-[#1e293b] hover:bg-slate-800 cursor-pointer' : 'bg-slate-300 cursor-not-allowed opacity-60'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Regenerate</span>
          </button>

          <button
            onClick={handleDownload}
            disabled={!generatedFirDoc}
            className={`flex items-center gap-1.5 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm transition-all ${
              generatedFirDoc ? 'bg-[#1e293b] hover:bg-slate-800 cursor-pointer' : 'bg-slate-300 cursor-not-allowed opacity-60'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download</span>
          </button>

          <button
            onClick={handleDiscard}
            className="flex items-center gap-1.5 bg-[#fee2e2] hover:bg-[#fecaca] text-[#ef4444] text-xs font-semibold px-4 py-2.5 rounded-lg transition-all cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Discard & Start Over</span>
          </button>
        </div>
      </div>

      {/* 4. Secondary Output Box: Legal Procedure & Decision Flowchart */}
      <ProceduralStrategyBox
        analysis={analysisResult || (complaintText.trim() ? parseAndAnalyzeFIR(complaintText) : null)}
        complaintText={complaintText}
        generatedFirDoc={generatedFirDoc}
      />

      {/* 5. LegalFeasibilityBox: Success Pathways & Risk Factors */}
      <LegalFeasibilityBox
        analysis={analysisResult || (complaintText.trim() ? parseAndAnalyzeFIR(complaintText) : null)}
        complaintText={complaintText}
        generatedFirDoc={generatedFirDoc}
      />

      {/* 6. Saved FIR Records Section */}
      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#c49a6c]" />
            <h3 className="font-headline text-lg font-bold text-[#1e293b]">
              Saved FIR Records
            </h3>
          </div>
          {savedCases.length > 0 && (
            <span className="text-xs text-slate-500 font-medium">
              {savedCases.length} record{savedCases.length > 1 ? 's' : ''} stored locally
            </span>
          )}
        </div>

        {savedCases.length === 0 ? (
          /* Empty state matching Screenshot */
          <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center shadow-2xs">
            <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2.5 stroke-[1.5]" />
            <div className="text-xs text-slate-500 font-medium">
              No FIR records saved yet
            </div>
          </div>
        ) : (
          /* Populated saved cases */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {savedCases.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  setComplaintText(item.firContent);
                  generateDocument(item.firContent);
                }}
                className="bg-white border border-slate-200 hover:border-[#c49a6c] rounded-xl p-4 cursor-pointer transition-all shadow-2xs flex items-center justify-between gap-3 group"
              >
                <div>
                  <div className="font-bold text-xs text-[#1e293b] group-hover:text-[#c49a6c]">
                    {item.firNumber}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    {item.policeStation} • {item.dateOccurrence}
                  </div>
                  <div className="text-[10px] text-blue-700 font-medium mt-1">
                    {item.category}
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteSavedCase(item.id);
                      setSavedCases(getSavedCases());
                    }}
                    className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-slate-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
