import React from 'react';

interface LegasolCrestProps {
  className?: string;
  size?: number;
  watermark?: boolean;
}

export const LegasolCrest: React.FC<LegasolCrestProps> = ({ className = '', size = 56, watermark = false }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 500 500"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${watermark ? 'opacity-10 pointer-events-none select-none' : ''} ${className}`}
    >
      <defs>
        {/* Gradients matching legasol.in.png */}
        <radialGradient id="sapphireGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#38bdf8" />
          <stop offset="40%" stopColor="#1d4ed8" />
          <stop offset="100%" stopColor="#0f265c" />
        </radialGradient>

        <linearGradient id="goldFiligree" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fef08a" />
          <stop offset="35%" stopColor="#eab308" />
          <stop offset="70%" stopColor="#ca8a04" />
          <stop offset="100%" stopColor="#854d0e" />
        </linearGradient>

        <linearGradient id="silverBezel" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="40%" stopColor="#cbd5e1" />
          <stop offset="70%" stopColor="#94a3b8" />
          <stop offset="100%" stopColor="#475569" />
        </linearGradient>

        <linearGradient id="deepRoyalBlue" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#1e3a8a" />
          <stop offset="50%" stopColor="#172554" />
          <stop offset="100%" stopColor="#0f172a" />
        </linearGradient>
      </defs>

      {/* Outer Circular Frame */}
      <circle cx="250" cy="235" r="210" stroke="url(#goldFiligree)" strokeWidth="6" fill="url(#deepRoyalBlue)" />
      <circle cx="250" cy="235" r="200" stroke="url(#silverBezel)" strokeWidth="3" fill="none" opacity="0.8" />
      <circle cx="250" cy="235" r="192" stroke="url(#goldFiligree)" strokeWidth="1.5" strokeDasharray="6 4" fill="none" />

      {/* Triangular Shield / Pediment */}
      <polygon
        points="250,55 425,360 75,360"
        fill="url(#deepRoyalBlue)"
        stroke="url(#silverBezel)"
        strokeWidth="12"
        strokeLinejoin="round"
      />
      <polygon
        points="250,75 405,348 95,348"
        fill="none"
        stroke="url(#goldFiligree)"
        strokeWidth="4"
        strokeLinejoin="round"
      />

      {/* Classical Pillar (Doric / Ionic Column) */}
      <rect x="225" y="225" width="50" height="95" rx="3" fill="url(#silverBezel)" stroke="url(#goldFiligree)" strokeWidth="2" />
      {/* Column grooves */}
      <line x1="235" y1="230" x2="235" y2="315" stroke="#1e293b" strokeWidth="2" />
      <line x1="245" y1="230" x2="245" y2="315" stroke="#1e293b" strokeWidth="2" />
      <line x1="255" y1="230" x2="255" y2="315" stroke="#1e293b" strokeWidth="2" />
      <line x1="265" y1="230" x2="265" y2="315" stroke="#1e293b" strokeWidth="2" />

      {/* Column Capital */}
      <path d="M215 225 C215 210, 285 210, 285 225 Z" fill="url(#silverBezel)" stroke="url(#goldFiligree)" strokeWidth="3" />
      <circle cx="225" cy="220" r="7" fill="url(#goldFiligree)" />
      <circle cx="275" cy="220" r="7" fill="url(#goldFiligree)" />

      {/* Column Base */}
      <rect x="215" y="320" width="70" height="15" rx="2" fill="url(#silverBezel)" stroke="url(#goldFiligree)" strokeWidth="2" />

      {/* Scales of Justice Beam */}
      <line x1="175" y1="170" x2="325" y2="170" stroke="url(#goldFiligree)" strokeWidth="6" strokeLinecap="round" />
      <circle cx="250" cy="170" r="6" fill="url(#silverBezel)" stroke="url(#goldFiligree)" strokeWidth="2" />

      {/* Left Pan & Chains */}
      <line x1="175" y1="170" x2="160" y2="215" stroke="url(#silverBezel)" strokeWidth="1.5" />
      <line x1="175" y1="170" x2="190" y2="215" stroke="url(#silverBezel)" strokeWidth="1.5" />
      <path d="M150 215 C150 230, 200 230, 200 215 Z" fill="url(#silverBezel)" stroke="url(#goldFiligree)" strokeWidth="2" />

      {/* Right Pan & Chains */}
      <line x1="325" y1="170" x2="310" y2="215" stroke="url(#silverBezel)" strokeWidth="1.5" />
      <line x1="325" y1="170" x2="340" y2="215" stroke="url(#silverBezel)" strokeWidth="1.5" />
      <path d="M300 215 C300 230, 350 230, 350 215 Z" fill="url(#silverBezel)" stroke="url(#goldFiligree)" strokeWidth="2" />

      {/* Central Top Sapphire Diamond Gem */}
      <polygon points="250,110 275,135 250,165 225,135" fill="url(#sapphireGlow)" stroke="url(#silverBezel)" strokeWidth="3" />
      <polygon points="250,110 275,135 250,140" fill="#7dd3fc" opacity="0.6" />

      {/* Laurel Wreath */}
      <path
        d="M165 315 C150 270, 165 240, 195 235"
        stroke="url(#silverBezel)"
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
      />
      <path
        d="M335 315 C350 270, 335 240, 305 235"
        stroke="url(#silverBezel)"
        strokeWidth="4"
        fill="none"
        strokeLinecap="round"
      />

      {/* Bottom Center Blue Jewel */}
      <circle cx="250" cy="335" r="16" fill="url(#sapphireGlow)" stroke="url(#goldFiligree)" strokeWidth="3" />
      <circle cx="245" cy="330" r="4" fill="#ffffff" opacity="0.8" />

      {/* Lower Ribbon Banner */}
      <path
        d="M80 395 C140 375, 360 375, 420 395 L405 440 C350 425, 150 425, 95 440 Z"
        fill="url(#deepRoyalBlue)"
        stroke="url(#goldFiligree)"
        strokeWidth="5"
      />

      {/* Banner Text with LEGA and SOL highlighted in red */}
      <text
        x="250"
        y="418"
        textAnchor="middle"
        fontFamily="Cinzel, serif"
        fontSize="28"
        fontWeight="bold"
        letterSpacing="4"
      >
        <tspan fill="#ef4444">LEGA</tspan><tspan fill="#ef4444">SOL</tspan><tspan fill="#ffffff">.IN</tspan>
      </text>

      <text
        x="250"
        y="450"
        textAnchor="middle"
        fontFamily="Cinzel, serif"
        fontSize="13"
        fontWeight="600"
        letterSpacing="2"
      >
        <tspan fill="#ef4444">LEGA</tspan><tspan fill="url(#goldFiligree)">L </tspan><tspan fill="#ef4444">SOL</tspan><tspan fill="url(#goldFiligree)">UTIONS AND VERDICT</tspan>
      </text>
    </svg>
  );
};
