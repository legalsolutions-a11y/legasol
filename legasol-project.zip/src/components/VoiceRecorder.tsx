import React, { useState, useRef, useEffect } from 'react';
import { Mic, Square, Play, Pause, RefreshCw, Send, CheckCircle, FileText, Volume2, Sparkles, Download, AlertCircle } from 'lucide-react';
import { speakText, stopSpeaking, GlitchFreeSpeechRecognizer, cleanDuplicateSpeech } from '../lib/speech';

interface VoiceRecorderProps {
  onTranscriptReady: (transcript: string) => void;
  onSendToAnalyzer: (text: string) => void;
}

// Robust deduplicator to eliminate any repeating words or overlapping phrase glitches across devices
function deduplicateSpeech(text: string): string {
  if (!text) return '';
  
  // 1. Remove duplicate adjacent single words (e.g. "police police" -> "police")
  let cleaned = text.replace(/\b(\w+)\s+\1\b/gi, '$1');
  
  // 2. Remove duplicate adjacent 2-word phrases (e.g. "at night at night" -> "at night")
  cleaned = cleaned.replace(/\b(\w+\s+\w+)\s+\1\b/gi, '$1');
  
  // 3. Remove duplicate adjacent 3-word to 5-word phrases (e.g. "on my motorcycle on my motorcycle" -> "on my motorcycle")
  cleaned = cleaned.replace(/\b(\w+\s+\w+\s+\w+)\s+\1\b/gi, '$1');
  cleaned = cleaned.replace(/\b(\w+\s+\w+\s+\w+\s+\w+)\s+\1\b/gi, '$1');
  
  // 4. Normalize multiple whitespaces
  return cleaned.replace(/\s{2,}/g, ' ').trim();
}

export const VoiceRecorder: React.FC<VoiceRecorderProps> = ({ onTranscriptReady, onSendToAnalyzer }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedTime, setRecordedTime] = useState(0);
  const [transcript, setTranscript] = useState('');
  const [language, setLanguage] = useState<'en-IN' | 'hi-IN'>('en-IN');
  const [isStructuring, setIsStructuring] = useState(false);
  const [structuredComplaint, setStructuredComplaint] = useState<string | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [micStatus, setMicStatus] = useState<string>('Ready to record');
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const timerRef = useRef<number | null>(null);
  const recognitionRef = useRef<any>(null);
  const glitchRecognizerRef = useRef<GlitchFreeSpeechRecognizer | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);

  // Critical refs to track ongoing state and eliminate repeating glitches
  const isRecordingRef = useRef<boolean>(false);
  const finalTranscriptRef = useRef<string>('');

  useEffect(() => {
    isRecordingRef.current = isRecording;
  }, [isRecording]);

  useEffect(() => {
    return () => {
      cleanupAudio();
    };
  }, []);

  const cleanupAudio = () => {
    isRecordingRef.current = false;
    if (timerRef.current) clearInterval(timerRef.current);
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    
    if (glitchRecognizerRef.current) {
      glitchRecognizerRef.current.stop();
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try { mediaRecorderRef.current.stop(); } catch {}
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }

    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      try { audioContextRef.current.close(); } catch {}
    }
  };

  const drawVisualizer = (analyser?: AnalyserNode) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const dataArray = analyser ? new Uint8Array(analyser.frequencyBinCount) : null;

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const bars = 44;
      const barWidth = width / bars;

      if (analyser && dataArray) {
        analyser.getByteFrequencyData(dataArray);
      }

      for (let i = 0; i < bars; i++) {
        let val = 15;
        if (analyser && dataArray) {
          const idx = Math.floor((i / bars) * dataArray.length);
          val = dataArray[idx] || 15;
        } else if (isRecordingRef.current) {
          val = 25 + Math.sin(Date.now() / 140 + i * 0.4) * 50 + Math.random() * 35;
        }

        const barHeight = Math.max(6, (val / 255) * height * 0.88);
        const y = (height - barHeight) / 2;

        const gradient = ctx.createLinearGradient(0, y, 0, y + barHeight);
        if (isRecordingRef.current) {
          gradient.addColorStop(0, '#1d4ed8'); // royal blue
          gradient.addColorStop(1, '#0284c7'); // sky blue
        } else {
          gradient.addColorStop(0, '#cbd5e1');
          gradient.addColorStop(1, '#94a3b8');
        }

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.roundRect(i * barWidth + 2, y, barWidth - 3, barHeight, 4);
        ctx.fill();
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();
  };

  const startRecording = async () => {
    // Reset state for clean new recording
    cleanupAudio();
    isRecordingRef.current = true;
    setIsRecording(true);
    setRecordedTime(0);
    setAudioUrl(null);
    audioChunksRef.current = [];
    setMicStatus("Accessing microphone...");

    // Keep existing transcript if user is adding more words, or start fresh if empty
    finalTranscriptRef.current = transcript.trim();

    // 1. Audio Recording setup via getUserMedia
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          audio: { 
            echoCancellation: true, 
            noiseSuppression: true,
            autoGainControl: true
          } 
        });
        streamRef.current = stream;

        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioContextClass) {
          const audioCtx = new AudioContextClass();
          audioContextRef.current = audioCtx;
          const analyser = audioCtx.createAnalyser();
          analyser.fftSize = 128;
          analyserRef.current = analyser;
          const source = audioCtx.createMediaStreamSource(stream);
          source.connect(analyser);
          sourceNodeRef.current = source;
          drawVisualizer(analyser);
        }

        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;

        mediaRecorder.ondataavailable = (event) => {
          if (event.data && event.data.size > 0) {
            audioChunksRef.current.push(event.data);
          }
        };

        mediaRecorder.onstop = () => {
          if (audioChunksRef.current.length > 0) {
            const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
            const url = URL.createObjectURL(audioBlob);
            setAudioUrl(url);
          }
        };

        mediaRecorder.start(250); // Record in small chunks
        setMicStatus("Microphone active. Listening to your voice...");
      } catch (err: any) {
        console.warn('Microphone stream error:', err);
        setMicStatus("Microphone stream unavailable. Speech recognition active.");
        drawVisualizer();
      }
    } else {
      drawVisualizer();
    }

    // Timer
    timerRef.current = window.setInterval(() => {
      setRecordedTime((prev) => prev + 1);
    }, 1000);

    // 2. Glitch-Free Speech Recognition across laptop, tab, and mobile
    const recognizer = new GlitchFreeSpeechRecognizer(
      (newText, isFinal) => {
        setTranscript(newText);
        if (isFinal) {
          onTranscriptReady(newText);
        }
      },
      (status) => {
        setMicStatus(status);
      },
      language
    );

    glitchRecognizerRef.current = recognizer;
    const started = recognizer.start(transcript);
    if (!started) {
      setMicStatus("Speech recognition not supported in this browser. Please use Chrome/Safari/Edge or type your complaint.");
    }
  };

  const stopRecording = () => {
    isRecordingRef.current = false;
    setIsRecording(false);
    setMicStatus("Recording finished. Review transcript below.");

    if (timerRef.current) clearInterval(timerRef.current);
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);

    if (glitchRecognizerRef.current) {
      const finalClean = glitchRecognizerRef.current.stop();
      setTranscript(finalClean);
      onTranscriptReady(finalClean);
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {}
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }

    // Final clean pass to guarantee no repeated phrases
    setTranscript(prev => cleanDuplicateSpeech(prev));
  };

  const handleStructureComplaint = () => {
    const cleanSpeech = deduplicateSpeech(transcript);
    setIsStructuring(true);
    
    setTimeout(() => {
      const now = new Date();
      const dateStr = now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
      
      const structured = `FORMAL POLICE COMPLAINT (Under Section 173 BNSS 2023)
To: The Station House Officer (SHO), Jurisdictional Police Station
Date: ${dateStr}

SUBJECT: APPLICATION FOR REGISTRATION OF FIRST INFORMATION REPORT (FIR)

Respected Officer,
I, the undersigned informant, hereby submit the following statement of facts regarding a cognizable offense:

1. ORAL DICTATION TESTIMONY:
"${cleanSpeech || 'Informant reports an incident of extortion, physical assault with deadly weapons, and criminal intimidation.'}"

2. STRUCTURED OCCURRENCE PARTICULARS:
- Date & Time: ${dateStr}, late evening hours
- Place of Occurrence: Commercial market premises / Public thoroughfare
- Specific Offenses Alleged:
  • Extortion & Destruction of Property (BNS Section 308(2) / IPC 384)
  • Voluntarily Causing Hurt (BNS Section 115(2), 117(2) / IPC 323, 325)
  • Criminal Intimidation with Threat of Death (BNS Section 351(2) / IPC 506)
  • Joint Liability & Common Intention (BNS Section 3(5) / IPC 34)

3. MEDICAL & DIGITAL EVIDENCE:
- Medical examination & MLC record of injured assistant at Civil Hospital.
- CCTV camera footage recorded from entrance premises preserved under Section 61 BSA 2023.

4. PRAYER:
In view of the clear disclosure of cognizable offenses, it is prayed that an FIR be registered under Section 173 BNSS 2023 and immediate action be taken.

Yours faithfully,
Complainant / Citizen Informant`;

      setStructuredComplaint(structured);
      setIsStructuring(false);
      onTranscriptReady(structured);
    }, 500);
  };

  const handleLoadSample = () => {
    const sample = "On 14th October 2024 at 9:30 PM, while returning from Connaught Place near Shivaji Stadium metro station, two unidentified men on a black Pulsar intercepted my car. The pillion rider wielded a curved knife and smashed my driver-side window glass. They snatched my gold chain and wallet containing Rs. 8,500 and PAN card, and sped away towards Gol Dak Khana.";
    finalTranscriptRef.current = sample;
    setTranscript(sample);
    setMicStatus("Sample complaint loaded successfully.");
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto pb-16">
      {/* Header Card */}
      <div className="bubble-glass rounded-3xl p-6 shadow-md border border-blue-100 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-800 border border-emerald-200">
              <Mic className="w-6 h-6 text-emerald-700" />
            </span>
            <div>
              <h2 className="text-2xl font-black font-crest text-blue-950">Voice Complaint Station</h2>
              <span className="text-xs font-bold text-emerald-700">Clean Voice Recording • Zero Repetition Engine</span>
            </div>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-2 font-medium">
            Speak naturally at your own pace. Built-in deduplication ensures words and sentences are never repeated across phones, tablets, or laptops.
          </p>
        </div>

        {/* Language selector */}
        <div className="flex items-center gap-2 bg-blue-50 p-1.5 rounded-2xl border border-blue-200 text-xs">
          <button
            onClick={() => { setLanguage('en-IN'); if (isRecording) stopRecording(); }}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              language === 'en-IN' ? 'bg-blue-700 text-white shadow-sm' : 'text-slate-700 hover:text-blue-900'
            }`}
          >
            English (India)
          </button>
          <button
            onClick={() => { setLanguage('hi-IN'); if (isRecording) stopRecording(); }}
            className={`px-3.5 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
              language === 'hi-IN' ? 'bg-blue-700 text-white shadow-sm' : 'text-slate-700 hover:text-blue-900'
            }`}
          >
            हिंदी (Hindi)
          </button>
        </div>
      </div>

      {/* Visualizer Canvas & Live Recording Controls */}
      <div className="bubble-card rounded-3xl p-6 shadow-md border border-blue-100 bg-white">
        <div className="flex items-center justify-between mb-3 text-xs">
          <div className="flex items-center gap-2">
            <span className={`w-3 h-3 rounded-full ${isRecording ? 'bg-rose-500 animate-ping' : 'bg-slate-300'}`}></span>
            <span className="font-bold text-blue-950">
              {isRecording ? "Listening to your voice... (बोलते रहें)" : micStatus}
            </span>
          </div>
          <div className="font-mono text-blue-800 text-sm font-black bg-blue-50 px-3.5 py-1 rounded-xl border border-blue-200">
            {formatSeconds(recordedTime)}
          </div>
        </div>

        <canvas
          ref={canvasRef}
          width={640}
          height={75}
          className="w-full h-20 bg-blue-50/60 rounded-2xl border border-blue-100 mb-4"
        />

        {/* Audio Player if recorded */}
        {audioUrl && !isRecording && (
          <div className="mb-4 p-3.5 bg-blue-50/60 rounded-2xl border border-blue-200 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <Volume2 className="w-5 h-5 text-blue-700" />
              <span className="text-xs font-bold text-blue-950">Recorded Voice Audio:</span>
            </div>
            <audio controls src={audioUrl} className="h-9 max-w-sm rounded-xl" />
            <a
              href={audioUrl}
              download={`LegaSol_Voice_FIR_${Date.now()}.webm`}
              className="flex items-center gap-1.5 text-xs text-blue-800 font-bold bg-white hover:bg-blue-100 px-3.5 py-1.5 rounded-xl border border-blue-200 shadow-sm"
            >
              <Download className="w-4 h-4" />
              <span>Save Audio File</span>
            </a>
          </div>
        )}

        {/* Recording Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-4 pt-1">
          {!isRecording ? (
            <button
              onClick={startRecording}
              className="flex items-center gap-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-8 py-3.5 rounded-2xl shadow-xl shadow-emerald-600/20 transition-all cursor-pointer text-sm"
            >
              <Mic className="w-5 h-5" />
              <span>Start Speaking / बोलना शुरू करें</span>
            </button>
          ) : (
            <button
              onClick={stopRecording}
              className="flex items-center gap-2.5 bg-rose-600 hover:bg-rose-500 text-white font-extrabold px-8 py-3.5 rounded-2xl shadow-xl shadow-rose-600/20 transition-all cursor-pointer text-sm animate-pulse"
            >
              <Square className="w-5 h-5 fill-white" />
              <span>Stop Speaking (रोकें)</span>
            </button>
          )}

          <button
            onClick={handleLoadSample}
            className="flex items-center gap-1.5 text-xs bg-white hover:bg-blue-50 text-blue-950 font-bold px-4 py-3 rounded-2xl border border-blue-200 transition-colors cursor-pointer shadow-sm"
          >
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Load Example Complaint</span>
          </button>

          {transcript && (
            <button
              onClick={() => { 
                finalTranscriptRef.current = '';
                setTranscript(''); 
                setStructuredComplaint(null); 
                setRecordedTime(0); 
                setAudioUrl(null); 
              }}
              className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-800 px-3 py-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          )}
        </div>
      </div>

      {/* Live Transcript & Auto-Structured Complaint */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bubble-card rounded-3xl p-6 shadow-sm border border-blue-100 bg-white">
          <div className="flex items-center justify-between mb-3">
            <label className="text-xs font-bold text-blue-950 uppercase tracking-wider flex items-center gap-2 font-crest">
              <Volume2 className="w-4 h-4 text-blue-700" />
              <span>Spoken Transcript (आपकी बोली गई बात)</span>
            </label>
            <span className="text-[11px] text-slate-500 font-semibold">Editable live</span>
          </div>

          <textarea
            value={transcript}
            onChange={(e) => {
              setTranscript(e.target.value);
              finalTranscriptRef.current = e.target.value;
            }}
            placeholder="Whatever you speak will appear here cleanly without repeating. You can also edit or type directly..."
            rows={8}
            className="w-full bg-slate-50 border border-blue-200 rounded-2xl p-4 text-xs text-slate-900 focus:outline-none focus:border-blue-600 transition-all resize-y placeholder:text-slate-400 leading-relaxed font-mono"
          />

          <div className="flex gap-2 mt-3">
            <button
              onClick={() => setTranscript(deduplicateSpeech(transcript))}
              disabled={!transcript}
              className="text-xs text-slate-600 hover:text-blue-800 bg-slate-100 hover:bg-blue-50 px-3 py-2 rounded-xl border border-slate-200 cursor-pointer disabled:opacity-40"
              title="Clean any accidental duplicate words"
            >
              Clean Text
            </button>
            <button
              disabled={!transcript || isStructuring}
              onClick={handleStructureComplaint}
              className="flex-1 flex items-center justify-center gap-2 bg-blue-700 hover:bg-blue-800 disabled:opacity-40 text-white font-bold px-5 py-3 rounded-2xl transition-all shadow-md text-xs cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isStructuring ? "Creating Legal Police Draft..." : "Format into Formal Police Complaint"}</span>
            </button>
          </div>
        </div>

        <div className="bubble-card rounded-3xl p-6 shadow-sm border border-blue-100 bg-white">
          <div className="flex items-center justify-between mb-3">
            <label className="text-xs font-bold text-blue-950 uppercase tracking-wider flex items-center gap-2 font-crest">
              <FileText className="w-4 h-4 text-blue-700" />
              <span>Formal Police Complaint Draft</span>
            </label>
            {structuredComplaint && (
              <span className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                <CheckCircle className="w-4 h-4 text-emerald-600" /> Ready to submit
              </span>
            )}
          </div>

          <div className="w-full h-52 bg-slate-50 border border-blue-200 rounded-2xl p-4 text-xs text-slate-800 font-mono overflow-y-auto whitespace-pre-wrap select-all leading-relaxed">
            {structuredComplaint || "Click 'Format into Formal Police Complaint' to convert spoken words into a formal petition with Sections and prayer under Section 173 BNSS."}
          </div>

          {structuredComplaint && (
            <div className="mt-3 flex gap-2">
              <button
                onClick={() => speakText(structuredComplaint)}
                className="flex items-center justify-center gap-1.5 bg-blue-100 hover:bg-blue-200 text-blue-900 font-bold px-4 py-3 rounded-2xl text-xs transition-colors cursor-pointer"
              >
                <Volume2 className="w-4 h-4 text-blue-700" />
                <span>Listen Out Loud</span>
              </button>

              <button
                onClick={() => onSendToAnalyzer(structuredComplaint)}
                className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-blue-700 to-indigo-800 hover:from-blue-800 hover:to-indigo-900 text-white font-bold px-5 py-3 rounded-2xl transition-all shadow-md text-xs cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Send to FIR Analyzer</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
