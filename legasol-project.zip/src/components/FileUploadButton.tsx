import React, { useRef, useState } from 'react';
import { UploadCloud, FileText, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { extractTextFromFile } from '../lib/fileTextExtractor';

interface FileUploadButtonProps {
  onTextLoaded: (text: string, fileName: string) => void;
  label?: string;
  sublabel?: string;
}

export const FileUploadButton: React.FC<FileUploadButtonProps> = ({
  onTextLoaded,
  label = "Upload FIR Document",
  sublabel = "Supports PDF, TXT, Scanned Police FIR Images, or DOC"
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastUploaded, setLastUploaded] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleFile = async (file: File) => {
    setIsProcessing(true);
    try {
      const res = await extractTextFromFile(file);
      setLastUploaded(res.fileName);
      onTextLoaded(res.text, res.fileName);
    } catch {
      alert("Error extracting document content. Please try another file or paste text directly.");
    } finally {
      setIsProcessing(false);
    }
  };

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${
        isDragging
          ? 'border-amber-400 bg-amber-500/10'
          : 'border-slate-700 hover:border-slate-500 bg-slate-900/60 hover:bg-slate-800/40'
      }`}
      onClick={() => fileInputRef.current?.click()}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept=".txt,.pdf,.png,.jpg,.jpeg,.doc,.docx,.json"
        className="hidden"
        onChange={onChange}
      />
      
      <div className="flex flex-col items-center justify-center gap-1.5">
        {isProcessing ? (
          <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
        ) : lastUploaded ? (
          <CheckCircle2 className="w-6 h-6 text-emerald-400" />
        ) : (
          <UploadCloud className="w-6 h-6 text-amber-400" />
        )}

        <div className="text-xs font-semibold text-slate-200">
          {isProcessing ? "Processing & OCR Ingestion..." : lastUploaded ? `Loaded: ${lastUploaded}` : label}
        </div>
        <p className="text-[11px] text-slate-400">
          {sublabel}
        </p>
      </div>
    </div>
  );
};
