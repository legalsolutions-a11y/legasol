import React, { useState, useRef } from 'react';
import { 
  FileText, ArrowLeftRight, Upload, Scale, Database, AlertCircle, 
  Check, Download, Trash2, Gavel, Clock, Save, ShieldAlert,
  CheckCircle2, XCircle, AlertTriangle, ShieldCheck, Sparkles, ChevronRight
} from 'lucide-react';
import { 
  compareComplaintsDetailed, 
  DetailedComparisonResult 
} from '../lib/analysis';
import { extractTextFromFile } from '../lib/fileTextExtractor';
import { CaseProgressTimeline } from './CaseProgressTimeline';

interface SavedComparisonRecord {
  id: string;
  title: string;
  date: string;
  partAText: string;
  partBText: string;
  recommendation: string;
  partARisk: string;
  partBRisk: string;
}

interface FirCompareProps {
  onNavigateToRecording: () => void;
}

export const FirCompare: React.FC<FirCompareProps> = ({ onNavigateToRecording }) => {
  const [partAText, setPartAText] = useState('');
  const [partBText, setPartBText] = useState('');
  const [hasCompared, setHasCompared] = useState(false);
  const [comparisonResult, setComparisonResult] = useState<DetailedComparisonResult | null>(null);
  const [analysisName, setAnalysisName] = useState('');
  const [savedAnalyses, setSavedAnalyses] = useState<SavedComparisonRecord[]>(() => {
    try {
      const stored = localStorage.getItem('legasol_saved_comparisons');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });
  const [saveToast, setSaveToast] = useState(false);
  const [showStandaloneTimeline, setShowStandaloneTimeline] = useState(false);

  const fileInputARef = useRef<HTMLInputElement>(null);
  const fileInputBRef = useRef<HTMLInputElement>(null);

  const handleFileUploadA = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const res = await extractTextFromFile(e.target.files[0]);
      setPartAText(res.text);
    }
  };

  const handleFileUploadB = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const res = await extractTextFromFile(e.target.files[0]);
      setPartBText(res.text);
    }
  };

  const handleCompare = (customA?: string, customB?: string) => {
    const textA = customA !== undefined ? customA : partAText;
    const textB = customB !== undefined ? customB : partBText;
    if (!textA.trim() && !textB.trim()) return;
    const res = compareComplaintsDetailed(textA, textB);
    setComparisonResult(res);
    setHasCompared(true);
  };

  const loadSampleScenario = (scenario: 'murder' | 'assault') => {
    if (scenario === 'murder') {
      const sampleA = 'murder';
      const sampleB = 'moblynching';
      setPartAText(sampleA);
      setPartBText(sampleB);
      handleCompare(sampleA, sampleB);
    } else {
      const sampleA = 'The accused person attacked the complainant with an iron rod and country-made gun near Market Yard, causing severe head injuries and extorting cash of Rs. 45,000.';
      const sampleB = 'The complainant had a verbal altercation over parking space; no weapon was involved and no physical assault occurred.';
      setPartAText(sampleA);
      setPartBText(sampleB);
      handleCompare(sampleA, sampleB);
    }
  };

  const handleSaveAnalysis = () => {
    if (!comparisonResult) return;
    const today = new Date();
    const titleToUse = analysisName.trim() || `Comparison Audit #${savedAnalyses.length + 1} (${today.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})`;
    
    const newRecord: SavedComparisonRecord = {
      id: `comparison-${Date.now()}`,
      title: titleToUse,
      date: today.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      partAText,
      partBText,
      recommendation: comparisonResult.recommendation,
      partARisk: comparisonResult.partA.riskBadge,
      partBRisk: comparisonResult.partB.riskBadge
    };

    const updated = [newRecord, ...savedAnalyses];
    setSavedAnalyses(updated);
    try {
      localStorage.setItem('legasol_saved_comparisons', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }

    setSaveToast(true);
    setAnalysisName('');
    setTimeout(() => setSaveToast(false), 2000);
  };

  const handleDeleteAnalysis = (id: string) => {
    const updated = savedAnalyses.filter(a => a.id !== id);
    setSavedAnalyses(updated);
    try {
      localStorage.setItem('legasol_saved_comparisons', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleDownloadReport = () => {
    if (!comparisonResult) return;

    const res = comparisonResult;
    const dateStr = new Date().toLocaleString('en-IN');
    const separator = "═".repeat(68);
    const subSep = "─".repeat(68);

    const reportContent = `${separator}
LEGAL INTELLIGENCE COMPLAINT COMPARISON REPORT
Bharatiya Nyaya Sanhita, 2023 & BNSS 2023 Statutory Analysis
${separator}
Generated On:      ${dateStr}
Reference Docket:  COMP-AUDIT-${Date.now().toString().slice(-6)}
Jurisdiction:      Indian Criminal Procedure Code (BNSS 2023 / BNS 2023)

${separator}
1. DECISION SUPPORT RECOMMENDATION
${separator}
${res.recommendation}

${separator}
2. SIDE-BY-SIDE RISK & STATUTORY CHECKLIST EVALUATION
${separator}
[PART A EVALUATION]
Risk Classification:   ${res.partA.riskBadge}
Severity Level:        ${res.partA.severity}
Evidence Foundation:   ${res.partA.evidence}
Cognizable Offenses:   ${res.partA.cognizableCount}
Detail Assessment:     ${res.partA.detail}

Statutory Checklist:
• Bailable Offenses:     ${res.partA.bailableCount}
• Non-Bailable Offenses: ${res.partA.nonBailableCount}
• Weapon Involvement:    ${res.partA.weaponInvolvement}
• Financial Aspect:      ${res.partA.financialAspect}

[PART B EVALUATION]
Risk Classification:   ${res.partB.riskBadge}
Severity Level:        ${res.partB.severity}
Evidence Foundation:   ${res.partB.evidence}
Cognizable Offenses:   ${res.partB.cognizableCount}
Detail Assessment:     ${res.partB.detail}

Statutory Checklist:
• Bailable Offenses:     ${res.partB.bailableCount}
• Non-Bailable Offenses: ${res.partB.nonBailableCount}
• Weapon Involvement:    ${res.partB.weaponInvolvement}
• Financial Aspect:      ${res.partB.financialAspect}

${subSep}
3. IDENTIFIED STATUTORY SECTIONS & PROVISIONS
${subSep}
PART A SECTIONS:
${res.partA.identifiedSections.length > 0 ? res.partA.identifiedSections.map(s => `• ${s.code} - BNS Section ${s.bnsSection} (IPC ${s.ipcSection}): ${s.bnsTitle}\n  Classification: ${s.cognizable ? 'Cognizable' : 'Non-Cognizable'} | ${s.bailable ? 'Bailable' : 'Non-Bailable'}\n  Punishment: ${s.punishment}\n  Court: ${s.court}`).join('\n\n') : 'No direct statutory offense identified in Part A complaint text.'}

PART B SECTIONS:
${res.partB.identifiedSections.length > 0 ? res.partB.identifiedSections.map(s => `• ${s.code} - BNS Section ${s.bnsSection} (IPC ${s.ipcSection}): ${s.bnsTitle}\n  Classification: ${s.cognizable ? 'Cognizable' : 'Non-Cognizable'} | ${s.bailable ? 'Bailable' : 'Non-Bailable'}\n  Punishment: ${s.punishment}\n  Court: ${s.court}`).join('\n\n') : 'No direct statutory offense identified in Part B complaint text.'}

${subSep}
4. SIMILARITIES BETWEEN COMPLAINTS
${subSep}
${res.similarities}

${subSep}
5. POTENTIAL LEGAL OUTCOMES & JUDICIAL PROGNOSIS
${subSep}
PART A OUTCOMES:
${res.partA.potentialOutcomes.map(o => `  • ${o}`).join('\n')}

PART B OUTCOMES:
${res.partB.potentialOutcomes.map(o => `  • ${o}`).join('\n')}

${subSep}
6. COMPLAINANT / COUNTER STATEMENTS RECORDED
${subSep}
[PART A RECORDED INPUT]:
"${res.partA.rawText || 'No text entered.'}"

[PART B RECORDED INPUT]:
"${res.partB.rawText || 'No text entered.'}"

${separator}
Generated by LegaSol AI Legal Intelligence · legasol.in
${separator}`;

    const blob = new Blob([reportContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `LegaSol_Judicial_Complaint_Comparison_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const wordCountA = partAText.trim() ? partAText.trim().split(/\s+/).length : 0;
  const wordCountB = partBText.trim() ? partBText.trim().split(/\s+/).length : 0;

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-20">
      {/* 1. Top Banner Matching Screenshot (55) */}
      <div className="text-center pt-2">
        <a 
          href="https://legasol.in" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-4 py-1 rounded-full border border-slate-300 bg-white text-xs text-slate-700 font-medium tracking-wide shadow-sm hover:border-slate-400 transition-colors"
        >
          <FileText className="w-3.5 h-3.5 text-[#b08958]" />
          <span><strong className="text-red-600 font-extrabold">LEGA</strong><strong className="text-red-600 font-extrabold">SOL</strong>.IN • FIR & ANALYSIS MODULE</span>
        </a>

        <h1 className="font-headline font-bold text-3xl sm:text-4xl text-[#1e293b] mt-4 tracking-tight">
          <span className="text-red-600 font-extrabold">Lega</span><span className="text-red-600 font-extrabold">Sol</span> Cross-Complaint Comparison & Audit
        </h1>

        <p className="text-sm text-slate-600 max-w-2xl mx-auto mt-2 leading-relaxed">
          Create Indian FIR drafts and compare complaint texts to identify applicable BNS sections, assess risk, and generate decision support recommendations.
        </p>

        {/* Segmented Mode Buttons Matching Screenshot (55) */}
        <div className="inline-flex items-center p-1 rounded-xl bg-white border border-slate-200 shadow-sm mt-6">
          <button
            onClick={onNavigateToRecording}
            className="flex items-center gap-2 px-6 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors cursor-pointer"
          >
            <FileText className="w-4 h-4" />
            <span>FIR Recording</span>
          </button>

          <button
            className="flex items-center gap-2 px-6 py-2 rounded-lg text-xs font-semibold bg-[#c49a6c] text-white shadow-sm cursor-pointer"
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span>Compare Complaints</span>
          </button>
        </div>
      </div>

      {/* 2. Side-by-Side Dual Input Section Matching Screenshot (55) */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            INPUT COMPLAINTS (PART A VS PART B)
          </span>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Quick Test:</span>
            <button
              onClick={() => loadSampleScenario('murder')}
              className="text-xs font-medium text-blue-700 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-md border border-blue-200 transition-colors cursor-pointer"
            >
              Murder vs Cross-Claim
            </button>
            <button
              onClick={() => loadSampleScenario('assault')}
              className="text-xs font-medium text-teal-800 hover:text-teal-950 bg-teal-50 hover:bg-teal-100 px-2.5 py-1 rounded-md border border-teal-200 transition-colors cursor-pointer"
            >
              Armed Assault vs Dispute
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* PART A INPUT */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
              PART A INPUT
            </label>
            <div className="bg-white border border-slate-300 rounded-xl p-3.5 shadow-2xs space-y-3">
              <textarea
                value={partAText}
                onChange={(e) => setPartAText(e.target.value)}
                rows={9}
                placeholder="Add complaint text or upload document images to begin analysis..."
                className="w-full bg-white border-0 text-xs text-slate-800 focus:outline-none leading-relaxed resize-none font-normal placeholder:text-slate-400"
              />

              <div className="text-xs text-slate-400 font-mono pt-1">
                {wordCountA} words
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100">
                <input
                  ref={fileInputARef}
                  type="file"
                  accept=".txt,.pdf,.png,.jpg,.jpeg,.doc,.docx"
                  className="hidden"
                  onChange={handleFileUploadA}
                />
                <button
                  onClick={() => fileInputARef.current?.click()}
                  className="flex items-center gap-1.5 bg-[#1e293b] hover:bg-slate-800 text-white text-xs font-medium px-3.5 py-2 rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload File</span>
                </button>
                <span className="text-[11px] text-slate-500">
                  PDF, TXT, JPG, PNG, TIFF · drag & drop supported
                </span>
              </div>
            </div>
          </div>

          {/* PART B INPUT */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
              PART B INPUT
            </label>
            <div className="bg-white border border-slate-300 rounded-xl p-3.5 shadow-2xs space-y-3">
              <textarea
                value={partBText}
                onChange={(e) => setPartBText(e.target.value)}
                rows={9}
                placeholder="Add complaint text or upload document images to begin analysis..."
                className="w-full bg-white border-0 text-xs text-slate-800 focus:outline-none leading-relaxed resize-none font-normal placeholder:text-slate-400"
              />

              <div className="text-xs text-slate-400 font-mono pt-1">
                {wordCountB} words
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100">
                <input
                  ref={fileInputBRef}
                  type="file"
                  accept=".txt,.pdf,.png,.jpg,.jpeg,.doc,.docx"
                  className="hidden"
                  onChange={handleFileUploadB}
                />
                <button
                  onClick={() => fileInputBRef.current?.click()}
                  className="flex items-center gap-1.5 bg-[#1e293b] hover:bg-slate-800 text-white text-xs font-medium px-3.5 py-2 rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload File</span>
                </button>
                <span className="text-[11px] text-slate-500">
                  PDF, TXT, JPG, PNG, TIFF · drag & drop supported
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Compare Complaints Button & Case Progress Tracker */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <button
            onClick={() => handleCompare()}
            disabled={!partAText.trim() && !partBText.trim()}
            className={`flex-1 w-full py-3.5 px-6 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all shadow-sm ${
              partAText.trim() || partBText.trim()
                ? 'bg-[#c49a6c] hover:bg-[#b3895b] text-white cursor-pointer'
                : 'bg-[#e6cfb8] text-white/80 cursor-not-allowed'
            }`}
          >
            <Scale className="w-4 h-4" />
            <span>Compare Complaints</span>
          </button>

          <button
            type="button"
            onClick={() => setShowStandaloneTimeline(!showStandaloneTimeline)}
            className="w-full sm:w-auto py-3.5 px-5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 border border-blue-200 bg-blue-50 hover:bg-blue-100 text-blue-900 transition-all shadow-2xs cursor-pointer whitespace-nowrap active:scale-95"
            title="Track statutory milestones, bail deadlines, and chargesheet timeline"
          >
            <Clock className="w-4 h-4 text-blue-700" />
            <span>{showStandaloneTimeline ? 'Hide Case Timeline' : 'Track Legal Case Status & Timeline'}</span>
          </button>
        </div>

        {/* Standalone Timeline when toggled */}
        {showStandaloneTimeline && (
          <CaseProgressTimeline
            highestSeverity={comparisonResult?.partA.severity || 'Moderate / Bailable'}
            isBailable={comparisonResult ? comparisonResult.partA.nonBailableCount === 0 : true}
            isCognizable={comparisonResult ? comparisonResult.partA.cognizableCount > 0 : true}
            weaponInvolved={comparisonResult ? comparisonResult.partA.weaponInvolvement.includes('Involved') : false}
            financialAspect={comparisonResult ? comparisonResult.partA.financialAspect.includes('Involved') : false}
          />
        )}
      </div>

      {/* 4. DEDICATED DECISION SUPPORT PANEL Matching Screenshots (56) & (57) */}
      {hasCompared && comparisonResult && (
        <div className="bg-[#fcfbf9] border-2 border-[#b08958]/30 rounded-3xl p-5 sm:p-7 shadow-sm space-y-6">
          {/* Panel Header */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-4">
            <div className="flex items-center gap-2.5">
              <span className="p-2 rounded-xl bg-[#b08958]/10 text-[#b08958]">
                <Gavel className="w-5 h-5" />
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-headline text-lg sm:text-xl font-bold text-[#1e293b]">
                    Decision Support Panel
                  </h2>
                  <span className="bg-[#1e293b] text-white font-mono text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                    BNS & BNSS 2023
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  Judicial risk comparison, statutory offense checklist, and case outcomes prognosis.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleDownloadReport}
                className="flex items-center gap-1.5 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-300 shadow-2xs transition-all cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                <span>Export Audit</span>
              </button>
            </div>
          </div>

          {/* A. Decision Support Recommendation Card Matching Screenshot (56) */}
          <div className="bg-[#fefaf6] border border-[#f5e6d3] rounded-2xl p-5 sm:p-6 shadow-2xs space-y-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#b08958]" />
              <h3 className="font-headline text-sm sm:text-base font-bold text-[#1e293b]">
                Decision Support Recommendation
              </h3>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-normal">
              {comparisonResult.recommendation}
            </p>
          </div>

          {/* B. Visual Statutory Case Progress Timeline Tracker */}
          <CaseProgressTimeline
            highestSeverity={comparisonResult.partA.severity || comparisonResult.partB.severity}
            isBailable={comparisonResult.partA.nonBailableCount === 0 && comparisonResult.partB.nonBailableCount === 0}
            isCognizable={comparisonResult.partA.cognizableCount > 0 || comparisonResult.partB.cognizableCount > 0}
            weaponInvolved={
              comparisonResult.partA.weaponInvolvement.toLowerCase().includes('involved') ||
              comparisonResult.partB.weaponInvolvement.toLowerCase().includes('involved') ||
              comparisonResult.partA.weaponInvolvement.toLowerCase().includes('recovered')
            }
            financialAspect={
              comparisonResult.partA.financialAspect.toLowerCase().includes('involved') ||
              comparisonResult.partB.financialAspect.toLowerCase().includes('involved')
            }
          />

          {/* C. Side-by-Side Dual Risk & Checklist Boxes Matching Screenshot (56) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* PART A RISK BOX (Red outline) */}
            <div className="bg-white border-2 border-red-200 rounded-2xl p-6 shadow-2xs space-y-5">
              {/* Box Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <span className="font-bold text-sm text-slate-800 block">
                    {comparisonResult.partA.riskTitle}
                  </span>
                  <span className="text-[11px] text-slate-500">Complainant / Accuser Statement</span>
                </div>
                <span className={`text-xs font-bold tracking-wider uppercase px-2.5 py-1 rounded-md ${
                  comparisonResult.partA.riskBadge === 'SEVERE RISK' ? 'bg-red-50 text-red-600 border border-red-200' :
                  comparisonResult.partA.riskBadge === 'HIGH RISK' ? 'bg-orange-50 text-orange-600 border border-orange-200' :
                  comparisonResult.partA.riskBadge === 'MODERATE RISK' ? 'bg-amber-50 text-amber-600 border border-amber-200' : 
                  'bg-emerald-50 text-emerald-600 border border-emerald-200'
                }`}>
                  {comparisonResult.partA.riskBadge}
                </span>
              </div>

              {/* 4 Metric Grid Tiles (2x2) */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#f8fafc] border border-slate-100 rounded-xl p-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      SEVERITY
                    </span>
                    <span className={`w-2 h-2 rounded-full ${
                      comparisonResult.partA.severity === 'Very High' ? 'bg-red-500 animate-pulse' :
                      comparisonResult.partA.severity === 'High' ? 'bg-orange-500' :
                      comparisonResult.partA.severity === 'Moderate' ? 'bg-amber-500' : 'bg-emerald-500'
                    }`} />
                  </div>
                  <span className={`text-sm font-bold mt-1 block ${
                    comparisonResult.partA.severity === 'Very High' || comparisonResult.partA.severity === 'High'
                      ? 'text-emerald-500' // matches screenshot green styling for severity
                      : 'text-slate-800'
                  }`}>
                    {comparisonResult.partA.severity}
                  </span>
                </div>

                <div className="bg-[#f8fafc] border border-slate-100 rounded-xl p-3.5">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                    EVIDENCE
                  </span>
                  <span className="text-sm font-bold text-slate-900 mt-1 block">
                    {comparisonResult.partA.evidence}
                  </span>
                </div>

                <div className="bg-[#f8fafc] border border-slate-100 rounded-xl p-3.5">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                    COGNIZABLE
                  </span>
                  <span className="text-sm font-bold text-slate-900 mt-1 block">
                    {comparisonResult.partA.cognizableCount}
                  </span>
                </div>

                <div className="bg-[#f8fafc] border border-slate-100 rounded-xl p-3.5">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                    DETAIL
                  </span>
                  <span className="text-sm font-bold text-slate-900 mt-1 block">
                    {comparisonResult.partA.detail}
                  </span>
                </div>
              </div>

              {/* STATUTORY & EVIDENTIARY CHECKLIST */}
              <div className="space-y-2.5 pt-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  STATUTORY & EVIDENTIARY CHECKLIST
                </span>

                <div className="space-y-2 bg-[#f8fafc] border border-slate-200/80 rounded-xl p-3.5 text-xs">
                  {/* Bailable Checklist Item */}
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/60">
                    <div className="flex items-center gap-2">
                      {comparisonResult.partA.bailableCount > 0 ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <span className="w-4 h-4 rounded-full border border-slate-300 inline-flex items-center justify-center text-[10px] text-slate-400">0</span>
                      )}
                      <span className="text-slate-700 font-medium">Bailable Status</span>
                    </div>
                    <span className="font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded text-[11px] border border-emerald-200">
                      {comparisonResult.partA.bailableCount} {comparisonResult.partA.bailableCount === 1 ? 'Section' : 'Sections'}
                    </span>
                  </div>

                  {/* Non-Bailable Checklist Item */}
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/60">
                    <div className="flex items-center gap-2">
                      {comparisonResult.partA.nonBailableCount > 0 ? (
                        <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      )}
                      <span className="text-slate-700 font-medium">Non-Bailable Status</span>
                    </div>
                    <span className={`font-bold px-2 py-0.5 rounded text-[11px] border ${
                      comparisonResult.partA.nonBailableCount > 0 
                        ? 'text-red-600 bg-red-50 border-red-200' 
                        : 'text-slate-600 bg-slate-100 border-slate-200'
                    }`}>
                      {comparisonResult.partA.nonBailableCount} {comparisonResult.partA.nonBailableCount === 1 ? 'Section' : 'Sections'}
                    </span>
                  </div>

                  {/* Weapon Involvement Checklist Item */}
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/60">
                    <div className="flex items-center gap-2">
                      {comparisonResult.partA.weaponInvolvement.toLowerCase().includes('weapon mentioned') ? (
                        <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                      <span className="text-slate-700 font-medium">Weapon Involvement</span>
                    </div>
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${
                      comparisonResult.partA.weaponInvolvement.toLowerCase().includes('weapon mentioned')
                        ? 'bg-red-50 text-red-700 border-red-200'
                        : 'bg-white text-slate-600 border-slate-200'
                    }`}>
                      {comparisonResult.partA.weaponInvolvement}
                    </span>
                  </div>

                  {/* Financial Aspect Checklist Item */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {comparisonResult.partA.financialAspect.toLowerCase().includes('financial') ? (
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                      <span className="text-slate-700 font-medium">Financial Aspect</span>
                    </div>
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${
                      comparisonResult.partA.financialAspect.toLowerCase().includes('financial')
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-white text-slate-600 border-slate-200'
                    }`}>
                      {comparisonResult.partA.financialAspect}
                    </span>
                  </div>
                </div>
              </div>

              {/* Identified Sections (if any) */}
              {comparisonResult.partA.identifiedSections.length > 0 && (
                <div className="pt-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                    IDENTIFIED BNS SECTIONS
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {comparisonResult.partA.identifiedSections.map((sec, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center bg-[#1e293b] text-white text-xs font-mono font-bold px-2.5 py-1 rounded shadow-2xs"
                        title={`${sec.bnsTitle} (IPC ${sec.ipcSection}) - ${sec.punishment}`}
                      >
                        {sec.code}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Potential Outcomes */}
              <div className="pt-2">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                  POTENTIAL OUTCOMES
                </span>
                <div className="space-y-1.5">
                  {comparisonResult.partA.potentialOutcomes.map((outcome, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-600">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{outcome}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* PART B RISK BOX (Green outline) */}
            <div className="bg-white border-2 border-emerald-200 rounded-2xl p-6 shadow-2xs space-y-5">
              {/* Box Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div>
                  <span className="font-bold text-sm text-slate-800 block">
                    {comparisonResult.partB.riskTitle}
                  </span>
                  <span className="text-[11px] text-slate-500">Opposing Party / Counter-Statement</span>
                </div>
                <span className={`text-xs font-bold tracking-wider uppercase px-2.5 py-1 rounded-md ${
                  comparisonResult.partB.riskBadge === 'SEVERE RISK' ? 'bg-red-50 text-red-600 border border-red-200' :
                  comparisonResult.partB.riskBadge === 'HIGH RISK' ? 'bg-orange-50 text-orange-600 border border-orange-200' :
                  comparisonResult.partB.riskBadge === 'MODERATE RISK' ? 'bg-amber-50 text-amber-600 border border-amber-200' : 
                  'bg-emerald-50 text-emerald-600 border border-emerald-200'
                }`}>
                  {comparisonResult.partB.riskBadge}
                </span>
              </div>

              {/* 4 Metric Grid Tiles (2x2) */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#f8fafc] border border-slate-100 rounded-xl p-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      SEVERITY
                    </span>
                    <span className={`w-2 h-2 rounded-full ${
                      comparisonResult.partB.severity === 'Very High' ? 'bg-red-500 animate-pulse' :
                      comparisonResult.partB.severity === 'High' ? 'bg-orange-500' :
                      comparisonResult.partB.severity === 'Moderate' ? 'bg-amber-500' : 'bg-emerald-500'
                    }`} />
                  </div>
                  <span className="text-sm font-bold mt-1 block text-emerald-500">
                    {comparisonResult.partB.severity}
                  </span>
                </div>

                <div className="bg-[#f8fafc] border border-slate-100 rounded-xl p-3.5">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                    EVIDENCE
                  </span>
                  <span className="text-sm font-bold text-slate-900 mt-1 block">
                    {comparisonResult.partB.evidence}
                  </span>
                </div>

                <div className="bg-[#f8fafc] border border-slate-100 rounded-xl p-3.5">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                    COGNIZABLE
                  </span>
                  <span className="text-sm font-bold text-slate-900 mt-1 block">
                    {comparisonResult.partB.cognizableCount}
                  </span>
                </div>

                <div className="bg-[#f8fafc] border border-slate-100 rounded-xl p-3.5">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                    DETAIL
                  </span>
                  <span className="text-sm font-bold text-slate-900 mt-1 block">
                    {comparisonResult.partB.detail}
                  </span>
                </div>
              </div>

              {/* STATUTORY & EVIDENTIARY CHECKLIST */}
              <div className="space-y-2.5 pt-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  STATUTORY & EVIDENTIARY CHECKLIST
                </span>

                <div className="space-y-2 bg-[#f8fafc] border border-slate-200/80 rounded-xl p-3.5 text-xs">
                  {/* Bailable Checklist Item */}
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/60">
                    <div className="flex items-center gap-2">
                      {comparisonResult.partB.bailableCount > 0 ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <span className="w-4 h-4 rounded-full border border-slate-300 inline-flex items-center justify-center text-[10px] text-slate-400">0</span>
                      )}
                      <span className="text-slate-700 font-medium">Bailable Status</span>
                    </div>
                    <span className="font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded text-[11px] border border-emerald-200">
                      {comparisonResult.partB.bailableCount} {comparisonResult.partB.bailableCount === 1 ? 'Section' : 'Sections'}
                    </span>
                  </div>

                  {/* Non-Bailable Checklist Item */}
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/60">
                    <div className="flex items-center gap-2">
                      {comparisonResult.partB.nonBailableCount > 0 ? (
                        <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      )}
                      <span className="text-slate-700 font-medium">Non-Bailable Status</span>
                    </div>
                    <span className={`font-bold px-2 py-0.5 rounded text-[11px] border ${
                      comparisonResult.partB.nonBailableCount > 0 
                        ? 'text-red-600 bg-red-50 border-red-200' 
                        : 'text-slate-600 bg-slate-100 border-slate-200'
                    }`}>
                      {comparisonResult.partB.nonBailableCount} {comparisonResult.partB.nonBailableCount === 1 ? 'Section' : 'Sections'}
                    </span>
                  </div>

                  {/* Weapon Involvement Checklist Item */}
                  <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/60">
                    <div className="flex items-center gap-2">
                      {comparisonResult.partB.weaponInvolvement.toLowerCase().includes('weapon mentioned') ? (
                        <ShieldAlert className="w-4 h-4 text-red-500 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                      <span className="text-slate-700 font-medium">Weapon Involvement</span>
                    </div>
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${
                      comparisonResult.partB.weaponInvolvement.toLowerCase().includes('weapon mentioned')
                        ? 'bg-red-50 text-red-700 border-red-200'
                        : 'bg-white text-slate-600 border-slate-200'
                    }`}>
                      {comparisonResult.partB.weaponInvolvement}
                    </span>
                  </div>

                  {/* Financial Aspect Checklist Item */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {comparisonResult.partB.financialAspect.toLowerCase().includes('financial') ? (
                        <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                      <span className="text-slate-700 font-medium">Financial Aspect</span>
                    </div>
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded border ${
                      comparisonResult.partB.financialAspect.toLowerCase().includes('financial')
                        ? 'bg-amber-50 text-amber-800 border-amber-200'
                        : 'bg-white text-slate-600 border-slate-200'
                    }`}>
                      {comparisonResult.partB.financialAspect}
                    </span>
                  </div>
                </div>
              </div>

              {/* Identified Sections (if any) */}
              {comparisonResult.partB.identifiedSections.length > 0 && (
                <div className="pt-2">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                    IDENTIFIED BNS SECTIONS
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {comparisonResult.partB.identifiedSections.map((sec, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center bg-[#1e293b] text-white text-xs font-mono font-bold px-2.5 py-1 rounded shadow-2xs"
                        title={`${sec.bnsTitle} (IPC ${sec.ipcSection}) - ${sec.punishment}`}
                      >
                        {sec.code}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Potential Outcomes */}
              <div className="pt-2">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
                  POTENTIAL OUTCOMES
                </span>
                <div className="space-y-1.5">
                  {comparisonResult.partB.potentialOutcomes.map((outcome, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-600">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{outcome}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* C. Similarities Between Complaints Matching Screenshot (57) */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-2xs">
            <h3 className="text-xs font-bold text-slate-700 block mb-1">
              Similarities & Contradictions Between Complaints
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              {comparisonResult.similarities}
            </p>
          </div>

          {/* D. Action & Save Row Matching Screenshot (57) */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-1">
            <input
              type="text"
              value={analysisName}
              onChange={(e) => setAnalysisName(e.target.value)}
              placeholder="Name this comparison audit (optional)"
              className="flex-1 bg-white border border-slate-300 rounded-lg px-3.5 py-2.5 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-slate-500 shadow-2xs font-medium"
            />

            <button
              onClick={handleSaveAnalysis}
              className="flex items-center justify-center gap-1.5 bg-[#1e293b] hover:bg-slate-800 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm transition-all cursor-pointer whitespace-nowrap"
            >
              {saveToast ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Save className="w-3.5 h-3.5" />}
              <span>{saveToast ? "Analysis Saved!" : "Save Analysis"}</span>
            </button>

            <button
              onClick={handleDownloadReport}
              className="flex items-center justify-center gap-1.5 bg-[#c49a6c] hover:bg-[#b3895b] text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm transition-all cursor-pointer whitespace-nowrap"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Full Report</span>
            </button>
          </div>
        </div>
      )}

      {/* 5. Saved Comparison Analyses Section Matching Screenshot (57) */}
      <div className="space-y-3 pt-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-[#c49a6c]" />
            <h2 className="font-headline text-lg font-bold text-[#1e293b]">
              Saved Comparison Analyses
            </h2>
          </div>
          {savedAnalyses.length > 0 && (
            <span className="text-xs text-slate-500 font-medium">
              {savedAnalyses.length} saved
            </span>
          )}
        </div>

        {savedAnalyses.length === 0 ? (
          <div className="bg-white border border-dashed border-slate-300 rounded-2xl p-8 text-center text-xs text-slate-500 space-y-1">
            <Scale className="w-6 h-6 text-slate-400 mx-auto mb-2" />
            <p className="font-medium text-slate-700">No saved comparisons yet</p>
            <p>Run a comparison above and click &quot;Save Analysis&quot; to preserve side-by-side audit records.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {savedAnalyses.map((item) => (
              <div
                key={item.id}
                className="bg-white border border-slate-200 rounded-xl p-4 shadow-2xs space-y-3 hover:border-slate-300 transition-all flex flex-col justify-between"
              >
                <div className="space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-bold text-xs text-slate-900 leading-snug">
                      {item.title}
                    </h3>
                    <button
                      onClick={() => handleDeleteAnalysis(item.id)}
                      className="text-slate-400 hover:text-red-600 transition-colors cursor-pointer p-1"
                      title="Delete saved analysis"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    Saved on {item.date}
                  </div>
                  <div className="flex items-center gap-2 pt-1 text-[11px]">
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-red-50 text-red-600 font-semibold border border-red-200">
                      Part A: {item.partARisk}
                    </span>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-emerald-50 text-emerald-600 font-semibold border border-emerald-200">
                      Part B: {item.partBRisk}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-2 pt-1 leading-relaxed">
                    {item.recommendation}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                  <button
                    onClick={() => {
                      setPartAText(item.partAText);
                      setPartBText(item.partBText);
                      handleCompare(item.partAText, item.partBText);
                      window.scrollTo({ top: 400, behavior: 'smooth' });
                    }}
                    className="text-xs font-semibold text-[#b08958] hover:text-[#8a6538] flex items-center gap-1 cursor-pointer"
                  >
                    <span>Reload in Decision Support</span>
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
