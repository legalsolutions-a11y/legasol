import React, { useState, useMemo } from 'react';
import { 
  Landmark, BookOpen, Scale, Search, Copy, Check, Volume2, 
  Sparkles, ExternalLink, Filter, ChevronDown, ChevronUp, 
  ShieldCheck, AlertCircle, Quote, Award, Compass, Info
} from 'lucide-react';
import { LEGAL_PRECEDENTS, LegalPrecedent, getPrecedentsForAnalysis } from '../data/legalPrecedents';
import { speakText } from '../lib/speech';

interface LegalPrecedentSectionProps {
  activeSections: string[];
  predictedOutcome: 'conviction' | 'acquittal' | 'dilution';
  convictionProb: number;
  acquittalProb: number;
  dilutionProb: number;
  selectedCategoryName: string;
}

export const LegalPrecedentSection: React.FC<LegalPrecedentSectionProps> = ({
  activeSections,
  predictedOutcome,
  convictionProb,
  acquittalProb,
  dilutionProb,
  selectedCategoryName
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterSupport, setFilterSupport] = useState<'all' | 'predicted' | 'acquittal' | 'conviction' | 'dilution'>('predicted');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Automatically retrieve precedents matching active sections and category
  const relevantPrecedents = useMemo(() => {
    return getPrecedentsForAnalysis(activeSections, predictedOutcome);
  }, [activeSections, predictedOutcome]);

  // Filter based on search and support toggle
  const filteredPrecedents = useMemo(() => {
    return relevantPrecedents.filter(item => {
      // Search matching
      const matchesSearch = searchQuery.trim() === '' || 
        item.caseTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.citation.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.ratioDecidendi.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sections.some(s => s.toLowerCase().includes(searchQuery.toLowerCase())) ||
        item.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

      if (!matchesSearch) return false;

      if (filterSupport === 'predicted') {
        return item.outcomeSupport === predictedOutcome || item.outcomeSupport === 'all';
      }
      if (filterSupport === 'acquittal') {
        return item.outcomeSupport === 'acquittal' || item.outcomeSupport === 'all';
      }
      if (filterSupport === 'conviction') {
        return item.outcomeSupport === 'conviction' || item.outcomeSupport === 'all';
      }
      if (filterSupport === 'dilution') {
        return item.outcomeSupport === 'dilution' || item.outcomeSupport === 'all';
      }
      return true;
    });
  }, [relevantPrecedents, searchQuery, filterSupport, predictedOutcome]);

  const handleCopyCitation = (prec: LegalPrecedent) => {
    const textToCopy = `${prec.caseTitle}, ${prec.citation} [${prec.court}]. Ratio: ${prec.ratioDecidendi}`;
    navigator.clipboard.writeText(textToCopy);
    setCopiedId(prec.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeakPrecedent = (prec: LegalPrecedent) => {
    const speech = `Precedent: ${prec.caseTitle}, citation ${prec.citation}. Binding ratio: ${prec.ratioDecidendi}. Application to current case: ${prec.evidentiaryApplication}`;
    speakText(speech);
  };

  const getOutcomeBadge = (support: 'conviction' | 'acquittal' | 'dilution' | 'all') => {
    switch (support) {
      case 'acquittal':
        return {
          label: 'Supports Acquittal / Benefit of Doubt',
          color: 'bg-emerald-50 text-emerald-800 border-emerald-300',
          dot: 'bg-emerald-600'
        };
      case 'conviction':
        return {
          label: 'Supports Conviction / Evidentiary Threshold',
          color: 'bg-rose-50 text-rose-800 border-rose-300',
          dot: 'bg-rose-600'
        };
      case 'dilution':
        return {
          label: 'Supports Charge Dilution / Lesser Offence',
          color: 'bg-amber-50 text-amber-800 border-amber-300',
          dot: 'bg-amber-600'
        };
      case 'all':
      default:
        return {
          label: 'Supreme Court Sentencing / Evidence Charter',
          color: 'bg-blue-50 text-blue-800 border-blue-300',
          dot: 'bg-blue-600'
        };
    }
  };

  const currentOutcomeLabel = 
    predictedOutcome === 'conviction' ? 'Conviction as Charged' :
    predictedOutcome === 'acquittal' ? 'Acquittal on Benefit of Doubt' : 'Charge Dilution & Lesser Penalty';

  return (
    <section className="bg-white border border-blue-100 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
      {/* Section Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-blue-100">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-100/70 text-blue-900 border border-blue-200">
              <Landmark className="w-5 h-5 text-blue-700" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-crest font-bold text-lg sm:text-xl text-blue-950">
                  Legal Precedents & Landmark Case Law
                </h3>
                <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200">
                  <Sparkles className="w-3 h-3 text-blue-600" />
                  Auto-Retrieved
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Authoritative Supreme Court of India precedents mapped to active BNS sections to legally substantiate the simulated outcome
              </p>
            </div>
          </div>
        </div>

        {/* Current Outcome Alignment Banner */}
        <div className="flex items-center gap-2.5 bg-gradient-to-r from-blue-50 via-slate-50 to-blue-50 p-3 rounded-2xl border border-blue-200 shrink-0">
          <Scale className="w-4 h-4 text-blue-700 shrink-0" />
          <div className="text-xs">
            <span className="text-slate-500 font-medium">Outcome Focus: </span>
            <strong className="text-blue-950 font-bold">{currentOutcomeLabel}</strong>
            <span className="text-slate-400 font-mono ml-1.5 text-[11px]">
              ({predictedOutcome === 'conviction' ? convictionProb : predictedOutcome === 'acquittal' ? acquittalProb : dilutionProb}%)
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Support Outcome Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setFilterSupport('predicted')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              filterSupport === 'predicted'
                ? 'bg-white text-blue-950 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Matches Predicted Outcome ({currentOutcomeLabel})
          </button>
          <button
            onClick={() => setFilterSupport('all')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              filterSupport === 'all'
                ? 'bg-white text-blue-950 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All Citations ({relevantPrecedents.length})
          </button>
          <button
            onClick={() => setFilterSupport('acquittal')}
            className={`px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
              filterSupport === 'acquittal'
                ? 'bg-emerald-600 text-white shadow-xs font-bold'
                : 'text-emerald-800 hover:bg-emerald-100/50'
            }`}
          >
            Acquittal Authorities
          </button>
          <button
            onClick={() => setFilterSupport('conviction')}
            className={`px-2.5 py-1.5 rounded-lg transition-all cursor-pointer ${
              filterSupport === 'conviction'
                ? 'bg-rose-600 text-white shadow-xs font-bold'
                : 'text-rose-800 hover:bg-rose-100/50'
            }`}
          >
            Conviction Authorities
          </button>
        </div>

        {/* Search input */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search cases, citations, ratios..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-blue-400 focus:bg-white transition-all"
          />
        </div>
      </div>

      {/* Precedent Cards List */}
      <div className="space-y-4">
        {filteredPrecedents.length === 0 ? (
          <div className="text-center py-10 px-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <BookOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700">No matching legal precedents found</p>
            <p className="text-xs text-slate-500 mt-1">Try clearing your search query or switching to "All Citations".</p>
            <button
              onClick={() => { setSearchQuery(''); setFilterSupport('all'); }}
              className="mt-3 px-3.5 py-1.5 bg-blue-900 text-white text-xs font-bold rounded-lg cursor-pointer hover:bg-blue-800"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          filteredPrecedents.map((prec) => {
            const badge = getOutcomeBadge(prec.outcomeSupport);
            const isExpanded = expandedId === prec.id;
            const isCopied = copiedId === prec.id;
            const matchesCurrentOutcome = prec.outcomeSupport === predictedOutcome || prec.outcomeSupport === 'all';

            return (
              <div
                key={prec.id}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  matchesCurrentOutcome
                    ? 'border-blue-200 bg-gradient-to-br from-white via-white to-blue-50/30 shadow-xs hover:border-blue-300'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                {/* Header Row */}
                <div className="p-4 sm:p-5">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`inline-flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${badge.color}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`}></span>
                          <span>{badge.label}</span>
                        </span>

                        <span className="text-[11px] font-mono font-medium text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                          {prec.court} ({prec.year})
                        </span>

                        {prec.sections.map(s => (
                          <span key={s} className="text-[11px] font-bold text-blue-900 bg-blue-100/70 border border-blue-200 px-2 py-0.5 rounded-md">
                            BNS {s}
                          </span>
                        ))}
                      </div>

                      {/* Case Title and Citation */}
                      <div>
                        <h4 className="font-headline font-bold text-base sm:text-lg text-slate-900 tracking-tight">
                          {prec.caseTitle}
                        </h4>
                        <div className="text-xs font-mono font-semibold text-blue-800 mt-0.5">
                          {prec.citation} <span className="text-slate-400 font-sans">• Bench: {prec.bench}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons: Listen & Copy */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => handleSpeakPrecedent(prec)}
                        className="flex items-center gap-1 text-xs text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer font-medium"
                        title="Listen to legal ratio"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span className="hidden sm:inline">Listen</span>
                      </button>

                      <button
                        onClick={() => handleCopyCitation(prec)}
                        className={`flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-lg transition-all cursor-pointer font-medium border ${
                          isCopied 
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                            : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
                        }`}
                        title="Copy case citation"
                      >
                        {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{isCopied ? 'Copied' : 'Cite'}</span>
                      </button>

                      <button
                        onClick={() => setExpandedId(isExpanded ? null : prec.id)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
                        title={isExpanded ? 'Collapse analysis' : 'Expand full analysis'}
                      >
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Ratio Decidendi Summary */}
                  <div className="mt-3 text-xs text-slate-700 leading-relaxed font-normal bg-slate-50/80 p-3.5 rounded-xl border border-slate-150">
                    <strong className="text-blue-950 font-bold block mb-1">Binding Principle (Ratio Decidendi):</strong>
                    {prec.ratioDecidendi}
                  </div>

                  {/* Evidentiary Application Banner */}
                  <div className="mt-2.5 flex items-start gap-2 text-xs bg-amber-50/80 border border-amber-200/80 p-2.5 rounded-xl text-amber-950">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600 mt-0.5 shrink-0" />
                    <div>
                      <strong className="font-semibold text-amber-900">Application to Predicted Outcome: </strong>
                      <span className="text-amber-900/90">{prec.evidentiaryApplication}</span>
                    </div>
                  </div>

                  {/* Expanded Details Drawer */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-slate-200 space-y-3 text-xs animate-in fade-in duration-200">
                      {/* Key Quotation */}
                      <div className="bg-blue-50/50 border-l-4 border-blue-600 p-3 rounded-r-xl">
                        <div className="flex items-center gap-1.5 text-blue-900 font-bold mb-1">
                          <Quote className="w-3.5 h-3.5" />
                          <span>Authoritative Judicial Dictum:</span>
                        </div>
                        <p className="italic text-slate-800 leading-relaxed font-serif text-[12.5px]">
                          "{prec.keyQuotation}"
                        </p>
                      </div>

                      {/* Landmark Significance */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="bg-white p-3 rounded-xl border border-slate-200">
                          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                            Landmark Jurisprudence
                          </span>
                          <p className="text-slate-700 text-xs leading-normal">
                            {prec.landmarkSignificance}
                          </p>
                        </div>

                        <div className="bg-white p-3 rounded-xl border border-slate-200">
                          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                            Statutory & IPC Counterpart
                          </span>
                          <p className="text-slate-700 text-xs font-mono leading-normal">
                            {prec.ipcCounterpart}
                          </p>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {prec.tags.map(t => (
                              <span key={t} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-sans">
                                #{t}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Footer Note */}
      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-blue-50">
        <div className="flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-slate-400" />
          <span>Citations are indexed from official law reporters (SCC, AIR, SCR) and applied under the Bharatiya Sakshya Adhiniyam, 2023.</span>
        </div>
        <span className="font-semibold text-blue-900">
          Showing {filteredPrecedents.length} precedent{filteredPrecedents.length === 1 ? '' : 's'}
        </span>
      </div>
    </section>
  );
};
