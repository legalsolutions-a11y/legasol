import React, { useState, useRef, useEffect } from 'react';
import { 
  Search, Mic, Square, BookOpen, Landmark, Scale, ShieldCheck, 
  AlertCircle, Volume2, Sparkles, ArrowRight, Gavel, FileText, CheckCircle2,
  Copy, Check, Download, ChevronRight, Filter, Book, ExternalLink, ShieldAlert,
  FileCheck2, Compass
} from 'lucide-react';
import { 
  STATUTORY_COMPENDIUM, 
  StatutoryItem, 
  processLegalQuery, 
  SearchResult 
} from '../data/statutoryAndConstitution';
import { 
  BNS_GAZETTE_CHAPTERS, 
  BNS_GAZETTE_SECTIONS, 
  BNSGazetteSection 
} from '../data/bnsGazetteFullText';
import { 
  BNSS_GAZETTE_CHAPTERS, 
  BNSS_GAZETTE_SECTIONS, 
  BNSSGazetteSection 
} from '../data/bnssGazetteFullText';
import { speakText, stopSpeaking, GlitchFreeSpeechRecognizer } from '../lib/speech';
import { HighlightKeyword, countKeywordMatches } from './HighlightKeyword';

export const StatutoryConstitutionExplorer: React.FC = () => {
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'All' | 'BNS 2023' | 'BNSS 2023' | 'BSA 2023' | 'Constitution of India'>('All');
  const [isListening, setIsListening] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<string | null>(null);
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [hasQueried, setHasQueried] = useState(false);

  // Dedicated Official BNS Gazette Box States
  const [selectedGazetteChapter, setSelectedGazetteChapter] = useState<string>('All');
  const [selectedSectionNum, setSelectedSectionNum] = useState<string>('103');
  const [gazetteSearchText, setGazetteSearchText] = useState<string>('');
  const [gazetteViewMode, setGazetteViewMode] = useState<'section-reader' | 'chapters-overview' | 'all-sections'>('section-reader');
  const [copiedGazette, setCopiedGazette] = useState(false);

  // Dedicated Official BNSS Gazette Box States (Completely separate box below BNS)
  const [selectedBnssChapter, setSelectedBnssChapter] = useState<string>('All');
  const [selectedBnssSectionNum, setSelectedBnssSectionNum] = useState<string>('173');
  const [bnssSearchText, setBnssSearchText] = useState<string>('');
  const [bnssViewMode, setBnssViewMode] = useState<'section-reader' | 'chapters-overview' | 'all-sections' | 'forms-overview'>('section-reader');
  const [copiedBnss, setCopiedBnss] = useState(false);

  const recognizerRef = useRef<GlitchFreeSpeechRecognizer | null>(null);
  const bnsBoxRef = useRef<HTMLDivElement>(null);
  const bnssBoxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    recognizerRef.current = new GlitchFreeSpeechRecognizer(
      (speechText, isFinal) => {
        setQuery(speechText);
        if (isFinal) {
          executeSearch(speechText);
        }
      },
      (status) => setVoiceStatus(status),
      'en-IN'
    );

    return () => {
      if (recognizerRef.current) recognizerRef.current.stop();
      stopSpeaking();
    };
  }, []);

  const executeSearch = (searchText: string) => {
    const q = searchText.trim();
    if (!q) {
      setSearchResults([]);
      setHasQueried(false);
      return;
    }

    setHasQueried(true);
    const results = processLegalQuery(q);
    setSearchResults(results);

    // If query matches a specific BNS section, jump to it in BNS reader
    const bnsMatch = q.match(/\b(?:bns|b\.n\.s\.?|section|sec\.?)\s*(\d{1,3})/i);
    if (bnsMatch) {
      const targetBns = BNS_GAZETTE_SECTIONS.find(s => s.sectionNumber === bnsMatch[1]);
      if (targetBns) {
        setSelectedSectionNum(targetBns.sectionNumber);
      }
    }

    // If query matches a BNSS section or concept, jump to it in BNSS reader
    const bnssMatch = q.match(/\b(?:bnss|b\.n\.s\.s\.?|crpc)\s*(\d{1,3})/i);
    if (bnssMatch) {
      const targetBnss = BNSS_GAZETTE_SECTIONS.find(s => s.sectionNumber === bnssMatch[1]);
      if (targetBnss) {
        setSelectedBnssSectionNum(targetBnss.sectionNumber);
      }
    } else {
      if (/bail|undertrial|479/i.test(q)) setSelectedBnssSectionNum('479');
      else if (/fir|zero fir|e-fir|173/i.test(q)) setSelectedBnssSectionNum('173');
      else if (/arrest|handcuff|35|43/i.test(q)) setSelectedBnssSectionNum('35');
      else if (/chargesheet|police report|193/i.test(q)) setSelectedBnssSectionNum('193');
      else if (/anticipatory|pre-arrest|482/i.test(q)) setSelectedBnssSectionNum('482');
      else if (/maintenance|wife maintenance|144/i.test(q)) setSelectedBnssSectionNum('144');
      else if (/trial in absentia|proclaimed offender|356/i.test(q)) setSelectedBnssSectionNum('356');
    }

    if (results.length > 0) {
      const top = results[0];
      const speechSummary = `Found ${results.length} relevant sections. Top match is ${top.matchedItem.act} ${top.matchedItem.number}: ${top.matchedItem.title}. ${
        top.matchedItem.punishment ? `Punishment: ${top.matchedItem.punishment}.` : ''
      } ${top.matchedItem.whomToBeTakenTo ? top.matchedItem.whomToBeTakenTo : ''}`;
      speakText(speechSummary);
    }
  };

  const handleVoiceToggle = () => {
    if (isListening) {
      if (recognizerRef.current) {
        const finalTxt = recognizerRef.current.stop();
        setIsListening(false);
        setVoiceStatus(null);
        executeSearch(finalTxt || query);
      }
    } else {
      setIsListening(true);
      setVoiceStatus('Listening to your legal question...');
      if (recognizerRef.current) {
        recognizerRef.current.start(query);
      }
    }
  };

  const handlePromptClick = (prompt: string) => {
    setQuery(prompt);
    executeSearch(prompt);
  };

  const jumpToBnsSection = (secNum: string) => {
    setSelectedSectionNum(secNum);
    setGazetteViewMode('section-reader');
    if (bnsBoxRef.current) {
      bnsBoxRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const jumpToBnssSection = (secNum: string) => {
    setSelectedBnssSectionNum(secNum);
    setBnssViewMode('section-reader');
    if (bnssBoxRef.current) {
      bnssBoxRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const filteredItems = STATUTORY_COMPENDIUM.filter((item) => {
    if (activeCategory !== 'All' && item.act !== activeCategory) {
      return false;
    }
    if (!query.trim()) return true;

    const q = query.toLowerCase();
    return (
      item.number.toLowerCase().includes(q) ||
      item.title.toLowerCase().includes(q) ||
      (item.legacyReference && item.legacyReference.toLowerCase().includes(q)) ||
      item.description.toLowerCase().includes(q) ||
      item.keywords.some((k) => k.toLowerCase().includes(q))
    );
  });

  // Current selected BNS section
  const activeBnsSection = BNS_GAZETTE_SECTIONS.find(
    (s) => s.sectionNumber === selectedSectionNum
  ) || BNS_GAZETTE_SECTIONS[0];

  // Filtered BNS Gazette Sections
  const filteredBnsSections = BNS_GAZETTE_SECTIONS.filter((s) => {
    if (selectedGazetteChapter !== 'All' && s.chapterNumber !== selectedGazetteChapter) {
      return false;
    }
    if (!gazetteSearchText.trim()) return true;
    const term = gazetteSearchText.toLowerCase();
    return (
      s.sectionNumber.includes(term) ||
      s.marginalTitle.toLowerCase().includes(term) ||
      s.statutoryText.toLowerCase().includes(term) ||
      s.ipcEquivalent.toLowerCase().includes(term) ||
      s.keywords.some(k => k.toLowerCase().includes(term))
    );
  });

  // Current selected BNSS section
  const activeBnssSection = BNSS_GAZETTE_SECTIONS.find(
    (s) => s.sectionNumber === selectedBnssSectionNum
  ) || BNSS_GAZETTE_SECTIONS[0];

  // Filtered BNSS Gazette Sections
  const filteredBnssSections = BNSS_GAZETTE_SECTIONS.filter((s) => {
    if (selectedBnssChapter !== 'All' && s.chapterNumber !== selectedBnssChapter) {
      return false;
    }
    if (!bnssSearchText.trim()) return true;
    const term = bnssSearchText.toLowerCase();
    return (
      s.sectionNumber.includes(term) ||
      s.marginalTitle.toLowerCase().includes(term) ||
      s.statutoryText.toLowerCase().includes(term) ||
      s.crpcEquivalent.toLowerCase().includes(term) ||
      s.keywords.some(k => k.toLowerCase().includes(term))
    );
  });

  const handleCopyBnsText = () => {
    if (!activeBnsSection) return;
    const fullText = `THE BHARATIYA NYAYA SANHITA, 2023 (ACT NO. 45 OF 2023)\n${activeBnsSection.chapter}\n\nSection ${activeBnsSection.sectionNumber}. ${activeBnsSection.marginalTitle}\n[Formerly: ${activeBnsSection.ipcEquivalent}]\n\n${activeBnsSection.statutoryText}\n\n${activeBnsSection.explanationsAndIllustrations || ''}\n\nCLASSIFICATION: ${activeBnsSection.cognizable ? 'Cognizable' : 'Non-Cognizable'} | ${activeBnsSection.bailable ? 'Bailable' : 'Non-Bailable'}\nPUNISHMENT: ${activeBnsSection.punishment}\nCOURT: ${activeBnsSection.court}\nWHOM TO BE TAKEN TO: ${activeBnsSection.whomToBeTakenTo}`;
    navigator.clipboard.writeText(fullText);
    setCopiedGazette(true);
    setTimeout(() => setCopiedGazette(false), 2000);
  };

  const handleCopyBnssText = () => {
    if (!activeBnssSection) return;
    const fullText = `THE BHARATIYA NAGARIK SURAKSHA SANHITA, 2023 (ACT NO. 46 OF 2023)\n${activeBnssSection.chapter}\n\nSection ${activeBnssSection.sectionNumber}. ${activeBnssSection.marginalTitle}\n[Formerly: ${activeBnssSection.crpcEquivalent}]\n\n${activeBnssSection.statutoryText}\n\nPROCEDURAL CATEGORY: ${activeBnssSection.category}\nSTATUTORY TIMELINES: ${activeBnssSection.keyTimelines || 'Standard procedure'}\nCOMPETENT COURT: ${activeBnssSection.court}\nRIGHTS & ACCUSED MANDATES: ${activeBnssSection.whomToBeTakenTo}`;
    navigator.clipboard.writeText(fullText);
    setCopiedBnss(true);
    setTimeout(() => setCopiedBnss(false), 2000);
  };

  const handleDownloadBnssText = () => {
    if (!activeBnssSection) return;
    const fullText = `══════════════════════════════════════════════════════════════════
THE GAZETTE OF INDIA EXTRAORDINARY (NO. 54, NEW DELHI, DEC 25, 2023)
MINISTRY OF LAW AND JUSTICE (LEGISLATIVE DEPARTMENT)
THE BHARATIYA NAGARIK SURAKSHA SANHITA, 2023 (ACT NO. 46 OF 2023)
══════════════════════════════════════════════════════════════════

${activeBnssSection.chapter}

SECTION ${activeBnssSection.sectionNumber}: ${activeBnssSection.marginalTitle.toUpperCase()}
[Corresponding CrPC Provision: ${activeBnssSection.crpcEquivalent}]

STATUTORY TEXT (OFFICIAL GAZETTE):
${activeBnssSection.statutoryText}

PROCEDURAL & JUDICIAL SAFEGUARDS:
• Category:       ${activeBnssSection.category}
• Key Timelines:  ${activeBnssSection.keyTimelines || 'As prescribed by trial court'}
• Court:          ${activeBnssSection.court}
• Accused Rights: ${activeBnssSection.whomToBeTakenTo}

${activeBnssSection.keyChangesIn2023 ? `2023 REFORMS & KEY CHANGES:\n${activeBnssSection.keyChangesIn2023}\n` : ''}
══════════════════════════════════════════════════════════════════
Verified Official Publication · legasol.in
══════════════════════════════════════════════════════════════════`;

    const blob = new Blob([fullText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BNSS_2023_Section_${activeBnssSection.sectionNumber}_Gazette_Text.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto pb-20">
      {/* 1. Header */}
      <div className="text-center pt-2">
        <a 
          href="https://legasol.in" 
          target="_blank" 
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 px-4 py-1 rounded-full border border-slate-300 bg-white text-xs text-slate-700 font-medium tracking-wide shadow-sm hover:border-slate-400 transition-colors"
        >
          <Landmark className="w-3.5 h-3.5 text-[#b08958]" />
          <span><strong className="text-red-600 font-extrabold">LEGA</strong><strong className="text-red-600 font-extrabold">SOL</strong>.IN • STATUTORY COMPENDIUM</span>
        </a>

        <h1 className="font-headline font-bold text-3xl sm:text-4xl text-[#1e293b] mt-4 tracking-tight">
          <span className="text-red-600 font-extrabold">Lega</span><span className="text-red-600 font-extrabold">Sol</span> Bharatiya Laws & Indian Constitution Explorer
        </h1>

        <p className="text-sm text-slate-600 max-w-2xl mx-auto mt-2 leading-relaxed">
          Ask questions naturally or search across the complete official text of the <strong>Bharatiya Nyaya Sanhita, 2023 (Act 45 of 2023)</strong>, <strong>Bharatiya Nagarik Suraksha Sanhita, 2023 (Act 46 of 2023)</strong>, <strong>Bharatiya Sakshya Adhiniyam</strong>, and <strong>The Constitution of India</strong>.
        </p>
      </div>

      {/* 2. 2026 AI Search Bar with Voice */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="relative flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                if (e.target.value.trim().length > 2) {
                  executeSearch(e.target.value);
                } else if (!e.target.value.trim()) {
                  setHasQueried(false);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  executeSearch(query);
                }
              }}
              placeholder="Ask anything e.g. 'what sections are used for a murder', 'bail under section 479', 'notice under 35(3)', 'trial in absentia 356'..."
              className="w-full bg-slate-50 hover:bg-white focus:bg-white border border-slate-300 focus:border-blue-600 rounded-xl pl-12 pr-4 py-3.5 text-xs sm:text-sm text-slate-800 focus:outline-none transition-all placeholder:text-slate-400 font-normal shadow-inner"
            />
          </div>

          {/* Voice Search Button */}
          <button
            onClick={handleVoiceToggle}
            className={`p-3.5 rounded-xl text-white font-medium shadow-sm transition-all flex items-center justify-center cursor-pointer ${
              isListening 
                ? 'bg-red-600 animate-pulse ring-2 ring-red-400 ring-offset-1' 
                : 'bg-[#ef4444] hover:bg-red-600'
            }`}
            title="Ask with Voice / 2026 AI Voice Query"
          >
            {isListening ? <Square className="w-5 h-5 fill-white" /> : <Mic className="w-5 h-5" />}
          </button>

          <button
            onClick={() => executeSearch(query)}
            className="px-5 py-3.5 rounded-xl bg-[#c49a6c] hover:bg-[#b3895b] text-white text-xs sm:text-sm font-bold shadow-sm transition-all cursor-pointer hidden sm:flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Search</span>
          </button>
        </div>

        {query.trim().length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs bg-amber-50/90 border border-amber-200/90 px-3.5 py-2 rounded-xl text-amber-900 shadow-2xs animate-in fade-in duration-150">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse shrink-0"></span>
              <span>
                Real-Time Keyword Highlighting: <strong className="font-mono bg-white px-2 py-0.5 rounded border border-amber-300 text-amber-950 font-bold">"{query.trim()}"</strong>
              </span>
            </div>
            <span className="text-[11px] text-amber-800 font-medium">
              Automatically highlighted in yellow across all statutory and PDF text as you type
            </span>
          </div>
        )}

        {voiceStatus && (
          <div className="flex items-center gap-2 text-xs text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-200 font-medium">
            <span className="w-2 h-2 rounded-full bg-red-600 animate-ping"></span>
            <span>{voiceStatus}</span>
          </div>
        )}

        {/* Quick Question Chips */}
        <div className="pt-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-2">
            FREQUENTLY ASKED LEGAL QUERIES:
          </span>
          <div className="flex flex-wrap gap-2">
            {[
              "What sections are used for a murder?",
              "Undertrial bail for first time offender (BNSS 479)",
              "Police notice of appearance (BNSS 35(3))",
              "Anticipatory bail procedure (BNSS 482)",
              "Trial in absentia of proclaimed absconders (BNSS 356)",
              "Mobile & chain snatching (BNS 304)",
              "False promise to marry (BNS 69)",
              "Article 21: Right to life & liberty"
            ].map((p, idx) => (
              <button
                key={idx}
                onClick={() => handlePromptClick(p)}
                className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 border border-slate-200 text-xs text-slate-700 font-medium transition-all cursor-pointer"
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 3. 2026 AI Search Results View (If queried) */}
      {hasQueried && searchResults.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#c49a6c]" />
              <h2 className="font-headline text-lg font-bold text-[#1e293b]">
                2026 AI Legal Verdict & Statutory Analysis
              </h2>
            </div>
            <span className="text-xs text-slate-500 font-medium">
              {searchResults.length} match{searchResults.length > 1 ? 'es' : ''} found
            </span>
          </div>

          <div className="space-y-4">
            {searchResults.map((res, idx) => {
              const item = res.matchedItem;
              return (
                <div
                  key={idx}
                  className="bg-white border border-slate-200 hover:border-blue-300 rounded-2xl p-6 shadow-sm space-y-4 transition-all"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 mb-1.5">
                        <span className={`font-mono font-bold text-xs px-3 py-1 rounded-lg shadow-2xs text-white ${
                          item.act === 'BNSS 2023' ? 'bg-[#0f766e]' : item.act === 'BNS 2023' ? 'bg-blue-700' : 'bg-slate-800'
                        }`}>
                          {item.act} • {item.number}
                        </span>

                        {item.legacyReference && (
                          <span className="bg-slate-100 text-slate-700 font-mono text-xs px-2.5 py-1 rounded-lg border border-slate-200">
                            Formerly: {item.legacyReference}
                          </span>
                        )}

                        <span className="text-xs font-semibold text-slate-500 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200">
                          {item.category}
                        </span>
                      </div>

                      <h3 className="font-headline text-lg font-bold text-[#1e293b]">
                        <HighlightKeyword text={item.title} queries={[query]} />
                      </h3>
                      {item.hindiTitle && (
                        <div className="text-xs text-blue-800 font-medium mt-0.5">
                          {item.hindiTitle}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => speakText(`${item.act} ${item.number}. ${item.title}. ${item.description}. ${item.punishment ? `Punishment is ${item.punishment}.` : ''} ${item.whomToBeTakenTo || ''}`)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-blue-700 shadow-2xs transition-all cursor-pointer"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>Listen / सुनें</span>
                      </button>

                      {item.act === 'BNS 2023' && (
                        <button
                          onClick={() => {
                            const match = item.number.match(/\d+/);
                            if (match) jumpToBnsSection(match[0]);
                          }}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1e293b] hover:bg-slate-800 text-white text-xs font-semibold shadow-2xs transition-all cursor-pointer"
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>View in BNS Box</span>
                        </button>
                      )}

                      {item.act === 'BNSS 2023' && (
                        <button
                          onClick={() => {
                            const match = item.number.match(/\d+/);
                            if (match) jumpToBnssSection(match[0]);
                          }}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0f766e] hover:bg-teal-800 text-white text-xs font-semibold shadow-2xs transition-all cursor-pointer"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>View in BNSS Box</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Offense Badges */}
                  <div className="flex flex-wrap gap-2 text-xs">
                    {item.cognizable !== undefined && (
                      <span className={`px-2.5 py-1 rounded-lg font-bold ${
                        item.cognizable ? 'bg-rose-100 text-rose-800 border border-rose-200' : 'bg-slate-100 text-slate-700 border border-slate-200'
                      }`}>
                        {item.cognizable ? 'Cognizable (संज्ञेय — पुलिस बिना वारंट गिरफ्तार कर सकती है)' : 'Non-Cognizable (असंज्ञेय)'}
                      </span>
                    )}

                    {item.bailable !== undefined && (
                      <span className={`px-2.5 py-1 rounded-lg font-bold ${
                        item.bailable ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-amber-100 text-amber-900 border border-amber-200'
                      }`}>
                        {item.bailable ? 'Bailable (जमानती अपराध)' : 'Non-Bailable (गैर-जमानती अपराध)'}
                      </span>
                    )}

                    {item.court && (
                      <span className="bg-slate-100 text-slate-800 px-2.5 py-1 rounded-lg font-medium border border-slate-200 flex items-center gap-1">
                        <Gavel className="w-3.5 h-3.5 text-slate-500" />
                        <span>Court: {item.court}</span>
                      </span>
                    )}
                  </div>

                  {/* Direct Answers to User Question */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    {item.whomToBeTakenTo && (
                      <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200 space-y-1">
                        <span className="text-[10px] font-bold text-blue-900 uppercase tracking-wider block">
                          WHOM SHOULD HE BE TAKEN TO? (सक्षम अधिकारी)
                        </span>
                        <p className="text-xs text-blue-950 font-medium leading-relaxed">
                          <HighlightKeyword text={item.whomToBeTakenTo} queries={[query]} />
                        </p>
                      </div>
                    )}

                    {item.punishment && (
                      <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200 space-y-1">
                        <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block">
                          PRISON SENTENCE & VERDICT (सजा व कारावास)
                        </span>
                        <p className="text-xs text-amber-950 font-bold leading-relaxed">
                          <HighlightKeyword text={item.punishment} queries={[query]} />
                        </p>
                        {item.prisonYears && (
                          <div className="text-[11px] text-amber-800 font-semibold">
                            Sentence Term: {item.prisonYears}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* AI Explanation & Gazette Verbatim Preview */}
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-800 leading-relaxed space-y-2">
                    <div className="font-bold text-slate-900 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-[#b08958]" />
                      <span>2026 AI Legal Advisory:</span>
                    </div>
                    <p className="text-slate-700">
                      <HighlightKeyword text={res.aiExplanation} queries={[query]} />
                    </p>
                    {item.gazetteVerbatimText && (
                      <div className="pt-2 border-t border-slate-200">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                          Official Gazette of India Verbatim Text:
                        </span>
                        <div className="bg-white p-3 rounded-lg border border-slate-300 font-mono text-[11px] text-slate-800 whitespace-pre-wrap">
                          <HighlightKeyword text={item.gazetteVerbatimText} queries={[query]} />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. DEDICATED BOX 1: THE GAZETTE OF INDIA (BHARATIYA NYAYA SANHITA, 2023) */}
      <div 
        ref={bnsBoxRef}
        className="bg-white border-2 border-[#c49a6c]/50 rounded-2xl p-6 sm:p-7 shadow-sm space-y-6"
      >
        {/* Official Gazette Emblem & Header */}
        <div className="border-b border-slate-200 pb-5 text-center space-y-2">
          <div className="flex items-center justify-center gap-2 text-xs font-bold tracking-widest text-[#b08958] uppercase">
            <Landmark className="w-4 h-4" />
            <span>भारत का राजपत्र · THE GAZETTE OF INDIA EXTRAORDINARY</span>
          </div>

          <div className="font-serif text-[11px] text-slate-500">
            PART II — Section 1 · PUBLISHED BY AUTHORITY · No. 53 · NEW DELHI, MONDAY, DECEMBER 25, 2023 / PAUSHA 4, 1945 (SAKA)
          </div>

          <h2 className="font-headline font-extrabold text-2xl sm:text-3xl text-[#1e293b] tracking-tight">
            THE BHARATIYA NYAYA SANHITA, 2023
          </h2>

          <div className="text-xs font-mono font-semibold text-slate-700">
            ACT NO. 45 OF 2023 · Assented by the President of India on 25th December, 2023
          </div>

          <p className="text-xs text-slate-600 max-w-2xl mx-auto italic">
            "An Act to consolidate and amend the provisions relating to offences and for matters connected therewith or incidental thereto."
          </p>

          <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2 text-xs">
            <span className="bg-[#fef9f2] text-[#b08958] border border-[#f5e6d3] px-3 py-1 rounded-full font-bold">
              Complete 20 Chapters
            </span>
            <span className="bg-[#fef9f2] text-[#b08958] border border-[#f5e6d3] px-3 py-1 rounded-full font-bold">
              358 Total Sections (Sections 1 – 358)
            </span>
            <span className="bg-blue-50 text-blue-800 border border-blue-200 px-3 py-1 rounded-full font-bold">
              Official Verbatim Gazette of India PDF Text
            </span>
          </div>
        </div>

        {/* View Mode Switcher inside the BNS Box */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setGazetteViewMode('section-reader')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                gazetteViewMode === 'section-reader'
                  ? 'bg-[#1e293b] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Section Text Reader
            </button>

            <button
              onClick={() => setGazetteViewMode('chapters-overview')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                gazetteViewMode === 'chapters-overview'
                  ? 'bg-[#1e293b] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              20 Chapters Directory
            </button>

            <button
              onClick={() => setGazetteViewMode('all-sections')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                gazetteViewMode === 'all-sections'
                  ? 'bg-[#1e293b] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Browse All BNS Sections ({BNS_GAZETTE_SECTIONS.length})
            </button>
          </div>

          <div className="text-xs text-slate-500 font-mono">
            Viewing Section {activeBnsSection.sectionNumber} of 358
          </div>
        </div>

        {/* Filter Controls within the BNS Box */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              FILTER BY CHAPTER (I – XX)
            </label>
            <select
              value={selectedGazetteChapter}
              onChange={(e) => setSelectedGazetteChapter(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-blue-600 font-medium"
            >
              <option value="All">All 20 Chapters</option>
              {BNS_GAZETTE_CHAPTERS.map((ch) => (
                <option key={ch.number} value={ch.number}>
                  {ch.number}: {ch.title} ({ch.sectionRange})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              SELECT BNS SECTION (1 – 358)
            </label>
            <select
              value={selectedSectionNum}
              onChange={(e) => {
                setSelectedSectionNum(e.target.value);
                setGazetteViewMode('section-reader');
              }}
              className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-blue-600 font-medium"
            >
              {filteredBnsSections.map((sec) => (
                <option key={sec.sectionNumber} value={sec.sectionNumber}>
                  Section {sec.sectionNumber} — {sec.marginalTitle}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              SEARCH INSIDE BNS GAZETTE
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={gazetteSearchText}
                onChange={(e) => setGazetteSearchText(e.target.value)}
                placeholder="Search word e.g. murder, snatching, fraud..."
                className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-2.5 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-600"
              />
            </div>
          </div>
        </div>

        {/* MODE A: BNS SECTION VERBATIM GAZETTE READER */}
        {gazetteViewMode === 'section-reader' && activeBnsSection && (
          <div className="space-y-5 bg-[#fffdfa] border border-slate-200 rounded-xl p-5 sm:p-6 shadow-2xs">
            <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-4">
              <div>
                <span className="text-xs font-bold text-[#b08958] uppercase tracking-wide block mb-1">
                  {activeBnsSection.chapter}
                </span>

                <h3 className="font-headline text-xl sm:text-2xl font-bold text-[#1e293b]">
                  Section {activeBnsSection.sectionNumber}. <HighlightKeyword text={activeBnsSection.marginalTitle} queries={[query, gazetteSearchText]} />
                </h3>

                <div className="flex flex-wrap items-center gap-2 mt-2">
                  <span className="bg-slate-100 text-slate-700 text-xs font-mono font-medium px-2.5 py-0.5 rounded border border-slate-200">
                    Corresponding: {activeBnsSection.ipcEquivalent}
                  </span>

                  {activeBnsSection.isNewProvision && (
                    <span className="bg-amber-100 text-amber-900 text-xs font-bold px-2.5 py-0.5 rounded border border-amber-200">
                      ★ New 2023 Enactment
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => speakText(`The Bharatiya Nyaya Sanhita, 2023. Section ${activeBnsSection.sectionNumber}. ${activeBnsSection.marginalTitle}. ${activeBnsSection.statutoryText}`)}
                  className="flex items-center gap-1.5 bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen to Text</span>
                </button>

                <button
                  onClick={handleCopyBnsText}
                  className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 transition-all cursor-pointer"
                >
                  {copiedGazette ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedGazette ? "Copied" : "Copy"}</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">COGNIZABILITY</span>
                <span className={`font-bold mt-0.5 block ${activeBnsSection.cognizable ? 'text-rose-700' : 'text-slate-700'}`}>
                  {activeBnsSection.cognizable ? 'Cognizable (No Warrant)' : 'Non-Cognizable'}
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">BAIL STATUS</span>
                <span className={`font-bold mt-0.5 block ${activeBnsSection.bailable ? 'text-emerald-700' : 'text-amber-800'}`}>
                  {activeBnsSection.bailable ? 'Bailable (As of Right)' : 'Non-Bailable'}
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">TRIAL COURT</span>
                <span className="font-bold text-slate-800 mt-0.5 block">
                  {activeBnsSection.court}
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">COMPOUNDABLE</span>
                <span className="font-bold text-slate-800 mt-0.5 block">
                  {activeBnsSection.compoundable ? 'Yes (Settlement Allowed)' : 'No (Non-Compoundable)'}
                </span>
              </div>
            </div>

            {/* Real-time Keyword Match Badge */}
            {countKeywordMatches(activeBnsSection.statutoryText, [query, gazetteSearchText]) > 0 && (
              <div className="flex items-center justify-between text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-200 px-3.5 py-2 rounded-xl">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>
                    <strong>{countKeywordMatches(activeBnsSection.statutoryText, [query, gazetteSearchText])}</strong> keyword match{countKeywordMatches(activeBnsSection.statutoryText, [query, gazetteSearchText]) === 1 ? '' : 'es'} highlighted in this BNS section for "{query || gazetteSearchText}"
                  </span>
                </div>
                <span className="text-[10px] font-mono text-amber-700 bg-amber-100 px-2 py-0.5 rounded font-bold">
                  Highlight Active
                </span>
              </div>
            )}

            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
                OFFICIAL STATUTORY TEXT (THE GAZETTE OF INDIA EXTRAORDINARY):
              </span>
              <div className="bg-white border border-slate-300 rounded-xl p-5 font-mono text-xs text-slate-900 whitespace-pre-wrap leading-relaxed shadow-inner">
                <HighlightKeyword text={activeBnsSection.statutoryText} queries={[query, gazetteSearchText]} />
              </div>
            </div>

            {activeBnsSection.explanationsAndIllustrations && (
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
                  EXPLANATIONS & STATUTORY ILLUSTRATIONS:
                </span>
                <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-4 text-xs text-slate-800 whitespace-pre-wrap leading-relaxed">
                  <HighlightKeyword text={activeBnsSection.explanationsAndIllustrations} queries={[query, gazetteSearchText]} />
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <div className="p-4 rounded-xl bg-amber-50/80 border border-amber-200 space-y-1">
                <span className="text-[10px] font-bold text-amber-900 uppercase tracking-wider block">
                  STATUTORY SENTENCE & VERDICT (सजा व कारावास)
                </span>
                <div className="text-xs text-amber-950 font-bold leading-relaxed">
                  {activeBnsSection.punishment}
                </div>
                <div className="text-[11px] text-amber-800 font-medium">
                  Prescribed Term: {activeBnsSection.prisonYears}
                </div>
              </div>

              <div className="p-4 rounded-xl bg-blue-50/80 border border-blue-200 space-y-1">
                <span className="text-[10px] font-bold text-blue-900 uppercase tracking-wider block">
                  WHOM ACCUSED MUST BE PRODUCED BEFORE (सक्षम अधिकारी)
                </span>
                <div className="text-xs text-blue-950 font-medium leading-relaxed">
                  {activeBnsSection.whomToBeTakenTo}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* MODE B: BNS 20 CHAPTERS DIRECTORY OVERVIEW */}
        {gazetteViewMode === 'chapters-overview' && (
          <div className="space-y-4">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
              ALL 20 CHAPTERS OF THE BHARATIYA NYAYA SANHITA, 2023:
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {BNS_GAZETTE_CHAPTERS.map((ch) => (
                <div
                  key={ch.number}
                  onClick={() => {
                    setSelectedGazetteChapter(ch.number);
                    setGazetteViewMode('all-sections');
                  }}
                  className="bg-white border border-slate-200 hover:border-[#c49a6c] rounded-xl p-4 shadow-2xs cursor-pointer transition-all space-y-1.5 group"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-blue-900 group-hover:text-[#c49a6c]">
                      {ch.number}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {ch.sectionRange}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-[#1e293b]">
                    {ch.title}
                  </h4>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {ch.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODE C: BROWSE ALL BNS SECTIONS */}
        {gazetteViewMode === 'all-sections' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Showing {filteredBnsSections.length} BNS sections</span>
              {selectedGazetteChapter !== 'All' && (
                <button
                  onClick={() => setSelectedGazetteChapter('All')}
                  className="text-blue-700 font-semibold hover:underline cursor-pointer"
                >
                  Clear Chapter Filter
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[500px] overflow-y-auto pr-1">
              {filteredBnsSections.map((sec) => (
                <div
                  key={sec.sectionNumber}
                  onClick={() => {
                    setSelectedSectionNum(sec.sectionNumber);
                    setGazetteViewMode('section-reader');
                  }}
                  className={`border rounded-xl p-3.5 cursor-pointer transition-all shadow-2xs space-y-1.5 ${
                    selectedSectionNum === sec.sectionNumber
                      ? 'bg-blue-50/60 border-blue-400 ring-1 ring-blue-300'
                      : 'bg-white border-slate-200 hover:border-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs bg-slate-900 text-white px-2 py-0.5 rounded">
                      Section {sec.sectionNumber}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      {sec.ipcEquivalent}
                    </span>
                  </div>

                  <h5 className="font-bold text-xs text-slate-900">
                    <HighlightKeyword text={sec.marginalTitle} queries={[query, gazetteSearchText]} />
                  </h5>

                  <p className="text-[11px] text-slate-600 line-clamp-2">
                    <HighlightKeyword text={sec.statutoryText} queries={[query, gazetteSearchText]} />
                  </p>

                  <div className="flex items-center gap-2 pt-1 text-[10px] text-slate-500">
                    <span className={sec.cognizable ? 'text-red-700 font-semibold' : 'text-slate-600'}>
                      {sec.cognizable ? 'Cognizable' : 'Non-Cognizable'}
                    </span>
                    <span>•</span>
                    <span className={sec.bailable ? 'text-emerald-700 font-semibold' : 'text-amber-800 font-semibold'}>
                      {sec.bailable ? 'Bailable' : 'Non-Bailable'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 5. DEDICATED BOX 2: THE GAZETTE OF INDIA (BHARATIYA NAGARIK SURAKSHA SANHITA, 2023) */}
      {/* Placed below the BNS box in a completely separate box as requested */}
      <div 
        ref={bnssBoxRef}
        className="bg-white border-2 border-teal-600/40 rounded-2xl p-6 sm:p-7 shadow-sm space-y-6"
      >
        {/* Official Gazette BNSS Header */}
        <div className="border-b border-slate-200 pb-5 text-center space-y-2">
          <div className="flex items-center justify-center gap-2 text-xs font-bold tracking-widest text-[#0f766e] uppercase">
            <ShieldCheck className="w-4 h-4" />
            <span>भारत का राजपत्र · THE GAZETTE OF INDIA EXTRAORDINARY</span>
          </div>

          <div className="font-serif text-[11px] text-slate-500">
            PART II — Section 1 · PUBLISHED BY AUTHORITY · No. 54 · NEW DELHI, MONDAY, DECEMBER 25, 2023 / PAUSHA 4, 1945 (SAKA)
          </div>

          <h2 className="font-headline font-extrabold text-2xl sm:text-3xl text-[#0f766e] tracking-tight">
            THE BHARATIYA NAGARIK SURAKSHA SANHITA, 2023
          </h2>

          <div className="text-xs font-mono font-semibold text-slate-700">
            ACT NO. 46 OF 2023 · Assented by the President of India on 25th December, 2023
          </div>

          <p className="text-xs text-slate-600 max-w-2xl mx-auto italic">
            "An Act to consolidate and amend the law relating to Criminal Procedure."
          </p>

          <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2 text-xs">
            <span className="bg-teal-50 text-teal-800 border border-teal-200 px-3 py-1 rounded-full font-bold">
              Complete 39 Chapters
            </span>
            <span className="bg-teal-50 text-teal-800 border border-teal-200 px-3 py-1 rounded-full font-bold">
              531 Total Sections (Sections 1 – 531)
            </span>
            <span className="bg-blue-50 text-blue-800 border border-blue-200 px-3 py-1 rounded-full font-bold">
              First Schedule (Offence Classification)
            </span>
            <span className="bg-purple-50 text-purple-800 border border-purple-200 px-3 py-1 rounded-full font-bold">
              Second Schedule (58 Statutory Forms)
            </span>
          </div>
        </div>

        {/* View Mode Switcher inside the BNSS Box */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setBnssViewMode('section-reader')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                bnssViewMode === 'section-reader'
                  ? 'bg-[#0f766e] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              BNSS Section Reader
            </button>

            <button
              onClick={() => setBnssViewMode('chapters-overview')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                bnssViewMode === 'chapters-overview'
                  ? 'bg-[#0f766e] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              39 Chapters Directory
            </button>

            <button
              onClick={() => setBnssViewMode('all-sections')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                bnssViewMode === 'all-sections'
                  ? 'bg-[#0f766e] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Browse All BNSS Sections ({BNSS_GAZETTE_SECTIONS.length})
            </button>

            <button
              onClick={() => setBnssViewMode('forms-overview')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                bnssViewMode === 'forms-overview'
                  ? 'bg-[#0f766e] text-white shadow-sm'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              58 Statutory Forms & Schedules
            </button>
          </div>

          <div className="text-xs text-slate-500 font-mono">
            Viewing BNSS Section {activeBnssSection.sectionNumber} of 531
          </div>
        </div>

        {/* Filter Controls within the BNSS Box */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-xl bg-slate-50 border border-slate-200">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              FILTER BY CHAPTER (I – XXXIX)
            </label>
            <select
              value={selectedBnssChapter}
              onChange={(e) => setSelectedBnssChapter(e.target.value)}
              className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-teal-600 font-medium"
            >
              <option value="All">All 39 Chapters</option>
              {BNSS_GAZETTE_CHAPTERS.map((ch) => (
                <option key={ch.number} value={ch.number}>
                  {ch.number}: {ch.title} ({ch.sectionRange})
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              SELECT BNSS SECTION (1 – 531)
            </label>
            <select
              value={selectedBnssSectionNum}
              onChange={(e) => {
                setSelectedBnssSectionNum(e.target.value);
                setBnssViewMode('section-reader');
              }}
              className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs text-slate-800 focus:outline-none focus:border-teal-600 font-medium"
            >
              {filteredBnssSections.map((sec) => (
                <option key={sec.sectionNumber} value={sec.sectionNumber}>
                  Section {sec.sectionNumber} — {sec.marginalTitle}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              SEARCH INSIDE BNSS GAZETTE
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={bnssSearchText}
                onChange={(e) => setBnssSearchText(e.target.value)}
                placeholder="Search word e.g. bail, notice, handcuff, fir..."
                className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-2.5 py-2 text-xs text-slate-800 focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>
        </div>

        {/* MODE A: BNSS SECTION VERBATIM GAZETTE READER */}
        {bnssViewMode === 'section-reader' && activeBnssSection && (
          <div className="space-y-5 bg-[#fafffd] border border-teal-200 rounded-xl p-5 sm:p-6 shadow-2xs">
            <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-4">
              <div>
                <span className="text-xs font-bold text-[#0f766e] uppercase tracking-wide block mb-1">
                  {activeBnssSection.chapter}
                </span>

                <h3 className="font-headline text-xl sm:text-2xl font-bold text-[#1e293b]">
                  Section {activeBnssSection.sectionNumber}. <HighlightKeyword text={activeBnssSection.marginalTitle} queries={[query, bnssSearchText]} highlightClassName="bg-teal-200 text-teal-950 font-bold px-0.5 rounded shadow-2xs" />
                </h3>

                <div className="flex flex-wrap items-center gap-2 mt-2">
                  <span className="bg-slate-100 text-slate-700 text-xs font-mono font-medium px-2.5 py-0.5 rounded border border-slate-200">
                    Corresponding: {activeBnssSection.crpcEquivalent}
                  </span>

                  {activeBnssSection.isNewProvision && (
                    <span className="bg-emerald-100 text-emerald-900 text-xs font-bold px-2.5 py-0.5 rounded border border-emerald-200">
                      ★ Landmark 2023 Reform
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => speakText(`The Bharatiya Nagarik Suraksha Sanhita, 2023. Section ${activeBnssSection.sectionNumber}. ${activeBnssSection.marginalTitle}. ${activeBnssSection.statutoryText}`)}
                  className="flex items-center gap-1.5 bg-[#0f766e] hover:bg-teal-800 text-white text-xs font-semibold px-3 py-1.5 rounded-lg shadow-sm transition-all cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Listen to Text</span>
                </button>

                <button
                  onClick={handleCopyBnssText}
                  className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 transition-all cursor-pointer"
                >
                  {copiedBnss ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedBnss ? "Copied" : "Copy"}</span>
                </button>

                <button
                  onClick={handleDownloadBnssText}
                  className="flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-200 transition-all cursor-pointer"
                  title="Download BNSS section text"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
              </div>
            </div>

            {/* Quick Procedural Attributes */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">CATEGORY</span>
                <span className="font-bold text-teal-800 mt-0.5 block truncate">
                  {activeBnssSection.category}
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">STATUTORY TIMELINE</span>
                <span className="font-bold text-slate-800 mt-0.5 block">
                  {activeBnssSection.keyTimelines || 'Standard procedure'}
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">COMPETENT FORUM</span>
                <span className="font-bold text-slate-800 mt-0.5 block">
                  {activeBnssSection.court}
                </span>
              </div>

              <div className="p-2.5 rounded-lg bg-white border border-slate-200 text-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase block">FORMER CRPC</span>
                <span className="font-bold text-slate-800 mt-0.5 block">
                  {activeBnssSection.crpcEquivalent}
                </span>
              </div>
            </div>

            {/* Real-time Keyword Match Badge */}
            {countKeywordMatches(activeBnssSection.statutoryText, [query, bnssSearchText]) > 0 && (
              <div className="flex items-center justify-between text-xs font-semibold bg-teal-50 text-teal-900 border border-teal-200 px-3.5 py-2 rounded-xl">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                  <span>
                    <strong>{countKeywordMatches(activeBnssSection.statutoryText, [query, bnssSearchText])}</strong> keyword match{countKeywordMatches(activeBnssSection.statutoryText, [query, bnssSearchText]) === 1 ? '' : 'es'} highlighted in this BNSS section for "{query || bnssSearchText}"
                  </span>
                </div>
                <span className="text-[10px] font-mono text-teal-700 bg-teal-100 px-2 py-0.5 rounded font-bold">
                  Highlight Active
                </span>
              </div>
            )}

            {/* Official Gazette Verbatim Text */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
                OFFICIAL STATUTORY TEXT (THE GAZETTE OF INDIA EXTRAORDINARY, NO. 54):
              </span>
              <div className="bg-white border border-slate-300 rounded-xl p-5 font-mono text-xs text-slate-900 whitespace-pre-wrap leading-relaxed shadow-inner">
                <HighlightKeyword 
                  text={activeBnssSection.statutoryText} 
                  queries={[query, bnssSearchText]} 
                  highlightClassName="bg-amber-200 text-amber-950 font-bold px-0.5 rounded shadow-2xs"
                />
              </div>
            </div>

            {/* Accused & Victim Procedural Mandates */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
              <div className="p-4 rounded-xl bg-teal-50/80 border border-teal-200 space-y-1">
                <span className="text-[10px] font-bold text-teal-900 uppercase tracking-wider block">
                  ACCUSED RIGHTS & POLICE MANDATES (नागरिक सुरक्षा अधिकार)
                </span>
                <div className="text-xs text-teal-950 font-medium leading-relaxed">
                  {activeBnssSection.whomToBeTakenTo}
                </div>
              </div>

              {activeBnssSection.keyChangesIn2023 && (
                <div className="p-4 rounded-xl bg-blue-50/80 border border-blue-200 space-y-1">
                  <span className="text-[10px] font-bold text-blue-900 uppercase tracking-wider block">
                    KEY REFORMS & MODERNIZATION IN BNSS 2023
                  </span>
                  <div className="text-xs text-blue-950 font-medium leading-relaxed">
                    {activeBnssSection.keyChangesIn2023}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* MODE B: 39 CHAPTERS DIRECTORY OVERVIEW */}
        {bnssViewMode === 'chapters-overview' && (
          <div className="space-y-4">
            <span className="text-xs font-bold text-slate-600 uppercase tracking-wider block">
              ALL 39 CHAPTERS OF THE BHARATIYA NAGARIK SURAKSHA SANHITA, 2023:
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[550px] overflow-y-auto pr-1">
              {BNSS_GAZETTE_CHAPTERS.map((ch) => (
                <div
                  key={ch.number}
                  onClick={() => {
                    setSelectedBnssChapter(ch.number);
                    setBnssViewMode('all-sections');
                  }}
                  className="bg-white border border-slate-200 hover:border-teal-600 rounded-xl p-4 shadow-2xs cursor-pointer transition-all space-y-1.5 group"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-teal-800 group-hover:text-teal-600">
                      {ch.number}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                      {ch.sectionRange}
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-[#1e293b]">
                    {ch.title}
                  </h4>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {ch.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODE C: BROWSE ALL BNSS SECTIONS */}
        {bnssViewMode === 'all-sections' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Showing {filteredBnssSections.length} BNSS sections</span>
              {selectedBnssChapter !== 'All' && (
                <button
                  onClick={() => setSelectedBnssChapter('All')}
                  className="text-teal-700 font-semibold hover:underline cursor-pointer"
                >
                  Clear Chapter Filter
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[500px] overflow-y-auto pr-1">
              {filteredBnssSections.map((sec) => (
                <div
                  key={sec.sectionNumber}
                  onClick={() => {
                    setSelectedBnssSectionNum(sec.sectionNumber);
                    setBnssViewMode('section-reader');
                  }}
                  className={`border rounded-xl p-3.5 cursor-pointer transition-all shadow-2xs space-y-1.5 ${
                    selectedBnssSectionNum === sec.sectionNumber
                      ? 'bg-teal-50/60 border-teal-500 ring-1 ring-teal-300'
                      : 'bg-white border-slate-200 hover:border-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-xs bg-[#0f766e] text-white px-2 py-0.5 rounded">
                      Section {sec.sectionNumber}
                    </span>
                    <span className="text-[11px] font-mono text-slate-500">
                      {sec.crpcEquivalent}
                    </span>
                  </div>

                  <h5 className="font-bold text-xs text-slate-900">
                    <HighlightKeyword text={sec.marginalTitle} queries={[query, bnssSearchText]} highlightClassName="bg-teal-200 text-teal-950 font-bold px-0.5 rounded shadow-2xs" />
                  </h5>

                  <p className="text-[11px] text-slate-600 line-clamp-2">
                    <HighlightKeyword text={sec.statutoryText} queries={[query, bnssSearchText]} highlightClassName="bg-amber-200 text-amber-950 font-bold px-0.5 rounded shadow-2xs" />
                  </p>

                  <div className="text-[10px] text-teal-700 font-semibold pt-1">
                    {sec.category}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODE D: 58 STATUTORY FORMS IN SECOND SCHEDULE */}
        {bnssViewMode === 'forms-overview' && (
          <div className="space-y-4">
            <div className="bg-teal-50/70 border border-teal-200 rounded-xl p-4 text-xs text-teal-950 space-y-1">
              <span className="font-bold text-teal-900 uppercase block">
                THE SECOND SCHEDULE (SECTION 522) — 58 STATUTORY POLICE & COURT FORMS
              </span>
              <p className="text-slate-700">
                The official Gazette prescribes 58 mandatory statutory formats for notices, summons, warrants, bail bonds, proclamations, charges, and execution orders under the Bharatiya Nagarik Suraksha Sanhita, 2023.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[450px] overflow-y-auto pr-1 text-xs">
              {[
                { no: "1", title: "Notice for Appearance by Police", sec: "Section 35(3)", use: "Mandatory notice before arrest for offences punishable up to 7 years" },
                { no: "2", title: "Summons to an Accused Person", sec: "Section 63", use: "Court summons with digital signature/encrypted electronic mode" },
                { no: "3", title: "Warrant of Arrest", sec: "Section 72", use: "Formal arrest warrant bearing Court seal" },
                { no: "4", title: "Bond and Bail-Bond After Arrest under Warrant", sec: "Section 83", use: "Personal undertaking and surety bond" },
                { no: "5", title: "Proclamation for Proclaimed Person", sec: "Section 84", use: "30-day public notice in newspaper and residence" },
                { no: "6", title: "Proclamation Requiring Attendance of Witness", sec: "Section 84, 90", use: "Compelling absconding witness appearance" },
                { no: "7", title: "Order of Attachment of Property of Witness", sec: "Section 85", use: "Distress warrant against defaulting witnesses" },
                { no: "8", title: "Order of Attachment of Property of Accused", sec: "Section 85", use: "Seizure of absconder's movable/immovable assets" },
                { no: "9", title: "Order Authorising Attachment by DM/Collector", sec: "Section 85", use: "Revenue land attachment through District Collector" },
                { no: "11", title: "Warrant to Search After Information of Offence", sec: "Section 96", use: "General search warrant for evidence and places" },
                { no: "12", title: "Warrant to Search Suspected Place of Deposit", sec: "Section 97", use: "Search for stolen property, counterfeit coins, or fake seals" },
                { no: "13", title: "Bond to Keep the Peace", sec: "Section 125, 126", use: "Preventive bond executed before Executive Magistrate" },
                { no: "14", title: "Bond for Good Behaviour", sec: "Section 127, 128, 129", use: "Bond from suspected persons and habitual offenders" },
                { no: "19", title: "Warrant of Imprisonment for Default of Maintenance", sec: "Section 144", use: "Commitment to jail for failure to maintain wife/parents" },
                { no: "20", title: "Warrant to Enforce Maintenance by Attachment", sec: "Section 144", use: "Levy of maintenance allowance as fine" },
                { no: "21", title: "Order for Removal of Nuisances", sec: "Section 152", use: "Conditional order for clearing public way or health hazard" },
                { no: "25", title: "Order to Prevent Obstruction, Riot, etc.", sec: "Section 163", use: "Urgent prohibitive orders replacing Section 144 CrPC" },
                { no: "26", title: "Order Declaring Party Entitled to Possession", sec: "Section 164", use: "Land and water dispute possession confirmation" },
                { no: "29", title: "Bond and Bail-Bond on Preliminary Police Inquiry", sec: "Section 189", use: "Station bail bond executed before police officer" },
                { no: "30", title: "Bond to Prosecute or Give Evidence", sec: "Section 190", use: "Witness and complainant undertaking for trial attendance" },
                { no: "31", title: "Special Summons for Petty Offence", sec: "Section 229", use: "Plea of guilty by post with fine up to Rs 5,000" },
                { no: "33", title: "Charges (Single, Joint & Subsequent)", sec: "Section 234-236", use: "Formal statutory charge sheet framed by Court" },
                { no: "35", title: "Warrant of Commitment on Sentence of Imprisonment", sec: "Section 258, 271", use: "Jail commitment warrant following conviction" },
                { no: "41", title: "Warrant of Commitment Under Sentence of Death", sec: "Section 407", use: "Sessions death sentence warrant pending High Court confirmation" },
                { no: "43", title: "Warrant of Execution of Sentence of Death", sec: "Section 453, 454", use: "Final execution warrant following judicial confirmation" },
                { no: "47", title: "Bond and Bail-Bond for Court Attendance", sec: "Section 478-482", use: "Universal regular and anticipatory bail bond format" },
                { no: "58", title: "Warrant on Forfeiture of Bond for Good Behaviour", sec: "Section 491", use: "Commitment to civil jail upon bond breach" }
              ].map((f, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-white border border-slate-200 shadow-2xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-teal-800">
                      Form No. {f.no}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                      {f.sec}
                    </span>
                  </div>
                  <div className="font-bold text-slate-900 text-xs">
                    {f.title}
                  </div>
                  <p className="text-[11px] text-slate-600">
                    {f.use}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* 6. Complete Compendium of All Laws & Constitution Directory */}
      <div className="space-y-4 pt-4">
        {/* Act Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-2">
          {(['All', 'BNS 2023', 'BNSS 2023', 'BSA 2023', 'Constitution of India'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                activeCategory === cat
                  ? 'bg-[#1e293b] text-white shadow-sm'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {cat === 'All' ? 'All Laws & Constitution' : cat}
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#c49a6c]" />
            <h2 className="font-headline text-lg font-bold text-[#1e293b]">
              Statutory Compendium ({filteredItems.length} Enactments & Articles)
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white border border-slate-200 hover:border-blue-400 rounded-2xl p-5 shadow-2xs space-y-3 transition-all flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className={`font-mono font-bold text-xs px-2.5 py-1 rounded-lg text-white ${
                    item.act === 'BNSS 2023' ? 'bg-[#0f766e]' : item.act === 'BNS 2023' ? 'bg-blue-700' : 'bg-[#102a4e]'
                  }`}>
                    {item.act} • {item.number}
                  </span>

                  <button
                    onClick={() => speakText(`${item.act} ${item.number}. ${item.title}. ${item.description}.`)}
                    className="p-1 rounded-full text-slate-400 hover:text-blue-700 hover:bg-slate-50 cursor-pointer"
                    title="Listen"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>

                {item.legacyReference && (
                  <div className="text-[11px] font-mono text-slate-500">
                    Legacy: {item.legacyReference}
                  </div>
                )}

                <h3 className="font-bold text-sm text-[#1e293b]">
                  {item.title}
                </h3>

                <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-100 space-y-2 text-xs">
                {item.punishment && (
                  <div className="text-[11px] font-medium text-amber-900 bg-amber-50/70 p-2 rounded-lg border border-amber-100">
                    <strong>Verdict:</strong> {item.punishment}
                  </div>
                )}

                {item.whomToBeTakenTo && (
                  <div className="text-[11px] text-blue-900 bg-blue-50/70 p-2 rounded-lg border border-blue-100">
                    <strong>Whom to take to:</strong> {item.whomToBeTakenTo}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
