import React, { useState } from 'react';
import { 
  Folder, FolderOpen, FileCode, FileText, ChevronRight, ChevronDown, 
  Copy, Check, X, Code, Terminal, Layers, Info, ExternalLink, ShieldAlert
} from 'lucide-react';

interface FileNode {
  name: string;
  type: 'file' | 'folder';
  path: string;
  size?: string;
  description?: string;
  children?: FileNode[];
}

const PROJECT_TREE: FileNode[] = [
  {
    name: 'legasol-criminal-justice-platform',
    type: 'folder',
    path: '/',
    children: [
      {
        name: 'package.json',
        type: 'file',
        path: '/package.json',
        size: '887 B',
        description: 'Project manifest, scripts (dev, build, lint), dependencies (React 19, Tailwind v4, Lucide, GenAI)'
      },
      {
        name: 'vite.config.ts',
        type: 'file',
        path: '/vite.config.ts',
        size: '705 B',
        description: 'Vite build and dev-server configuration with React and Tailwind plugins'
      },
      {
        name: 'tsconfig.json',
        type: 'file',
        path: '/tsconfig.json',
        size: '538 B',
        description: 'TypeScript compiler configuration for React JSX and ESNext modules'
      },
      {
        name: 'index.html',
        type: 'file',
        path: '/index.html',
        size: '1.4 KB',
        description: 'HTML5 entry point with responsive viewport, Inter/Crest typography, and SEO tags'
      },
      {
        name: 'metadata.json',
        type: 'file',
        path: '/metadata.json',
        size: '396 B',
        description: 'AI Studio applet configuration and capabilities'
      },
      {
        name: '.env.example',
        type: 'file',
        path: '/.env.example',
        size: '445 B',
        description: 'Environment variable specifications'
      },
      {
        name: 'src',
        type: 'folder',
        path: '/src',
        children: [
          {
            name: 'main.tsx',
            type: 'file',
            path: '/src/main.tsx',
            size: '159 B',
            description: 'Application DOM bootstrap rendering App into root'
          },
          {
            name: 'App.tsx',
            type: 'file',
            path: '/src/App.tsx',
            size: '8.5 KB',
            description: 'Core application layout, tab switching, global header, brand crest, and footer'
          },
          {
            name: 'index.css',
            type: 'file',
            path: '/src/index.css',
            size: '2.0 KB',
            description: 'Global Tailwind v4 stylesheet and styling utilities'
          },
          {
            name: 'components',
            type: 'folder',
            path: '/src/components',
            children: [
              {
                name: 'Navbar.tsx',
                type: 'file',
                path: '/src/components/Navbar.tsx',
                size: '5.2 KB',
                description: 'Top navigation bar with brand email, tabs, and folder/zip actions'
              },
              {
                name: 'Home.tsx',
                type: 'file',
                path: '/src/components/Home.tsx',
                size: '41 KB',
                description: 'Primary incident intake dashboard, FIR recording, flowchart, and feasibility modules'
              },
              {
                name: 'FirCompare.tsx',
                type: 'file',
                path: '/src/components/FirCompare.tsx',
                size: '47 KB',
                description: 'Dual FIR side-by-side comparison, structural variance, and section mapping'
              },
              {
                name: 'VerdictWizard.tsx',
                type: 'file',
                path: '/src/components/VerdictWizard.tsx',
                size: '23 KB',
                description: 'Judicial simulator, probability meters, legal precedent integration, and trial timeline'
              },
              {
                name: 'StatutoryConstitutionExplorer.tsx',
                type: 'file',
                path: '/src/components/StatutoryConstitutionExplorer.tsx',
                size: '75 KB',
                description: 'Explorer for BNS, BNSS, BSA 2023, and Indian Constitution with live text search'
              },
              {
                name: 'ProceduralStrategyBox.tsx',
                type: 'file',
                path: '/src/components/ProceduralStrategyBox.tsx',
                size: '36 KB',
                description: 'Interactive post-FIR procedural flowchart and decision tree'
              },
              {
                name: 'LegalFeasibilityDirectionBox.tsx',
                type: 'file',
                path: '/src/components/LegalFeasibilityDirectionBox.tsx',
                size: '36 KB',
                description: 'Dual 5-point probabilistic analysis (5 Strategic Pathways & 5 Failure Risks)'
              },
              {
                name: 'LegalPrecedentSection.tsx',
                type: 'file',
                path: '/src/components/LegalPrecedentSection.tsx',
                size: '18 KB',
                description: 'Supreme Court & High Court precedent retrieval engine and citation card generator'
              },
              {
                name: 'VoiceDictationConsole.tsx',
                type: 'file',
                path: '/src/components/VoiceDictationConsole.tsx',
                size: '10 KB',
                description: 'Real-time multi-lingual speech-to-text dictation console'
              },
              {
                name: 'VoiceRecorder.tsx',
                type: 'file',
                path: '/src/components/VoiceRecorder.tsx',
                size: '22 KB',
                description: 'Audio intake recorder with waveform visualizer and speech-to-FIR engine'
              },
              {
                name: 'FeedbackModal.tsx',
                type: 'file',
                path: '/src/components/FeedbackModal.tsx',
                size: '17 KB',
                description: 'Direct feedback modal forwarding submissions to legalsolutions@legasol.in'
              },
              {
                name: 'TrialProgressTimeline.tsx',
                type: 'file',
                path: '/src/components/TrialProgressTimeline.tsx',
                size: '17 KB',
                description: 'Visual progress tracker from Investigation to High Court Appeal'
              },
              {
                name: 'CaseProgressTimeline.tsx',
                type: 'file',
                path: '/src/components/CaseProgressTimeline.tsx',
                size: '18 KB',
                description: 'FIR milestone progression bar'
              },
              {
                name: 'LegasolCrest.tsx',
                type: 'file',
                path: '/src/components/LegasolCrest.tsx',
                size: '6.3 KB',
                description: 'Custom SVG insignia for the LegaSol brand identity'
              },
              {
                name: 'HighlightKeyword.tsx',
                type: 'file',
                path: '/src/components/HighlightKeyword.tsx',
                size: '2.6 KB',
                description: 'Dynamic text highlighter for search keyword highlighting'
              },
              {
                name: 'FileUploadButton.tsx',
                type: 'file',
                path: '/src/components/FileUploadButton.tsx',
                size: '2.8 KB',
                description: 'Document and FIR text extraction handler'
              }
            ]
          },
          {
            name: 'data',
            type: 'folder',
            path: '/src/data',
            children: [
              {
                name: 'bnsSections.ts',
                type: 'file',
                path: '/src/data/bnsSections.ts',
                size: '24 KB',
                description: 'BNS 2023 sections, IPC mapping, punishments, and bailable/cognizable flags'
              },
              {
                name: 'legalPrecedents.ts',
                type: 'file',
                path: '/src/data/legalPrecedents.ts',
                size: '24 KB',
                description: 'Curated Supreme Court ratios, landmark citations, and evidentiary thresholds'
              },
              {
                name: 'bnsGazetteFullText.ts',
                type: 'file',
                path: '/src/data/bnsGazetteFullText.ts',
                size: '70 KB',
                description: 'Official statutory text of Bharatiya Nyaya Sanhita 2023'
              },
              {
                name: 'bnssGazetteFullText.ts',
                type: 'file',
                path: '/src/data/bnssGazetteFullText.ts',
                size: '59 KB',
                description: 'Official statutory text of Bharatiya Nagarik Suraksha Sanhita 2023'
              },
              {
                name: 'statutoryAndConstitution.ts',
                type: 'file',
                path: '/src/data/statutoryAndConstitution.ts',
                size: '38 KB',
                description: 'BSA 2023 evidentiary provisions and Indian Constitution fundamental rights'
              },
              {
                name: 'crimeData.ts',
                type: 'file',
                path: '/src/data/crimeData.ts',
                size: '9.6 KB',
                description: 'Preloaded sample cases across 6 criminal categories'
              }
            ]
          },
          {
            name: 'lib',
            type: 'folder',
            path: '/src/lib',
            children: [
              {
                name: 'analysis.ts',
                type: 'file',
                path: '/src/lib/analysis.ts',
                size: '25 KB',
                description: 'Legal inference engine for section classification and penalty estimation'
              },
              {
                name: 'speech.ts',
                type: 'file',
                path: '/src/lib/speech.ts',
                size: '14 KB',
                description: 'Text-to-Speech synthesis and Web Speech API audio helper'
              },
              {
                name: 'fileTextExtractor.ts',
                type: 'file',
                path: '/src/lib/fileTextExtractor.ts',
                size: '2.6 KB',
                description: 'Extracts text from PDF, TXT, and DOC documents'
              },
              {
                name: 'storage.ts',
                type: 'file',
                path: '/src/lib/storage.ts',
                size: '1.2 KB',
                description: 'Local storage caching for FIR drafts and user preferences'
              }
            ]
          }
        ]
      }
    ]
  }
];

interface ProjectFolderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ProjectFolderModal: React.FC<ProjectFolderModalProps> = ({ isOpen, onClose }) => {
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    '/': true,
    '/src': true,
    '/src/components': true,
    '/src/data': true,
    '/src/lib': true
  });
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(PROJECT_TREE[0].children![0]);
  const [copiedPath, setCopiedPath] = useState(false);

  if (!isOpen) return null;

  const toggleFolder = (path: string) => {
    setExpandedFolders(prev => ({
      ...prev,
      [path]: !prev[path]
    }));
  };

  const handleCopyPath = (path: string) => {
    navigator.clipboard.writeText(path);
    setCopiedPath(true);
    setTimeout(() => setCopiedPath(false), 2000);
  };

  const renderTree = (nodes: FileNode[], depth = 0) => {
    return nodes.map(node => {
      const isFolder = node.type === 'folder';
      const isExpanded = isFolder ? !!expandedFolders[node.path] : false;
      const isSelected = selectedFile?.path === node.path;

      return (
        <div key={node.path} className="select-none">
          <div
            onClick={() => {
              if (isFolder) {
                toggleFolder(node.path);
              } else {
                setSelectedFile(node);
              }
            }}
            style={{ paddingLeft: `${depth * 16 + 8}px` }}
            className={`flex items-center gap-2 py-1.5 px-2 rounded-md text-xs cursor-pointer transition-colors ${
              isSelected
                ? 'bg-blue-600 text-white font-semibold'
                : 'text-slate-700 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            {isFolder ? (
              <>
                {isExpanded ? (
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                ) : (
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                )}
                {isExpanded ? (
                  <FolderOpen className="w-4 h-4 text-amber-500 shrink-0" />
                ) : (
                  <Folder className="w-4 h-4 text-amber-500 shrink-0" />
                )}
                <span className="font-semibold truncate">{node.name}/</span>
              </>
            ) : (
              <>
                <span className="w-3.5 h-3.5 shrink-0" />
                {node.name.endsWith('.tsx') || node.name.endsWith('.ts') ? (
                  <FileCode className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-white' : 'text-blue-500'}`} />
                ) : (
                  <FileText className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-white' : 'text-slate-400'}`} />
                )}
                <span className="truncate">{node.name}</span>
                {node.size && (
                  <span className={`ml-auto text-[10px] font-mono shrink-0 ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                    {node.size}
                  </span>
                )}
              </>
            )}
          </div>

          {isFolder && isExpanded && node.children && (
            <div className="border-l border-slate-200 ml-4">
              {renderTree(node.children, depth + 1)}
            </div>
          )}
        </div>
      );
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-4xl max-h-[85vh] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-400">
              <FolderOpen className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold flex items-center gap-2">
                Project File & Directory Explorer
                <span className="text-[10px] bg-blue-500/20 text-blue-300 border border-blue-400/30 px-2 py-0.5 rounded-full font-mono">
                  Folder Format
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Browse complete project folder structure, view file specifications, and copy paths
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Info banner */}
        <div className="bg-blue-50/70 border-b border-blue-100 px-6 py-2.5 flex items-center justify-between text-xs text-blue-900">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-blue-600 shrink-0" />
            <span>
              All source code files are directly editable and browsable in the left-hand files sidebar of the AI Studio development environment.
            </span>
          </div>
          <div className="font-mono text-[11px] text-blue-700 bg-white px-2 py-0.5 rounded border border-blue-200 shrink-0">
            30+ Files • Complete Source
          </div>
        </div>

        {/* Content Split: Left Tree, Right File Detail */}
        <div className="grid grid-cols-1 md:grid-cols-12 flex-1 overflow-hidden min-h-[380px]">
          {/* Left Column: Folder Tree */}
          <div className="md:col-span-5 border-r border-slate-200 p-3 overflow-y-auto max-h-[60vh] bg-slate-50/50">
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 px-2 flex items-center justify-between">
              <span>Directory Hierarchy</span>
              <button 
                onClick={() => setExpandedFolders({
                  '/': true, '/src': true, '/src/components': true, '/src/data': true, '/src/lib': true
                })}
                className="text-blue-600 hover:underline cursor-pointer lowercase"
              >
                expand all
              </button>
            </div>
            {renderTree(PROJECT_TREE)}
          </div>

          {/* Right Column: File Details & Copy Tool */}
          <div className="md:col-span-7 p-6 overflow-y-auto max-h-[60vh] bg-white flex flex-col justify-between">
            {selectedFile ? (
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Selected File
                    </span>
                    <h4 className="text-base font-bold text-slate-900 font-mono flex items-center gap-2">
                      <FileCode className="w-4 h-4 text-blue-600" />
                      {selectedFile.name}
                    </h4>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">
                      {selectedFile.path}
                    </p>
                  </div>
                  <button
                    onClick={() => handleCopyPath(selectedFile.path)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-700 hover:bg-slate-50 cursor-pointer shadow-sm transition-all"
                  >
                    {copiedPath ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-semibold">Path Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-500" />
                        <span>Copy Path</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <div className="text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-slate-500" />
                    Role & Description
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {selectedFile.description || 'Source file in application directory.'}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-400 text-[10px] block font-semibold uppercase">File Size</span>
                    <span className="font-mono font-bold text-slate-800">{selectedFile.size || 'N/A'}</span>
                  </div>
                  <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                    <span className="text-slate-400 text-[10px] block font-semibold uppercase">Parent Directory</span>
                    <span className="font-mono font-bold text-slate-800">
                      {selectedFile.path.substring(0, selectedFile.path.lastIndexOf('/')) || '/'}
                    </span>
                  </div>
                </div>

                <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-3">
                  <Code className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <span className="font-bold">Accessing Full File Content:</span>
                    <p className="text-[11px] text-amber-800 leading-normal">
                      In the AI Studio development window, click any file in the left sidebar directory tree to inspect, edit, or copy its entire raw code.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center text-slate-400 p-8">
                <Folder className="w-12 h-12 text-slate-300 mb-2 stroke-1" />
                <p className="text-xs font-medium">Select any file from the directory tree on the left to view details</p>
              </div>
            )}

            {/* Bottom Terminal Quick Guide */}
            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
              <span className="font-mono text-[11px] text-slate-600 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-slate-400" />
                bun dev / npm run dev • port 3000
              </span>
              <button
                onClick={onClose}
                className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-medium rounded-lg text-xs cursor-pointer transition-colors"
              >
                Close Explorer
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
