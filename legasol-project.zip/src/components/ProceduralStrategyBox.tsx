import React, { useState } from 'react';
import { 
  GitBranch, ArrowRight, CheckCircle2, Clock, ShieldAlert, FileText, 
  HelpCircle, ChevronRight, ChevronDown, ChevronUp, AlertCircle, 
  Gavel, Scale, Landmark, UserCheck, ShieldCheck, Download, Copy, Check, Sparkles
} from 'lucide-react';
import { ExtractedFIRMetadata } from '../lib/analysis';

interface ProceduralStrategyBoxProps {
  analysis: ExtractedFIRMetadata | null;
  complaintText: string;
  generatedFirDoc: string;
}

export type ProceduralTrack = 'standard' | 'police_refusal' | 'bail_custody' | 'settlement';

interface FlowNode {
  id: string;
  stepNumber: number;
  title: string;
  statutoryReference: string;
  timeLimit: string;
  summary: string;
  actionableChecklist: string[];
  mandatoryRights: string;
  criticalCaution: string;
  status: 'pending' | 'in-progress' | 'completed';
}

export const ProceduralStrategyBox: React.FC<ProceduralStrategyBoxProps> = ({
  analysis,
  complaintText,
  generatedFirDoc
}) => {
  const [activeTrack, setActiveTrack] = useState<ProceduralTrack>('standard');
  const [expandedNodeId, setExpandedNodeId] = useState<string | null>('node-1');
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>({});
  const [copiedActionPlan, setCopiedActionPlan] = useState(false);

  const toggleStepCompleted = (nodeId: string) => {
    setCompletedSteps(prev => ({
      ...prev,
      [nodeId]: !prev[nodeId]
    }));
  };

  const isBailable = analysis ? analysis.isBailableOverall : false;
  const isCognizable = analysis ? analysis.isCognizableOverall : true;
  const severity = analysis ? analysis.severityLevel : 'Major';

  // Standard Investigation & Prosecution Track (BNSS 2023)
  const standardTrackNodes: FlowNode[] = [
    {
      id: 'node-1',
      stepNumber: 1,
      title: 'Formal FIR Registration & Securing Free Signed Copy',
      statutoryReference: 'BNSS Section 173(1) & 173(2) [Former CrPC 154]',
      timeLimit: 'Immediate (Within 0 Hours of Reporting)',
      summary: 'The Police Officer in Charge is statutorily mandated to read over the recorded information to the informant and issue an authenticated carbon/digital copy free of charge.',
      actionableChecklist: [
        'Demand the official FIR Number, GD (General Diary) entry number, and Date/Time stamp.',
        'Insist on receiving your statutory free copy under BNSS Section 173(2) — refusing to give copy is illegal.',
        'Verify that all named suspects, weapon types, vehicle numbers, and stolen articles are correctly transcribed.',
        'Sign the FIR only after confirming every word corresponds to your verbal or written statement.'
      ],
      mandatoryRights: 'Under BNSS 173(2), a copy of the information recorded shall be given forthwith, free of cost, to the informant or victim.',
      criticalCaution: 'Do not leave the police station without the signed physical or digital copy carrying the official seal.',
      status: completedSteps['node-1'] ? 'completed' : 'in-progress'
    },
    {
      id: 'node-2',
      stepNumber: 2,
      title: 'Preservation of Physical, Medical & Digital Forensic Traces',
      statutoryReference: 'BNSS Section 176(3) & BSA Section 61 (Former Sec 65B)',
      timeLimit: 'Within 24 to 48 Hours',
      summary: 'Mandatory videography of crime scenes and forensic evidence collection by scientific experts for offenses punishable with 7+ years.',
      actionableChecklist: [
        'Undergo immediate Medical Legal Examination (MLC) at a Government Hospital if any physical injury was sustained.',
        'Request the Investigating Officer (IO) to seize surrounding CCTV footage before 7-day server auto-overwrite cycles.',
        'Preserve mobile call logs, WhatsApp chats, and digital photos with an accompanying certificate under Section 61 BSA 2023.',
        'Provide names and contact numbers of independent shopkeepers, neighbors, or eye-witnesses to the IO.'
      ],
      mandatoryRights: 'Mandatory collection of forensic evidence on scene by a forensic expert under BNSS 176(3).',
      criticalCaution: 'Delay in medical examination allows defense to argue injuries were self-inflicted or sustained elsewhere.',
      status: completedSteps['node-2'] ? 'completed' : 'pending'
    },
    {
      id: 'node-3',
      stepNumber: 3,
      title: 'Police Investigation, Witness Examination & Case Diary Monitoring',
      statutoryReference: 'BNSS Section 180 & 192 [Former CrPC 161 & 172]',
      timeLimit: 'Ongoing (14-day preliminary enquiry cap for 3-7 yr offenses)',
      summary: 'IO examines witnesses under BNSS 180, records daily progress in the official Case Diary (BNSS 192), and seeks arrest warrants or summons.',
      actionableChecklist: [
        'Follow up with the IO weekly for Case Diary updates under BNSS Section 192.',
        'For vulnerable or sexual assault victims, request immediate recording of statement before a Judicial Magistrate under BNSS Section 183 (164 CrPC).',
        'Submit any newly discovered documentary evidence via formal written application with an acknowledgment receipt.',
        'Ensure the IO initiates property attachment or weapon seizure memos with independent panchas.'
      ],
      mandatoryRights: 'Audio-video electronic recording of witness statements is now statutorily recognized under BNSS Section 180(3).',
      criticalCaution: 'Statements made to police under BNSS 180 are not signed by the witness and cannot be used as substantive proof in court.',
      status: completedSteps['node-3'] ? 'completed' : 'pending'
    },
    {
      id: 'node-4',
      stepNumber: 4,
      title: 'Final Police Report / Chargesheet Submission in Court',
      statutoryReference: 'BNSS Section 193(3) & 187(3) [Former CrPC 173 & 167]',
      timeLimit: '60 Days (under 10 yr penalty) or 90 Days (death/life/10+ yr)',
      summary: 'Police submits completion report to the Magistrate. If evidence is sufficient, a Chargesheet is filed; if insufficient, a Closure/Final Report is submitted.',
      actionableChecklist: [
        'Track the 60-day or 90-day statutory deadline to prevent accused from seeking default bail under BNSS 187(3).',
        'Obtain certified copy of the Chargesheet with all annexures (witness lists, forensic lab reports, seizure memos).',
        'If police submits a negative Final/Closure Report, file a "Protest Petition" before the Magistrate detailing flaws in investigation.',
        'Engage private counsel or request District Legal Services Authority (DLSA) legal aid advocate.'
      ],
      mandatoryRights: 'Magistrate must issue notice to the complainant/informant prior to accepting any police closure report.',
      criticalCaution: 'If the chargesheet is not filed within 60/90 days, the accused has an indefeasible right to Default Bail.',
      status: completedSteps['node-4'] ? 'completed' : 'pending'
    },
    {
      id: 'node-5',
      stepNumber: 5,
      title: 'Judicial Trial, Framing of Charges & Verdict Pronouncement',
      statutoryReference: 'BNSS Sections 251-265 & 356 (Trial in Absentia)',
      timeLimit: 'Trial Schedule Directed by Court of Session / Magistrate',
      summary: 'Court frames formal charges, examines prosecution witnesses in chief and cross, examines accused, and delivers judgment.',
      actionableChecklist: [
        'Prepare thoroughly for deposition in court: align oral testimony strictly with the initial FIR and medical reports.',
        'Respond to summons promptly to avoid non-bailable warrants or adjournments.',
        'If the accused absconds or flees the country, invoke BNSS Section 356 for "Trial in Absentia".',
        'Claim victim compensation under BNSS Section 396 upon conviction or discharge.'
      ],
      mandatoryRights: 'Complainant can engage an advocate to assist the Public Prosecutor with permission of the court under BNSS Section 301.',
      criticalCaution: 'Contradictions between court dock deposition and initial FIR provide grounds for benefit of doubt acquittal.',
      status: completedSteps['node-5'] ? 'completed' : 'pending'
    }
  ];

  // Remedy Track if Police Refuses / Delays FIR Registration
  const refusalTrackNodes: FlowNode[] = [
    {
      id: 'refusal-1',
      stepNumber: 1,
      title: 'Oral / Written Complaint Refusal at Police Station',
      statutoryReference: 'BNSS Section 173(1) & Supreme Court in Lalita Kumari',
      timeLimit: 'Day 0',
      summary: 'Police refuses to record FIR or dismisses the complaint as a civil/non-cognizable matter.',
      actionableChecklist: [
        'Note down the Station House Officer (SHO) name, badge number, and date/time of refusal.',
        'Request entry in the General Diary (GD) or Station Diary stating reasons for refusal.',
        'Send the exact complaint via Registered Post with Acknowledgment Due (RPAD) or Speed Post to the Police Station.'
      ],
      mandatoryRights: 'Constitution Bench in Lalita Kumari v. Govt of UP: FIR registration is mandatory if information discloses cognizable offense.',
      criticalCaution: 'Do not engage in physical altercations; create a clean paper trail of statutory attempts.',
      status: completedSteps['refusal-1'] ? 'completed' : 'in-progress'
    },
    {
      id: 'refusal-2',
      stepNumber: 2,
      title: 'Representation to Superintendent of Police (SP / DCP)',
      statutoryReference: 'BNSS Section 173(3) & 173(4) [Former CrPC 154(3)]',
      timeLimit: 'Within 3 to 7 Days of Refusal',
      summary: 'Send written substance of information by post or in person to the Superintendent of Police / Deputy Commissioner of Police.',
      actionableChecklist: [
        'Draft a formal representation addressed to the Superintendent of Police / Commissioner.',
        'Attach postal receipt and postal tracking confirmation proving the local police station received your complaint.',
        'Explain clearly how the incident constitutes a cognizable BNS offense.',
        'Request the SP to either investigate personally or direct a subordinate officer to register the FIR.'
      ],
      mandatoryRights: 'If satisfied, the SP must either investigate or direct investigation under BNSS 173(4).',
      criticalCaution: 'Without filing a Section 173(3) representation to the SP, the Magistrate will reject your 175(3) application.',
      status: completedSteps['refusal-2'] ? 'completed' : 'pending'
    },
    {
      id: 'refusal-3',
      stepNumber: 3,
      title: 'Judicial Application to Judicial Magistrate to Direct FIR',
      statutoryReference: 'BNSS Section 175(3) & 223 [Former CrPC 156(3) & 200]',
      timeLimit: 'Within 15 to 30 Days',
      summary: 'File a formal application before the jurisdictional Judicial Magistrate seeking an order directing the police to register FIR and investigate.',
      actionableChecklist: [
        'Attach an affidavit under oath affirming compliance with BNSS 173(1) and 173(3) as mandated by Priyanka Srivastava judgment.',
        'Magistrate examines prima facie cognizable ingredients and calls for an Action Taken Report (ATR) from police.',
        'Magistrate can direct police to register FIR immediately or proceed under private complaint procedure (BNSS Section 223).'
      ],
      mandatoryRights: 'The Magistrate possesses judicial supervision power to order police to register FIR and monitor investigation.',
      criticalCaution: 'Filing without sworn affidavit or without postal receipts will lead to immediate dismissal with perjury warning.',
      status: completedSteps['refusal-3'] ? 'completed' : 'pending'
    },
    {
      id: 'refusal-4',
      stepNumber: 4,
      title: 'High Court Writ Petition / Inherent Powers Invoke',
      statutoryReference: 'Constitution Article 226 & BNSS Section 528 [Former CrPC 482]',
      timeLimit: 'When Subordinate Remedies are Exhausted or Malice is Glaring',
      summary: 'Approach the High Court for a Writ of Mandamus directing law enforcement to act, or seeking CBI/independent agency transfer.',
      actionableChecklist: [
        'File Writ Petition under Article 226 of the Constitution of India in High Court.',
        'Demonstrate institutional police bias, political collusion, or gross refusal to follow statutory mandates.',
        'Seek transfer of investigation to Crime Branch / CID / Special Investigation Team (SIT).'
      ],
      mandatoryRights: 'High Court has inherent constitutional authority to protect fundamental rights under Article 21.',
      criticalCaution: 'High Courts generally decline writs if statutory remedies under BNSS 173(3) and 175(3) have not been exhausted first.',
      status: completedSteps['refusal-4'] ? 'completed' : 'pending'
    }
  ];

  // Bail & Arrest Track
  const bailTrackNodes: FlowNode[] = [
    {
      id: 'bail-1',
      stepNumber: 1,
      title: 'Offense Classification: Penalty Threshold & Arrest Safeguards',
      statutoryReference: 'BNSS Section 35(3) [Former CrPC 41A] & Arnesh Kumar Guidelines',
      timeLimit: 'Immediate',
      summary: 'For offenses punishable with imprisonment up to 7 years, police cannot mechanically arrest without serving formal appearance notice.',
      actionableChecklist: [
        'Determine whether offense carries punishment under 7 years or above 7 years.',
        'If under 7 years, police must serve formal Notice of Appearance under BNSS Section 35(3).',
        'Accused who complies with the notice cannot be arrested unless police records written reasons of flight risk or witness tampering.'
      ],
      mandatoryRights: 'Mandatory notice under BNSS 35(3) protects citizens against arbitrary custodial detention.',
      criticalCaution: 'Violating Section 35 notice procedures makes police officers liable for departmental disciplinary action and contempt of court.',
      status: completedSteps['bail-1'] ? 'completed' : 'in-progress'
    },
    {
      id: 'bail-2',
      stepNumber: 2,
      title: 'Anticipatory Bail Application in Sessions Court / High Court',
      statutoryReference: 'BNSS Section 482 [Former CrPC 438]',
      timeLimit: 'Prior to Arrest / Upon Anticipation of Non-Bailable FIR',
      summary: 'Person apprehending arrest in non-bailable offense applies for transit or pre-arrest bail to prevent humiliating police detention.',
      actionableChecklist: [
        'File Anticipatory Bail Petition before Court of Session with comprehensive affidavit.',
        'Establish roots in society, absence of criminal antecedents, and willingness to join police investigation.',
        'Provide interim protection request to restrain police arrest until final arguments are heard.'
      ],
      mandatoryRights: 'Supreme Court in Sushila Aggarwal: Anticipatory bail need not be restricted to fixed time and can continue till trial conclusion.',
      criticalCaution: 'Anticipatory bail is statutorily barred in certain offenses like POCSO and SC/ST Act unless prima facie false.',
      status: completedSteps['bail-2'] ? 'completed' : 'pending'
    },
    {
      id: 'bail-3',
      stepNumber: 3,
      title: 'Regular Bail & Default Bail Lifeline',
      statutoryReference: 'BNSS Section 480 & 187(3) [Former CrPC 437 & 167(2)]',
      timeLimit: 'Post-Arrest / After 60-90 Days in Custody',
      summary: 'Arrested person applies for regular bail upon judicial remand. If police fails to file chargesheet in time, default statutory bail is mandatory.',
      actionableChecklist: [
        'Apply for regular bail before the Magistrate or Sessions Court under BNSS Section 480.',
        'Highlight medical conditions, lack of custodial interrogation necessity, and that evidence is primarily documentary.',
        'Track the 60th or 90th day of remand: file Default Bail application immediately at 10:00 AM on the 61st/91st day.'
      ],
      mandatoryRights: 'Default Bail under BNSS Section 187(3) is an absolute fundamental right that cannot be defeated by subsequent chargesheet filing.',
      criticalCaution: 'Bail application must be ready to be furnished with local sureties and identity documents.',
      status: completedSteps['bail-3'] ? 'completed' : 'pending'
    }
  ];

  // Compoundable Settlement & Mediation Track
  const settlementTrackNodes: FlowNode[] = [
    {
      id: 'settle-1',
      stepNumber: 1,
      title: 'Checking Compoundability under BNSS Section 359 Table',
      statutoryReference: 'BNSS Section 359 [Former CrPC 320]',
      timeLimit: 'Any Stage Before Judgment',
      summary: 'Offenses like simple hurt (BNS 115), defamation (BNS 356), insult (BNS 352), criminal trespass, and cheating can be legally settled between parties.',
      actionableChecklist: [
        'Review BNSS Section 359 Table: Determine if the offense is compoundable without court permission or with permission.',
        'Serious offenses like rape (BNS 64), murder (BNS 103), and dacoity cannot be compounded under any circumstances.',
        'Negotiate written Memorandum of Understanding (MoU) or Compromise Agreement detailing financial settlement or apology.'
      ],
      mandatoryRights: 'Composition of an offense under BNSS Section 359 has the legal effect of an absolute acquittal of the accused.',
      criticalCaution: 'Paying money without court-sanctioned compounding deed leaves the accused vulnerable to ongoing prosecution.',
      status: completedSteps['settle-1'] ? 'completed' : 'in-progress'
    },
    {
      id: 'settle-2',
      stepNumber: 2,
      title: 'Lok Adalat / Court-Annexed Mediation Process',
      statutoryReference: 'Legal Services Authorities Act, 1987 & BNSS Section 359',
      timeLimit: 'National Lok Adalat Schedule or On-Demand Referral',
      summary: 'Parties submit joint petition before the trial Magistrate to refer the matter to the National Lok Adalat or Mediation Centre.',
      actionableChecklist: [
        'File joint compounding application signed by both complainant and accused.',
        'Approve terms before the judicial mediator; ensure full restitution of property or agreed compensation.',
        'Lok Adalat bench records statement under oath and passes final disposal order.'
      ],
      mandatoryRights: 'Lok Adalat award is final, non-appealable, and completely refund of court fees is provided.',
      criticalCaution: 'Ensure complainant signs the withdrawal deed in open court before judicial officer.',
      status: completedSteps['settle-2'] ? 'completed' : 'pending'
    },
    {
      id: 'settle-3',
      stepNumber: 3,
      title: 'High Court Quashing of Non-Compoundable FIR on Settlement',
      statutoryReference: 'BNSS Section 528 [Former CrPC 482] & Gian Singh v. State of Punjab',
      timeLimit: 'Before Charges are Framed or Evidence Commences',
      summary: 'Where offenses have private or commercial nature and parties reach compromise, High Court exercises inherent powers to quash the FIR.',
      actionableChecklist: [
        'File joint Criminal Petition under BNSS Section 528 before the High Court.',
        'Attach original settlement deed and affidavit of complainant stating they have no objection to quashing the FIR.',
        'Complainant appears personally or via video-conferencing before High Court Registrar to confirm voluntary settlement.'
      ],
      mandatoryRights: 'Gian Singh & Narinder Singh Supreme Court precedents authorize quashing non-heinous criminal disputes resolved amicably.',
      criticalCaution: 'High Courts strictly refuse to quash heinous offenses like murder, rape, or crimes against society on grounds of settlement.',
      status: completedSteps['settle-3'] ? 'completed' : 'pending'
    }
  ];

  const currentNodes = 
    activeTrack === 'standard' ? standardTrackNodes :
    activeTrack === 'police_refusal' ? refusalTrackNodes :
    activeTrack === 'bail_custody' ? bailTrackNodes : settlementTrackNodes;

  const handleCopyTrackPlan = () => {
    const lines = [
      `LEGAL ACTION PLAN: ${activeTrack.toUpperCase().replace('_', ' ')}`,
      `Statutory Framework: Bharatiya Nagarik Suraksha Sanhita, 2023 (BNSS)`,
      `Generated for FIR: ${analysis?.firNumber || 'New Draft'}`,
      `------------------------------------------------------------`,
      ...currentNodes.map(n => `[Step ${n.stepNumber}]: ${n.title}\n• Law: ${n.statutoryReference}\n• Time Limit: ${n.timeLimit}\n• Action Items:\n  - ${n.actionableChecklist.join('\n  - ')}\n`)
    ];
    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedActionPlan(true);
    setTimeout(() => setCopiedActionPlan(false), 2000);
  };

  return (
    <div className="bg-gradient-to-br from-white via-white to-blue-50/40 border border-blue-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
      {/* 1. Header with Badge & Output Identifier */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-blue-100">
        <div className="flex items-start gap-3">
          <span className="w-8 h-8 rounded-2xl bg-blue-900 text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-sm">
            <GitBranch className="w-4 h-4" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-headline font-bold text-xl text-blue-950">
                Legal Procedure & Decision Flowchart
              </h3>
              <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 border border-blue-200">
                Procedural Strategy Box
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Step-by-step, legally sound action plan and interactive decision tree detailing immediate next steps following FIR registration under BNSS 2023
            </p>
          </div>
        </div>

        {/* Copy Action Plan Button */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleCopyTrackPlan}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
              copiedActionPlan 
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-300 shadow-2xs'
            }`}
          >
            {copiedActionPlan ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedActionPlan ? 'Plan Copied!' : 'Copy Action Plan'}</span>
          </button>
        </div>
      </div>

      {/* 2. Interactive Decision Pathway Switcher Tabs */}
      <div className="space-y-2">
        <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block font-crest">
          Select Procedural Decision Branch / कानूनी रास्ता चुनें:
        </label>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          <button
            onClick={() => { setActiveTrack('standard'); setExpandedNodeId('node-1'); }}
            className={`flex flex-col text-left p-3.5 rounded-2xl border transition-all cursor-pointer ${
              activeTrack === 'standard'
                ? 'bg-blue-900 text-white border-blue-900 shadow-md ring-2 ring-blue-300/40'
                : 'bg-white text-slate-700 hover:bg-blue-50/50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-crest">1. Standard Police Investigation</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded ${activeTrack === 'standard' ? 'bg-blue-800 text-blue-100' : 'bg-slate-100 text-slate-600'}`}>5 Steps</span>
            </div>
            <span className={`text-[11px] mt-1 line-clamp-2 ${activeTrack === 'standard' ? 'text-blue-200' : 'text-slate-500'}`}>
              FIR receipt ➔ Medical/CCTV seizure ➔ Witness statements ➔ Chargesheet in Court
            </span>
          </button>

          <button
            onClick={() => { setActiveTrack('police_refusal'); setExpandedNodeId('refusal-1'); }}
            className={`flex flex-col text-left p-3.5 rounded-2xl border transition-all cursor-pointer ${
              activeTrack === 'police_refusal'
                ? 'bg-rose-900 text-white border-rose-900 shadow-md ring-2 ring-rose-300/40'
                : 'bg-white text-slate-700 hover:bg-rose-50/50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-crest">2. Remedies if Police Refuses</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded ${activeTrack === 'police_refusal' ? 'bg-rose-800 text-rose-100' : 'bg-rose-50 text-rose-700 font-bold'}`}>Remedy Path</span>
            </div>
            <span className={`text-[11px] mt-1 line-clamp-2 ${activeTrack === 'police_refusal' ? 'text-rose-200' : 'text-slate-500'}`}>
              SP Representation 173(3) ➔ Magistrate Order 175(3) ➔ High Court 528 Writ
            </span>
          </button>

          <button
            onClick={() => { setActiveTrack('bail_custody'); setExpandedNodeId('bail-1'); }}
            className={`flex flex-col text-left p-3.5 rounded-2xl border transition-all cursor-pointer ${
              activeTrack === 'bail_custody'
                ? 'bg-amber-900 text-white border-amber-900 shadow-md ring-2 ring-amber-300/40'
                : 'bg-white text-slate-700 hover:bg-amber-50/50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-crest">3. Bail & Custody Dynamics</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded ${activeTrack === 'bail_custody' ? 'bg-amber-800 text-amber-100' : 'bg-amber-50 text-amber-700 font-bold'}`}>Bail Track</span>
            </div>
            <span className={`text-[11px] mt-1 line-clamp-2 ${activeTrack === 'bail_custody' ? 'text-amber-200' : 'text-slate-500'}`}>
              Sec 35(3) Notice ➔ Anticipatory Bail ➔ Regular Bail & Default Bail Lifeline
            </span>
          </button>

          <button
            onClick={() => { setActiveTrack('settlement'); setExpandedNodeId('settle-1'); }}
            className={`flex flex-col text-left p-3.5 rounded-2xl border transition-all cursor-pointer ${
              activeTrack === 'settlement'
                ? 'bg-emerald-900 text-white border-emerald-900 shadow-md ring-2 ring-emerald-300/40'
                : 'bg-white text-slate-700 hover:bg-emerald-50/50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-crest">4. Compounding & Settlement</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded ${activeTrack === 'settlement' ? 'bg-emerald-800 text-emerald-100' : 'bg-emerald-50 text-emerald-700 font-bold'}`}>Alternative</span>
            </div>
            <span className={`text-[11px] mt-1 line-clamp-2 ${activeTrack === 'settlement' ? 'text-emerald-200' : 'text-slate-500'}`}>
              Sec 359 BNSS Compounding ➔ Lok Adalat Mediation ➔ High Court Quashing 528
            </span>
          </button>
        </div>
      </div>

      {/* 3. Visual Timeline / Flowchart Nodes */}
      <div className="space-y-4 pt-2">
        <div className="flex items-center justify-between text-xs text-slate-500">
          <span className="font-semibold text-slate-700">
            Interactive Action Sequence ({currentNodes.length} Stages)
          </span>
          <span className="text-[11px]">
            Click any step to inspect legal mandates, checklists, and cautions
          </span>
        </div>

        <div className="space-y-3">
          {currentNodes.map((node, index) => {
            const isExpanded = expandedNodeId === node.id;
            const isCompleted = completedSteps[node.id];
            const isLast = index === currentNodes.length - 1;

            return (
              <div 
                key={node.id}
                className={`relative rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isExpanded 
                    ? 'border-blue-400 bg-white shadow-md ring-1 ring-blue-200' 
                    : isCompleted
                    ? 'border-emerald-200 bg-emerald-50/20'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                {/* Node Summary Row */}
                <div 
                  onClick={() => setExpandedNodeId(isExpanded ? null : node.id)}
                  className="p-4 sm:p-5 flex items-start justify-between gap-3 cursor-pointer select-none"
                >
                  <div className="flex items-start gap-3 flex-1">
                    {/* Step Number Circle */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleStepCompleted(node.id);
                      }}
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 transition-transform active:scale-90 ${
                        isCompleted
                          ? 'bg-emerald-600 text-white'
                          : isExpanded
                          ? 'bg-blue-900 text-white shadow-sm'
                          : 'bg-slate-100 text-slate-700 hover:bg-blue-100'
                      }`}
                      title="Click to mark as done"
                    >
                      {isCompleted ? <Check className="w-4 h-4" /> : node.stepNumber}
                    </button>

                    <div className="space-y-1 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-headline font-bold text-sm sm:text-base text-slate-900">
                          {node.title}
                        </span>
                        <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-800 border border-blue-200">
                          {node.statutoryReference}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1 text-slate-600 font-medium">
                          <Clock className="w-3.5 h-3.5 text-blue-600" />
                          <span>{node.timeLimit}</span>
                        </span>
                        <span className="hidden sm:inline text-slate-300">•</span>
                        <span className="line-clamp-1 text-slate-600">{node.summary}</span>
                      </div>
                    </div>
                  </div>

                  {/* Expand / Collapse Icon */}
                  <div className="flex items-center gap-1.5 shrink-0 pt-1">
                    {isCompleted && (
                      <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        Done
                      </span>
                    )}
                    <span className="text-slate-400 p-1">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </div>
                </div>

                {/* Expanded Details Drawer */}
                {isExpanded && (
                  <div className="px-4 pb-5 sm:px-5 sm:pb-6 pt-1 border-t border-slate-150 space-y-4 bg-slate-50/50">
                    {/* Actionable Checklist */}
                    <div>
                      <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-2 font-crest">
                        Mandatory Action Items & Practical Tasks:
                      </span>
                      <div className="space-y-2">
                        {node.actionableChecklist.map((item, idx) => (
                          <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 bg-white p-2.5 rounded-xl border border-slate-200">
                            <span className="w-4 h-4 rounded-full bg-blue-100 text-blue-900 font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                              {idx + 1}
                            </span>
                            <span className="leading-relaxed">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Dual Cards: Statutory Right vs Critical Caution */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                      {/* Statutory Right */}
                      <div className="bg-blue-50/80 border border-blue-200 p-3.5 rounded-xl space-y-1">
                        <div className="flex items-center gap-1.5 font-bold text-blue-950">
                          <ShieldCheck className="w-4 h-4 text-blue-700 shrink-0" />
                          <span>Statutory Citizen Right (BNSS):</span>
                        </div>
                        <p className="text-slate-700 leading-relaxed text-[11.5px]">
                          {node.mandatoryRights}
                        </p>
                      </div>

                      {/* Critical Caution */}
                      <div className="bg-amber-50/80 border border-amber-200 p-3.5 rounded-xl space-y-1">
                        <div className="flex items-center gap-1.5 font-bold text-amber-950">
                          <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
                          <span>Critical Pitfall to Avoid:</span>
                        </div>
                        <p className="text-amber-900/90 leading-relaxed text-[11.5px]">
                          {node.criticalCaution}
                        </p>
                      </div>
                    </div>

                    {/* Mark as Completed Button */}
                    <div className="flex items-center justify-between pt-1">
                      <button
                        onClick={() => toggleStepCompleted(node.id)}
                        className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                          isCompleted
                            ? 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                            : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-2xs'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{isCompleted ? 'Mark as Incomplete' : 'Mark Step Completed'}</span>
                      </button>

                      {index < currentNodes.length - 1 && (
                        <button
                          onClick={() => setExpandedNodeId(currentNodes[index + 1].id)}
                          className="flex items-center gap-1 text-xs font-bold text-blue-800 hover:text-blue-950 cursor-pointer"
                        >
                          <span>Next: Step {index + 2}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* 4. Footer Note with Official Guidance */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-blue-100 text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <Landmark className="w-4 h-4 text-blue-700 shrink-0" />
          <span>Statutory roadmap aligned with Bharatiya Nagarik Suraksha Sanhita, 2023 (Act 46 of 2023).</span>
        </div>
        <div className="font-semibold text-blue-900">
          Completed: {Object.values(completedSteps).filter(Boolean).length} / {currentNodes.length} Steps
        </div>
      </div>
    </div>
  );
};
