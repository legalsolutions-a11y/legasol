import React, { useState } from 'react';
import { 
  Scale, CheckCircle2, ChevronRight, Gavel, FileText, 
  Sparkles, ShieldCheck, AlertCircle, Clock, BookOpen, UserCheck
} from 'lucide-react';

export interface TrialStage {
  id: number;
  name: string;
  hindiName: string;
  sectionRef: string;
  shortDesc: string;
  standardOfProof: string;
  courtFocus: string;
  prosecutionBurden: string;
  defenseStrategy: string;
}

interface TrialProgressTimelineProps {
  convictionProb: number;
  acquittalProb: number;
  dilutionProb: number;
  activeFactorsCount: number;
  totalFactorsCount: number;
  selectedCategoryName: string;
}

export const TrialProgressTimeline: React.FC<TrialProgressTimelineProps> = ({
  convictionProb,
  acquittalProb,
  dilutionProb,
  activeFactorsCount,
  totalFactorsCount,
  selectedCategoryName
}) => {
  const [activeStageIndex, setActiveStageIndex] = useState<number>(3); // Defaults to Evidence / Testimony stage

  const TRIAL_STAGES: TrialStage[] = [
    {
      id: 1,
      name: 'Scrutiny & Supply of Documents',
      hindiName: 'दस्तावेज़ों की जांच व प्रतियां देना',
      sectionRef: 'BNSS Section 230',
      shortDesc: 'Magistrate ensures all police chargesheet copies, FIR, and digital records are furnished to the accused without delay.',
      standardOfProof: 'Procedural verification; ensuring fairness of trial under Article 21.',
      courtFocus: 'Verifies whether electronic records have digital certificates under BSA Section 63.',
      prosecutionBurden: 'Provide all statements recorded under BNSS 180 and seizure memos.',
      defenseStrategy: 'Check for missing diary entries, uncertified electronic files, or contradictory initial statements.'
    },
    {
      id: 2,
      name: 'Framing of Formal Charges',
      hindiName: 'आरोप तय करना (चार्ज फ्रेमिंग)',
      sectionRef: 'BNSS Section 251 / 262',
      shortDesc: 'Court determines whether prima facie case exists to put the accused on trial or grant discharge under BNSS 250.',
      standardOfProof: 'Grave suspicion test; not proof beyond reasonable doubt at this threshold.',
      courtFocus: 'Checks whether ingredients of invoked BNS offenses are substantiated in complaint text.',
      prosecutionBurden: 'Establish prima facie nexus connecting accused to the charged criminal act.',
      defenseStrategy: 'File petition for discharge if allegations are purely civil, absurd, or groundless.'
    },
    {
      id: 3,
      name: 'Prosecution Evidence & Witnesses',
      hindiName: 'अभियोजन पक्ष की गवाही व सबूत',
      sectionRef: 'BSA 2023 Sec 137–142',
      shortDesc: 'Complainant, eyewitnesses, investigating officer, and medical doctors depose under oath and face cross-examination.',
      standardOfProof: 'Beyond reasonable doubt standard applies to each essential statutory ingredient.',
      courtFocus: 'Assesses credibility of eyewitnesses, consistency between MLC medical report and oral claims.',
      prosecutionBurden: 'Prove chain of custody of seized weapons/cash and verify digital timestamps.',
      defenseStrategy: 'Expose material contradictions, unexplained delays in FIR, or witness hostility.'
    },
    {
      id: 4,
      name: 'Statement of Accused & Defense Pleadings',
      hindiName: 'आरोपी का बयान व आत्मरक्षा',
      sectionRef: 'BNSS Sec 351 & BNS 34–44',
      shortDesc: 'Accused is personally examined on all incriminating circumstances and given opportunity to advance general exceptions.',
      standardOfProof: 'Preponderance of probabilities for defense claims (e.g. self-defense, sudden fight).',
      courtFocus: 'Whether accused was exercising private defense of body/property under BNS Section 34-44.',
      prosecutionBurden: 'Rebut defense plea of self-defense or sudden provocation with physical proof.',
      defenseStrategy: 'Establish reasonable doubt or substantiate justification for acts under statutory exceptions.'
    },
    {
      id: 5,
      name: 'Final Legal Arguments',
      hindiName: 'अंतिम कानूनी बहस',
      sectionRef: 'BNSS Section 257 / 264',
      shortDesc: 'Public Prosecutor and Defense Counsel summarize factual matrices, precedent rulings, and statutory interpretations.',
      standardOfProof: 'Evaluation of reasonable doubt. If two views are possible, court must lean towards the accused.',
      courtFocus: 'Whether chain of circumstantial evidence is complete and unbroken (Sharad Birdhichand test).',
      prosecutionBurden: 'Demonstrate guilt beyond all reasonable hypothesis of innocence.',
      defenseStrategy: 'Highlight gaps in investigation, absence of independent corroboration, or delay.'
    },
    {
      id: 6,
      name: 'Judgment & Verdict Pronouncement',
      hindiName: 'फैसला व दंडादेश (निर्णय)',
      sectionRef: 'BNSS Section 258 / 265',
      shortDesc: 'Court pronounces formal judgment of Conviction, Acquittal, or Alteration of charges to lesser compoundable offences.',
      standardOfProof: 'Final judicial verdict pronounced within strictly 30 days under BNSS 2023.',
      courtFocus: 'Detailed judicial reasoning covering each charge, evidentiary credibility, and statutory penalty.',
      prosecutionBurden: 'Request appropriate statutory sentencing within parameters of BNS 2023.',
      defenseStrategy: 'If convicted, plead for minimum sentence, probation, or statutory first-offender relief.'
    }
  ];

  const currentStage = TRIAL_STAGES[activeStageIndex];
  const trialProgress = Math.round(((activeStageIndex + 1) / TRIAL_STAGES.length) * 100);

  return (
    <div className="bg-white border-2 border-slate-200 rounded-3xl p-5 sm:p-7 shadow-sm space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-800 mb-1">
            <Gavel className="w-3.5 h-3.5 text-blue-700" />
            <span>COURTROOM TRIAL & VERDICT TIMELINE</span>
          </div>
          <h3 className="font-headline font-bold text-lg sm:text-xl text-slate-900 flex items-center gap-2">
            <span>Litigation Progress & Trial Trajectory</span>
            <span className="text-xs font-mono font-normal text-slate-500">
              ({selectedCategoryName})
            </span>
          </h3>
          <p className="text-xs text-slate-500">
            Interactive judicial trial milestones and evidentiary scrutiny under <span className="text-red-600 font-extrabold">Lega</span><span className="text-red-600 font-extrabold">Sol</span> Legal Intelligence.
          </p>
        </div>

        {/* Factors Examined pill */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Trial Readiness
            </span>
            <span className="text-sm font-extrabold font-mono text-blue-900">
              Stage {activeStageIndex + 1} of 6 ({trialProgress}%)
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center font-mono font-bold text-blue-800 text-sm shadow-inner">
            {trialProgress}%
          </div>
        </div>
      </div>

      {/* Trial Progress Bar */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping"></span>
            Litigation Phase: <strong className="text-slate-900">{currentStage.name}</strong>
          </span>
          <span className="font-mono text-slate-500 text-[11px]">
            {currentStage.sectionRef}
          </span>
        </div>

        {/* Glowing Progress Track */}
        <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200 shadow-inner">
          <div 
            className="h-full rounded-full bg-gradient-to-r from-blue-700 via-indigo-600 to-[#c49a6c] transition-all duration-500 ease-out shadow-sm"
            style={{ width: `${trialProgress}%` }}
          />
        </div>
      </div>

      {/* Dual Comparative Strength Meters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
        {/* Prosecution Case Weight */}
        <div className="bg-rose-50/60 border border-rose-200 rounded-2xl p-4 space-y-2 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-950 uppercase tracking-wide flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-600"></span>
              Prosecution Case Weight
            </span>
            <span className="text-sm font-bold font-mono text-rose-700">
              {convictionProb}%
            </span>
          </div>
          <div className="h-2 w-full bg-rose-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-rose-600 rounded-full transition-all duration-500"
              style={{ width: `${convictionProb}%` }}
            />
          </div>
          <p className="text-[11px] text-rose-800/80 leading-snug">
            Strength of incriminating testimonies, forensic discovery, and ocular proof.
          </p>
        </div>

        {/* Defense Viability */}
        <div className="bg-emerald-50/60 border border-emerald-200 rounded-2xl p-4 space-y-2 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-950 uppercase tracking-wide flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
              Defense Viability & Reasonable Doubt
            </span>
            <span className="text-sm font-bold font-mono text-emerald-700">
              {acquittalProb}%
            </span>
          </div>
          <div className="h-2 w-full bg-emerald-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-emerald-600 rounded-full transition-all duration-500"
              style={{ width: `${acquittalProb}%` }}
            />
          </div>
          <p className="text-[11px] text-emerald-800/80 leading-snug">
            Efficacy of mitigating evidence, self-defense claims, and delay in reporting.
          </p>
        </div>
      </div>

      {/* Interactive 6-Stage Courtroom Timeline Nodes */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 sm:gap-2.5 pt-1">
        {TRIAL_STAGES.map((stage, idx) => {
          const isSelected = activeStageIndex === idx;
          const isPast = activeStageIndex > idx;

          return (
            <button
              key={stage.id}
              onClick={() => setActiveStageIndex(idx)}
              className={`text-left p-2.5 sm:p-3 rounded-2xl border transition-all cursor-pointer relative group ${
                isSelected
                  ? 'bg-blue-50/90 border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : isPast
                  ? 'bg-emerald-50/50 border-emerald-200 hover:border-emerald-300'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-transform group-hover:scale-105 ${
                  isSelected
                    ? 'bg-blue-700 text-white shadow-xs'
                    : isPast
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-600 border border-slate-200'
                }`}>
                  {isPast ? <CheckCircle2 className="w-4 h-4" /> : stage.id}
                </span>

                <span className="text-[10px] font-mono text-slate-400 font-semibold">
                  Step {stage.id}
                </span>
              </div>

              <div className={`font-bold text-xs line-clamp-1 ${
                isSelected ? 'text-blue-950 font-extrabold' : 'text-slate-800'
              }`}>
                {stage.name}
              </div>

              <div className="text-[10px] font-mono text-slate-500 mt-0.5 truncate">
                {stage.sectionRef}
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Stage Detailed Court Guidance */}
      <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-blue-700 text-white shadow-xs">
              <Scale className="w-4 h-4" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-sm sm:text-base text-slate-900">
                  {currentStage.name}
                </h4>
                <span className="text-xs text-slate-500 font-medium">
                  ({currentStage.hindiName})
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-900 border border-blue-200 text-[10px] font-bold font-mono">
                  {currentStage.sectionRef}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                {currentStage.shortDesc}
              </p>
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-200/80 text-slate-800 text-xs font-medium">
            <BookOpen className="w-3.5 h-3.5 text-blue-700 shrink-0" />
            <span>Standard: <strong>{currentStage.standardOfProof}</strong></span>
          </div>
        </div>

        {/* 2-Column Court Strategy */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Prosecution Focus */}
          <div className="bg-white border border-rose-100 rounded-xl p-4 space-y-1.5 shadow-2xs">
            <div className="flex items-center gap-1.5 font-bold text-rose-900 uppercase tracking-wider text-[11px]">
              <Gavel className="w-4 h-4 text-rose-700" />
              <span>Prosecution Burden & Presentation</span>
            </div>
            <p className="text-slate-700 leading-relaxed font-normal">
              {currentStage.prosecutionBurden}
            </p>
          </div>

          {/* Defense Cross-Examination Strategy */}
          <div className="bg-white border border-emerald-100 rounded-xl p-4 space-y-1.5 shadow-2xs">
            <div className="flex items-center gap-1.5 font-bold text-emerald-900 uppercase tracking-wider text-[11px]">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Defense Strategy & Doubts to Raise</span>
            </div>
            <p className="text-slate-700 leading-relaxed font-normal">
              {currentStage.defenseStrategy}
            </p>
          </div>
        </div>

        {/* Judicial Scrutiny Banner */}
        <div className="p-3.5 rounded-xl bg-blue-50/80 border border-blue-100 flex items-start gap-2.5 text-xs text-blue-950">
          <Sparkles className="w-4 h-4 text-blue-700 mt-0.5 shrink-0" />
          <div className="leading-relaxed">
            <strong className="font-semibold text-blue-900">Judicial Focus: </strong>
            <span>{currentStage.courtFocus}</span>
          </div>
        </div>

        {/* Stage Navigation Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
          <button
            onClick={() => setActiveStageIndex(Math.max(0, activeStageIndex - 1))}
            disabled={activeStageIndex === 0}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-all cursor-pointer ${
              activeStageIndex > 0
                ? 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
            }`}
          >
            ← Previous Stage
          </button>

          <span className="text-[11px] text-slate-500 font-mono">
            Click any step to inspect evidentiary rules and courtroom procedures
          </span>

          <button
            onClick={() => setActiveStageIndex(Math.min(TRIAL_STAGES.length - 1, activeStageIndex + 1))}
            disabled={activeStageIndex === TRIAL_STAGES.length - 1}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-all cursor-pointer ${
              activeStageIndex < TRIAL_STAGES.length - 1
                ? 'bg-blue-700 hover:bg-blue-800 text-white border-blue-700 shadow-2xs'
                : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
            }`}
          >
            Next Stage →
          </button>
        </div>
      </div>
    </div>
  );
};
