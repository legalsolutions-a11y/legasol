import React, { useState } from 'react';
import { 
  Clock, ShieldAlert, CheckCircle2, ChevronRight, AlertTriangle, 
  Calendar, FileCheck, Scale, ArrowRight, BookOpen, UserCheck, ShieldCheck,
  Sparkles, Info
} from 'lucide-react';

export interface TimelineStage {
  id: number;
  name: string;
  bnssSection: string;
  shortDesc: string;
  timeLimit: string;
  status: 'completed' | 'current' | 'upcoming';
  complainantRights: string;
  accusedRights: string;
  statutoryChecklist: string[];
  keyAdvice: string;
}

interface CaseProgressTimelineProps {
  highestSeverity?: string;
  isBailable?: boolean;
  isCognizable?: boolean;
  weaponInvolved?: boolean;
  financialAspect?: boolean;
}

export const CaseProgressTimeline: React.FC<CaseProgressTimelineProps> = ({
  highestSeverity = 'Moderate / Bailable',
  isBailable = true,
  isCognizable = true,
  weaponInvolved = false,
  financialAspect = false
}) => {
  // Determine default stage based on severity
  const isHeinous = highestSeverity.includes('Fatal') || highestSeverity.includes('Heinous');
  const isSerious = highestSeverity.includes('Serious') || !isBailable || weaponInvolved;

  const defaultStage = isHeinous ? 3 : isSerious ? 2 : 1;
  const [selectedStageIndex, setSelectedStageIndex] = useState<number>(defaultStage);

  const STAGES: TimelineStage[] = [
    {
      id: 1,
      name: 'FIR Lodged & GD Entry',
      bnssSection: 'BNSS Section 173',
      shortDesc: 'Official First Information Report registration or General Diary entry.',
      timeLimit: 'Immediate for Cognizable offences; 3 days for e-FIR physical signature',
      status: selectedStageIndex > 0 ? 'completed' : 'current',
      complainantRights: 'Complainant is entitled to a free physical/digital certified copy of FIR immediately under BNSS 173(2).',
      accusedRights: 'Right to know specific grounds of arrest if apprehended immediately under BNSS Section 47.',
      statutoryChecklist: [
        'Free FIR copy provided to informant without delay',
        'Information recorded electronically verified within 3 days',
        'GD (General Diary) entry number assigned and logged'
      ],
      keyAdvice: 'Ensure informant details, time, place, and names of identifiable assailants are accurately transcribed without ambiguity.'
    },
    {
      id: 2,
      name: 'Preliminary Enquiry / Section 35 Notice',
      bnssSection: 'BNSS Section 173(3) & Sec 35',
      shortDesc: '14-day statutory inquiry for offences punishable with 3 to 7 years imprisonment.',
      timeLimit: 'Mandatory 14 days maximum with prior approval of DSP / SP',
      status: selectedStageIndex > 1 ? 'completed' : selectedStageIndex === 1 ? 'current' : 'upcoming',
      complainantRights: 'Right to receive status update if preliminary enquiry is initiated under DSP supervision.',
      accusedRights: 'Right to receive Section 35 Notice of Appearance instead of routine arrest for offences under 7 years.',
      statutoryChecklist: [
        'DSP prior approval obtained for preliminary inquiry (if applicable)',
        'Written notice of appearance served under BNSS Sec 35(3)',
        'Zero arrest conducted if accused complies with inquiry notice'
      ],
      keyAdvice: 'For non-heinous allegations, police must conduct preliminary enquiry within 14 days before registering regular FIR.'
    },
    {
      id: 3,
      name: 'Investigation & Forensic Seizure',
      bnssSection: 'BNSS Sec 175, 176 & BSA Sec 23',
      shortDesc: 'Forensic collection, search & seizure, and audio-video witness recordings.',
      timeLimit: 'Mandatory forensic team visit for offences punishable with 7+ years',
      status: selectedStageIndex > 2 ? 'completed' : selectedStageIndex === 2 ? 'current' : 'upcoming',
      complainantRights: 'Audio-video recording of sensitive victim statements mandatory under BNSS Section 176.',
      accusedRights: 'Search and seizure must follow strict video-recording protocols under BNSS Section 105.',
      statutoryChecklist: [
        'Forensic crime scene visit & evidence collection under BNSS 176(3)',
        'Electronic evidence seized with digital hash certificate under BSA 63',
        'Case Diary maintained daily with chronological entry log'
      ],
      keyAdvice: 'Under BNSS 2023, forensic team visit is statutorily mandatory for offences carrying 7 years imprisonment or more.'
    },
    {
      id: 4,
      name: 'Bail & Remand Determination',
      bnssSection: 'BNSS Sec 187, 480 & 482',
      shortDesc: 'Police custody evaluation (up to 15 days in initial 40/60 days) and judicial bail review.',
      timeLimit: 'Production before Magistrate within strictly 24 hours of arrest',
      status: selectedStageIndex > 3 ? 'completed' : selectedStageIndex === 3 ? 'current' : 'upcoming',
      complainantRights: 'Victim/Complainant right to be heard during bail hearings in serious or sexual offences.',
      accusedRights: 'Statutory default bail entitlement if investigation not finished within 60 or 90 days under BNSS 187(2).',
      statutoryChecklist: [
        'Production before nearest Magistrate within 24 hours (Article 22(2))',
        'Police custody limited to 15 days total within initial 40/60 days',
        'Medical examination performed immediately after arrest'
      ],
      keyAdvice: !isBailable 
        ? 'Non-bailable matter: Bail requires formal application before Sessions Court or High Court under BNSS Section 482.'
        : 'Bailable matter: Accused has statutory right to bail from police station or court upon furnishing reasonable surety.'
    },
    {
      id: 5,
      name: 'Police Report / Chargesheet',
      bnssSection: 'BNSS Section 193',
      shortDesc: 'Completion of investigation and submission of final report to Judicial Magistrate.',
      timeLimit: '60 days (offences < 10 yrs) or 90 days (offences 10+ yrs or death/life imprisonment)',
      status: selectedStageIndex > 4 ? 'completed' : selectedStageIndex === 4 ? 'current' : 'upcoming',
      complainantRights: 'Police must inform informant of chargesheet filing or closure report within 90 days under BNSS 193(3).',
      accusedRights: 'Right to receive complete certified copies of chargesheet and witness statements under BNSS 230.',
      statutoryChecklist: [
        'Chargesheet submitted within 60/90 days to avert default bail',
        'Informant formally notified of investigation outcome under BNSS 193(3)(ii)',
        'Digital copies of evidence served to accused'
      ],
      keyAdvice: 'Ensure police provide written notification of chargesheet status to the complainant within 90 days as mandated by BNSS 2023.'
    },
    {
      id: 6,
      name: 'Court Trial & Final Verdict',
      bnssSection: 'BNSS Sec 210, 251 & BNS 2023',
      shortDesc: 'Magistrate cognizance, charge framing, witness cross-examination, and judicial judgment.',
      timeLimit: 'Judgment within 30 days of argument completion (extendable to 45 days max)',
      status: selectedStageIndex === 5 ? 'current' : 'upcoming',
      complainantRights: 'Right to engage private advocate to assist Public Prosecutor under BNSS Section 24(8).',
      accusedRights: 'Presumption of innocence until proven guilty beyond reasonable doubt under Bharatiya Sakshya Adhiniyam.',
      statutoryChecklist: [
        'Formal charges framed and read out in vernacular language',
        'Examination of prosecution and defense witnesses under oath',
        'Judgment delivered within statutory 30-day timeline'
      ],
      keyAdvice: 'Judicial determination relies strictly on authenticated electronic evidence and corroborated witness depositions.'
    }
  ];

  const currentStage = STAGES[selectedStageIndex];
  const progressPercent = Math.round(((selectedStageIndex + 1) / STAGES.length) * 100);

  return (
    <div className="bg-white border-2 border-slate-200 rounded-3xl p-5 sm:p-7 shadow-sm space-y-6">
      {/* Tracker Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-800">
            <Clock className="w-3.5 h-3.5 text-blue-700" />
            <span>STATUTORY CASE TIMELINE & PROGRESS</span>
          </div>
          <h3 className="font-headline font-bold text-lg sm:text-xl text-slate-900 flex items-center gap-2">
            <span>Criminal Case Lifecycle Tracker</span>
            <span className="text-xs font-mono font-normal text-slate-500">
              (BNSS 2023 Statutory Procedure)
            </span>
          </h3>
          <p className="text-xs text-slate-500">
            Track statutory milestones, mandatory police deadlines, and procedural rights under <span className="text-red-600 font-extrabold">Lega</span><span className="text-red-600 font-extrabold">Sol</span> Legal Intelligence.
          </p>
        </div>

        {/* Current Status Badge */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Case Progression
            </span>
            <span className="text-sm font-extrabold font-mono text-blue-900">
              Stage {selectedStageIndex + 1} of 6 ({progressPercent}%)
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 border border-blue-200 flex items-center justify-center font-mono font-bold text-blue-800 text-sm shadow-inner">
            {progressPercent}%
          </div>
        </div>
      </div>

      {/* Visual Progress Bar with Glow */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-semibold text-slate-600">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Active Phase: <strong className="text-slate-900">{currentStage.name}</strong>
          </span>
          <span className="font-mono text-slate-500 text-[11px]">
            {currentStage.bnssSection}
          </span>
        </div>

        {/* The Progress Track */}
        <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200 shadow-inner">
          <div 
            className="h-full rounded-full bg-gradient-to-r from-blue-600 via-indigo-600 to-[#c49a6c] transition-all duration-500 ease-out shadow-sm"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Horizontal Multi-Stage Interactive Timeline Nodes */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 sm:gap-2.5 pt-1">
        {STAGES.map((stage, idx) => {
          const isSelected = selectedStageIndex === idx;
          const isPast = selectedStageIndex > idx;

          return (
            <button
              key={stage.id}
              onClick={() => setSelectedStageIndex(idx)}
              className={`text-left p-2.5 sm:p-3 rounded-2xl border transition-all cursor-pointer relative group ${
                isSelected
                  ? 'bg-blue-50/90 border-blue-500 shadow-sm ring-2 ring-blue-500/20'
                  : isPast
                  ? 'bg-emerald-50/50 border-emerald-200 hover:border-emerald-300'
                  : 'bg-white border-slate-200 hover:border-slate-300'
              }`}
            >
              {/* Top Node Indicator */}
              <div className="flex items-center justify-between mb-1.5">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-transform group-hover:scale-105 ${
                  isSelected
                    ? 'bg-blue-700 text-white shadow-xs'
                    : isPast
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 text-slate-600 border border-slate-200'
                }`}>
                  {isPast ? <CheckCircle2 className="w-4 h-4" /> : stage.id}
                </span>

                <span className="text-[10px] font-mono text-slate-400 font-semibold">
                  Step {stage.id}
                </span>
              </div>

              {/* Title */}
              <div className={`font-bold text-xs line-clamp-1 ${
                isSelected ? 'text-blue-950 font-extrabold' : 'text-slate-800'
              }`}>
                {stage.name}
              </div>

              {/* Section code */}
              <div className="text-[10px] font-mono text-slate-500 mt-0.5 truncate">
                {stage.bnssSection.replace('BNSS Section ', '§')}
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Stage Detail Drawer */}
      <div className="bg-slate-50 border border-slate-200/90 rounded-2xl p-5 sm:p-6 space-y-4">
        {/* Drawer Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-blue-700 text-white shadow-xs">
              <BookOpen className="w-4 h-4" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-sm sm:text-base text-slate-900">
                  {currentStage.name}
                </h4>
                <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-900 border border-blue-200 text-[10px] font-bold font-mono">
                  {currentStage.bnssSection}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                {currentStage.shortDesc}
              </p>
            </div>
          </div>

          {/* Statutory Clock / Deadline */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs font-semibold">
            <Clock className="w-3.5 h-3.5 text-amber-700 shrink-0" />
            <span>Time Limit: <strong>{currentStage.timeLimit}</strong></span>
          </div>
        </div>

        {/* 2-Column Rights & Safeguards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Complainant Rights */}
          <div className="bg-white border border-blue-100 rounded-xl p-4 space-y-1.5 shadow-2xs">
            <div className="flex items-center gap-1.5 font-bold text-blue-900 uppercase tracking-wider text-[11px]">
              <UserCheck className="w-4 h-4 text-blue-700" />
              <span>Complainant / Informant Rights</span>
            </div>
            <p className="text-slate-700 leading-relaxed font-normal">
              {currentStage.complainantRights}
            </p>
          </div>

          {/* Accused Safeguards */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-1.5 shadow-2xs">
            <div className="flex items-center gap-1.5 font-bold text-slate-800 uppercase tracking-wider text-[11px]">
              <ShieldCheck className="w-4 h-4 text-emerald-700" />
              <span>Accused Rights & Bail Safeguards</span>
            </div>
            <p className="text-slate-700 leading-relaxed font-normal">
              {currentStage.accusedRights}
            </p>
          </div>
        </div>

        {/* Statutory Action Checklist */}
        <div className="space-y-2 pt-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            Statutory Procedural Checklist (BNSS 2023 Compliance):
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {currentStage.statutoryChecklist.map((item, i) => (
              <div 
                key={i}
                className="flex items-start gap-2 bg-white border border-slate-200/80 rounded-xl p-2.5 text-[11px] text-slate-700"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                <span className="leading-snug">{item}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Actionable Advice Banner */}
        <div className="p-3.5 rounded-xl bg-indigo-50/70 border border-indigo-100 flex items-start gap-2.5 text-xs text-indigo-950">
          <Sparkles className="w-4 h-4 text-indigo-600 mt-0.5 shrink-0" />
          <div className="leading-relaxed">
            <strong className="font-semibold text-indigo-900">Judicial Advice for this Phase: </strong>
            <span>{currentStage.keyAdvice}</span>
          </div>
        </div>

        {/* Stage Navigation Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
          <button
            onClick={() => setSelectedStageIndex(Math.max(0, selectedStageIndex - 1))}
            disabled={selectedStageIndex === 0}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-all cursor-pointer ${
              selectedStageIndex > 0
                ? 'bg-white hover:bg-slate-100 text-slate-700 border-slate-300'
                : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
            }`}
          >
            ← Previous Stage
          </button>

          <span className="text-[11px] text-slate-500 font-mono">
            Click any numbered step to inspect statutory guidance
          </span>

          <button
            onClick={() => setSelectedStageIndex(Math.min(STAGES.length - 1, selectedStageIndex + 1))}
            disabled={selectedStageIndex === STAGES.length - 1}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-all cursor-pointer ${
              selectedStageIndex < STAGES.length - 1
                ? 'bg-blue-700 hover:bg-blue-800 text-white border-blue-700 shadow-2xs'
                : 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
            }`}
          >
            Next Stage →
          </button>
        </div>
      </div>
    </div>
  );
};
