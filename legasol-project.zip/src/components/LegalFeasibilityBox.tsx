import React, { useState } from 'react';
import { 
  Scale, CheckCircle2, AlertTriangle, TrendingUp, TrendingDown, 
  BookOpen, ShieldCheck, ShieldAlert, Sparkles, Copy, Check, Volume2, 
  HelpCircle, ArrowRight, Handshake, Gavel
} from 'lucide-react';
import { ExtractedFIRMetadata } from '../lib/analysis';
import { speakText } from '../lib/speech';

interface LegalFeasibilityBoxProps {
  analysis?: ExtractedFIRMetadata | null;
  complaintText?: string;
  generatedFirDoc?: string;
}

interface StrategicItem {
  number: number;
  title: string;
  statutoryRef: string;
  description: string;
  actionKey: string;
}

export const LegalFeasibilityBox: React.FC<LegalFeasibilityBoxProps> = ({
  analysis,
  complaintText = '',
  generatedFirDoc = ''
}) => {
  const [copied, setCopied] = useState(false);
  const [activeStrategyView, setActiveStrategyView] = useState<'both' | 'prosecution' | 'settlement'>('both');

  // Dynamic checks based on complaint text
  const text = complaintText || generatedFirDoc || '';
  const hasInjuries = /injury|bleeding|fracture|hospital|head injury|wound|beaten/i.test(text);
  const hasWeapon = /weapon|gun|knife|rod|pistol|iron rod|danda|lathi|blade/i.test(text);
  const hasDelay = /after \d+ days|delayed|months later|weeks later|last month/i.test(text);
  const hasFinancialLoss = /rupees|rs\.|cash|cheated|lakh|crore|money|bank|scam|snatched/i.test(text);

  let meritScore = 72;
  if (hasInjuries) meritScore += 6;
  if (hasWeapon) meritScore += 5;
  if (hasDelay) meritScore -= 15;
  if (hasFinancialLoss && !hasInjuries) meritScore -= 4;
  meritScore = Math.max(30, Math.min(88, meritScore));
  const riskScore = 100 - meritScore;

  // 1. Five Success Pathways for cases with strong merit
  const successPathways: StrategicItem[] = [
    {
      number: 1,
      title: 'Forensic & Electronic Evidence Seizure',
      statutoryRef: 'BNSS §176(3) & BSA §61 (Electronic Records)',
      description: 'Immediate statutory collection of crime scene videography, CCTV hard drives, and mobile call records with valid Section 61 BSA certificates eliminates digital tampering defense.',
      actionKey: 'Secure footage before 7-day server overwrite'
    },
    {
      number: 2,
      title: 'Contemporaneous Medical-Legal Examination (MLC)',
      statutoryRef: 'BSA 2023 §39/§45 (Expert & Medical Testimony)',
      description: 'Prompt government hospital examination maps weapon trauma, wound depth, and vital organ jeopardy, firmly corroborating physical assault charges against false fabrication claims.',
      actionKey: 'Undergo MLC within 24 hours of incident'
    },
    {
      number: 3,
      title: 'Independent Neutral Eyewitness Deposition',
      statutoryRef: 'BNSS §180(3) (Audio-Video Recorded Statements)',
      description: 'Corroborating statements from unbiased shopkeepers, commuters, or bystanders recorded via electronic video insulates the prosecution against allegations of personal malice.',
      actionKey: 'Furnish independent witness contacts on Day 1'
    },
    {
      number: 4,
      title: 'Sworn Judicial Statement Recording Before Magistrate',
      statutoryRef: 'BNSS §183(6) (Former CrPC §164 Statement)',
      description: 'Recording complainant or key witness testimony under oath before a Judicial Magistrate judicially binds statements, neutralizing subsequent witness intimidation or retraction.',
      actionKey: 'Request formal §183 statement recording in court'
    },
    {
      number: 5,
      title: 'Strict Statutory Ingredient Alignment',
      statutoryRef: 'The Bharatiya Nyaya Sanhita, 2023 (Act 45 of 2023)',
      description: 'Clear factual proof of deceptive intent at inception for cheating or overt act for bodily offenses ensures the FIR withstands discharge petitions and High Court quashing.',
      actionKey: 'Detail dates, amounts, and specific overt acts'
    }
  ];

  // 2. Five Risk Factors for cases prone to dismissal
  const riskFactors: StrategicItem[] = [
    {
      number: 1,
      title: 'Unexplained Delay in Lodging FIR',
      statutoryRef: 'Supreme Court Doctrine in Apren Joseph (1973)',
      description: 'Significant, unjustified time gap between occurrence and police reporting invites fatal judicial suspicion of afterthought, legal consultation, and embellished allegations.',
      actionKey: 'Must record valid cause of delay in FIR body'
    },
    {
      number: 2,
      title: 'Flawed Chain of Custody & Recovery Memos',
      statutoryRef: 'BSA §23 (Discovery of Fact / Former §27 IEA)',
      description: 'Weapons, digital devices, or recovered funds seized without independent local witnesses (panchas) or unsealed containers risk total evidentiary rejection during trial.',
      actionKey: 'Ensure independent witnesses sign recovery memo'
    },
    {
      number: 3,
      title: 'Omnibus Implication of Distant Relatives',
      statutoryRef: 'Kahkashan Kausar Doctrine (2020) 6 SCC 599',
      description: 'Sweeping, generalized accusations against extended family members without specific dates, locations, or overt acts lead to swift quashing and loss of complainant credibility.',
      actionKey: 'Name only individuals with direct physical roles'
    },
    {
      number: 4,
      title: 'Civil Disagreements Masked as Criminal Offenses',
      statutoryRef: 'Hridaya Ranjan Doctrine (2000) 4 SCC 168',
      description: 'Commercial invoice disputes or partnership friction lacking fraudulent intent at inception are dismissed as civil breaches and quashed under BNSS §528 as court abuse.',
      actionKey: 'Demonstrate forged records or fictitious entities'
    },
    {
      number: 5,
      title: 'Material Contradictions in Depositions',
      statutoryRef: 'BSA §148 & §155 (Impeaching Witness Credit)',
      description: 'Discrepancies regarding time, weapons, or identity between initial FIR, police statements, and trial dock testimony provide grounds for benefit-of-doubt acquittal.',
      actionKey: 'Align trial testimony strictly with signed FIR'
    }
  ];

  const handleCopy = () => {
    const text = [
      `LEGAL FEASIBILITY & DIRECTION ASSESSMENT`,
      `Platform: LegaSol AI Legal Intelligence · legasol.in`,
      `Judicial Viability Score: ${meritScore}% | Procedural Risk: ${riskScore}%`,
      `============================================================`,
      `PANEL 1: FIVE SUCCESS PATHWAYS (CASES WITH STRONG MERIT)`,
      ...successPathways.map(p => `[${p.number}] ${p.title}\n• Law: ${p.statutoryRef}\n• Description: ${p.description}\n• Action: ${p.actionKey}\n`),
      `============================================================`,
      `PANEL 2: FIVE RISK FACTORS (CASES PRONE TO DISMISSAL)`,
      ...riskFactors.map(r => `[${r.number}] ${r.title}\n• Law: ${r.statutoryRef}\n• Description: ${r.description}\n• Action: ${r.actionKey}\n`)
    ].join('\n');

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSpeakOverview = () => {
    speakText(`Legal Feasibility Analysis. Case merit viability score is ${meritScore} percent. Dismissal risk is ${riskScore} percent. Top success pathway: ${successPathways[0].title}. Top risk factor to mitigate: ${riskFactors[0].title}.`);
  };

  return (
    <section className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
      {/* 1. Header & Strategy Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-start gap-3">
          <span className="w-8 h-8 rounded-2xl bg-[#1e293b] text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-sm">
            <Scale className="w-4 h-4 text-amber-400" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-headline font-bold text-xl text-slate-900">
                Legal Feasibility & Strategic Direction
              </h3>
              <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200">
                LegalFeasibilityBox
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Objective dual-panel evaluation detailing legal pathways to victory versus fatal procedural hurdles to help you weigh your legal strategy
            </p>
          </div>
        </div>

        {/* Action Buttons: Listen & Copy */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleSpeakOverview}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 transition-all cursor-pointer"
            title="Listen to legal feasibility overview"
          >
            <Volume2 className="w-3.5 h-3.5 text-blue-700" />
            <span className="hidden sm:inline">Listen</span>
          </button>

          <button
            onClick={handleCopy}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
              copied 
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-300 shadow-2xs'
            }`}
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Analysis'}</span>
          </button>
        </div>
      </div>

      {/* 2. Visual Viability vs Risk Meter */}
      <div className="bg-gradient-to-r from-emerald-50/70 via-white to-rose-50/70 p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#c49a6c]" />
            <span className="font-crest font-bold text-xs uppercase tracking-wider text-slate-800">
              Judicial Feasibility & Risk Balance
            </span>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 font-bold text-emerald-800">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Merit Viability: {meritScore}%</span>
            </div>
            <span className="text-slate-300">•</span>
            <div className="flex items-center gap-1.5 font-bold text-rose-800">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
              <span>Dismissal Vulnerability: {riskScore}%</span>
            </div>
          </div>
        </div>

        {/* Dual Progress Bar */}
        <div className="w-full h-3 rounded-full bg-slate-200 overflow-hidden flex shadow-inner">
          <div 
            style={{ width: `${meritScore}%` }}
            className="bg-emerald-600 h-full transition-all duration-500 rounded-l-full"
            title={`Success Viability: ${meritScore}%`}
          />
          <div 
            style={{ width: `${riskScore}%` }}
            className="bg-rose-500 h-full transition-all duration-500 rounded-r-full"
            title={`Dismissal Risk: ${riskScore}%`}
          />
        </div>
      </div>

      {/* 3. Two Distinct Panels: Success Pathways vs Risk Factors */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Panel 1: Five 'Success Pathways' for cases with strong merit */}
        <div className="bg-emerald-50/30 border border-emerald-200/80 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-emerald-200/60">
            <div className="flex items-center gap-2 text-emerald-950 font-crest font-bold text-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Panel 1: Five Success Pathways (Strong Merit)</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200">
              5 Strategies
            </span>
          </div>

          <div className="space-y-3">
            {successPathways.map((item) => (
              <div 
                key={item.number}
                className="bg-white rounded-xl p-4 border border-emerald-100/80 shadow-2xs space-y-2 hover:border-emerald-300 transition-colors"
              >
                <div className="flex items-start gap-2.5">
                  <span className="w-6 h-6 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                    {item.number}
                  </span>
                  <div className="flex-1">
                    <h4 className="font-headline font-bold text-sm text-slate-900 leading-snug">
                      {item.title}
                    </h4>
                    <span className="text-[10.5px] font-mono text-emerald-700 font-semibold block mt-0.5">
                      {item.statutoryRef}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed pl-8">
                  {item.description}
                </p>

                <div className="pl-8 pt-1 flex items-center gap-1.5 text-[11px] text-emerald-900 font-medium">
                  <Sparkles className="w-3 h-3 text-emerald-600 shrink-0" />
                  <span><strong>Direction:</strong> {item.actionKey}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Panel 2: Five 'Risk Factors' for cases prone to dismissal */}
        <div className="bg-rose-50/30 border border-rose-200/80 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-rose-200/60">
            <div className="flex items-center gap-2 text-rose-950 font-crest font-bold text-sm">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>Panel 2: Five Risk Factors (Dismissal Vulnerabilities)</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-rose-100 text-rose-800 border border-rose-200">
              5 Hurdles
            </span>
          </div>

          <div className="space-y-3">
            {riskFactors.map((item) => (
              <div 
                key={item.number}
                className="bg-white rounded-xl p-4 border border-rose-100/80 shadow-2xs space-y-2 hover:border-rose-300 transition-colors"
              >
                <div className="flex items-start gap-2.5">
                  <span className="w-6 h-6 rounded-lg bg-rose-600 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                    {item.number}
                  </span>
                  <div className="flex-1">
                    <h4 className="font-headline font-bold text-sm text-slate-900 leading-snug">
                      {item.title}
                    </h4>
                    <span className="text-[10.5px] font-mono text-rose-700 font-semibold block mt-0.5">
                      {item.statutoryRef}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed pl-8">
                  {item.description}
                </p>

                <div className="pl-8 pt-1 flex items-center gap-1.5 text-[11px] text-rose-900 font-medium">
                  <ShieldAlert className="w-3 h-3 text-rose-600 shrink-0" />
                  <span><strong>Safeguard:</strong> {item.actionKey}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 4. Strategic Recommendation: Formal Prosecution vs Out-of-Court Settlement */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Handshake className="w-4 h-4 text-slate-700" />
            <h4 className="font-crest font-bold text-xs uppercase tracking-wide text-slate-800">
              Strategic Decision Guidance (मुकदमा बनाम समझौता)
            </h4>
          </div>

          <div className="flex items-center gap-1 text-[11px] font-semibold text-slate-600">
            <span>BNSS §359 Compounding & High Court §528 Mediation</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-blue-950">
              <Gavel className="w-3.5 h-3.5 text-blue-700" />
              <span>Pursue Formal Prosecution:</span>
            </div>
            <p className="text-slate-600 text-[11.5px] leading-relaxed">
              Recommended when physical violence, weapons, or repeated intimidation took place and legal deterrence or custodial sentencing is the primary requirement.
            </p>
          </div>

          <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-emerald-950">
              <Handshake className="w-3.5 h-3.5 text-emerald-700" />
              <span>Explore Out-of-Court Settlement:</span>
            </div>
            <p className="text-slate-600 text-[11.5px] leading-relaxed">
              Recommended for commercial transactions, financial debts, or simple neighborhood disputes where full financial recovery and immediate closure outweigh prolonged court appearances.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
