import React from 'react';
import { Scale, Sparkles, FileText, Landmark, Download, FolderOpen } from 'lucide-react';
import { LegasolCrest } from './LegasolCrest';

export type ActiveTab = 'home' | 'compare' | 'verdict' | 'bns-index';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenSample?: () => void;
  onOpenProjectFolder?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenSample, onOpenProjectFolder }) => {
  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left: Brand Identity matching screenshots */}
          <div 
            onClick={() => setActiveTab('home')}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-lg overflow-hidden bg-[#102a4e] flex items-center justify-center p-0.5 shadow-sm border border-slate-300">
              <LegasolCrest size={38} />
            </div>

            <div className="flex flex-col">
              <span className="text-base font-bold text-[#1e293b] tracking-tight leading-none group-hover:text-blue-900 transition-colors">
                legalsolutions@<span className="text-red-600 font-extrabold">lega</span><span className="text-red-600 font-extrabold">sol</span>.in
              </span>
              <span className="text-[10px] font-semibold tracking-wider text-slate-500 uppercase mt-1">
                <span className="text-red-600 font-bold">LEGA</span>L <span className="text-red-600 font-bold">SOL</span>UTIONS & VERDICT
              </span>
            </div>
          </div>

          {/* Right: Nav Tabs strictly ordered: Home -> FIR Compare -> Verdict Wizard -> BNS Sections */}
          <nav className="flex items-center gap-1 sm:gap-2 text-sm font-medium">
            {/* 1. Home */}
            <button
              onClick={() => setActiveTab('home')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'home'
                  ? 'text-[#1e293b] font-bold bg-slate-100/70'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Scale className="w-4 h-4 text-slate-700" />
              <span>Home</span>
            </button>

            {/* 2. FIR Compare (Coming right after Home as requested) */}
            <button
              onClick={() => setActiveTab('compare')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg transition-all cursor-pointer font-semibold ${
                activeTab === 'compare'
                  ? 'bg-[#1e293b] text-white shadow-sm'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>FIR Compare</span>
            </button>

            {/* 3. Verdict Wizard */}
            <button
              onClick={() => setActiveTab('verdict')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'verdict'
                  ? 'text-[#1e293b] font-bold bg-slate-100/70'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sparkles className="w-4 h-4 text-slate-700" />
              <span>Verdict Wizard</span>
            </button>

            {/* 4. BNS & Constitution */}
            <button
              onClick={() => setActiveTab('bns-index')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                activeTab === 'bns-index'
                  ? 'text-[#1e293b] font-bold bg-slate-100/70'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Landmark className="w-4 h-4 text-slate-700" />
              <span>BNS & Constitution</span>
            </button>

            {onOpenSample && (
              <button
                onClick={onOpenSample}
                className="hidden lg:flex items-center gap-1 text-xs text-blue-700 hover:text-blue-900 font-semibold px-2.5 py-1.5 rounded-lg border border-blue-200 hover:bg-blue-50/50 cursor-pointer ml-1"
              >
                Sample Cases
              </button>
            )}

            {/* View Project in Folder Format */}
            {onOpenProjectFolder && (
              <button
                onClick={onOpenProjectFolder}
                className="flex items-center gap-1.5 text-xs text-blue-900 bg-blue-50 hover:bg-blue-100 border border-blue-200 font-bold px-3 py-1.5 rounded-lg shadow-sm transition-all cursor-pointer ml-1"
                title="View full project hierarchy and source code in folder format"
              >
                <FolderOpen className="w-3.5 h-3.5 text-blue-600" />
                <span>Project Folders</span>
              </button>
            )}

            {/* Download Project ZIP Archive */}
            <a
              href="/legasol-project.zip"
              download="legasol-project.zip"
              className="flex items-center gap-1.5 text-xs text-white bg-slate-900 hover:bg-slate-800 font-bold px-3 py-1.5 rounded-lg shadow-sm transition-all cursor-pointer ml-1 group"
              title="Download full project source code as a ZIP archive"
            >
              <Download className="w-3.5 h-3.5 text-amber-400 group-hover:scale-110 transition-transform" />
              <span>Project ZIP</span>
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
};
