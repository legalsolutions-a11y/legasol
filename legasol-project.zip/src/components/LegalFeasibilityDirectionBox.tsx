import React, { useState } from 'react';
import { 
  Scale, ShieldAlert, CheckCircle2, AlertTriangle, ArrowRight, 
  HelpCircle, Sparkles, TrendingUp, TrendingDown, BookOpen, 
  Landmark, Info, Copy, Check, ChevronDown, ChevronUp, Handshake, Gavel
} from 'lucide-react';
import { ExtractedFIRMetadata } from '../lib/analysis';

interface LegalFeasibilityDirectionBoxProps {
  analysis: ExtractedFIRMetadata | null;
  complaintText: string;
  generatedFirDoc: string;
}

interface DualPoint {
  id: string;
  number: number;
  title: string;
  category: string;
  statutoryRule: string;
  landmarkCitation: string;
  comprehensiveNote: string;
  strategicImpact: string;
  mitigationAdvice: string;
  weightPercentage: number;
}

export const LegalFeasibilityDirectionBox: React.FC<LegalFeasibilityDirectionBoxProps> = ({
  analysis,
  complaintText,
  generatedFirDoc
}) => {
  const [activeTab, setActiveTab] = useState<'both' | 'success' | 'risks'>('both');
  const [expandedPointId, setExpandedPointId] = useState<string | null>('succ-1');
  const [selectedPathway, setSelectedPathway] = useState<'prosecution' | 'settlement'>('prosecution');
  const [copiedMatrix, setCopiedMatrix] = useState(false);

  // Derive dynamic probabilities based on FIR analysis
  const hasWeapon = /weapon|gun|knife|rod|pistol|iron rod|danda|lathi|blade/i.test(complaintText);
  const hasInjuries = /injury|bleeding|fracture|hospital|head injury|wound|beaten/i.test(complaintText);
  const hasFinancialLoss = /rupees|rs\.|cash|cheated|lakh|crore|money|bank|scam|snatched/i.test(complaintText);
  const hasDelay = /after \d+ days|delayed|months later|weeks later|last month/i.test(complaintText);
  const isCognizable = analysis ? analysis.isCognizableOverall : true;
  const isBailable = analysis ? analysis.isBailableOverall : false;
  
  // Calculate baseline success probability (60 - 85% range based on factual anchors)
  let successProbability = 68;
  if (hasInjuries) successProbability += 8;
  if (hasWeapon) successProbability += 6;
  if (hasDelay) successProbability -= 14;
  if (hasFinancialLoss && !hasInjuries) successProbability -= 5;
  successProbability = Math.max(25, Math.min(88, successProbability));

  const failureProbability = 100 - successProbability;

  // Check if compoundable under BNSS Section 359
  const isPotentiallyCompoundable = isBailable || hasFinancialLoss || (!hasWeapon && !/murder|rape|dacoity/i.test(complaintText));

  // 5 Strategic Pathways for Success
  const successPathways: DualPoint[] = [
    {
      id: 'succ-1',
      number: 1,
      title: 'Prompt Forensic & Electronic Evidence Seizure',
      category: 'Scientific Evidence',
      statutoryRule: 'BNSS Section 176(3) & BSA Section 61 (Former IEA Sec 65B)',
      landmarkCitation: 'Arjun Panditrao Khotkar v. Kailash Kushanrao (2020) 7 SCC 1',
      comprehensiveNote: 'The new criminal laws make forensic crime scene videography and expert collection mandatory for offenses punishable with 7+ years under BNSS Section 176(3). Immediate statutory seizure of CCTV hard drives, mobile call detail records (CDRs), and server logs—duly authenticated with an electronic certificate under Section 61 of the Bharatiya Sakshya Adhiniyam (BSA) 2023—prevents defense challenges regarding digital tampering or evidence fabrication.',
      strategicImpact: 'Transforms oral allegations into objective, indisputable electronic proof that withstands vigorous defense cross-examination.',
      mitigationAdvice: 'Formally submit written requests to the Investigating Officer within 48 hours to preserve surrounding CCTV feeds before automatic overwrite.',
      weightPercentage: 22
    },
    {
      id: 'succ-2',
      number: 2,
      title: 'Contemporaneous Medical Legal Certificate (MLC) & Injury Mapping',
      category: 'Medical Evidence',
      statutoryRule: 'Bharatiya Sakshya Adhiniyam, 2023 (BSA Section 39 & 45)',
      landmarkCitation: 'State of Maharashtra v. Balram Bama Patil (1983) 2 SCC 28',
      comprehensiveNote: 'A contemporaneous examination conducted at a Government Hospital immediately following the occurrence creates primary objective corroboration of physical trauma. Detailed medical documentation of weapon dimensions, depth of incised or blunt wounds, and whether vital organs were endangered substantiates charges under BNS Section 115(2), 117(2), or 109, totally demolishing defense arguments of fabricated or self-inflicted injuries.',
      strategicImpact: 'Converts simple physical hurt charges into severe non-bailable indictments, significantly shifting the burden of explanation onto the accused.',
      mitigationAdvice: 'Ensure the treating doctor accurately records the exact time of arrival, history of assault given by victim, and weapon description.',
      weightPercentage: 20
    },
    {
      id: 'succ-3',
      number: 3,
      title: 'Immediate Neutral Witness Recording & Audio-Visual Statements',
      category: 'Oral Testimony',
      statutoryRule: 'BNSS Section 180(3) [Audio-Video Recording of Statements]',
      landmarkCitation: 'Vadivelu Thevar v. State of Madras (AIR 1957 SC 614)',
      comprehensiveNote: 'Corroborating the complainant\'s narrative with independent, disinterested local shopkeepers, commuters, or neighbors insulates the prosecution against accusations of familial malice or partisan bias. Under the newly enacted BNSS Section 180(3), police are explicitly authorized to record witness statements through audio-video electronic means, creating an indelible record that deters witnesses from turning hostile.',
      strategicImpact: 'Establishes a credible, unbroken factual matrix where the testimony of independent witnesses provides strong ring-fence corroboration.',
      mitigationAdvice: 'Provide names, phone numbers, and physical business locations of independent bystanders in writing to the Investigating Officer on Day 1.',
      weightPercentage: 18
    },
    {
      id: 'succ-4',
      number: 4,
      title: 'Sworn Magistrate Statement Recording to Neutralize Witness Hostility',
      category: 'Judicial Safeguards',
      statutoryRule: 'BNSS Section 183(6) [Former CrPC 164 - Recording of Confessions & Statements]',
      landmarkCitation: 'State of Punjab v. Gurmit Singh (1996) 2 SCC 384',
      comprehensiveNote: 'In offenses involving sexual assault, serious bodily trauma, or vulnerable informants, having the victim\'s statement recorded under oath before a Judicial Magistrate under BNSS Section 183 binds the testimony judicially. Because it is recorded in a courtroom without police presence, it carries formidable evidentiary weight, prevents witness intimidation by the accused, and provides immediate grounds to cancel bail if threats occur.',
      strategicImpact: 'Eliminates the common criminal trial risk where victims retract statements due to coercion, financial settlement, or fear.',
      mitigationAdvice: 'File an application through the Public Prosecutor or private counsel under BNSS 183 to mandate statement recording before the Magistrate.',
      weightPercentage: 20
    },
    {
      id: 'succ-5',
      number: 5,
      title: 'Establishing Inviolable Mens Rea & Statutory Ingredients of Specific BNS Sections',
      category: 'Substantive Law',
      statutoryRule: 'The Bharatiya Nyaya Sanhita, 2023 (Act 45 of 2023)',
      landmarkCitation: 'Hridaya Ranjan Prasad Verma v. State of Bihar (2000) 4 SCC 168',
      comprehensiveNote: 'A successful prosecution hinges on demonstrating that every statutory ingredient of the charged BNS section is met. For economic fraud under BNS Section 318(4), fraudulent intention must be established from the very inception of the transaction; for extortion or robbery under BNS Section 308/309, putting the victim in fear of instant death or hurt must be proved. Precision in drafting and charges prevents the case from being quashed at the threshold stage.',
      strategicImpact: 'Ensures the FIR survives Section 250 BNSS discharge applications and High Court Section 528 quashing petitions.',
      mitigationAdvice: 'Clearly articulate exact dates of representation, specific deceptive assurances, and tangible transfers of property or funds in chronological order.',
      weightPercentage: 20
    }
  ];

  // 5 Risk Factors / Failure Reasons
  const riskFactors: DualPoint[] = [
    {
      id: 'risk-1',
      number: 1,
      title: 'Inordinate & Unexplained Delay in Lodging the FIR',
      category: 'Procedural Vulnerability',
      statutoryRule: 'BNSS Section 173 & Law of Evidence (BSA 2023)',
      landmarkCitation: 'Apren Joseph v. State of Kerala (1973) 3 SCC 114',
      comprehensiveNote: 'An unexplained time lag between the commission of the alleged offense and its reporting to law enforcement is one of the most fatal vulnerabilities in criminal prosecution. Trial courts view unexplained delay with deep suspicion, creating a legal inference that the complainant used the intervening time for deliberation, consultation, concoction, and afterthoughts to falsely implicate rivals or embellish injuries.',
      strategicImpact: 'Weakens prosecution credibility and frequently results in full acquittal on the ground of reasonable doubt.',
      mitigationAdvice: 'Always explain the exact justification for delay in the body of the FIR itself (e.g. medical emergency, fear of reprisal, mediation attempts).',
      weightPercentage: 24
    },
    {
      id: 'risk-2',
      number: 2,
      title: 'Flawed Chain of Custody & Recovery Memo Vulnerabilities',
      category: 'Evidentiary Defect',
      statutoryRule: 'BSA Section 23 [Discovery of Fact / Former Sec 27 IEA]',
      landmarkCitation: 'Sharad Birdhichand Sarda v. State of Maharashtra (1984) 4 SCC 116',
      comprehensiveNote: 'When weapons, mobile devices, stolen cash, or digital drives are seized without independent local witnesses (panchas), or where the recovery memo lacks signatures, time stamps, and intact seal impressions, the chain of custody is legally broken. Defense advocates routinely succeed in having recovered physical exhibits discarded as planted or fabricated by investigating officers.',
      strategicImpact: 'Collapses the circumstantial evidence chain ("Panchsheel"), depriving the prosecution of material physical corroboration.',
      mitigationAdvice: 'Verify that seizure memos are prepared on the spot with two independent non-police witnesses signing with full residential addresses.',
      weightPercentage: 20
    },
    {
      id: 'risk-3',
      number: 3,
      title: 'Omnibus Implication of Distant Relatives Without Specific Roles',
      category: 'Legal Overreach',
      statutoryRule: 'BNSS Section 250 (Discharge) & BNSS Section 528 (Quashing)',
      landmarkCitation: 'Kahkashan Kausar @ Sonam v. State of Bihar (2020) 6 SCC 599',
      comprehensiveNote: 'In disputes arising from marital friction (BNS Section 85) or property feuds, complainants frequently succumb to the impulse of naming elderly parents, married sisters-in-law, or distant relatives residing in separate cities. The Supreme Court has repeatedly held that general, sweeping, and omnibus allegations devoid of specific overt acts, dates, and times warrant immediate quashing or discharge.',
      strategicImpact: 'Destroys complainant credibility and exposes the complainant to counter-prosecution for malicious indictment under BNS Section 248.',
      mitigationAdvice: 'Name only individuals who directly committed overt criminal acts; avoid dragging family members who were mere bystanders or live elsewhere.',
      weightPercentage: 18
    },
    {
      id: 'risk-4',
      number: 4,
      title: 'Civil or Commercial Transactions Masquerading as Criminal Fraud',
      category: 'Jurisdictional Bar',
      statutoryRule: 'BNS Section 318(4) vs Specific Relief & Contract Act',
      landmarkCitation: 'Sushil Sethi v. State of Arunachal Pradesh (2020) 3 SCC 240',
      comprehensiveNote: 'Criminal courts strictly prohibit the misuse of police machinery and FIRs to recover commercial debts, unpaid invoices, or enforce breach of contractual promises. If the dispute fundamentally revolves around accounting balances, disputed delivery terms, or partnership accounts without deceptive intention at inception, High Courts routinely quash the FIR under BNSS Section 528 as an abuse of judicial process.',
      strategicImpact: 'Cases are dismissed before trial commences, wasting years of complainant effort without financial recovery.',
      mitigationAdvice: 'Establish clear evidence of counterfeit documents, forged checks, or fictitious entities created solely to defraud, not mere commercial default.',
      weightPercentage: 20
    },
    {
      id: 'risk-5',
      number: 5,
      title: 'Material Contradictions Between FIR Narration and Trial Dock Deposition',
      category: 'Trial Demolition',
      statutoryRule: 'BSA Section 148 & 155 [Impeaching Credit of Witness]',
      landmarkCitation: 'State of Rajasthan v. Kalki (1981) 2 SCC 752',
      comprehensiveNote: 'The defense attorney\'s primary objective during cross-examination is to confront the complainant with contradictions between the initial FIR, the Section 180 statement recorded by police, and the court deposition. Material discrepancies regarding the time of day, presence of weapons, identity of assailants, or sequence of blows provide the trial judge with immediate grounds to extend the "Benefit of Doubt" to the accused.',
      strategicImpact: 'Results in humiliating court acquittals and judicial strictures against the prosecution.',
      mitigationAdvice: 'Review the authenticated FIR copy thoroughly before giving evidence in court to ensure total consistency with prior statements.',
      weightPercentage: 18
    }
  ];

  const handleCopyAnalysis = () => {
    const text = [
      `SUCCESS PROBABILITY ANALYSIS & RISK ASSESSMENT`,
      `Platform: LegaSol AI Legal Intelligence · legasol.in`,
      `Prosecution Viability Score: ${successProbability}%`,
      `Procedural Risk / Dismissal Vulnerability: ${failureProbability}%`,
      `------------------------------------------------------------`,
      `5 STRATEGIC PATHWAYS FOR SUCCESS:`,
      ...successPathways.map(p => `[${p.number}] ${p.title} (${p.category})\n• Rule: ${p.statutoryRule}\n• Landmark: ${p.landmarkCitation}\n• Note: ${p.comprehensiveNote}\n• Strategy: ${p.mitigationAdvice}\n`),
      `------------------------------------------------------------`,
      `5 RISK FACTORS / FAILURE REASONS:`,
      ...riskFactors.map(r => `[${r.number}] ${r.title} (${r.category})\n• Rule: ${r.statutoryRule}\n• Landmark: ${r.landmarkCitation}\n• Note: ${r.comprehensiveNote}\n• Mitigation: ${r.mitigationAdvice}\n`),
      `------------------------------------------------------------`,
      `DECISION MATRIX RECOMMENDATION: ${selectedPathway === 'prosecution' ? 'Formal Criminal Prosecution' : 'Out-of-Court Compounding / Settlement'}`
    ].join('\n');

    navigator.clipboard.writeText(text);
    setCopiedMatrix(true);
    setTimeout(() => setCopiedMatrix(false), 2000);
  };

  return (
    <div className="bg-gradient-to-br from-white via-white to-slate-50 border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
      {/* 1. Header with Badge & Output Identifier */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="flex items-start gap-3">
          <span className="w-8 h-8 rounded-2xl bg-[#c49a6c] text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-sm">
            <Scale className="w-4 h-4" />
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-headline font-bold text-xl text-slate-900">
                Success Probability Analysis & Risk Assessment
              </h3>
              <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-md bg-amber-100 text-amber-900 border border-amber-200">
                Legal Feasibility & Direction Box
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">
              Dual 5-point probabilistic evaluation detailing legal pathways to victory versus fatal procedural hurdles and dismissal risks
            </p>
          </div>
        </div>

        {/* Copy Analysis Button */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleCopyAnalysis}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
              copiedMatrix 
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300' 
                : 'bg-white text-slate-700 hover:bg-slate-50 border-slate-300 shadow-2xs'
            }`}
          >
            {copiedMatrix ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedMatrix ? 'Analysis Copied!' : 'Copy Feasibility Audit'}</span>
          </button>
        </div>
      </div>

      {/* 2. Visual Probability Gauge & Dual Strength Meters */}
      <div className="bg-gradient-to-r from-emerald-50/70 via-white to-rose-50/70 p-5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#c49a6c]" />
            <span className="font-crest font-bold text-xs uppercase tracking-wider text-slate-800">
              Judicial Viability & Case Merit Outlook
            </span>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 font-bold text-emerald-800">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Merit Index: {successProbability}%</span>
            </div>
            <span className="text-slate-300">•</span>
            <div className="flex items-center gap-1.5 font-bold text-rose-800">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
              <span>Dismissal Risk: {failureProbability}%</span>
            </div>
          </div>
        </div>

        {/* Split Progress Bar */}
        <div className="space-y-1.5">
          <div className="w-full h-3.5 rounded-full bg-slate-200 overflow-hidden flex shadow-inner">
            <div 
              style={{ width: `${successProbability}%` }}
              className="bg-emerald-600 h-full transition-all duration-500 rounded-l-full relative group"
              title={`Strategic Success Probability: ${successProbability}%`}
            />
            <div 
              style={{ width: `${failureProbability}%` }}
              className="bg-rose-500 h-full transition-all duration-500 rounded-r-full relative group"
              title={`Procedural Failure Risk: ${failureProbability}%`}
            />
          </div>

          <div className="flex justify-between text-[11px] font-medium text-slate-500">
            <span className="flex items-center gap-1 text-emerald-700 font-bold">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>5 Strategic Pathways Favoring Prosecution</span>
            </span>
            <span className="flex items-center gap-1 text-rose-700 font-bold">
              <span>5 Fatal Vulnerabilities Favoring Defense</span>
              <TrendingDown className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </div>

      {/* 3. Section Filter Tabs: Both / 5 Success / 5 Risks */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-xl text-xs font-semibold">
          <button
            onClick={() => setActiveTab('both')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'both' ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Dual View (All 10 Points)
          </button>
          <button
            onClick={() => setActiveTab('success')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'success' ? 'bg-emerald-600 text-white shadow-2xs font-bold' : 'text-emerald-800 hover:bg-emerald-100/50'
            }`}
          >
            5 Pathways for Success
          </button>
          <button
            onClick={() => setActiveTab('risks')}
            className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'risks' ? 'bg-rose-600 text-white shadow-2xs font-bold' : 'text-rose-800 hover:bg-rose-100/50'
            }`}
          >
            5 Failure & Dismissal Risks
          </button>
        </div>

        <span className="text-xs text-slate-400 font-mono">
          Each point includes detailed explanatory notes
        </span>
      </div>

      {/* 4. The Dual 10-Point Grid / Accordion */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left Column: 5 Strategic Pathways for Success */}
        {(activeTab === 'both' || activeTab === 'success') && (
          <div className={`space-y-3 ${activeTab === 'success' ? 'lg:col-span-2' : ''}`}>
            <div className="flex items-center gap-2 pb-1 text-emerald-900 font-crest font-bold text-sm">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>5 Strategic Pathways for Success (जब केस मजबूत हो)</span>
            </div>

            {successPathways.map((point) => {
              const isExpanded = expandedPointId === point.id;
              return (
                <div 
                  key={point.id}
                  className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                    isExpanded 
                      ? 'border-emerald-300 bg-white shadow-xs ring-1 ring-emerald-200' 
                      : 'border-slate-200 bg-white hover:border-emerald-200'
                  }`}
                >
                  <div 
                    onClick={() => setExpandedPointId(isExpanded ? null : point.id)}
                    className="p-4 flex items-start justify-between gap-3 cursor-pointer select-none"
                  >
                    <div className="flex items-start gap-2.5 flex-1">
                      <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {point.number}
                      </span>
                      <div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <h4 className="font-headline font-bold text-sm text-slate-900">
                            {point.title}
                          </h4>
                          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                            +{point.weightPercentage}% Viability
                          </span>
                        </div>
                        <span className="text-[11px] font-mono text-emerald-700 font-semibold block mt-0.5">
                          {point.statutoryRule}
                        </span>
                      </div>
                    </div>

                    <span className="text-slate-400 p-1">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </div>

                  {isExpanded && (
                    <div className="px-4 pb-4 pt-1 border-t border-emerald-50 bg-emerald-50/20 space-y-2.5 text-xs text-slate-700 animate-in fade-in duration-150">
                      <div>
                        <strong className="text-emerald-950 font-bold block mb-1">
                          Comprehensive Explanatory Note:
                        </strong>
                        <p className="leading-relaxed text-slate-700 text-[11.5px]">
                          {point.comprehensiveNote}
                        </p>
                      </div>

                      <div className="bg-white p-2.5 rounded-xl border border-emerald-100 space-y-1">
                        <div className="flex items-center gap-1 font-bold text-emerald-900 text-[11px]">
                          <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Binding Precedent: {point.landmarkCitation}</span>
                        </div>
                        <p className="text-[11px] text-slate-600">
                          <strong>Strategic Impact:</strong> {point.strategicImpact}
                        </p>
                      </div>

                      <div className="bg-emerald-100/50 p-2.5 rounded-xl border border-emerald-200 text-[11px] text-emerald-950">
                        <strong>Actionable Direction:</strong> {point.mitigationAdvice}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Right Column: 5 Risk Factors / Failure Reasons */}
        {(activeTab === 'both' || activeTab === 'risks') && (
          <div className={`space-y-3 ${activeTab === 'risks' ? 'lg:col-span-2' : ''}`}>
            <div className="flex items-center gap-2 pb-1 text-rose-900 font-crest font-bold text-sm">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>5 Risk Factors & Dismissal Pitfalls (कमजोरी व खारिज होने के कारण)</span>
            </div>

            {riskFactors.map((point) => {
              const isExpanded = expandedPointId === point.id;
              return (
                <div 
                  key={point.id}
                  className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                    isExpanded 
                      ? 'border-rose-300 bg-white shadow-xs ring-1 ring-rose-200' 
                      : 'border-slate-200 bg-white hover:border-rose-200'
                  }`}
                >
                  <div 
                    onClick={() => setExpandedPointId(isExpanded ? null : point.id)}
                    className="p-4 flex items-start justify-between gap-3 cursor-pointer select-none"
                  >
                    <div className="flex items-start gap-2.5 flex-1">
                      <span className="w-6 h-6 rounded-lg bg-rose-100 text-rose-800 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        {point.number}
                      </span>
                      <div>
                        <div className="flex flex-wrap items-center gap-1.5">
                          <h4 className="font-headline font-bold text-sm text-slate-900">
                            {point.title}
                          </h4>
                          <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-rose-50 text-rose-800 border border-rose-200">
                            -{point.weightPercentage}% Risk
                          </span>
                        </div>
                        <span className="text-[11px] font-mono text-rose-700 font-semibold block mt-0.5">
                          {point.statutoryRule}
                        </span>
                      </div>
                    </div>

                    <span className="text-slate-400 p-1">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </span>
                  </div>

                  {isExpanded && (
                    <div className="px-4 pb-4 pt-1 border-t border-rose-50 bg-rose-50/20 space-y-2.5 text-xs text-slate-700 animate-in fade-in duration-150">
                      <div>
                        <strong className="text-rose-950 font-bold block mb-1">
                          Comprehensive Explanatory Note:
                        </strong>
                        <p className="leading-relaxed text-slate-700 text-[11.5px]">
                          {point.comprehensiveNote}
                        </p>
                      </div>

                      <div className="bg-white p-2.5 rounded-xl border border-rose-100 space-y-1">
                        <div className="flex items-center gap-1 font-bold text-rose-900 text-[11px]">
                          <BookOpen className="w-3.5 h-3.5 text-rose-600" />
                          <span>Defense Authority: {point.landmarkCitation}</span>
                        </div>
                        <p className="text-[11px] text-slate-600">
                          <strong>Vulnerability Risk:</strong> {point.strategicImpact}
                        </p>
                      </div>

                      <div className="bg-rose-100/50 p-2.5 rounded-xl border border-rose-200 text-[11px] text-rose-950">
                        <strong>Complainant Safeguard:</strong> {point.mitigationAdvice}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 5. Objective Decision Matrix: Formal Prosecution vs. Out-of-Court Settlement */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div>
            <h4 className="font-crest font-bold text-sm text-slate-900 uppercase tracking-wide">
              Strategic Decision Matrix: Court Prosecution vs. Out-of-Court Settlement
            </h4>
            <p className="text-xs text-slate-500 mt-0.5">
              Objective comparison to help you choose between formal criminal trial and an amicable settlement
            </p>
          </div>

          <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200 shrink-0">
            {isPotentiallyCompoundable ? 'Amicable Settlement Legally Viable' : 'Severe / Non-Compoundable Offenses'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Pathway A: Formal Criminal Prosecution */}
          <div 
            onClick={() => setSelectedPathway('prosecution')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-3 ${
              selectedPathway === 'prosecution'
                ? 'border-blue-700 bg-blue-50/40 shadow-sm ring-1 ring-blue-300'
                : 'border-slate-200 bg-white hover:border-slate-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Gavel className="w-4 h-4 text-blue-800" />
                <span className="font-headline font-bold text-sm text-blue-950">
                  Pathway A: Formal Criminal Prosecution
                </span>
              </div>
              <input 
                type="radio" 
                checked={selectedPathway === 'prosecution'} 
                onChange={() => setSelectedPathway('prosecution')}
                className="w-4 h-4 text-blue-700" 
              />
            </div>

            <ul className="text-xs space-y-2 text-slate-600">
              <li className="flex items-start gap-1.5">
                <span className="font-bold text-slate-800 shrink-0">• Time Horizon:</span>
                <span>12 to 36 months across Session/Magistrate courts.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="font-bold text-slate-800 shrink-0">• Standard of Proof:</span>
                <span>"Proof Beyond Reasonable Doubt" (Heavy burden on prosecution).</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="font-bold text-slate-800 shrink-0">• Personal Toll:</span>
                <span>Multiple cross-examination appearances, potential bail appeals.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="font-bold text-slate-800 shrink-0">• Legal Outcome:</span>
                <span className="text-blue-900 font-bold">Punishment, prison term, or fine against the accused.</span>
              </li>
            </ul>

            <div className="pt-2 text-[11px] text-blue-900 bg-blue-100/60 p-2.5 rounded-xl border border-blue-200 font-medium">
              <strong>Best Suited When:</strong> Physical violence, weapons, sexual assault, or habitual offenders are involved, and deterrence is the paramount priority.
            </div>
          </div>

          {/* Pathway B: Out-of-Court Settlement / Compromise */}
          <div 
            onClick={() => setSelectedPathway('settlement')}
            className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-3 ${
              selectedPathway === 'settlement'
                ? 'border-emerald-700 bg-emerald-50/40 shadow-sm ring-1 ring-emerald-300'
                : 'border-slate-200 bg-white hover:border-slate-300'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Handshake className="w-4 h-4 text-emerald-800" />
                <span className="font-headline font-bold text-sm text-emerald-950">
                  Pathway B: Out-of-Court Settlement / Compounding
                </span>
              </div>
              <input 
                type="radio" 
                checked={selectedPathway === 'settlement'} 
                onChange={() => setSelectedPathway('settlement')}
                className="w-4 h-4 text-emerald-700" 
              />
            </div>

            <ul className="text-xs space-y-2 text-slate-600">
              <li className="flex items-start gap-1.5">
                <span className="font-bold text-slate-800 shrink-0">• Time Horizon:</span>
                <span>1 to 3 months via Lok Adalat or High Court quashing.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="font-bold text-slate-800 shrink-0">• Legal Mechanism:</span>
                <span>BNSS Section 359 (Compounding) or Section 528 (Amicable Quash).</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="font-bold text-slate-800 shrink-0">• Recovery Rate:</span>
                <span>Immediate financial compensation, written apology, or property return.</span>
              </li>
              <li className="flex items-start gap-1.5">
                <span className="font-bold text-slate-800 shrink-0">• Legal Outcome:</span>
                <span className="text-emerald-900 font-bold">Absolute acquittal / complete closure without ongoing friction.</span>
              </li>
            </ul>

            <div className="pt-2 text-[11px] text-emerald-900 bg-emerald-100/60 p-2.5 rounded-xl border border-emerald-200 font-medium">
              <strong>Best Suited When:</strong> Financial disputes, neighbor brawls, simple hurt, or cheating where recovering money or restoring peace is more valuable than long court battles.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
