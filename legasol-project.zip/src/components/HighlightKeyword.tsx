import React, { useMemo } from 'react';

interface HighlightKeywordProps {
  text: string | null | undefined;
  queries: (string | null | undefined)[];
  className?: string;
  highlightClassName?: string;
}

// Extract clean keywords with length >= 2
export function extractKeywords(queries: (string | null | undefined)[]): string[] {
  const combined = queries
    .filter(Boolean)
    .join(' ')
    .trim();

  if (!combined) return [];

  // Split on whitespace and common punctuation, filter out single letters
  const tokens = combined
    .toLowerCase()
    .split(/[\s,+/;:|]+/)
    .map(t => t.replace(/^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$/g, ''))
    .filter(t => t.length >= 2);

  // Return unique keywords sorted by length descending so longer phrases match first
  return Array.from(new Set(tokens)).sort((a, b) => b.length - a.length);
}

// Count occurrences of keywords in text
export function countKeywordMatches(text: string | null | undefined, queries: (string | null | undefined)[]): number {
  if (!text) return 0;
  const keywords = extractKeywords(queries);
  if (keywords.length === 0) return 0;

  try {
    const escaped = keywords.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    const regex = new RegExp(`\\b(${escaped.join('|')})|(${escaped.join('|')})`, 'gi');
    const matches = text.match(regex);
    return matches ? matches.length : 0;
  } catch {
    return 0;
  }
}

export const HighlightKeyword: React.FC<HighlightKeywordProps> = ({
  text,
  queries,
  className = '',
  highlightClassName = 'bg-amber-200 text-amber-950 font-bold px-0.5 rounded shadow-2xs'
}) => {
  if (!text) return null;

  const keywords = useMemo(() => extractKeywords(queries), [queries]);

  if (keywords.length === 0) {
    return <span className={className}>{text}</span>;
  }

  try {
    const escaped = keywords.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    const regex = new RegExp(`(${escaped.join('|')})`, 'gi');
    const parts = text.split(regex);

    return (
      <span className={className}>
        {parts.map((part, index) => {
          if (!part) return null;
          const isMatch = keywords.some(k => k.toLowerCase() === part.toLowerCase());
          if (isMatch) {
            return (
              <mark
                key={index}
                className={highlightClassName}
                title={`Matching keyword: "${part}"`}
              >
                {part}
              </mark>
            );
          }
          return <React.Fragment key={index}>{part}</React.Fragment>;
        })}
      </span>
    );
  } catch {
    return <span className={className}>{text}</span>;
  }
};
